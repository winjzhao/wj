"""初始迁移 - 创建所有表

Revision ID: 001
Revises: None
Create Date: 2024-01-15
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa


revision: str = '001'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # lottery_draws 表
    op.create_table(
        'lottery_draws',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('period', sa.String(20), nullable=False),
        sa.Column('draw_date', sa.DateTime(), nullable=False),
        sa.Column('lottery_type', sa.String(10), server_default='ssq'),
        sa.Column('red1', sa.Integer(), nullable=True),
        sa.Column('red2', sa.Integer(), nullable=True),
        sa.Column('red3', sa.Integer(), nullable=True),
        sa.Column('red4', sa.Integer(), nullable=True),
        sa.Column('red5', sa.Integer(), nullable=True),
        sa.Column('red6', sa.Integer(), nullable=True),
        sa.Column('blue', sa.Integer(), nullable=True),
        sa.Column('main_ball1', sa.Integer(), nullable=True),
        sa.Column('main_ball2', sa.Integer(), nullable=True),
        sa.Column('main_ball3', sa.Integer(), nullable=True),
        sa.Column('main_ball4', sa.Integer(), nullable=True),
        sa.Column('main_ball5', sa.Integer(), nullable=True),
        sa.Column('main_ball6', sa.Integer(), nullable=True),
        sa.Column('main_ball7', sa.Integer(), nullable=True),
        sa.Column('main_ball8', sa.Integer(), nullable=True),
        sa.Column('main_ball9', sa.Integer(), nullable=True),
        sa.Column('main_ball10', sa.Integer(), nullable=True),
        sa.Column('main_ball11', sa.Integer(), nullable=True),
        sa.Column('main_ball12', sa.Integer(), nullable=True),
        sa.Column('main_ball13', sa.Integer(), nullable=True),
        sa.Column('main_ball14', sa.Integer(), nullable=True),
        sa.Column('main_ball15', sa.Integer(), nullable=True),
        sa.Column('main_ball16', sa.Integer(), nullable=True),
        sa.Column('main_ball17', sa.Integer(), nullable=True),
        sa.Column('main_ball18', sa.Integer(), nullable=True),
        sa.Column('main_ball19', sa.Integer(), nullable=True),
        sa.Column('main_ball20', sa.Integer(), nullable=True),
        sa.Column('bonus_ball1', sa.Integer(), nullable=True),
        sa.Column('bonus_ball2', sa.Integer(), nullable=True),
        sa.Column('main_balls_json', sa.JSON(), nullable=True),
        sa.Column('bonus_balls_json', sa.JSON(), nullable=True),
        sa.Column('red_sum', sa.Integer(), nullable=False),
        sa.Column('span', sa.Integer(), nullable=False),
        sa.Column('odd_count', sa.Integer(), nullable=False),
        sa.Column('zone1_count', sa.Integer(), nullable=False),
        sa.Column('zone2_count', sa.Integer(), nullable=False),
        sa.Column('zone3_count', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('period'),
    )
    op.create_index('ix_lottery_draws_period', 'lottery_draws', ['period'])

    # features 表
    op.create_table(
        'features',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('period', sa.String(20), nullable=False),
        sa.Column('lottery_type', sa.String(10), server_default='ssq'),
        sa.Column('feature_type', sa.String(50), nullable=False),
        sa.Column('feature_data', sa.JSON(), nullable=False),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_features_period', 'features', ['period'])

    # predictions 表
    op.create_table(
        'predictions',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('period', sa.String(20), nullable=False),
        sa.Column('lottery_type', sa.String(10), server_default='ssq'),
        sa.Column('model_name', sa.String(50), nullable=False),
        sa.Column('model_version', sa.String(30), nullable=False),
        sa.Column('main_balls', sa.JSON(), nullable=False),
        sa.Column('bonus_balls', sa.JSON(), nullable=True),
        sa.Column('score', sa.Float()),
        sa.Column('probability', sa.Float()),
        sa.Column('confidence', sa.Float()),
        sa.Column('weights', sa.JSON()),
        sa.Column('status', sa.String(20), server_default='pending'),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_predictions_period', 'predictions', ['period'])

    # model_checkpoints 表
    op.create_table(
        'model_checkpoints',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('model_name', sa.String(50), nullable=False),
        sa.Column('lottery_type', sa.String(10), server_default='ssq'),
        sa.Column('version', sa.String(30), nullable=False),
        sa.Column('file_path', sa.String(255), nullable=False),
        sa.Column('accuracy', sa.Float()),
        sa.Column('loss', sa.Float()),
        sa.Column('is_active', sa.Boolean(), server_default=sa.text('0')),
        sa.Column('training_config', sa.JSON()),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )

    # experiment_records 表
    op.create_table(
        'experiment_records',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('experiment_name', sa.String(100), nullable=False),
        sa.Column('lottery_type', sa.String(10), server_default='ssq'),
        sa.Column('model_name', sa.String(50), nullable=False),
        sa.Column('period', sa.String(20), nullable=False),
        sa.Column('prediction', sa.JSON()),
        sa.Column('actual', sa.JSON()),
        sa.Column('match_count', sa.Integer()),
        sa.Column('score', sa.Float()),
        sa.Column('remarks', sa.Text()),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )

    # system_logs 表
    op.create_table(
        'system_logs',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('level', sa.String(10), nullable=False),
        sa.Column('lottery_type', sa.String(10), server_default='ssq'),
        sa.Column('module', sa.String(50), nullable=False),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('data', sa.JSON()),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )

    # memory_records 表
    op.create_table(
        'memory_records',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('memory_type', sa.String(30), nullable=False),
        sa.Column('lottery_type', sa.String(10), server_default='ssq'),
        sa.Column('content', sa.JSON(), nullable=False),
        sa.Column('embedding', sa.JSON()),
        sa.Column('period', sa.String(20)),
        sa.Column('score', sa.Float()),
        sa.Column('tags', sa.JSON()),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )


def downgrade() -> None:
    op.drop_table('memory_records')
    op.drop_table('system_logs')
    op.drop_table('experiment_records')
    op.drop_table('model_checkpoints')
    op.drop_table('predictions')
    op.drop_table('features')
    op.drop_index('ix_lottery_draws_period', 'lottery_draws')
    op.drop_table('lottery_draws')
