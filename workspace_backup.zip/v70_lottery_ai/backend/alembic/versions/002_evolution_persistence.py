"""添加进化持久化表

Revision ID: 002
Revises: 001
Create Date: 2026-07-10

新增 evolution_state 表：保存融合权重、模型可信度、评分/命中追踪（每个 lottery_type 一条记录）
新增 evolution_history 表：保存每次进化周期的完整快照
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa


revision: str = '002'
down_revision: Union[str, None] = '001'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # evolution_state 表 — 进化核心成果持久化
    op.create_table(
        'evolution_state',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('lottery_type', sa.String(10), nullable=False),
        sa.Column('total_iterations', sa.Integer(), server_default='0'),
        sa.Column('last_evolution_at', sa.DateTime(), nullable=True),
        sa.Column('fusion_weights', sa.JSON(), nullable=False),
        sa.Column('model_credibility', sa.JSON(), nullable=False),
        sa.Column('model_scores', sa.JSON(), nullable=False),
        sa.Column('model_hits', sa.JSON(), nullable=False),
        sa.Column('feedback_iteration', sa.Integer(), server_default='0'),
        sa.Column('feedback_count', sa.Integer(), server_default='0'),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.func.now()),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('lottery_type'),
    )
    op.create_index('ix_evolution_state_lottery_type', 'evolution_state', ['lottery_type'])

    # evolution_history 表 — 进化周期历史快照
    op.create_table(
        'evolution_history',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('lottery_type', sa.String(10), nullable=False),
        sa.Column('iteration', sa.Integer(), nullable=False),
        sa.Column('status', sa.String(20), nullable=False),
        sa.Column('matched_count', sa.Integer(), server_default='0'),
        sa.Column('old_weights', sa.JSON(), nullable=True),
        sa.Column('new_weights', sa.JSON(), nullable=True),
        sa.Column('model_performance', sa.JSON(), nullable=True),
        sa.Column('credibility_updates', sa.JSON(), nullable=True),
        sa.Column('model_updates', sa.JSON(), nullable=True),
        sa.Column('duration_seconds', sa.Float(), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_evolution_history_lottery_type', 'evolution_history', ['lottery_type'])
    op.create_index('ix_evolution_history_created_at', 'evolution_history', ['created_at'])


def downgrade() -> None:
    op.drop_index('ix_evolution_history_created_at', 'evolution_history')
    op.drop_index('ix_evolution_history_lottery_type', 'evolution_history')
    op.drop_table('evolution_history')
    op.drop_index('ix_evolution_state_lottery_type', 'evolution_state')
    op.drop_table('evolution_state')
