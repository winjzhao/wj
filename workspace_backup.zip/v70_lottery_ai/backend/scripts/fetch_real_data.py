"""
从真实 API 抓取三种彩票历史数据，导出为 JSON 文件供 Flutter 前端离线使用。

数据源:
- 双色球(SSQ): 中彩网 cwl.gov.cn API
- 大乐透(DLT): 体彩网 sporttery.cn API
- 快乐8(K8):   中彩网 cwl.gov.cn API

导出格式: /workspace/v70_lottery_ai/flutter_app/assets/lottery_data.json
"""
import asyncio
import json
import re
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import httpx

# ============================================================
# API 配置
# ============================================================
CWL_API = "https://www.cwl.gov.cn/cwl_admin/front/cwlkj/search/kjxx/findDrawNotice"
CWL_NAME_MAP = {"ssq": "ssq", "k8": "kl8"}

SPORTTERY_DLT_API = "https://webapi.sporttery.cn/gateway/lottery/getHistoryPageListV1.qry"

OUTPUT_DIR = Path(__file__).resolve().parent.parent.parent / "flutter_app" / "assets"
OUTPUT_FILE = OUTPUT_DIR / "lottery_data.json"


async def fetch_from_cwl(name: str, page_no: int = 1, page_size: int = 50) -> dict | None:
    """从中彩网 API 获取一页数据"""
    params = {"name": name, "pageNo": page_no, "pageSize": page_size, "systemType": "PC"}
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(CWL_API, params=params)
            resp.raise_for_status()
            data = resp.json()
            if data.get("state") == 0:
                return data
            else:
                print(f"  [中彩网] {name} p{page_no}: {data.get('message')}")
                return None
    except Exception as e:
        print(f"  [中彩网] {name} p{page_no}: {e}")
        return None


def parse_cwl_draw(raw: dict, lottery_type: str) -> dict | None:
    """解析中彩网单条数据"""
    try:
        period = raw.get("code", "")
        if not period:
            return None
        m = re.match(r"(\d{4}-\d{2}-\d{2})", raw.get("date", ""))
        draw_date = m.group(1) if m else ""

        red_str = raw.get("red", "")
        main_balls = [int(x.strip()) for x in red_str.split(",") if x.strip()] if red_str else []
        blue_str = raw.get("blue", "")
        bonus_balls = [int(x.strip()) for x in blue_str.split(",") if x.strip()] if blue_str else []

        return {
            "period": period,
            "draw_date": draw_date,
            "lottery_type": lottery_type,
            "main_balls": main_balls,
            "bonus_balls": bonus_balls,
            "sales": raw.get("sales", ""),
            "pool_money": raw.get("poolmoney", ""),
        }
    except Exception as e:
        print(f"  parse err (period={raw.get('code', '?')}): {e}")
        return None


async def fetch_dlt_from_sporttery(page_no: int = 1, page_size: int = 50) -> list[dict]:
    """从体彩网 API 获取大乐透数据"""
    params = {"gameNo": 85, "provinceId": 0, "pageSize": page_size, "isVerify": 1, "pageNo": page_no}
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": "https://www.lottery.gov.cn/",
    }
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(SPORTTERY_DLT_API, params=params, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            value = data.get("value", {})
            items = value.get("list", [])
            results = []
            for item in items:
                period = item.get("lotteryDrawNum", "")
                draw_date = item.get("lotteryDrawTime", "")
                result_str = item.get("lotteryDrawResult", "")
                nums = [int(x) for x in result_str.split() if x.strip()]
                main_balls = sorted(nums[:5]) if len(nums) >= 5 else nums
                bonus_balls = sorted(nums[5:7]) if len(nums) >= 7 else []

                results.append({
                    "period": period,
                    "draw_date": draw_date,
                    "lottery_type": "dlt",
                    "main_balls": main_balls,
                    "bonus_balls": bonus_balls,
                    "sales": item.get("totalSaleAmount", ""),
                    "pool_money": item.get("poolBalanceAfterdraw", ""),
                })
            return results
    except Exception as e:
        print(f"  [体彩网] DLT p{page_no}: {e}")
        return []


async def fetch_ssq_k8(lottery_type: str, max_pages: int = 6) -> list[dict]:
    """抓取 SSQ 或 K8 数据"""
    api_name = CWL_NAME_MAP.get(lottery_type)
    if not api_name:
        return []
    all_draws = []
    for page in range(1, max_pages + 1):
        print(f"  第 {page}/{max_pages} 页...")
        data = await fetch_from_cwl(api_name, page_no=page, page_size=50)
        if not data:
            break
        for item in data.get("result", []):
            parsed = parse_cwl_draw(item, lottery_type)
            if parsed:
                all_draws.append(parsed)
        print(f"  已 {len(all_draws)} 条")
        await asyncio.sleep(0.6)
    all_draws.sort(key=lambda x: x["period"], reverse=True)
    return all_draws


async def fetch_dlt(max_pages: int = 6) -> list[dict]:
    """抓取大乐透数据"""
    all_draws = []
    for page in range(1, max_pages + 1):
        print(f"  第 {page}/{max_pages} 页...")
        draws = await fetch_dlt_from_sporttery(page_no=page, page_size=50)
        if not draws:
            break
        all_draws.extend(draws)
        print(f"  已 {len(all_draws)} 条")
        await asyncio.sleep(0.6)
    all_draws.sort(key=lambda x: x["period"], reverse=True)
    return all_draws


async def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    result = {
        "generated_at": "",
        "data_sources": {
            "ssq": "中彩网 cwl.gov.cn",
            "dlt": "体彩网 sporttery.cn",
            "k8": "中彩网 cwl.gov.cn",
        },
        "ssq": [],
        "dlt": [],
        "k8": [],
    }

    for label, fetcher, lt in [
        ("SSQ", fetch_ssq_k8, "ssq"),
        ("DLT", fetch_dlt, "dlt"),
        ("K8", fetch_ssq_k8, "k8"),
    ]:
        print(f"\n{'='*50}")
        print(f"抓取 {label} 数据...")
        print(f"{'='*50}")
        if lt == "dlt":
            draws = await fetcher(max_pages=6)
        else:
            draws = await fetcher(lt, max_pages=6)
        result[lt] = draws
        print(f"  {lt}: 共 {len(draws)} 条")

    result["generated_at"] = datetime.now().isoformat()

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    total = sum(len(result[k]) for k in ["ssq", "dlt", "k8"])
    print(f"\n{'='*50}")
    print(f"导出完成: {OUTPUT_FILE}")
    for k in ["ssq", "dlt", "k8"]:
        print(f"  {k.upper()}: {len(result[k])} 条")
    print(f"  总计: {total} 条")
    print(f"{'='*50}")


if __name__ == "__main__":
    asyncio.run(main())
