import asyncio, httpx, json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

async def fetch_dlt():
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://www.lottery.gov.cn/',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9',
    }
    url = 'https://webapi.sporttery.cn/gateway/lottery/getHistoryPageListV1.qry'
    all_draws = []
    for page in range(1, 7):
        async with httpx.AsyncClient(timeout=30, follow_redirects=True) as c:
            r = await c.get(url, params={
                'gameNo': 85, 'provinceId': 0, 'pageSize': 50,
                'isVerify': 1, 'pageNo': page,
            }, headers=headers)
            print(f'DLT Page {page}: status={r.status_code}')
            if r.status_code != 200:
                print(f'  body: {r.text[:200]}')
                break
            data = r.json()
            items = data.get('value', {}).get('list', [])
            print(f'  items: {len(items)}')
            for item in items:
                nums = [int(x) for x in item.get('lotteryDrawResult', '').split() if x.strip()]
                all_draws.append({
                    'period': item.get('lotteryDrawNum', ''),
                    'draw_date': item.get('lotteryDrawTime', ''),
                    'lottery_type': 'dlt',
                    'main_balls': sorted(nums[:5]) if len(nums) >= 5 else [],
                    'bonus_balls': sorted(nums[5:7]) if len(nums) >= 7 else [],
                    'sales': item.get('totalSaleAmount', ''),
                    'pool_money': item.get('poolBalanceAfterdraw', ''),
                })
        await asyncio.sleep(1.5)
    all_draws.sort(key=lambda x: x['period'], reverse=True)
    print(f'Total DLT: {len(all_draws)}')
    return all_draws

async def main():
    dlt = await fetch_dlt()
    out_file = Path(__file__).resolve().parent.parent.parent / 'flutter_app' / 'assets' / 'lottery_data.json'
    with open(out_file) as f:
        data = json.load(f)
    data['dlt'] = dlt
    data['data_sources']['dlt'] = '体彩网 sporttery.cn'
    with open(out_file, 'w') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f'Updated {out_file} with {len(dlt)} DLT records')

asyncio.run(main())
