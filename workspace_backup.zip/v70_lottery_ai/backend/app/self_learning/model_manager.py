"""
V70 彩票AI工作台 - 模型状态管理器 (ModelManager)
负责模型 A/B 对比、自动降级检测、自动重训练触发、模型淘汰

核心能力：
1. 模型状态管理（active / degraded / retired / retraining）
2. 自动降级检测 — 基于 trend、score、stability 多维度判断
3. A/B 对比 — pairwise 模型性能对比
4. 自动重训练触发 — 降级后自动安排重训练
5. 模型淘汰 — 长期低效模型自动退役
"""

import asyncio
from enum import Enum
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from loguru import logger
import numpy as np


class ModelState(str, Enum):
    """模型运行状态"""
    ACTIVE = "active"          # 正常参与预测
    DEGRADED = "degraded"      # 性能下降，降低参与权重
    RETRAINING = "retraining"  # 正在重训练
    RETIRED = "retired"        # 已退役，不参与预测
    COLD_START = "cold_start"  # 冷启动，样本不足


class ModelStatus:
    """单个模型的运行状态追踪"""

    def __init__(self, name: str):
        self.name = name
        self.state: ModelState = ModelState.COLD_START
        self.state_since: datetime = datetime.now()

        # 降级检测追踪
        self.consecutive_poor_rounds: int = 0       # 连续表现差轮次
        self.consecutive_declining_rounds: int = 0   # 连续下降轮次
        self.last_score: float = 0.0
        self.score_history: List[float] = []          # 最近 30 轮分数
        self.degradation_count: int = 0               # 历史降级次数
        self.retraining_count: int = 0                # 历史重训练次数

        # 对比追踪
        self.comparison_results: List[Dict] = []      # A/B 对比历史

    def record_score(self, score: float):
        """记录本轮分数"""
        self.score_history.append(score)
        if len(self.score_history) > 30:
            self.score_history = self.score_history[-30:]
        self.last_score = score

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "state": self.state.value,
            "state_since": self.state_since.isoformat(),
            "consecutive_poor_rounds": self.consecutive_poor_rounds,
            "consecutive_declining_rounds": self.consecutive_declining_rounds,
            "degradation_count": self.degradation_count,
            "retraining_count": self.retraining_count,
            "recent_scores": self.score_history[-10:] if self.score_history else [],
        }


class ModelManager:
    """
    模型状态管理器

    降级规则：
    1. 连续 5 轮 score < 0.08 → DEGRADED
    2. 连续 8 轮 trend = declining → DEGRADED
    3. 连续 15 轮 score < 0.10 → RETIRED（除非重训练后恢复）
    4. credibility_score < 0.15 持续 10 轮 → RETIRED

    恢复规则：
    1. DEGRADED 模型经过重训练且新 score >= 0.12 → ACTIVE
    2. 连续 3 轮 score >= 0.15 → ACTIVE
    """

    # 降级阈值
    POOR_SCORE_THRESHOLD = 0.08       # 低于此分数视为"差"
    VERY_POOR_SCORE_THRESHOLD = 0.05  # 极差分数
    MIN_VIABLE_SCORE = 0.10           # 最低可接受分数

    # 连续轮次阈值
    POOR_ROUNDS_FOR_DEGRADE = 5       # 连续差轮次 → 降级
    DECLINING_ROUNDS_FOR_DEGRADE = 8  # 连续下降 → 降级
    POOR_ROUNDS_FOR_RETIRE = 15       # 长期差 → 退役
    LOW_CRED_ROUNDS_FOR_RETIRE = 10   # 低可信度 → 退役

    # 恢复阈值
    RECOVER_ROUNDS = 3                # 连续好轮次 → 恢复
    RECOVER_SCORE = 0.12              # 恢复所需最低分数

    def __init__(self):
        self.models: Dict[str, ModelStatus] = {}
        self._init_default_models()
        self.ab_history: List[Dict] = []  # A/B 对比历史

    def _init_default_models(self):
        """初始化默认模型"""
        default_names = ["XGBoost", "LSTM", "Transformer", "PPO", "Statistic", "Behavior"]
        for name in default_names:
            self.models[name] = ModelStatus(name)

    def get_or_create(self, name: str) -> ModelStatus:
        """获取或创建模型状态"""
        if name not in self.models:
            self.models[name] = ModelStatus(name)
        return self.models[name]

    # ============================================================
    # 降级检测
    # ============================================================

    def detect_degradation(
        self,
        model_name: str,
        current_score: float,
        trend: str,
        credibility: float,
        orchestrator=None,
    ) -> Dict[str, Any]:
        """
        检测模型是否需要降级/退役

        Args:
            model_name: 模型名称
            current_score: 当前轮评分
            trend: 趋势 ("improving"/"declining"/"stable")
            credibility: 当前可信度

        Returns:
            检测结果，包含 action 和 reason
        """
        status = self.get_or_create(model_name)
        status.record_score(current_score)

        result = {"model": model_name, "action": "none", "previous_state": status.state.value}

        # 1. 检查是否需要退役（长期低效）
        if current_score < self.POOR_SCORE_THRESHOLD:
            status.consecutive_poor_rounds += 1
        else:
            status.consecutive_poor_rounds = max(0, status.consecutive_poor_rounds - 1)

        if status.consecutive_poor_rounds >= self.POOR_ROUNDS_FOR_RETIRE:
            self._transition(model_name, ModelState.RETIRED, "连续表现差", orchestrator)
            result["action"] = "retired"
            result["reason"] = f"连续 {status.consecutive_poor_rounds} 轮 score < {self.POOR_SCORE_THRESHOLD}"
            result["new_state"] = ModelState.RETIRED.value
            return result

        # 2. 检查是否需要降级
        if status.state == ModelState.ACTIVE or status.state == ModelState.COLD_START:
            should_degrade = False
            reason = ""

            if status.consecutive_poor_rounds >= self.POOR_ROUNDS_FOR_DEGRADE:
                should_degrade = True
                reason = f"连续 {status.consecutive_poor_rounds} 轮 score < {self.POOR_SCORE_THRESHOLD}"

            if trend == "declining":
                status.consecutive_declining_rounds += 1
                if status.consecutive_declining_rounds >= self.DECLINING_ROUNDS_FOR_DEGRADE:
                    should_degrade = True
                    reason = f"连续 {status.consecutive_declining_rounds} 轮趋势下降"
            else:
                status.consecutive_declining_rounds = 0

            if should_degrade:
                self._transition(model_name, ModelState.DEGRADED, reason, orchestrator)
                result["action"] = "degraded"
                result["reason"] = reason
                result["new_state"] = ModelState.DEGRADED.value
                return result

        # 3. 检查是否需要恢复
        if status.state == ModelState.DEGRADED:
            if current_score >= self.RECOVER_SCORE:
                # 检查最近 RECOVER_ROUNDS 轮是否都达标
                recent = status.score_history[-self.RECOVER_ROUNDS:]
                if len(recent) >= self.RECOVER_ROUNDS and all(
                    s >= self.RECOVER_SCORE for s in recent
                ):
                    self._transition(model_name, ModelState.ACTIVE, "性能恢复", orchestrator)
                    status.consecutive_poor_rounds = 0
                    result["action"] = "recovered"
                    result["reason"] = f"连续 {self.RECOVER_ROUNDS} 轮 score >= {self.RECOVER_SCORE}"
                    result["new_state"] = ModelState.ACTIVE.value

        # 4. 冷启动 → 激活（收集足够样本后）
        if status.state == ModelState.COLD_START:
            if len(status.score_history) >= 10:
                avg = np.mean(status.score_history[-10:])
                if avg >= self.MIN_VIABLE_SCORE:
                    self._transition(model_name, ModelState.ACTIVE, "样本充足，自动激活", orchestrator)
                    result["action"] = "activated"
                    result["new_state"] = ModelState.ACTIVE.value

        result["new_state"] = status.state.value
        return result

    def _transition(
        self, model_name: str, new_state: ModelState, reason: str,
        orchestrator=None,
    ):
        """执行模型状态转换"""
        status = self.get_or_create(model_name)
        old_state = status.state
        status.state = new_state
        status.state_since = datetime.now()

        if new_state == ModelState.DEGRADED:
            status.degradation_count += 1

        logger.warning(
            f"[模型管理] {model_name}: {old_state.value} → {new_state.value} | 原因: {reason}"
        )

        # 如果提供了 orchestrator，更新其中的模型状态
        if orchestrator and model_name in orchestrator.models:
            orchestrator.models[model_name]._model_state = new_state.value

    # ============================================================
    # A/B 对比
    # ============================================================

    def compare_models(
        self,
        model_a: str,
        model_b: str,
        window: int = 20,
    ) -> Dict[str, Any]:
        """
        对两个模型进行 A/B 对比

        对比维度：平均分数、命中率稳定性、趋势、可信度
        """
        status_a = self.get_or_create(model_a)
        status_b = self.get_or_create(model_b)

        scores_a = status_a.score_history[-window:]
        scores_b = status_b.score_history[-window:]

        if len(scores_a) < 5 or len(scores_b) < 5:
            return {
                "model_a": model_a, "model_b": model_b,
                "winner": "insufficient_data",
                "reason": "样本不足",
            }

        avg_a = np.mean(scores_a)
        avg_b = np.mean(scores_b)
        std_a = np.std(scores_a) if len(scores_a) > 1 else 0.1
        std_b = np.std(scores_b) if len(scores_b) > 1 else 0.1

        # 计算趋势
        half = max(2, len(scores_a) // 2)
        trend_a = np.mean(scores_a[-half:]) - np.mean(scores_a[:half])
        trend_b = np.mean(scores_b[-half:]) - np.mean(scores_b[:half])

        # 综合评分 = 平均分 - 稳定性惩罚 + 趋势奖励
        composite_a = avg_a - std_a * 0.3 + trend_a * 2
        composite_b = avg_b - std_b * 0.3 + trend_b * 2

        result = {
            "model_a": model_a,
            "model_b": model_b,
            "a_score": round(avg_a, 4),
            "b_score": round(avg_b, 4),
            "a_stability": round(1.0 / (1.0 + std_a), 4),
            "b_stability": round(1.0 / (1.0 + std_b), 4),
            "a_trend": round(trend_a, 4),
            "b_trend": round(trend_b, 4),
            "a_composite": round(composite_a, 4),
            "b_composite": round(composite_b, 4),
            "sample_size": len(scores_a),
        }

        diff = abs(composite_a - composite_b)
        if diff < 0.01:
            result["winner"] = "tie"
            result["confidence"] = "low"
        elif composite_a > composite_b:
            result["winner"] = model_a
            result["margin"] = round(diff, 4)
            result["confidence"] = "high" if diff > 0.03 else "medium"
        else:
            result["winner"] = model_b
            result["margin"] = round(diff, 4)
            result["confidence"] = "high" if diff > 0.03 else "medium"

        self.ab_history.append(result)
        return result

    def compare_all_models(self, window: int = 20) -> List[Dict]:
        """对所有模型进行全量 A/B 对比"""
        model_names = list(self.models.keys())
        results = []

        for i in range(len(model_names)):
            for j in range(i + 1, len(model_names)):
                result = self.compare_models(model_names[i], model_names[j], window)
                if result.get("winner") != "insufficient_data":
                    results.append(result)

        # 按 margin 排序
        results.sort(key=lambda x: x.get("margin", 0), reverse=True)
        return results

    # ============================================================
    # 自动重训练
    # ============================================================

    async def auto_retrain_degraded_models(
        self,
        orchestrator=None,
        db=None,
    ) -> List[Dict]:
        """
        自动检测并重训练降级模型

        返回重训练结果列表
        """
        results = []
        for name, status in self.models.items():
            if status.state != ModelState.DEGRADED:
                continue

            # 如果已经在重训练中，跳过
            if status.state == ModelState.RETRAINING:
                continue

            logger.info(f"[模型管理] 自动触发重训练: {name}")

            try:
                status.state = ModelState.RETRAINING
                status.retraining_count += 1

                # 调用训练管道
                if orchestrator:
                    from app.training.trainer import ModelTrainer
                    trainer = ModelTrainer()
                    train_result = await trainer.train_model(name, db=db)

                    if train_result and train_result.get("success"):
                        # 重训练成功，重置降级计数
                        status.consecutive_poor_rounds = 0
                        status.consecutive_declining_rounds = 0
                        status.state = ModelState.ACTIVE
                        status.state_since = datetime.now()

                        logger.info(f"[模型管理] {name} 重训练成功，已恢复为 ACTIVE")
                        results.append({
                            "model": name,
                            "action": "retrained_and_recovered",
                            "success": True,
                        })
                    else:
                        # 重训练失败，保持降级状态
                        status.state = ModelState.DEGRADED
                        logger.warning(f"[模型管理] {name} 重训练失败")
                        results.append({
                            "model": name,
                            "action": "retrain_failed",
                            "success": False,
                        })
                else:
                    # 无 orchestrator，标记重训练请求
                    results.append({
                        "model": name,
                        "action": "retrain_requested",
                        "success": True,
                    })

            except Exception as e:
                logger.error(f"[模型管理] {name} 重训练异常: {e}")
                status.state = ModelState.DEGRADED
                results.append({
                    "model": name,
                    "action": "retrain_error",
                    "error": str(e),
                })

        return results

    # ============================================================
    # 获取活跃模型列表
    # ============================================================

    def get_active_models(self) -> List[str]:
        """获取当前活跃模型列表（排除降级和退役）"""
        return [
            name for name, status in self.models.items()
            if status.state in (ModelState.ACTIVE, ModelState.COLD_START)
        ]

    def get_all_model_statuses(self) -> List[Dict]:
        """获取所有模型状态"""
        return [status.to_dict() for status in self.models.values()]

    def get_degraded_models(self) -> List[str]:
        """获取降级模型列表"""
        return [
            name for name, status in self.models.items()
            if status.state == ModelState.DEGRADED
        ]

    def get_ab_history(self, limit: int = 20) -> List[Dict]:
        """获取 A/B 对比历史"""
        return self.ab_history[-limit:]

    # ============================================================
    # 模型淘汰
    # ============================================================

    def retire_model(self, model_name: str, reason: str = "手动淘汰"):
        """手动淘汰模型"""
        self._transition(model_name, ModelState.RETIRED, reason)
        logger.info(f"[模型管理] {model_name} 已退役: {reason}")

    def reactivate_model(self, model_name: str):
        """手动重新激活模型"""
        status = self.get_or_create(model_name)
        if status.state == ModelState.RETIRED:
            status.state = ModelState.COLD_START
            status.state_since = datetime.now()
            status.consecutive_poor_rounds = 0
            status.consecutive_declining_rounds = 0
            logger.info(f"[模型管理] {model_name} 已重新激活（冷启动模式）")

    def get_summary(self) -> Dict:
        """获取模型管理摘要"""
        active = sum(1 for s in self.models.values() if s.state == ModelState.ACTIVE)
        degraded = sum(1 for s in self.models.values() if s.state == ModelState.DEGRADED)
        retired = sum(1 for s in self.models.values() if s.state == ModelState.RETIRED)
        retraining = sum(1 for s in self.models.values() if s.state == ModelState.RETRAINING)
        cold_start = sum(1 for s in self.models.values() if s.state == ModelState.COLD_START)

        return {
            "total_models": len(self.models),
            "active": active,
            "degraded": degraded,
            "retired": retired,
            "retraining": retraining,
            "cold_start": cold_start,
            "ab_comparisons": len(self.ab_history),
            "models": self.get_all_model_statuses(),
        }


# 全局实例
model_manager = ModelManager()
