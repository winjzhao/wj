"""
V70 彩票AI工作台 - 反馈引擎 (FeedbackEngine)
基于真实开奖结果，动态调整模型可信度和融合权重
"""
import numpy as np
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
from loguru import logger

from app.self_learning.match_engine import MatchResult
from app.config.settings import settings


class FeedbackEngine:
    """
    反馈引擎 — 自学习核心
    基于预测vs实际结果的匹配数据，自动调整:
    1. 各模型的可信度评分 (credibility_score)
    2. 融合引擎的权重分配 (base_weights)
    3. 长期趋势追踪

    核心算法:
    - 可信度更新: 指数加权移动平均 (EWMA)
    - 权重调整: 基于近期F1分数 + 稳定性惩罚
    - 冷启动保护: 样本不足时回退到默认权重
    """

    def __init__(self, learning_rate: float = 0.15, decay_factor: float = 0.95):
        self.learning_rate = learning_rate  # 学习率
        self.decay_factor = decay_factor    # 旧权重衰减因子
        self.feedback_history: List[Dict] = []
        self.iteration = 0

        # 各模型的历史表现追踪
        self.model_scores: Dict[str, List[float]] = defaultdict(list)
        self.model_hits: Dict[str, List[int]] = defaultdict(list)

        # 默认基础权重（用于冷启动）
        self.default_weights = {
            "XGBoost": settings.XGBOOST_WEIGHT,
            "LSTM": settings.LSTM_WEIGHT,
            "Transformer": settings.TRANSFORMER_WEIGHT,
            "PPO": settings.PPO_WEIGHT,
            "Statistic": settings.STATISTIC_WEIGHT,
            "Behavior": settings.BEHAVIOR_WEIGHT,
        }

        # 最小样本数（少于此时不调整权重）
        self.min_samples_for_update = 5

    def process_match_results(
        self, match_results: List[MatchResult]
    ) -> Dict[str, Dict]:
        """
        处理一批匹配结果，更新模型表现追踪
        返回各模型的更新信息
        """
        if not match_results:
            return {}

        self.iteration += 1
        updates = {}

        for match in match_results:
            name = match.model_name
            self.model_scores[name].append(match.score)
            self.model_hits[name].append(match.total_hits)

            # 限制历史记录长度
            if len(self.model_scores[name]) > 100:
                self.model_scores[name] = self.model_scores[name][-100:]
                self.model_hits[name] = self.model_hits[name][-100:]

        # 记录本次反馈
        feedback_entry = {
            "iteration": self.iteration,
            "matches_processed": len(match_results),
            "models_affected": list(set(m.model_name for m in match_results)),
        }
        self.feedback_history.append(feedback_entry)

        logger.info(
            f"[反馈引擎] 第{self.iteration}次反馈: "
            f"处理{len(match_results)}条匹配, "
            f"涉及{len(feedback_entry['models_affected'])}个模型"
        )

        return self._calculate_updates(match_results)

    def _calculate_updates(self, match_results: List[MatchResult]) -> Dict[str, Dict]:
        """计算各模型的更新量"""
        updates = {}
        affected_models = set(m.model_name for m in match_results)

        for name in affected_models:
            scores = self.model_scores.get(name, [])
            hits = self.model_hits.get(name, [])

            if len(scores) < self.min_samples_for_update:
                continue

            # 近期表现 (最近N次)
            recent_n = min(20, len(scores))
            recent_scores = scores[-recent_n:]
            recent_hits = hits[-recent_n:]

            avg_score = np.mean(recent_scores)
            avg_hits = np.mean(recent_hits)
            score_std = np.std(recent_scores) if len(recent_scores) > 1 else 0.1

            # 稳定性 = 1 / (1 + 变异系数)
            stability = 1.0 / (1.0 + score_std / max(avg_score, 0.01))

            # 趋势: 后一半 vs 前一半
            half = max(1, len(recent_scores) // 2)
            recent_half = recent_scores[-half:]
            early_half = recent_scores[:half]
            trend_score = np.mean(recent_half) - np.mean(early_half)

            updates[name] = {
                "avg_score": round(avg_score, 4),
                "avg_hits": round(avg_hits, 2),
                "stability": round(stability, 4),
                "trend": round(trend_score, 4),
                "sample_count": len(recent_scores),
            }

        return updates

    def compute_new_weights(
        self, current_weights: Dict[str, float]
    ) -> Dict[str, float]:
        """
        基于历史表现计算新的融合权重
        公式: new_weight = old_weight * decay + performance_score * (1 - decay)
        """
        # 计算各模型的性能评分
        performance_scores = {}
        for name in self.default_weights:
            scores = self.model_scores.get(name, [])
            if len(scores) >= self.min_samples_for_update:
                recent = scores[-20:]
                avg_score = np.mean(recent)
                # 结合稳定性惩罚
                std = np.std(recent) if len(recent) > 1 else 0.1
                performance_scores[name] = avg_score / (1.0 + std)
            else:
                performance_scores[name] = 0

        # 归一化性能评分
        total_perf = sum(performance_scores.values())
        if total_perf <= 0:
            # 无足够数据，保持当前权重
            return current_weights

        normalized_perf = {
            name: score / total_perf
            for name, score in performance_scores.items()
        }

        # 指数平滑: 新权重 = 旧权重 * decay + 性能权重 * (1 - decay)
        new_weights = {}
        for name in self.default_weights:
            old_w = current_weights.get(name, self.default_weights[name])
            perf_w = normalized_perf.get(name, self.default_weights[name])
            new_weights[name] = round(
                old_w * self.decay_factor + perf_w * (1 - self.decay_factor), 4
            )

        # 归一化确保总和为1
        total = sum(new_weights.values())
        new_weights = {k: round(v / total, 4) for k, v in new_weights.items()}

        logger.info(
            f"[反馈引擎] 权重更新: "
            f"{' | '.join(f'{k}={v:.3f}' for k, v in new_weights.items())}"
        )

        return new_weights

    def compute_credibility_updates(self) -> Dict[str, float]:
        """
        计算各模型的可信度更新值
        用于更新 BaseAIModel.credibility_score
        """
        credibility_updates = {}

        for name in self.default_weights:
            scores = self.model_scores.get(name, [])
            if len(scores) >= self.min_samples_for_update:
                recent = scores[-20:]
                mean_perf = np.mean(recent)
                std_perf = np.std(recent) if len(recent) > 1 else 0.1
                # 表现越稳定、均值越高 -> 可信度越高
                credibility = mean_perf / (1.0 + std_perf)
                credibility = min(1.0, max(0.05, credibility))
                credibility_updates[name] = round(credibility, 4)

        return credibility_updates

    def get_evolution_report(self) -> Dict:
        """获取自学习进化报告"""
        model_summaries = {}
        for name in self.default_weights:
            scores = self.model_scores.get(name, [])
            hits = self.model_hits.get(name, [])
            if scores:
                recent_n = min(20, len(scores))
                recent_scores = scores[-recent_n:]
                recent_hits = hits[-recent_n:]

                # 计算趋势
                if len(recent_scores) >= 4:
                    q = len(recent_scores) // 4
                    q1 = np.mean(recent_scores[:q])
                    q4 = np.mean(recent_scores[-q:])
                    trend = "improving" if q4 > q1 * 1.05 else (
                        "declining" if q4 < q1 * 0.95 else "stable"
                    )
                else:
                    trend = "insufficient_data"

                model_summaries[name] = {
                    "total_samples": len(scores),
                    "recent_avg_score": round(np.mean(recent_scores), 4),
                    "recent_avg_hits": round(np.mean(recent_hits), 2),
                    "best_score": round(np.max(recent_scores), 4),
                    "worst_score": round(np.min(recent_scores), 4),
                    "stability": round(
                        1.0 / (1.0 + np.std(recent_scores)) if len(recent_scores) > 1 else 0.5,
                        4,
                    ),
                    "trend": trend,
                }

        return {
            "iteration": self.iteration,
            "total_feedbacks": len(self.feedback_history),
            "models": model_summaries,
            "learning_rate": self.learning_rate,
            "decay_factor": self.decay_factor,
        }

    def reset(self):
        """重置反馈引擎"""
        self.feedback_history.clear()
        self.model_scores.clear()
        self.model_hits.clear()
        self.iteration = 0
        logger.info("[反馈引擎] 已重置")
