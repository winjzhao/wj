"""
V70 彩票AI工作台 - 进化持久化管理器 (EvolutionPersistence)
负责将自学习进化的核心成果（权重、可信度、评分追踪、进化历史）持久化到 SQLite，
并在启动时恢复，解决重启后学习成果丢失的问题。
"""
from typing import Dict, List, Optional, Any
from datetime import datetime
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from app.database.models import EvolutionState, EvolutionHistory


# 默认模型列表
DEFAULT_MODELS = ["XGBoost", "LSTM", "Transformer", "PPO", "Statistic", "Behavior"]


class EvolutionPersistence:
    """进化数据持久化管理器"""

    # ============================================================
    # 进化状态读写
    # ============================================================

    @staticmethod
    async def save_evolution_state(
        db: AsyncSession,
        lottery_type: str,
        fusion_weights: Dict[str, float],
        model_credibility: Dict[str, float],
        model_scores: Dict[str, List[float]],
        model_hits: Dict[str, List[int]],
        total_iterations: int,
        feedback_iteration: int,
        feedback_count: int,
        last_evolution_at: Optional[datetime] = None,
    ):
        """
        保存或更新进化状态
        每个 lottery_type 只有一条记录，使用 upsert 模式
        """
        # 查找现有记录
        result = await db.execute(
            select(EvolutionState).where(EvolutionState.lottery_type == lottery_type)
        )
        existing = result.scalar_one_or_none()

        if existing:
            # 更新现有记录
            existing.fusion_weights = fusion_weights
            existing.model_credibility = model_credibility
            existing.model_scores = model_scores
            existing.model_hits = model_hits
            existing.total_iterations = total_iterations
            existing.feedback_iteration = feedback_iteration
            existing.feedback_count = feedback_count
            if last_evolution_at:
                existing.last_evolution_at = last_evolution_at
            existing.updated_at = datetime.now()
        else:
            # 创建新记录
            state = EvolutionState(
                lottery_type=lottery_type,
                fusion_weights=fusion_weights,
                model_credibility=model_credibility,
                model_scores=model_scores,
                model_hits=model_hits,
                total_iterations=total_iterations,
                feedback_iteration=feedback_iteration,
                feedback_count=feedback_count,
                last_evolution_at=last_evolution_at,
            )
            db.add(state)

        await db.commit()
        logger.info(f"[持久化] 进化状态已保存 (lottery_type={lottery_type})")

    @staticmethod
    async def load_evolution_state(
        db: AsyncSession,
        lottery_type: str,
    ) -> Optional[Dict[str, Any]]:
        """
        从数据库加载进化状态
        返回 None 表示没有保存的状态（首次运行）
        """
        result = await db.execute(
            select(EvolutionState).where(EvolutionState.lottery_type == lottery_type)
        )
        state = result.scalar_one_or_none()

        if not state:
            logger.info(f"[持久化] 无进化状态记录 (lottery_type={lottery_type})，使用默认值")
            return None

        logger.info(
            f"[持久化] 成功加载进化状态 (lottery_type={lottery_type}): "
            f"iterations={state.total_iterations}, "
            f"last_evo={state.last_evolution_at}"
        )
        return {
            "lottery_type": state.lottery_type,
            "fusion_weights": state.fusion_weights or {},
            "model_credibility": state.model_credibility or {},
            "model_scores": state.model_scores or {},
            "model_hits": state.model_hits or {},
            "total_iterations": state.total_iterations or 0,
            "feedback_iteration": state.feedback_iteration or 0,
            "feedback_count": state.feedback_count or 0,
            "last_evolution_at": state.last_evolution_at,
        }

    # ============================================================
    # 进化历史读写
    # ============================================================

    @staticmethod
    async def save_evolution_history(
        db: AsyncSession,
        lottery_type: str,
        cycle_result: Dict[str, Any],
    ):
        """保存一条进化周期历史记录"""
        record = EvolutionHistory(
            lottery_type=lottery_type,
            iteration=cycle_result.get("iteration", 0),
            status=cycle_result.get("status", "unknown"),
            matched_count=cycle_result.get("matched_count", 0),
            old_weights=cycle_result.get("old_weights"),
            new_weights=cycle_result.get("new_weights"),
            model_performance=cycle_result.get("model_performance"),
            credibility_updates=cycle_result.get("credibility_updates"),
            model_updates=cycle_result.get("model_updates"),
            duration_seconds=cycle_result.get("duration_seconds"),
            error_message=cycle_result.get("error"),
        )
        db.add(record)
        await db.commit()
        logger.debug(f"[持久化] 进化历史已保存: iteration={cycle_result.get('iteration')}")

    @staticmethod
    async def get_evolution_history(
        db: AsyncSession,
        lottery_type: str,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        """查询进化历史记录"""
        result = await db.execute(
            select(EvolutionHistory)
            .where(EvolutionHistory.lottery_type == lottery_type)
            .order_by(EvolutionHistory.created_at.desc())
            .limit(limit)
        )
        records = result.scalars().all()

        return [
            {
                "id": r.id,
                "iteration": r.iteration,
                "status": r.status,
                "matched_count": r.matched_count,
                "old_weights": r.old_weights,
                "new_weights": r.new_weights,
                "model_performance": r.model_performance,
                "credibility_updates": r.credibility_updates,
                "duration_seconds": r.duration_seconds,
                "error_message": r.error_message,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in records
        ]

    @staticmethod
    async def get_evolution_history_count(
        db: AsyncSession,
        lottery_type: str,
    ) -> int:
        """获取进化历史总数"""
        from sqlalchemy import func
        result = await db.execute(
            select(func.count()).where(EvolutionHistory.lottery_type == lottery_type)
        )
        return result.scalar() or 0

    # ============================================================
    # 记忆库读写
    # ============================================================

    @staticmethod
    async def save_memory(
        db: AsyncSession,
        memory_type: str,
        content: Dict,
        lottery_type: str = "ssq",
        period: str = "",
        score: float = 0.0,
        tags: List[str] = None,
    ):
        """将一条记忆存入 memory_records 表"""
        from app.database.models import MemoryRecord

        record = MemoryRecord(
            memory_type=memory_type,
            lottery_type=lottery_type,
            content=content,
            period=period,
            score=score,
            tags=tags or [],
        )
        db.add(record)
        await db.commit()

    @staticmethod
    async def load_recent_memories(
        db: AsyncSession,
        memory_type: Optional[str] = None,
        lottery_type: str = "ssq",
        limit: int = 200,
    ) -> List[Dict]:
        """从数据库加载最近的记忆"""
        from app.database.models import MemoryRecord

        query = select(MemoryRecord).where(
            MemoryRecord.lottery_type == lottery_type
        )
        if memory_type:
            query = query.where(MemoryRecord.memory_type == memory_type)
        query = query.order_by(MemoryRecord.created_at.desc()).limit(limit)

        result = await db.execute(query)
        records = result.scalars().all()

        return [
            {
                "id": r.id,
                "memory_type": r.memory_type,
                "content": r.content,
                "period": r.period,
                "score": r.score,
                "tags": r.tags,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in records
        ]

    @staticmethod
    async def load_high_score_memories(
        db: AsyncSession,
        lottery_type: str = "ssq",
        min_score: float = 0.2,
        limit: int = 100,
    ) -> List[Dict]:
        """加载高分记忆（用于启动时恢复经验）"""
        from app.database.models import MemoryRecord

        result = await db.execute(
            select(MemoryRecord)
            .where(
                MemoryRecord.lottery_type == lottery_type,
                MemoryRecord.score >= min_score,
            )
            .order_by(MemoryRecord.score.desc())
            .limit(limit)
        )
        records = result.scalars().all()
        return [
            {
                "id": r.id,
                "memory_type": r.memory_type,
                "content": r.content,
                "period": r.period,
                "score": r.score,
                "tags": r.tags,
            }
            for r in records
        ]

    # ============================================================
    # 重置
    # ============================================================

    @staticmethod
    async def reset_evolution_state(db: AsyncSession, lottery_type: str):
        """删除指定彩票类型的进化状态"""
        result = await db.execute(
            select(EvolutionState).where(EvolutionState.lottery_type == lottery_type)
        )
        state = result.scalar_one_or_none()
        if state:
            await db.delete(state)
            await db.commit()
            logger.info(f"[持久化] 进化状态已删除 (lottery_type={lottery_type})")

    @staticmethod
    async def reset_evolution_history(db: AsyncSession, lottery_type: str):
        """删除指定彩票类型的进化历史"""
        from sqlalchemy import delete
        await db.execute(
            delete(EvolutionHistory).where(EvolutionHistory.lottery_type == lottery_type)
        )
        await db.commit()
        logger.info(f"[持久化] 进化历史已删除 (lottery_type={lottery_type})")


# 全局持久化管理器实例
persistence = EvolutionPersistence()
