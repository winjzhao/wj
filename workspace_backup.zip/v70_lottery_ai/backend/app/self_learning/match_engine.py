"""
V70 彩票AI工作台 - 结果匹配引擎 (ResultMatcher)
自动将预测结果与真实开奖数据进行比对，计算命中率
"""
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_

from app.database.models import Prediction, LotteryDraw
from app.core.lottery_schema import get_schema


class MatchResult:
    """单次预测-结果匹配记录"""

    def __init__(
        self,
        prediction_id: int,
        period: str,
        lottery_type: str,
        model_name: str,
        predicted_main: List[int],
        predicted_bonus: List[List[int]],
        actual_main: List[int],
        actual_bonus: List[List[int]],
    ):
        self.prediction_id = prediction_id
        self.period = period
        self.lottery_type = lottery_type
        self.model_name = model_name
        self.predicted_main = predicted_main
        self.predicted_bonus = predicted_bonus
        self.actual_main = actual_main
        self.actual_bonus = actual_bonus

        # 计算命中数
        self.main_hits = self._count_main_hits()
        self.bonus_hits = self._count_bonus_hits()
        self.total_hits = self.main_hits + self.bonus_hits

        # 命中率评分 (0-1)
        schema = get_schema(lottery_type)
        main_count = schema["main_count"]
        total_bonus = sum(b["count"] for b in schema["bonus_balls"])
        self.main_hit_rate = self.main_hits / main_count if main_count > 0 else 0
        self.bonus_hit_rate = self.bonus_hits / total_bonus if total_bonus > 0 else 0

        # 综合评分 (主球权重0.7, 附加球权重0.3)
        self.score = round(
            self.main_hit_rate * 0.7 + self.bonus_hit_rate * 0.3, 4
        )

    def _count_main_hits(self) -> int:
        """计算主球区命中数"""
        predicted_set = set(self.predicted_main)
        actual_set = set(self.actual_main)
        return len(predicted_set & actual_set)

    def _count_bonus_hits(self) -> int:
        """计算附加球区命中数"""
        total_hits = 0
        for pred_group, actual_group in zip(self.predicted_bonus, self.actual_bonus):
            pred_set = set(pred_group)
            actual_set = set(actual_group)
            total_hits += len(pred_set & actual_set)
        return total_hits

    def to_dict(self) -> Dict:
        return {
            "prediction_id": self.prediction_id,
            "period": self.period,
            "lottery_type": self.lottery_type,
            "model_name": self.model_name,
            "main_hits": self.main_hits,
            "bonus_hits": self.bonus_hits,
            "total_hits": self.total_hits,
            "main_hit_rate": round(self.main_hit_rate, 4),
            "bonus_hit_rate": round(self.bonus_hit_rate, 4),
            "score": self.score,
            "predicted_main": self.predicted_main,
            "actual_main": self.actual_main,
        }


class ResultMatcher:
    """
    结果匹配引擎
    自动查找数据库中已开奖但未匹配的预测，计算命中率
    """

    def __init__(self):
        self.match_history: List[MatchResult] = []

    async def match_pending_predictions(
        self, db: AsyncSession, lottery_type: Optional[str] = None
    ) -> List[MatchResult]:
        """
        匹配所有待验证的预测记录
        找到 status='pending' 的预测，查找对应期号的开奖数据，计算命中率
        """
        results = []

        try:
            # 1. 查找所有待匹配的预测
            pred_query = select(Prediction).where(
                Prediction.status == "pending"
            )
            if lottery_type:
                pred_query = pred_query.where(Prediction.lottery_type == lottery_type)

            pred_result = await db.execute(pred_query)
            pending_preds = pred_result.scalars().all()

            if not pending_preds:
                logger.info("[匹配引擎] 没有待匹配的预测记录")
                return results

            logger.info(f"[匹配引擎] 发现 {len(pending_preds)} 条待匹配预测")

            # 2. 按期号分组，批量查找开奖数据
            periods = list(set(p.period for p in pending_preds))
            draw_query = select(LotteryDraw).where(
                LotteryDraw.period.in_(periods)
            )
            draw_result = await db.execute(draw_query)
            draws = {d.period: d for d in draw_result.scalars().all()}

            # 3. 逐条匹配
            matched_count = 0
            for pred in pending_preds:
                draw = draws.get(pred.period)
                if not draw:
                    # 该期尚未开奖，跳过
                    continue

                # 解析预测数据
                predicted_main = pred.main_balls if isinstance(pred.main_balls, list) else []
                predicted_bonus = pred.bonus_balls if isinstance(pred.bonus_balls, list) else [[]]

                # 获取实际开奖数据
                actual_main = draw.get_main_balls()
                actual_bonus = draw.get_bonus_balls()

                if not actual_main:
                    logger.warning(f"[匹配引擎] 期号 {pred.period} 开奖数据不完整")
                    continue

                # 计算命中
                match = MatchResult(
                    prediction_id=pred.id,
                    period=pred.period,
                    lottery_type=pred.lottery_type,
                    model_name=pred.model_name,
                    predicted_main=predicted_main,
                    predicted_bonus=predicted_bonus,
                    actual_main=actual_main,
                    actual_bonus=actual_bonus,
                )
                results.append(match)
                self.match_history.append(match)
                matched_count += 1

                # 更新预测状态为已匹配，同时写入对比结果
                await db.execute(
                    update(Prediction)
                    .where(Prediction.id == pred.id)
                    .values(
                        status="matched",
                        score=match.score,
                        actual_main_balls=actual_main,
                        actual_bonus_balls=actual_bonus,
                        match_main_count=match.main_hits,
                        match_bonus_count=match.bonus_hits,
                        match_total=match.total_hits,
                        match_hit_rate=match.score,
                        matched_at=datetime.now(),
                    )
                )

                logger.info(
                    f"[匹配引擎] 期号={pred.period} 模型={pred.model_name} "
                    f"命中={match.total_hits} 评分={match.score:.4f}"
                )

            if matched_count > 0:
                await db.commit()
                logger.info(f"[匹配引擎] 成功匹配 {matched_count} 条预测")

        except Exception as e:
            await db.rollback()
            logger.error(f"[匹配引擎] 匹配失败: {e}")
            raise

        return results

    async def match_specific_prediction(
        self, db: AsyncSession, prediction_id: int
    ) -> Optional[MatchResult]:
        """匹配特定预测记录"""
        result = await db.execute(
            select(Prediction).where(Prediction.id == prediction_id)
        )
        pred = result.scalar_one_or_none()

        if not pred:
            return None

        draw_result = await db.execute(
            select(LotteryDraw).where(LotteryDraw.period == pred.period)
        )
        draw = draw_result.scalar_one_or_none()

        if not draw:
            return None

        actual_main = draw.get_main_balls()
        actual_bonus = draw.get_bonus_balls()

        match = MatchResult(
            prediction_id=pred.id,
            period=pred.period,
            lottery_type=pred.lottery_type,
            model_name=pred.model_name,
            predicted_main=pred.main_balls or [],
            predicted_bonus=pred.bonus_balls or [[]],
            actual_main=actual_main,
            actual_bonus=actual_bonus,
        )

        await db.execute(
            update(Prediction)
            .where(Prediction.id == pred.id)
            .values(
                status="matched",
                score=match.score,
                actual_main_balls=actual_main,
                actual_bonus_balls=actual_bonus,
                match_main_count=match.main_hits,
                match_bonus_count=match.bonus_hits,
                match_total=match.total_hits,
                match_hit_rate=match.score,
                matched_at=datetime.now(),
            )
        )
        await db.commit()

        return match

    def get_model_performance(
        self, window: int = 20
    ) -> Dict[str, Dict[str, float]]:
        """
        按模型汇总近期表现
        返回: {model_name: {avg_hits, avg_score, trend, sample_count}}
        """
        from collections import defaultdict

        model_results = defaultdict(list)
        for m in self.match_history[-window:]:
            model_results[m.model_name].append(m)

        performance = {}
        for name, results in model_results.items():
            scores = [r.score for r in results]
            hits = [r.total_hits for r in results]

            # 计算趋势: 近期vs前期
            half = len(scores) // 2 or 1
            recent_avg = np.mean(scores[-half:]) if scores[-half:] else 0
            early_avg = np.mean(scores[:half]) if scores[:half] else 0

            trend = "improving" if recent_avg > early_avg * 1.05 else (
                "declining" if recent_avg < early_avg * 0.95 else "stable"
            )

            performance[name] = {
                "avg_hits": round(np.mean(hits), 2),
                "avg_score": round(np.mean(scores), 4),
                "max_score": round(np.max(scores), 4),
                "trend": trend,
                "sample_count": len(results),
            }

        return performance

    def get_recent_matches(self, limit: int = 50) -> List[Dict]:
        """获取最近的匹配记录"""
        return [
            m.to_dict() for m in self.match_history[-limit:]
        ]
