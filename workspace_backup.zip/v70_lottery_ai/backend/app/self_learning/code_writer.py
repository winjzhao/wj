"""
V70 彩票AI工作台 - 代码自优化器 (CodeWriter)
让进化引擎能够将验证过的学习成果自动写回源代码，
实现真正的"自我进化"——AI 不仅能调整内存参数，还能优化代码本身。

核心能力：
1. 优化 settings.py 中的模型权重配置
2. 优化 feedback_engine.py 中的学习率和衰减因子
3. 优化 fusion.py 中的评分权重和候选生成参数
4. 优化各模型内部的策略参数
5. 写入前自动备份，支持回滚
6. 只有多轮验证通过的优化才会写入代码
"""

import os
import re
import json
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from loguru import logger


# ============================================================
# 代码文件路径
# ============================================================
BACKEND_DIR = Path(__file__).resolve().parent.parent.parent  # backend/
APP_DIR = BACKEND_DIR / "app"
SETTINGS_FILE = APP_DIR / "config" / "settings.py"
FEEDBACK_FILE = APP_DIR / "self_learning" / "feedback_engine.py"
FUSION_FILE = APP_DIR / "fusion_engine" / "fusion.py"
BACKUP_DIR = BACKEND_DIR / "code_backups"


class CodeWriter:
    """
    代码自优化器

    工作流:
    1. 收集进化引擎验证通过的优化建议
    2. 对比当前代码中的参数值
    3. 如果优化值显著优于当前值（多轮验证），自动写入代码
    4. 写入前创建备份文件
    5. 记录所有代码变更日志
    """

    def __init__(self):
        self.change_log: List[Dict] = []
        self.min_improvement_threshold = 0.05  # 最小改进阈值（5%）
        self.min_validation_rounds = 3         # 最少验证轮次
        self.backup_dir = BACKUP_DIR
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    # ============================================================
    # 模型权重优化
    # ============================================================

    def optimize_model_weights(
        self,
        evolved_weights: Dict[str, float],
        validation_rounds: int = 3,
        avg_improvement: float = 0.0,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        将进化验证过的模型权重写入 settings.py

        Args:
            evolved_weights: 进化后的模型权重 {"XGBoost": 0.22, ...}
            validation_rounds: 已验证的轮次
            avg_improvement: 平均改进幅度
            dry_run: 仅模拟，不实际写入
        """
        if validation_rounds < self.min_validation_rounds:
            return {
                "action": "skip",
                "reason": f"验证轮次不足 ({validation_rounds} < {self.min_validation_rounds})",
            }

        if avg_improvement < self.min_improvement_threshold:
            return {
                "action": "skip",
                "reason": f"改进幅度不足 ({avg_improvement:.3f} < {self.min_improvement_threshold})",
            }

        # 读取当前 settings.py
        content = SETTINGS_FILE.read_text(encoding="utf-8")
        original = content

        changes = []
        weight_keys = {
            "XGBoost": "XGBOOST_WEIGHT",
            "LSTM": "LSTM_WEIGHT",
            "Transformer": "TRANSFORMER_WEIGHT",
            "PPO": "PPO_WEIGHT",
            "Statistic": "STATISTIC_WEIGHT",
            "Behavior": "BEHAVIOR_WEIGHT",
        }

        for model_name, config_key in weight_keys.items():
            if model_name not in evolved_weights:
                continue
            new_val = evolved_weights[model_name]
            old_val = self._extract_float_param(content, config_key)
            if old_val is not None and abs(new_val - old_val) > 0.001:
                # 替换
                pattern = rf'({config_key}\s*:\s*float\s*=\s*)[\d.]+'
                replacement = rf'\g<1>{new_val:.4f}'
                new_content = re.sub(pattern, replacement, content)
                if new_content != content:
                    changes.append({
                        "param": config_key,
                        "old": old_val,
                        "new": new_val,
                    })
                    content = new_content

        if not changes:
            return {"action": "skip", "reason": "权重无显著变化"}

        if dry_run:
            return {
                "action": "dry_run",
                "changes": changes,
                "file": str(SETTINGS_FILE),
            }

        # 备份 + 写入
        self._backup_and_write(SETTINGS_FILE, content)
        self._log_change("model_weights", changes)

        logger.info("[代码写入] 模型权重已优化: {}".format(
            [(c["param"], "{}→{}".format(c["old"], c["new"])) for c in changes]
        ))
        return {
            "action": "written",
            "changes": changes,
            "file": str(SETTINGS_FILE),
        }

    # ============================================================
    # 学习率优化
    # ============================================================

    def optimize_learning_params(
        self,
        learning_rate: Optional[float] = None,
        decay_factor: Optional[float] = None,
        min_samples: Optional[int] = None,
        validation_rounds: int = 3,
        avg_improvement: float = 0.0,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        将进化验证过的学习参数写入 feedback_engine.py
        """
        if validation_rounds < self.min_validation_rounds:
            return {
                "action": "skip",
                "reason": f"验证轮次不足 ({validation_rounds} < {self.min_validation_rounds})",
            }

        content = FEEDBACK_FILE.read_text(encoding="utf-8")
        changes = []

        param_map = {
            "learning_rate": (learning_rate, r'(learning_rate\s*=\s*)[\d.]+'),
            "decay_factor": (decay_factor, r'(decay_factor\s*=\s*)[\d.]+'),
            "min_samples_for_update": (min_samples, r'(self\.min_samples_for_update\s*=\s*)\d+'),
        }

        for param_name, (new_val, pattern) in param_map.items():
            if new_val is None:
                continue
            old_val = self._extract_first_match(content, pattern)
            if old_val is not None:
                # 判断类型
                is_float = isinstance(new_val, float)
                if abs(new_val - float(old_val)) < (0.001 if is_float else 0.5):
                    continue
                replacement = rf'\g<1>{new_val:.4f}' if is_float else rf'\g<1>{int(new_val)}'
                new_content = re.sub(pattern, replacement, content)
                if new_content != content:
                    changes.append({"param": param_name, "old": float(old_val), "new": new_val})
                    content = new_content

        if not changes:
            return {"action": "skip", "reason": "学习参数无显著变化"}

        if dry_run:
            return {"action": "dry_run", "changes": changes, "file": str(FEEDBACK_FILE)}

        self._backup_and_write(FEEDBACK_FILE, content)
        self._log_change("learning_params", changes)

        logger.info("[代码写入] 学习参数已优化: {}".format(
            [(c["param"], "{}→{}".format(c["old"], c["new"])) for c in changes]
        ))
        return {"action": "written", "changes": changes, "file": str(FEEDBACK_FILE)}

    # ============================================================
    # 融合评分权重优化
    # ============================================================

    def optimize_fusion_scores(
        self,
        prob_weight: Optional[float] = None,
        structure_weight: Optional[float] = None,
        stability_weight: Optional[float] = None,
        candidate_count: Optional[int] = None,
        top_results: Optional[int] = None,
        validation_rounds: int = 3,
        avg_improvement: float = 0.0,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        将进化验证过的融合评分权重写入 fusion.py
        """
        if validation_rounds < self.min_validation_rounds:
            return {
                "action": "skip",
                "reason": f"验证轮次不足 ({validation_rounds} < {self.min_validation_rounds})",
            }

        content = FUSION_FILE.read_text(encoding="utf-8")

        # 融合评分权重位于 _score_candidate 方法末尾
        # prob_score * 0.5 + structure_score * 0.3 + stability_score * 0.2
        changes = []

        # 1. 优化候选方案数量 (settings.py 中的 CANDIDATE_COUNT)
        if candidate_count is not None:
            settings_content = SETTINGS_FILE.read_text(encoding="utf-8")
            old_count = self._extract_float_param(settings_content, "CANDIDATE_COUNT")
            if old_count is not None and abs(candidate_count - int(old_count)) > 0:
                new_sc = re.sub(
                    r'(CANDIDATE_COUNT\s*:\s*int\s*=\s*)\d+',
                    rf'\g<1>{candidate_count}',
                    settings_content,
                )
                if new_sc != settings_content:
                    self._backup_and_write(SETTINGS_FILE, new_sc)
                    changes.append({
                        "param": "CANDIDATE_COUNT",
                        "old": int(old_count),
                        "new": candidate_count,
                    })

        # 2. 优化 TOP_RESULTS
        if top_results is not None:
            settings_content = SETTINGS_FILE.read_text(encoding="utf-8")
            old_top = self._extract_float_param(settings_content, "TOP_RESULTS")
            if old_top is not None and abs(top_results - int(old_top)) > 0:
                new_sc = re.sub(
                    r'(TOP_RESULTS\s*:\s*int\s*=\s*)\d+',
                    rf'\g<1>{top_results}',
                    settings_content,
                )
                if new_sc != settings_content:
                    self._backup_and_write(SETTINGS_FILE, new_sc)
                    changes.append({
                        "param": "TOP_RESULTS",
                        "old": int(old_top),
                        "new": top_results,
                    })

        # 3. 优化融合评分权重 (fusion.py 中)
        # final = prob_score * 0.5 + structure_score * 0.3 + stability_score * 0.2
        if prob_weight is not None and structure_weight is not None and stability_weight is not None:
            old_p, old_s, old_st = self._extract_fusion_score_weights(content)
            if old_p is not None and (
                abs(prob_weight - old_p) > 0.01
                or abs(structure_weight - old_s) > 0.01
                or abs(stability_weight - old_st) > 0.01
            ):
                # 替换评分权重行
                pattern = r'(\s+final\s*=\s*prob_score\s*\*\s*)[\d.]+(\s*\+\s*structure_score\s*\*\s*)[\d.]+(\s*\+\s*stability_score\s*\*\s*)[\d.]+'
                replacement = rf'\g<1>{prob_weight:.2f}\g<2>{structure_weight:.2f}\g<3>{stability_weight:.2f}'
                new_content = re.sub(pattern, replacement, content)
                if new_content != content:
                    changes.append({
                        "param": "fusion_score_weights",
                        "old": f"{old_p}/{old_s}/{old_st}",
                        "new": f"{prob_weight}/{structure_weight}/{stability_weight}",
                    })
                    content = new_content

        if not changes:
            return {"action": "skip", "reason": "融合参数无显著变化"}

        if dry_run:
            return {"action": "dry_run", "changes": changes, "file": str(FUSION_FILE)}

        # 只写 fusion.py（settings.py 的修改已在上面的步骤中处理）
        if any("fusion" in str(c.get("param", "")) for c in changes):
            self._backup_and_write(FUSION_FILE, content)

        self._log_change("fusion_params", changes)

        logger.info("[代码写入] 融合参数已优化: {}".format(
            [(c["param"], "{}→{}".format(c["old"], c["new"])) for c in changes]
        ))
        return {"action": "written", "changes": changes, "file": str(FUSION_FILE)}

    # ============================================================
    # 批量自动优化（进化引擎调用入口）
    # ============================================================

    def auto_optimize_from_evolution(
        self,
        evolved_weights: Dict[str, float],
        evolved_learning_rate: Optional[float] = None,
        evolved_decay_factor: Optional[float] = None,
        evolved_prob_weight: Optional[float] = None,
        evolved_structure_weight: Optional[float] = None,
        evolved_stability_weight: Optional[float] = None,
        evolved_candidate_count: Optional[int] = None,
        validation_rounds: int = 3,
        avg_improvement: float = 0.0,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        批量自动优化 — 进化引擎的统一调用入口

        根据验证轮次和平均改进幅度，自动判断是否值得写入代码。
        只有通过多轮验证且改进显著的参数才会被写入。
        """
        results = {
            "weights": None,
            "learning": None,
            "fusion": None,
            "summary": [],
        }

        # 1. 优化模型权重
        if evolved_weights:
            results["weights"] = self.optimize_model_weights(
                evolved_weights=evolved_weights,
                validation_rounds=validation_rounds,
                avg_improvement=avg_improvement,
                dry_run=dry_run,
            )

        # 2. 优化学习参数
        if evolved_learning_rate or evolved_decay_factor:
            results["learning"] = self.optimize_learning_params(
                learning_rate=evolved_learning_rate,
                decay_factor=evolved_decay_factor,
                validation_rounds=validation_rounds,
                avg_improvement=avg_improvement,
                dry_run=dry_run,
            )

        # 3. 优化融合参数
        if any([evolved_prob_weight, evolved_structure_weight, evolved_stability_weight]):
            results["fusion"] = self.optimize_fusion_scores(
                prob_weight=evolved_prob_weight,
                structure_weight=evolved_structure_weight,
                stability_weight=evolved_stability_weight,
                candidate_count=evolved_candidate_count,
                validation_rounds=validation_rounds,
                avg_improvement=avg_improvement,
                dry_run=dry_run,
            )

        # 汇总
        for key, result in results.items():
            if result and result.get("action") == "written":
                results["summary"].append(f"{key}: {len(result.get('changes', []))} 项变更已写入")

        total_changes = sum(
            len(r.get("changes", []))
            for r in [results["weights"], results["learning"], results["fusion"]]
            if r and r.get("action") == "written"
        )

        logger.info(
            f"[代码写入] 自动优化完成: {len(results['summary'])} 个模块, "
            f"共 {total_changes} 项代码变更"
        )

        return results

    # ============================================================
    # 策略规则自动生成
    # ============================================================

    def generate_strategy_rules(
        self,
        discovered_patterns: List[Dict[str, Any]],
        strategy_file: Optional[str] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        根据进化发现的模式自动生成策略规则代码

        discovered_patterns 格式:
        [
            {
                "name": "hot_number_bias",
                "condition": "号码在近10期出现>=3次",
                "action": "提高概率0.15",
                "confidence": 0.72,
                "validation_score": 0.18,
            },
            ...
        ]
        """
        if not discovered_patterns:
            return {"action": "skip", "reason": "无新模式"}

        # 只保留高可信度模式
        valid_patterns = [
            p for p in discovered_patterns
            if p.get("confidence", 0) >= 0.6 and p.get("validation_score", 0) >= 0.10
        ]

        if not valid_patterns:
            return {"action": "skip", "reason": "无高可信度模式"}

        # 生成策略代码
        strategy_code = self._generate_strategy_code(valid_patterns)

        if strategy_file is None:
            strategy_file = str(APP_DIR / "self_learning" / "generated_strategies.py")

        strategy_path = Path(strategy_file)

        if dry_run:
            return {
                "action": "dry_run",
                "file": str(strategy_path),
                "patterns": valid_patterns,
                "preview": strategy_code[:500],
            }

        self._backup_and_write(strategy_path, strategy_code)
        self._log_change("strategy_rules", [{"patterns_count": len(valid_patterns)}])

        logger.info(f"[代码写入] 已生成 {len(valid_patterns)} 条新策略规则 → {strategy_file}")
        return {
            "action": "written",
            "file": str(strategy_path),
            "patterns": valid_patterns,
        }

    # ============================================================
    # 回滚功能
    # ============================================================

    def rollback(self, change_id: Optional[int] = None) -> Dict[str, Any]:
        """
        回滚代码变更
        默认回滚最近一次变更
        """
        if not self.change_log:
            return {"action": "skip", "reason": "无变更记录"}

        if change_id is None:
            # 回滚最近一次
            last_change = self.change_log[-1]
            change_id = len(self.change_log) - 1
        else:
            if change_id >= len(self.change_log):
                return {"action": "error", "reason": f"无效的变更ID: {change_id}"}
            last_change = self.change_log[change_id]

        # 查找对应备份
        backup_file = last_change.get("backup_file")
        original_file = last_change.get("original_file")

        if not backup_file or not os.path.exists(backup_file):
            return {"action": "error", "reason": "备份文件不存在"}

        # 还原
        shutil.copy2(backup_file, original_file)
        logger.info(f"[代码回滚] 已还原 {original_file} (变更ID={change_id})")

        return {
            "action": "rolled_back",
            "file": original_file,
            "change": last_change.get("description"),
        }

    def list_backups(self) -> List[Dict]:
        """列出所有备份文件"""
        backups = []
        if self.backup_dir.exists():
            for f in sorted(self.backup_dir.iterdir(), reverse=True):
                if f.is_file():
                    backups.append({
                        "filename": f.name,
                        "size": f.stat().st_size,
                        "created": datetime.fromtimestamp(f.stat().st_mtime).isoformat(),
                    })
        return backups

    def list_changes(self) -> List[Dict]:
        """列出所有代码变更记录"""
        return self.change_log

    # ============================================================
    # 内部工具方法
    # ============================================================

    def _backup_and_write(self, filepath: Path, new_content: str):
        """备份原文件并写入新内容"""
        # 创建备份
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{filepath.stem}_{timestamp}{filepath.suffix}"
        backup_path = self.backup_dir / backup_name
        shutil.copy2(str(filepath), str(backup_path))

        # 写入新内容
        filepath.write_text(new_content, encoding="utf-8")

        logger.debug(f"[代码备份] {filepath.name} → {backup_name}")

    def _extract_float_param(self, content: str, param_name: str) -> Optional[float]:
        """从内容中提取浮点参数值"""
        pattern = rf'{param_name}\s*:\s*(?:int|float)\s*=\s*([\d.]+)'
        match = re.search(pattern, content)
        if match:
            return float(match.group(1))
        return None

    def _extract_first_match(self, content: str, pattern: str) -> Optional[str]:
        """提取第一个正则匹配组"""
        match = re.search(pattern, content)
        if match:
            return match.group(1)
        return None

    def _extract_fusion_score_weights(self, content: str) -> Tuple[Optional[float], ...]:
        """从 fusion.py 提取评分权重"""
        pattern = r'prob_score\s*\*\s*([\d.]+)\s*\+\s*structure_score\s*\*\s*([\d.]+)\s*\+\s*stability_score\s*\*\s*([\d.]+)'
        match = re.search(pattern, content)
        if match:
            return float(match.group(1)), float(match.group(2)), float(match.group(3))
        return None, None, None

    def _log_change(self, change_type: str, details: List[Dict]):
        """记录代码变更"""
        self.change_log.append({
            "type": change_type,
            "details": details,
            "timestamp": datetime.now().isoformat(),
        })

    def _generate_strategy_code(self, patterns: List[Dict]) -> str:
        """生成策略规则 Python 代码"""
        lines = [
            '"""',
            'V70 彩票AI工作台 - 自动生成的策略规则',
            f'生成时间: {datetime.now().isoformat()}',
            '由进化引擎自动生成，基于多轮验证通过的发现',
            '请勿手动编辑此文件',
            '"""',
            '',
            'from typing import List, Dict, Any',
            '',
            '',
            'class GeneratedStrategies:',
            '    """自动生成的策略规则集"""',
            '',
            '    strategies = [',
        ]

        for i, p in enumerate(patterns):
            name = p.get("name", f"strategy_{i}")
            condition = p.get("condition", "")
            action = p.get("action", "")
            confidence = p.get("confidence", 0)
            score = p.get("validation_score", 0)

            lines.append('        {')
            lines.append(f'            "name": "{name}",')
            lines.append(f'            "condition": "{condition}",')
            lines.append(f'            "action": "{action}",')
            lines.append(f'            "confidence": {confidence:.4f},')
            lines.append(f'            "validation_score": {score:.4f},')
            lines.append('        },')

        lines.append('    ]')
        lines.append('')
        lines.append('    @classmethod')
        lines.append('    def apply(cls, context: Dict[str, Any]) -> Dict[str, Any]:')
        lines.append('        """')
        lines.append('        将生成的策略应用到当前预测上下文')
        lines.append('        返回策略调整建议')
        lines.append('        """')
        lines.append('        adjustments = {}')
        lines.append('        for s in cls.strategies:')
        lines.append('            if s["confidence"] >= 0.6:')
        lines.append('                adjustments[s["name"]] = {')
        lines.append('                    "action": s["action"],')
        lines.append('                    "weight": s["confidence"],')
        lines.append('                }')
        lines.append('        return adjustments')
        lines.append('')
        lines.append('')
        lines.append('# 全局实例')
        lines.append('generated_strategies = GeneratedStrategies()')
        lines.append('')

        return '\n'.join(lines)


# 全局实例
code_writer = CodeWriter()
