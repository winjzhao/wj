"""
V70 彩票AI工作台 - 进化引擎 (EvolutionEngine)
整合匹配引擎和反馈引擎，驱动完整的自学习闭环
每次进化完成后自动将权重、可信度、评分追踪持久化到 SQLite
当多轮验证通过后，自动将优化写入源代码（真正的"自我进化"）
自动检测模型降级、A/B对比、异常告警
"""
import asyncio
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.self_learning.match_engine import ResultMatcher, MatchResult
from app.self_learning.feedback_engine import FeedbackEngine
from app.database.models import Prediction
from app.core.alerting import AlertLevel, AlertCategory
from app.core.lottery_schema import get_schema


class EvolutionEngine:
    """
    自学习进化引擎
    编排完整的"预测→开奖→匹配→反馈→权重更新→代码自优化"闭环

    工作流:
    1. 数据更新 → 获取最新开奖数据
    2. 结果匹配 → 将pending预测与开奖结果比对
    3. 反馈计算 → 计算各模型命中率、评分
    4. 可信度更新 → 更新各模型 credibility_score
    5. 权重进化 → 动态调整融合引擎权重
    6. 记忆沉淀 → 将高价值经验存入长期记忆
    7. 持久化 → 将核心成果写入 SQLite（防重启丢失）
    8. 代码自优化 → 多轮验证通过后自动写入源代码（真正自我进化）
    9. 模型管理 → 自动检测降级、A/B对比、触发重训练
   10. 异常告警 → 检测预测质量、数据完整性、系统健康
    """

    def __init__(self):
        self.matcher = ResultMatcher()
        self.feedback = FeedbackEngine(learning_rate=0.15, decay_factor=0.92)
        self.evolution_history: List[Dict] = []
        self.total_iterations = 0
        self.last_evolution_at: Optional[datetime] = None

        # 代码自优化追踪
        self._weight_snapshots: List[Dict[str, float]] = []  # 最近N轮权重快照
        self._code_optimize_interval = 10  # 每10轮进化尝试一次代码写入
        self._last_code_write_iteration = 0

        # 模型管理
        from app.self_learning.model_manager import model_manager
        self.model_manager = model_manager

        # 告警管理
        from app.core.alerting import alert_manager
        self.alert_manager = alert_manager

    async def restore_from_database(self, db: AsyncSession, orchestrator=None, lottery_type: str = "ssq"):
        """
        从数据库恢复学习成果
        在系统启动时调用，加载之前进化得到的所有数据
        """
        from app.self_learning.persistence import persistence

        saved = await persistence.load_evolution_state(db, lottery_type)
        if not saved:
            logger.info(f"[进化引擎] 未发现已保存的进化状态 ({lottery_type})，从默认值开始")
            return False

        # 恢复进化引擎状态
        self.total_iterations = saved.get("total_iterations", 0)
        self.last_evolution_at = saved.get("last_evolution_at")

        # 恢复反馈引擎状态
        self.feedback.iteration = saved.get("feedback_iteration", 0)
        self.feedback.model_scores = {
            k: v for k, v in saved.get("model_scores", {}).items()
        }
        self.feedback.model_hits = {
            k: v for k, v in saved.get("model_hits", {}).items()
        }
        # feedback_count 用于显示
        saved_fb_count = saved.get("feedback_count", 0)
        if saved_fb_count > 0 and len(self.feedback.feedback_history) == 0:
            self.feedback.feedback_history = [
                {"iteration": i, "matches_processed": 0, "models_affected": [], "restored": True}
                for i in range(1, saved_fb_count + 1)
            ]

        # 恢复融合权重到 orchestrator
        fusion_weights = saved.get("fusion_weights", {})
        if orchestrator and fusion_weights:
            orchestrator.fusion_engine.base_weights = fusion_weights
            logger.info(f"[进化引擎] 恢复融合权重 ({lottery_type}): {fusion_weights}")

        # 恢复模型可信度
        credibility = saved.get("model_credibility", {})
        if orchestrator and credibility:
            for model_name, score in credibility.items():
                if model_name in orchestrator.models:
                    orchestrator.models[model_name].credibility_score = score
            logger.info(f"[进化引擎] 恢复模型可信度 ({lottery_type}): {credibility}")

        # 从数据库加载进化历史到内存
        try:
            db_history = await persistence.get_evolution_history(db, lottery_type, limit=100)
            self.evolution_history = [
                {
                    "iteration": h["iteration"],
                    "status": h["status"],
                    "matched_count": h["matched_count"],
                    "old_weights": h.get("old_weights"),
                    "new_weights": h.get("new_weights"),
                    "model_performance": h.get("model_performance"),
                    "credibility_updates": h.get("credibility_updates"),
                    "duration_seconds": h.get("duration_seconds"),
                    "started_at": h.get("created_at"),
                }
                for h in reversed(db_history)  # 反转回来保持时间顺序
            ]
            logger.info(f"[进化引擎] 恢复进化历史 ({lottery_type}): {len(self.evolution_history)} 条")
        except Exception as e:
            logger.warning(f"[进化引擎] 恢复进化历史失败: {e}")

        # 恢复记忆库
        try:
            from app.self_learning.persistence import persistence
            from app.memory_center.memory import global_memory
            high_score_mems = await persistence.load_high_score_memories(
                db, lottery_type, min_score=0.15, limit=100
            )
            for mem in high_score_mems:
                if mem["memory_type"] == "model" and mem["content"]:
                    exp = mem["content"]
                    model_name = exp.get("model_name", "")
                    if model_name:
                        global_memory.store_model_experience(model_name, exp)
            logger.info(f"[进化引擎] 恢复记忆库 ({lottery_type}): {len(high_score_mems)} 条高分记忆")
        except Exception as e:
            logger.warning(f"[进化引擎] 恢复记忆库失败: {e}")

        logger.info(
            f"[进化引擎] 状态恢复完成 ({lottery_type}): "
            f"iterations={self.total_iterations}, "
            f"models_loaded={len(credibility)}, "
            f"history_loaded={len(self.evolution_history)}"
        )
        return True

    async def run_evolution_cycle(
        self,
        db: AsyncSession,
        orchestrator=None,
        lottery_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        运行一个完整的进化周期

        Args:
            db: 数据库会话
            orchestrator: 编排器实例（用于更新模型权重）
            lottery_type: 彩票类型，None表示所有类型
        """
        start_time = datetime.now()
        self.total_iterations += 1
        cycle_result = {
            "iteration": self.total_iterations,
            "started_at": start_time.isoformat(),
            "lottery_type": lottery_type,
            "status": "started",
        }

        try:
            # Step 1: 匹配预测与实际结果
            logger.info(f"[进化引擎] 第{self.total_iterations}轮进化开始")
            match_results = await self.matcher.match_pending_predictions(
                db, lottery_type=lottery_type
            )
            cycle_result["matched_count"] = len(match_results)

            if not match_results:
                cycle_result["status"] = "no_new_data"
                logger.info("[进化引擎] 无新增匹配，跳过后续步骤")
                return cycle_result

            # Step 2: 反馈引擎处理匹配结果
            model_updates = self.feedback.process_match_results(match_results)
            cycle_result["model_updates"] = model_updates

            # Step 3: 更新各模型的可信度评分
            if orchestrator:
                credibility_updates = self.feedback.compute_credibility_updates()
                for model_name, credibility in credibility_updates.items():
                    if model_name in orchestrator.models:
                        orchestrator.models[model_name].credibility_score = credibility
                        logger.debug(
                            f"  模型 [{model_name}] 可信度 → {credibility:.4f}"
                        )
                cycle_result["credibility_updates"] = credibility_updates

            # Step 4: 进化融合权重
            if orchestrator:
                current_weights = orchestrator.fusion_engine.base_weights
                new_weights = self.feedback.compute_new_weights(current_weights)
                orchestrator.fusion_engine.base_weights = new_weights
                cycle_result["new_weights"] = new_weights
                cycle_result["old_weights"] = current_weights.copy()

            # Step 5: 模型性能报告
            model_performance = self.matcher.get_model_performance(window=30)
            cycle_result["model_performance"] = model_performance

            # Step 5.5: 模型降级检测 + A/B 对比 + 自动重训练
            degradation_results = await self._check_and_manage_models(
                match_results=match_results,
                model_updates=model_updates,
                credibility_updates=credibility_updates,
                orchestrator=orchestrator,
                db=db,
                lottery_type=lottery_type or "ssq",
            )
            cycle_result["model_management"] = degradation_results

            # Step 5.6: 预测质量 + 数据完整性告警检测
            alert_results = await self._check_alerts(
                match_results=match_results,
                db=db,
                lottery_type=lottery_type or "ssq",
            )
            cycle_result["alerts"] = alert_results

            # Step 6: 将高分经验存入记忆库
            self._store_high_value_experiences(match_results)

            cycle_result["status"] = "completed"
            cycle_result["duration_seconds"] = round(
                (datetime.now() - start_time).total_seconds(), 2
            )
            self.last_evolution_at = datetime.now()

            # Step 7: 持久化核心成果到 SQLite（防重启丢失）
            await self._persist_evolution_result(
                db=db,
                lottery_type=lottery_type or "ssq",
                cycle_result=cycle_result,
                orchestrator=orchestrator,
            )

            # Step 8: 记录权重快照，尝试代码自优化
            self._record_weight_snapshot(orchestrator)
            code_write_result = await self._try_code_optimization(
                lottery_type=lottery_type or "ssq",
                orchestrator=orchestrator,
            )
            cycle_result["code_write"] = code_write_result

            logger.info(
                f"[进化引擎] 第{self.total_iterations}轮进化完成: "
                f"匹配{len(match_results)}条, "
                f"更新{len(model_updates)}个模型, "
                f"耗时{cycle_result['duration_seconds']}s"
                + (f", 代码写入={code_write_result.get('action')}" if code_write_result else "")
            )

        except Exception as e:
            cycle_result["status"] = "error"
            cycle_result["error"] = str(e)
            logger.error(f"[进化引擎] 进化周期失败: {e}")

        self.evolution_history.append(cycle_result)
        return cycle_result

    def _store_high_value_experiences(self, match_results: List[MatchResult]):
        """将高分匹配经验存入长期记忆库"""
        from app.memory_center.memory import global_memory

        for match in match_results:
            if match.score >= 0.2:  # 至少命中20%才算有价值
                experience = {
                    "model_name": match.model_name,
                    "period": match.period,
                    "main_hits": match.main_hits,
                    "bonus_hits": match.bonus_hits,
                    "score": match.score,
                    "predicted_main": match.predicted_main,
                    "actual_main": match.actual_main,
                }
                global_memory.store_model_experience(
                    model_name=match.model_name,
                    experience=experience,
                )

    async def _persist_evolution_result(
        self,
        db: AsyncSession,
        lottery_type: str,
        cycle_result: Dict[str, Any],
        orchestrator=None,
    ):
        """
        将进化周期的核心成果持久化到 SQLite
        包括：融合权重、模型可信度、评分追踪、进化历史
        """
        from app.self_learning.persistence import persistence

        try:
            # 1. 收集当前状态
            fusion_weights = {}
            model_credibility = {}
            if orchestrator:
                fusion_weights = dict(orchestrator.fusion_engine.base_weights)
                model_credibility = {
                    name: model.credibility_score
                    for name, model in orchestrator.models.items()
                }

            # 2. 保存进化状态（权重、可信度、评分追踪）
            await persistence.save_evolution_state(
                db=db,
                lottery_type=lottery_type,
                fusion_weights=fusion_weights,
                model_credibility=model_credibility,
                model_scores=dict(self.feedback.model_scores),
                model_hits=dict(self.feedback.model_hits),
                total_iterations=self.total_iterations,
                feedback_iteration=self.feedback.iteration,
                feedback_count=len(self.feedback.feedback_history),
                last_evolution_at=self.last_evolution_at,
            )

            # 3. 保存进化历史记录
            await persistence.save_evolution_history(
                db=db,
                lottery_type=lottery_type,
                cycle_result=cycle_result,
            )

            # 4. 持久化高分记忆到 SQLite
            await self._persist_memory(db, lottery_type, cycle_result)

            logger.info(f"[进化引擎] 持久化完成 ({lottery_type}): 权重+可信度+历史已写入数据库")

        except Exception as e:
            logger.error(f"[进化引擎] 持久化失败 ({lottery_type}): {e}，内存数据不受影响")

    async def _persist_memory(
        self,
        db: AsyncSession,
        lottery_type: str,
        cycle_result: Dict[str, Any],
    ):
        """将高分经验写入 memory_records 表"""
        from app.self_learning.persistence import persistence
        from app.memory_center.memory import global_memory

        # 写入模型经验
        for model_name, experiences in global_memory.model_memory.items():
            # 只保存最新的几条高分经验
            recent_high = sorted(
                experiences,
                key=lambda x: x.get("experience", {}).get("score", 0),
                reverse=True,
            )[:10]
            for exp_entry in recent_high:
                exp = exp_entry.get("experience", {})
                score = exp.get("score", 0)
                if score >= 0.15:
                    try:
                        await persistence.save_memory(
                            db=db,
                            memory_type="model",
                            content=exp,
                            lottery_type=lottery_type,
                            period=exp.get("period", ""),
                            score=score,
                            tags=["evolution", f"model_{model_name}"],
                        )
                    except Exception as e:
                        logger.debug(f"[持久化] 保存记忆失败: {e}")

    async def run_manual_feedback(
        self,
        db: AsyncSession,
        orchestrator=None,
        period: Optional[str] = None,
        lottery_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        手动触发反馈（针对特定期号或类型）
        """
        result = await self.run_evolution_cycle(
            db=db,
            orchestrator=orchestrator,
            lottery_type=lottery_type,
        )
        return result

    # ============================================================
    # 模型管理：降级检测 + A/B 对比 + 自动重训练
    # ============================================================

    async def _check_and_manage_models(
        self,
        match_results: List,
        model_updates: Dict,
        credibility_updates: Dict,
        orchestrator=None,
        db=None,
        lottery_type: str = "ssq",
    ) -> Dict[str, Any]:
        """
        每轮进化后检测模型状态，执行必要的管理操作
        """
        results = {"degradation": [], "ab_compare": [], "retrain": []}

        # 1. 收集本轮各模型的分数和趋势
        feedback_report = self.feedback.get_evolution_report()
        model_summaries = feedback_report.get("models", {})

        for model_name, summary in model_summaries.items():
            current_score = summary.get("recent_avg_score", 0)
            trend = summary.get("trend", "stable")
            credibility = credibility_updates.get(model_name, 0.5)

            # 降级检测
            degradation = self.model_manager.detect_degradation(
                model_name=model_name,
                current_score=current_score,
                trend=trend,
                credibility=credibility,
                orchestrator=orchestrator,
            )

            if degradation.get("action") != "none":
                results["degradation"].append(degradation)

                # 告警：模型降级
                self.alert_manager.send_alert(
                    level=AlertLevel.WARNING if degradation["action"] == "degraded" else AlertLevel.ERROR,
                    category=AlertCategory.MODEL_HEALTH,
                    title=f"模型 {model_name} {degradation['action']}",
                    detail=degradation.get("reason", ""),
                    dedup_key=f"model:{degradation['action']}:{model_name}",
                )

        # 2. 每 5 轮做一次全量 A/B 对比
        if self.total_iterations % 5 == 0 and len(self.model_manager.models) >= 2:
            ab_results = self.model_manager.compare_all_models(window=20)
            results["ab_compare"] = [
                {"winner": r["winner"], "a": r["model_a"], "b": r["model_b"],
                 "margin": r.get("margin", 0)}
                for r in ab_results[:5]
            ]

        # 3. 自动重训练降级模型（每 10 轮）
        if self.total_iterations % 10 == 0:
            retrain_results = await self.model_manager.auto_retrain_degraded_models(
                orchestrator=orchestrator,
                db=db,
            )
            results["retrain"] = retrain_results

        return results

    # ============================================================
    # 告警检测：预测质量 + 数据完整性
    # ============================================================

    async def _check_alerts(
        self,
        match_results: List,
        db=None,
        lottery_type: str = "ssq",
    ) -> Dict[str, Any]:
        """每轮进化后检测系统异常"""
        results = {"prediction_quality": [], "data_integrity": []}

        # 1. 预测质量检测
        current_scores = {}
        for match in match_results:
            current_scores[match.model_name] = match.score

        if current_scores:
            # 获取历史平均分数用于对比
            historical_avg = {}
            for name in current_scores:
                scores = self.feedback.model_scores.get(name, [])
                if scores:
                    historical_avg[name] = sum(scores) / len(scores)

            quality_alerts = self.alert_manager.check_prediction_quality(
                current_scores=current_scores,
                historical_avg=historical_avg,
            )
            results["prediction_quality"] = [
                {"level": a.level.value, "title": a.title} for a in quality_alerts
            ]

        # 2. 数据完整性检测
        try:
            from sqlalchemy import select
            from app.database.models import LotteryDraw
            latest_result = await db.execute(
                select(LotteryDraw.draw_date, LotteryDraw.period)
                .where(LotteryDraw.lottery_type == lottery_type)
                .order_by(LotteryDraw.draw_date.desc())
                .limit(1)
            )
            row = latest_result.first()
            if row:
                latest_date, latest_period = row
                days_ago = (datetime.now() - latest_date).days
                data_alerts = self.alert_manager.check_data_integrity(
                    latest_period=latest_period,
                    days_since_last_draw=days_ago,
                )
                results["data_integrity"] = [
                    {"level": a.level.value, "title": a.title} for a in data_alerts
                ]
        except Exception as e:
            logger.debug(f"[告警] 数据完整性检测失败: {e}")

        return results

    def get_evolution_status(self) -> Dict[str, Any]:
        """获取进化引擎状态"""
        return {
            "total_iterations": self.total_iterations,
            "last_evolution_at": (
                self.last_evolution_at.isoformat()
                if self.last_evolution_at else None
            ),
            "feedback_report": self.feedback.get_evolution_report(),
            "recent_matches": self.matcher.get_recent_matches(limit=10),
            "model_performance": self.matcher.get_model_performance(window=30),
            "model_management": self.model_manager.get_summary(),
            "alerts": self.alert_manager.get_summary(),
        }

    def get_evolution_history(self, limit: int = 20) -> List[Dict]:
        """获取进化历史"""
        return self.evolution_history[-limit:]

    # ============================================================
    # 代码自优化
    # ============================================================

    def _record_weight_snapshot(self, orchestrator=None):
        """记录当前权重快照，用于判断权重是否收敛稳定"""
        if not orchestrator:
            return
        snapshot = dict(orchestrator.fusion_engine.base_weights)
        self._weight_snapshots.append(snapshot)
        # 保留最近50轮快照
        if len(self._weight_snapshots) > 50:
            self._weight_snapshots = self._weight_snapshots[-50:]

    def _check_weight_stability(self) -> Tuple[bool, float]:
        """
        检查权重是否已收敛稳定
        返回 (is_stable, stability_score)
        stability_score 越高说明权重越稳定
        """
        if len(self._weight_snapshots) < 5:
            return False, 0.0

        recent = self._weight_snapshots[-10:]  # 最近10轮
        if len(recent) < 5:
            return False, 0.0

        # 计算每轮权重的标准差，取平均值
        import numpy as np
        all_models = set()
        for snap in recent:
            all_models.update(snap.keys())

        variances = []
        for model in all_models:
            values = [snap.get(model, 0) for snap in recent]
            if len(values) >= 3:
                std = np.std(values)
                mean = np.mean(values) if np.mean(values) > 0 else 0.01
                variances.append(std / mean)  # 变异系数

        if not variances:
            return False, 0.0

        avg_cv = np.mean(variances)
        # CV < 0.05 说明权重很稳定（波动<5%）
        stability = max(0.0, 1.0 - avg_cv * 10)
        is_stable = avg_cv < 0.05

        return is_stable, stability

    def _compute_improvement_from_history(self) -> float:
        """
        从进化历史计算平均改进幅度
        比较最近几轮与前几轮的模型表现
        """
        if len(self.evolution_history) < 6:
            return 0.0

        recent = self.evolution_history[-5:]
        earlier = self.evolution_history[-10:-5]

        def avg_perf(entries):
            scores = []
            for e in entries:
                perf = e.get("model_performance", {})
                if isinstance(perf, dict):
                    for v in perf.values():
                        if isinstance(v, (int, float)):
                            scores.append(v)
            return sum(scores) / len(scores) if scores else 0

        recent_avg = avg_perf(recent)
        earlier_avg = avg_perf(earlier)

        if earlier_avg <= 0:
            return 0.0

        improvement = (recent_avg - earlier_avg) / earlier_avg
        return max(0.0, improvement)

    async def _try_code_optimization(
        self,
        lottery_type: str,
        orchestrator=None,
    ) -> Optional[Dict[str, Any]]:
        """
        尝试将验证通过的优化写入源代码

        条件:
        1. 达到代码优化间隔（默认每10轮）
        2. 权重已收敛稳定（变异系数 < 5%）
        3. 平均改进幅度 > 阈值（5%）
        """
        # 检查是否需要尝试
        if self.total_iterations - self._last_code_write_iteration < self._code_optimize_interval:
            return None

        is_stable, stability = self._check_weight_stability()
        if not is_stable:
            logger.debug(
                f"[代码优化] 权重尚未收敛 (stability={stability:.3f})，跳过代码写入"
            )
            return {"action": "skip", "reason": f"权重未收敛 (stability={stability:.3f})"}

        improvement = self._compute_improvement_from_history()
        if improvement < 0.05:
            logger.debug(
                f"[代码优化] 改进幅度不足 (improvement={improvement:.3f})，跳过代码写入"
            )
            return {"action": "skip", "reason": f"改进幅度不足 (improvement={improvement:.3f})"}

        # 收集当前最优参数
        try:
            from app.self_learning.code_writer import code_writer

            # 进化后的权重
            evolved_weights = {}
            if orchestrator:
                evolved_weights = dict(orchestrator.fusion_engine.base_weights)

            # 进化后的学习参数（基于反馈引擎的当前表现）
            evolved_learning_rate = None
            evolved_decay_factor = None
            if len(self.feedback.feedback_history) >= 20:
                # 根据历史反馈动态调整学习率
                # 趋势上升 → 增大学习率；趋势下降 → 减小学习率
                report = self.feedback.get_evolution_report()
                models = report.get("models", {})
                trending_up = sum(
                    1 for m in models.values()
                    if m.get("trend") == "improving"
                )
                trending_down = sum(
                    1 for m in models.values()
                    if m.get("trend") == "declining"
                )
                total = len(models)
                if total > 0 and trending_up > trending_down:
                    # 趋势向好，适度增大学习率
                    evolved_learning_rate = min(0.25, self.feedback.learning_rate * 1.05)
                    evolved_decay_factor = max(0.88, self.feedback.decay_factor * 0.995)
                elif trending_down > trending_up:
                    # 趋势变差，减小学习率
                    evolved_learning_rate = max(0.08, self.feedback.learning_rate * 0.95)
                    evolved_decay_factor = min(0.97, self.feedback.decay_factor * 1.005)

            # 执行代码优化
            result = code_writer.auto_optimize_from_evolution(
                evolved_weights=evolved_weights,
                evolved_learning_rate=evolved_learning_rate,
                evolved_decay_factor=evolved_decay_factor,
                validation_rounds=min(
                    len(self._weight_snapshots),
                    self._code_optimize_interval,
                ),
                avg_improvement=improvement,
                dry_run=False,  # 实际写入
            )

            self._last_code_write_iteration = self.total_iterations

            written_count = sum(
                len(r.get("changes", []))
                for r in [result.get("weights"), result.get("learning"), result.get("fusion")]
                if r and r.get("action") == "written"
            )

            if written_count > 0:
                logger.info(
                    f"[代码优化] 成功写入 {written_count} 项优化到源代码! "
                    f"(稳定性={stability:.3f}, 改进={improvement:.3f})"
                )

            return result

        except Exception as e:
            logger.error(f"[代码优化] 执行失败: {e}")
            return {"action": "error", "error": str(e)}


# 全局进化引擎实例
evolution_engine = EvolutionEngine()
