"""
V70 彩票AI工作台 - 贝叶斯权重调整
根据模型历史表现动态调整权重
"""
import numpy as np
from typing import Dict, List
from loguru import logger


class BayesianWeightAdjuster:
    """贝叶斯权重调整器"""

    def __init__(self, prior_alpha: float = 1.0):
        self.prior_alpha = prior_alpha  # Dirichlet先验参数
        self.performance_counts: Dict[str, List[int]] = {}  # 成功/失败计数

    def update(self, model_name: str, success: bool):
        """更新模型表现"""
        if model_name not in self.performance_counts:
            self.performance_counts[model_name] = [0, 0]  # [success, failure]
        if success:
            self.performance_counts[model_name][0] += 1
        else:
            self.performance_counts[model_name][1] += 1

    def get_posterior_weights(self, model_names: List[str]) -> Dict[str, float]:
        """
        计算后验权重
        使用Beta-Binomial共轭: Beta(α + success, β + failure)
        """
        weights = {}
        for name in model_names:
            if name in self.performance_counts:
                s, f = self.performance_counts[name]
                # 后验均值
                posterior_mean = (self.prior_alpha + s) / (2 * self.prior_alpha + s + f)
                weights[name] = posterior_mean
            else:
                weights[name] = 0.5  # 无数据时默认

        # 归一化
        total = sum(weights.values())
        if total > 0:
            weights = {k: v / total for k, v in weights.items()}

        return weights

    def get_model_credibility(self, model_name: str) -> float:
        """获取单个模型的可信度"""
        if model_name not in self.performance_counts:
            return 0.5
        s, f = self.performance_counts[model_name]
        total = s + f
        if total == 0:
            return 0.5
        # Wilson score interval 下界
        z = 1.96  # 95% confidence
        p = s / total
        denominator = 1 + z**2 / total
        centre = (p + z**2 / (2 * total)) / denominator
        margin = z * np.sqrt(p * (1-p) / total + z**2 / (4 * total**2)) / denominator
        return max(0.1, centre - margin)
