"""
V70 彩票AI工作台 - 概率融合模块
高级概率融合方法
"""
import numpy as np
from typing import List, Dict


class ProbabilityFusion:
    """概率融合"""

    @staticmethod
    def weighted_average(probs_list: List[np.ndarray], weights: List[float]) -> np.ndarray:
        """加权平均融合"""
        result = np.zeros_like(probs_list[0])
        for prob, w in zip(probs_list, weights):
            result += prob * w
        return result / sum(weights)

    @staticmethod
    def bayesian_fusion(probs_list: List[np.ndarray], priors: List[float]) -> np.ndarray:
        """贝叶斯融合"""
        result = np.ones_like(probs_list[0])
        for prob, prior in zip(probs_list, priors):
            # P(x|models) ∝ Π P(model_i|x) × P(x)
            result *= (prob * prior + 1e-8)
        return result / result.sum()

    @staticmethod
    def log_opinion_pool(probs_list: List[np.ndarray], weights: List[float]) -> np.ndarray:
        """对数意见池"""
        result = np.zeros_like(probs_list[0])
        for prob, w in zip(probs_list, weights):
            result += w * np.log(prob + 1e-8)
        result = np.exp(result)
        return result / result.sum()

    @staticmethod
    def mixture_of_experts(probs_list: List[np.ndarray],
                           gate_weights: np.ndarray) -> np.ndarray:
        """混合专家模型"""
        result = np.zeros_like(probs_list[0])
        for i, prob in enumerate(probs_list):
            result += gate_weights[i] * prob
        return result / result.sum()
