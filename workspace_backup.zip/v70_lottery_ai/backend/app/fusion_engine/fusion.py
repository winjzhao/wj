"""
V70 彩票AI工作台 - 融合决策引擎 (Fusion Decision Engine)
将多个AI模型的输出进行加权融合，生成最终决策
"""
import numpy as np
from typing import Dict, List, Any, Tuple, Optional
from loguru import logger
from dataclasses import dataclass, field
from app.config.settings import settings
from app.core.lottery_schema import get_schema


def _safe_normalize(probs: np.ndarray) -> np.ndarray:
    """安全归一化概率向量，处理 NaN、Inf、全零等边界情况。"""
    probs = np.nan_to_num(probs, nan=0.0, posinf=0.0, neginf=0.0)
    probs = np.clip(probs, 0, None)
    total = probs.sum()
    if total > 0:
        return probs / total
    else:
        # 全零时退化为均匀分布
        return np.ones_like(probs) / len(probs)


@dataclass
class ModelOutput:
    """单个模型输出"""
    name: str
    red_probs: List[float]    # 主球区概率向量（向后兼容）
    blue_probs: List[float]   # 附加球区概率向量（向后兼容）
    confidence: float
    credibility: float = 0.5


@dataclass
class FusionResult:
    """融合结果"""
    main_probs: List[float]
    bonus_probs: List[float]
    final_score: float
    model_contributions: Dict[str, float]
    candidates: List[Dict] = field(default_factory=list)


class FusionEngine:
    """
    融合决策引擎
    核心功能：
    1. 多模型输出加权融合
    2. 贝叶斯权重调整
    3. 候选方案生成
    4. 评分排序
    """

    def __init__(self):
        # 默认权重（会根据历史表现动态调整）
        self.base_weights = {
            "XGBoost": settings.XGBOOST_WEIGHT,
            "LSTM": settings.LSTM_WEIGHT,
            "Transformer": settings.TRANSFORMER_WEIGHT,
            "PPO": settings.PPO_WEIGHT,
            "Statistic": settings.STATISTIC_WEIGHT,
            "Behavior": settings.BEHAVIOR_WEIGHT,
        }
        self.credibility_history: Dict[str, List[float]] = {}
        self.fusion_count = 0

    def fuse(self, model_outputs: List[ModelOutput], lottery_type: str = "ssq") -> FusionResult:
        """
        融合多个模型输出
        公式: Final_Prob = Σ(Model_Prob × Model_Credibility × Base_Weight)
        """
        if not model_outputs:
            raise ValueError("没有模型输出可供融合")

        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]
        bonus_dims = schema["bonus_dims"]
        total_bonus_dim = sum(bonus_dims)

        # 1. 计算动态权重
        weights = self._calculate_weights(model_outputs)

        # 2. 加权融合主球区概率
        main_fused = np.zeros(main_dim)
        for mo in model_outputs:
            w = weights.get(mo.name, 0.1)
            probs = np.array(mo.red_probs)
            # 如果模型输出维度匹配，直接使用；否则截断或填充
            if len(probs) == main_dim:
                main_fused += probs * w
            elif len(probs) > main_dim:
                main_fused += probs[:main_dim] * w
            else:
                padded = np.zeros(main_dim)
                padded[:len(probs)] = probs
                main_fused += padded * w

        main_fused = _safe_normalize(main_fused)

        # 3. 加权融合附加球区概率
        if total_bonus_dim > 0:
            bonus_fused = np.zeros(total_bonus_dim)
            for mo in model_outputs:
                w = weights.get(mo.name, 0.1)
                probs = np.array(mo.blue_probs)
                if len(probs) == total_bonus_dim:
                    bonus_fused += probs * w
                elif len(probs) > total_bonus_dim:
                    bonus_fused += probs[:total_bonus_dim] * w
                else:
                    padded = np.zeros(total_bonus_dim)
                    padded[:len(probs)] = probs
                    bonus_fused += padded * w
            bonus_fused = _safe_normalize(bonus_fused)
        else:
            bonus_fused = np.array([])

        # 4. 生成候选方案
        candidates = self._generate_candidates(main_fused, bonus_fused, lottery_type)

        # 5. 计算最终评分
        final_score = self._calculate_final_score(main_fused, candidates)

        # 6. 记录融合历史
        self.fusion_count += 1
        self._update_history(model_outputs, weights)

        logger.info(f"融合完成 (#{self.fusion_count}): "
                     f"参与模型={len(model_outputs)}, "
                     f"候选方案={len(candidates)}, "
                     f"最终评分={final_score:.2f}")

        return FusionResult(
            main_probs=main_fused.tolist(),
            bonus_probs=bonus_fused.tolist(),
            final_score=final_score,
            model_contributions=weights,
            candidates=candidates,
        )

    def _calculate_weights(self, model_outputs: List[ModelOutput]) -> Dict[str, float]:
        """
        计算动态权重
        权重 = 基础权重 × 可信度 / 归一化因子
        """
        raw_weights = {}
        for mo in model_outputs:
            base_w = self.base_weights.get(mo.name, 0.2)
            credibility = mo.credibility
            raw_weights[mo.name] = base_w * credibility * mo.confidence

        # 归一化
        total = sum(raw_weights.values())
        if total > 0:
            normalized = {k: v / total for k, v in raw_weights.items()}
        else:
            n = len(model_outputs)
            normalized = {mo.name: 1.0 / n for mo in model_outputs}

        return normalized

    def _generate_candidates(self, main_probs: np.ndarray, bonus_probs: np.ndarray,
                              lottery_type: str = "ssq") -> List[Dict]:
        """
        生成候选方案
        流程: 概率采样 → 结构筛选 → 低撞过滤 → 评分排序
        """
        schema = get_schema(lottery_type)
        main_count = schema["main_count"]
        main_range = schema["main_balls"]["range"]
        main_lo, main_hi = main_range
        main_dim = main_hi - main_lo + 1

        bonus_cfgs = schema["bonus_balls"]
        total_bonus_count = sum(b["count"] for b in bonus_cfgs)

        candidates = []
        n_candidates = min(settings.CANDIDATE_COUNT, 5000)  # 限制计算量

        # 确保概率合法
        main_probs = np.nan_to_num(main_probs, nan=0.0, posinf=0.0, neginf=0.0)
        main_probs = np.clip(main_probs, 0, 1)
        main_probs = _safe_normalize(main_probs)

        has_bonus = total_bonus_count > 0 and len(bonus_probs) > 0
        if has_bonus:
            bonus_probs = np.nan_to_num(bonus_probs, nan=0.0, posinf=0.0, neginf=0.0)
            bonus_probs = np.clip(bonus_probs, 0, 1)
            bonus_probs = _safe_normalize(bonus_probs)

        # 基于概率分布采样
        for _ in range(n_candidates):
            # 从概率分布中采样主球区号码
            main_balls = [int(x) for x in (np.random.choice(main_dim, size=main_count, replace=False, p=main_probs) + main_lo)]
            main_balls.sort()

            # 采样附加球
            bonus_balls_list = []
            if has_bonus:
                offset = 0
                for cfg in bonus_cfgs:
                    count = cfg["count"]
                    lo, hi = cfg["range"]
                    sub_dim = hi - lo + 1
                    sub_probs = bonus_probs[offset:offset + sub_dim]
                    sub_probs = np.nan_to_num(sub_probs, nan=0.0, posinf=0.0, neginf=0.0)
                    sub_probs = np.clip(sub_probs, 0, 1)
                    sub_probs = _safe_normalize(sub_probs)
                    balls = [int(x) for x in (np.random.choice(sub_dim, size=count, replace=False, p=sub_probs) + lo)]
                    balls.sort()
                    bonus_balls_list.append(balls)
                    offset += sub_dim

            # 结构筛选
            if not self._structure_filter(main_balls, lottery_type):
                continue

            # 计算各项评分
            score = self._score_candidate(main_balls, bonus_balls_list, main_probs, bonus_probs, lottery_type)
            candidates.append({
                "main_balls": main_balls,
                "bonus_balls": bonus_balls_list,
                "score": score,
            })

        # 低撞过滤（去重+去除常见组合）
        candidates = self._low_collision_filter(candidates)

        # 按评分排序
        candidates.sort(key=lambda x: x["score"], reverse=True)

        # 保留TOP方案
        return candidates[:settings.TOP_RESULTS]

    def _structure_filter(self, main_balls: List[int], lottery_type: str = "ssq") -> bool:
        """结构筛选 - 过滤不合理组合（根据彩票类型自适应）"""
        schema = get_schema(lottery_type)
        main_count = schema["main_count"]
        main_lo, main_hi = schema["main_balls"]["range"]

        if lottery_type == "ssq":
            # 双色球结构筛选
            red_sum = sum(main_balls)
            if red_sum < 40 or red_sum > 180:
                return False
            span = max(main_balls) - min(main_balls)
            if span < 10 or span > 32:
                return False
            odd_count = sum(1 for r in main_balls if r % 2 == 1)
            if odd_count == 0 or odd_count == 6:
                return False
            zone1 = sum(1 for r in main_balls if r <= 11)
            zone2 = sum(1 for r in main_balls if 12 <= r <= 22)
            zone3 = sum(1 for r in main_balls if r >= 23)
            if zone1 == 6 or zone2 == 6 or zone3 == 6:
                return False

        elif lottery_type == "dlt":
            # 大乐透结构筛选
            main_sum = sum(main_balls)
            if main_sum < 30 or main_sum > 155:
                return False
            span = max(main_balls) - min(main_balls)
            if span < 8 or span > 34:
                return False
            odd_count = sum(1 for r in main_balls if r % 2 == 1)
            if odd_count == 0 or odd_count == 5:
                return False

        elif lottery_type == "k8":
            # 快乐8结构筛选
            if len(main_balls) != 20:
                return False
            main_sum = sum(main_balls)
            # 20个号码和值在合理范围 (理论最小1+2+...+20=210, 最大61+...+80=1410)
            if main_sum < 400 or main_sum > 1200:
                return False
            odd_count = sum(1 for r in main_balls if r % 2 == 1)
            if odd_count <= 2 or odd_count >= 18:
                return False

        return True

    def _score_candidate(self, main_balls: List[int], bonus_balls_list: List[List[int]],
                          main_probs: np.ndarray, bonus_probs: np.ndarray,
                          lottery_type: str = "ssq") -> float:
        """
        候选方案评分
        Final Score = 模型概率 + 结构评分 + 稳定性评分
        """
        schema = get_schema(lottery_type)
        main_lo = schema["main_balls"]["range"][0]
        main_count = schema["main_count"]

        # 模型概率评分
        prob_score = sum(main_probs[r - main_lo] for r in main_balls) / main_count

        # 附加球概率评分
        if bonus_balls_list and len(bonus_probs) > 0:
            bonus_cfgs = schema["bonus_balls"]
            bonus_score = 0
            offset = 0
            for balls, cfg in zip(bonus_balls_list, bonus_cfgs):
                lo = cfg["range"][0]
                count = cfg["count"]
                sub_dim = cfg["range"][1] - lo + 1
                for b in balls:
                    if b - lo < len(bonus_probs):
                        bonus_score += bonus_probs[b - lo]
                offset += sub_dim
            total_bonus_count = sum(b["count"] for b in bonus_cfgs)
            if total_bonus_count > 0:
                bonus_score = bonus_score / total_bonus_count
            prob_score = (prob_score + bonus_score) / 2.0
        else:
            prob_score = prob_score

        # 结构评分
        main_sum = sum(main_balls)
        structure_score = 1.0

        if lottery_type == "ssq":
            if 80 <= main_sum <= 130:
                structure_score += 0.2
            span = max(main_balls) - min(main_balls)
            if 18 <= span <= 28:
                structure_score += 0.1
        elif lottery_type == "dlt":
            if 50 <= main_sum <= 120:
                structure_score += 0.2
            span = max(main_balls) - min(main_balls)
            if 15 <= span <= 30:
                structure_score += 0.1
        elif lottery_type == "k8":
            if 600 <= main_sum <= 1000:
                structure_score += 0.2

        # 稳定性评分
        stability_score = 1.0 / (1.0 + np.std([main_probs[r - main_lo] for r in main_balls]))

        final = prob_score * 0.5 + structure_score * 0.3 + stability_score * 0.2
        return round(final * 100, 2)

    def _low_collision_filter(self, candidates: List[Dict]) -> List[Dict]:
        """低撞过滤 - 去重"""
        seen = set()
        filtered = []
        for c in candidates:
            key = tuple(sorted(c["main_balls"]))
            if "bonus_balls" in c and c["bonus_balls"]:
                for b_list in c["bonus_balls"]:
                    key += tuple(sorted(b_list))
            if key not in seen:
                seen.add(key)
                filtered.append(c)
        return filtered

    def _calculate_final_score(self, main_probs: np.ndarray,
                                candidates: List[Dict]) -> float:
        """计算融合引擎的最终评分"""
        if not candidates:
            return 0.0

        # 基于候选方案的评分分布
        scores = [c["score"] for c in candidates]
        mean_score = np.mean(scores)
        std_score = np.std(scores)

        # 分数越高且越集中，说明模型一致性好
        return float(mean_score / (1.0 + std_score * 0.1))

    def _update_history(self, model_outputs: List[ModelOutput],
                        weights: Dict[str, float]):
        """更新融合历史"""
        for mo in model_outputs:
            if mo.name not in self.credibility_history:
                self.credibility_history[mo.name] = []
            self.credibility_history[mo.name].append(mo.credibility)

    def update_weights(self, new_weights: Dict[str, float]):
        """动态更新模型权重（由调度器在训练评估后调用）"""
        self.base_weights.update(new_weights)
        logger.info(f"融合引擎权重已动态更新: {self.base_weights}")

    def get_engine_status(self) -> Dict:
        """获取引擎状态"""
        return {
            "fusion_count": self.fusion_count,
            "current_weights": self.base_weights,
            "model_count": len(self.credibility_history),
        }
