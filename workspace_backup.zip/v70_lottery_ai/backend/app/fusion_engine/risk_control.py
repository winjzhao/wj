"""
V70 彩票AI工作台 - 风险控制模块
对预测结果进行风险评估和控制
"""
import numpy as np
from typing import List, Dict
from loguru import logger
from app.core.lottery_schema import get_schema


class RiskController:
    """风险控制器"""

    def __init__(self):
        self.max_single_bet = 100      # 单注最大金额
        self.max_total_bet = 500       # 总投注上限
        self.risk_threshold = 0.7      # 风险阈值
        self.risk_history = []

    def assess_risk(self, candidates: List[Dict], lottery_type: str = "ssq") -> Dict:
        """评估候选方案的风险"""
        if not candidates:
            return {"risk_level": "unknown", "score": 0}

        schema = get_schema(lottery_type)
        main_count = schema["main_count"]

        # 计算方案分散度
        all_main = []
        for c in candidates:
            all_main.extend(c.get("main_balls", c.get("reds", [])))

        # 号码集中度风险
        unique_main = len(set(all_main))
        expected_total = len(candidates) * main_count
        concentration_risk = 1.0 - (unique_main / max(expected_total, 1))

        # 评分波动风险
        scores = [c["score"] for c in candidates]
        score_volatility = np.std(scores) / (np.mean(scores) + 1e-8)

        # 综合风险评分
        risk_score = concentration_risk * 0.5 + score_volatility * 0.5

        if risk_score < 0.3:
            level = "low"
        elif risk_score < 0.6:
            level = "medium"
        else:
            level = "high"

        self.risk_history.append(risk_score)
        if len(self.risk_history) > 50:
            self.risk_history = self.risk_history[-50:]

        return {
            "risk_level": level,
            "risk_score": round(risk_score, 4),
            "concentration_risk": round(concentration_risk, 4),
            "score_volatility": round(score_volatility, 4),
        }

    def apply_risk_limits(self, candidates: List[Dict]) -> List[Dict]:
        """应用风险限制"""
        # 过滤高风险方案
        filtered = [c for c in candidates if c["score"] > 30]
        return filtered[:10]  # 最多返回10个方案

    def get_risk_report(self) -> Dict:
        """获取风险报告"""
        if not self.risk_history:
            return {"avg_risk": 0, "trend": "stable"}

        avg_risk = np.mean(self.risk_history)
        recent_trend = self.risk_history[-10:] if len(self.risk_history) >= 10 else self.risk_history
        trend = "increasing" if np.polyfit(range(len(recent_trend)), recent_trend, 1)[0] > 0.01 else "stable"

        return {
            "avg_risk": round(float(avg_risk), 4),
            "trend": trend,
            "sample_count": len(self.risk_history),
        }
