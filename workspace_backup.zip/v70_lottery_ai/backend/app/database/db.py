"""
V70 彩票AI工作台 - 数据库连接管理
"""
import os
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from app.database.models import Base
from app.config.settings import settings
from loguru import logger
from pathlib import Path

# 确保数据目录存在
Path("data").mkdir(exist_ok=True)

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    future=True,
)

AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def run_migrations():
    """
    运行 Alembic 数据库迁移
    优先使用 Alembic 迁移，如果迁移失败则降级到 create_all
    """
    try:
        from alembic.config import Config
        from alembic import command

        # 获取项目根目录
        base_dir = Path(__file__).parent.parent.parent
        alembic_ini = base_dir / "alembic.ini"

        if alembic_ini.exists():
            alembic_cfg = Config(str(alembic_ini))

            # 检查当前数据库是否有 alembic_version 表
            async with engine.begin() as conn:

                def check_alembic_version(connection):
                    from sqlalchemy import inspect
                    inspector = inspect(connection)
                    return "alembic_version" in inspector.get_table_names()

                has_alembic = await conn.run_sync(check_alembic_version)

            if has_alembic:
                # 已有 alembic 版本记录，执行升级
                logger.info("检测到 Alembic 版本记录，执行迁移升级...")
                command.upgrade(alembic_cfg, "head")
            else:
                # 检查是否是新数据库
                async with engine.begin() as conn:

                    def check_tables(connection):
                        from sqlalchemy import inspect
                        inspector = inspect(connection)
                        tables = inspector.get_table_names()
                        return len(tables) > 0

                    has_tables = await conn.run_sync(check_tables)

                if has_tables:
                    # 已有表但没有 alembic 记录，标记当前版本
                    logger.info("数据库已有表但无 Alembic 记录，标记当前版本为 head...")
                    command.stamp(alembic_cfg, "head")
                else:
                    # 全新数据库，执行完整迁移
                    logger.info("全新数据库，执行 Alembic 迁移...")
                    command.upgrade(alembic_cfg, "head")

            logger.info("Alembic 迁移完成")
            return

    except ImportError:
        logger.warning("Alembic 未安装，降级到 create_all")
    except Exception as e:
        logger.warning(f"Alembic 迁移失败: {e}，降级到 create_all")

    # 降级：使用 SQLAlchemy create_all
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("数据库初始化完成 (create_all)")


async def init_db():
    """初始化数据库（优先使用 Alembic 迁移，降级到 create_all）"""
    await run_migrations()
    # 确保新字段存在（处理已有数据库的列缺失问题）
    await _ensure_new_columns()


async def _ensure_new_columns():
    """
    确保新添加的字段在已有数据库中存在
    用于增量升级场景，避免 Alembic 迁移失败时列缺失
    """
    from sqlalchemy import text, inspect

    new_columns = {
        "predictions": {
            "actual_main_balls": "JSON",
            "actual_bonus_balls": "JSON",
            "match_main_count": "INTEGER",
            "match_bonus_count": "INTEGER",
            "match_total": "INTEGER",
            "match_hit_rate": "FLOAT",
            "matched_at": "DATETIME",
        },
    }

    async with engine.begin() as conn:
        for table_name, columns in new_columns.items():
            # 获取已有列名
            def get_columns(connection, tbl):
                insp = inspect(connection)
                return [c["name"] for c in insp.get_columns(tbl)]

            existing_cols = await conn.run_sync(get_columns, table_name)

            for col_name, col_type in columns.items():
                if col_name not in existing_cols:
                    try:
                        await conn.execute(
                            text(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_type}")
                        )
                        logger.info(f"已添加列: {table_name}.{col_name} ({col_type})")
                    except Exception as e:
                        logger.warning(f"添加列 {table_name}.{col_name} 失败（可能已存在）: {e}")


async def close_db():
    """关闭数据库连接"""
    await engine.dispose()
    logger.info("数据库连接已关闭")


async def get_db():
    """获取数据库会话（依赖注入）"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()
