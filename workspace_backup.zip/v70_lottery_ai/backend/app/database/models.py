"""
V70 彩票AI工作台 - 数据库模型
"""
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, JSON, Text, Boolean, ForeignKey
)
from sqlalchemy.orm import DeclarativeBase, relationship
from datetime import datetime
from app.core.lottery_schema import get_schema


class Base(DeclarativeBase):
    pass


class LotteryDraw(Base):
    """开奖数据表 - 支持多彩票类型"""
    __tablename__ = "lottery_draws"

    id = Column(Integer, primary_key=True, autoincrement=True)
    period = Column(String(20), unique=True, nullable=False, index=True)
    draw_date = Column(DateTime, nullable=False)
    lottery_type = Column(String(10), default="ssq")

    # 红球 6个（SSQ） - 保持向后兼容，改为nullable
    red1 = Column(Integer, nullable=True)
    red2 = Column(Integer, nullable=True)
    red3 = Column(Integer, nullable=True)
    red4 = Column(Integer, nullable=True)
    red5 = Column(Integer, nullable=True)
    red6 = Column(Integer, nullable=True)

    # 蓝球 1个（SSQ） - 保持向后兼容，改为nullable
    blue = Column(Integer, nullable=True)

    # 通用主球区字段（最大支持20个，覆盖K8的20选号）
    main_ball1 = Column(Integer, nullable=True)
    main_ball2 = Column(Integer, nullable=True)
    main_ball3 = Column(Integer, nullable=True)
    main_ball4 = Column(Integer, nullable=True)
    main_ball5 = Column(Integer, nullable=True)
    main_ball6 = Column(Integer, nullable=True)
    main_ball7 = Column(Integer, nullable=True)
    main_ball8 = Column(Integer, nullable=True)
    main_ball9 = Column(Integer, nullable=True)
    main_ball10 = Column(Integer, nullable=True)
    main_ball11 = Column(Integer, nullable=True)
    main_ball12 = Column(Integer, nullable=True)
    main_ball13 = Column(Integer, nullable=True)
    main_ball14 = Column(Integer, nullable=True)
    main_ball15 = Column(Integer, nullable=True)
    main_ball16 = Column(Integer, nullable=True)
    main_ball17 = Column(Integer, nullable=True)
    main_ball18 = Column(Integer, nullable=True)
    main_ball19 = Column(Integer, nullable=True)
    main_ball20 = Column(Integer, nullable=True)

    # 通用附加球区字段（最大支持2个）
    bonus_ball1 = Column(Integer, nullable=True)
    bonus_ball2 = Column(Integer, nullable=True)

    # JSON格式通用存储
    main_balls_json = Column(JSON, nullable=True)
    bonus_balls_json = Column(JSON, nullable=True)

    # 统计信息
    red_sum = Column(Integer)
    span = Column(Integer)
    odd_count = Column(Integer)
    zone1_count = Column(Integer)
    zone2_count = Column(Integer)
    zone3_count = Column(Integer)

    created_at = Column(DateTime, default=datetime.now)

    @property
    def _main_ball_columns(self):
        """返回所有main_ball列名的有序列表"""
        return [
            self.main_ball1, self.main_ball2, self.main_ball3, self.main_ball4,
            self.main_ball5, self.main_ball6, self.main_ball7, self.main_ball8,
            self.main_ball9, self.main_ball10, self.main_ball11, self.main_ball12,
            self.main_ball13, self.main_ball14, self.main_ball15, self.main_ball16,
            self.main_ball17, self.main_ball18, self.main_ball19, self.main_ball20,
        ]

    def get_reds(self):
        """向后兼容: 返回红球列表（SSQ）"""
        return [self.red1, self.red2, self.red3, self.red4, self.red5, self.red6]

    def get_main_balls(self):
        """
        获取主球区号码列表（通用）
        根据lottery_type决定从哪个字段读取
        """
        schema = get_schema(self.lottery_type)
        main_count = schema["main_count"]

        # 优先从JSON读取
        if self.main_balls_json:
            return list(self.main_balls_json)

        # 从main_ball列读取
        balls = []
        cols = self._main_ball_columns
        for i in range(main_count):
            v = cols[i]
            if v is not None:
                balls.append(v)
        if balls:
            return balls

        # 向后兼容: SSQ从red列读取
        if self.lottery_type == "ssq":
            return self.get_reds()

        return []

    def get_bonus_balls(self):
        """
        获取附加球区号码列表（通用）
        根据lottery_type决定从哪个字段读取
        """
        schema = get_schema(self.lottery_type)

        # 优先从JSON读取
        if self.bonus_balls_json:
            return list(self.bonus_balls_json)

        bonus_counts = [b["count"] for b in schema["bonus_balls"]]
        total_bonus = sum(bonus_counts)

        if total_bonus == 0:
            return []

        # 从bonus_ball列读取
        bonus_cols = [self.bonus_ball1, self.bonus_ball2]
        balls = []
        for i in range(min(total_bonus, len(bonus_cols))):
            v = bonus_cols[i]
            if v is not None:
                balls.append(v)

        if balls:
            # 如果有多个附加球区，按配置拆分
            if len(bonus_counts) == 1:
                return [balls]

        # 向后兼容: SSQ从blue列读取
        if self.lottery_type == "ssq" and self.blue is not None:
            return [[self.blue]]

        return []


class Feature(Base):
    """特征数据表"""
    __tablename__ = "features"

    id = Column(Integer, primary_key=True, autoincrement=True)
    period = Column(String(20), nullable=False, index=True)
    lottery_type = Column(String(10), default="ssq")
    feature_type = Column(String(50), nullable=False)
    feature_data = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.now)


class Prediction(Base):
    """预测记录表"""
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    period = Column(String(20), nullable=False, index=True)
    lottery_type = Column(String(10), default="ssq")
    model_name = Column(String(50), nullable=False)
    model_version = Column(String(30), nullable=False)

    # 预测号码 - 通用字段
    main_balls = Column(JSON, nullable=False)     # 主球区号码列表
    bonus_balls = Column(JSON, nullable=True)     # 附加球区号码列表（二维列表）

    # 评分
    score = Column(Float)
    probability = Column(Float)
    confidence = Column(Float)

    # 融合权重
    weights = Column(JSON)

    # 状态
    status = Column(String(20), default="pending")

    # ============================================================
    # 对比结果字段（开奖后由匹配引擎写入）
    # ============================================================
    actual_main_balls = Column(JSON, nullable=True)    # 实际开奖主球区号码
    actual_bonus_balls = Column(JSON, nullable=True)   # 实际开奖附加球区号码
    match_main_count = Column(Integer, nullable=True)  # 主球命中数
    match_bonus_count = Column(Integer, nullable=True) # 附加球命中数
    match_total = Column(Integer, nullable=True)       # 总命中数
    match_hit_rate = Column(Float, nullable=True)      # 命中率评分 (0-1)
    matched_at = Column(DateTime, nullable=True)       # 匹配时间

    created_at = Column(DateTime, default=datetime.now)


class ModelCheckpoint(Base):
    """模型检查点表"""
    __tablename__ = "model_checkpoints"

    id = Column(Integer, primary_key=True, autoincrement=True)
    model_name = Column(String(50), nullable=False)
    lottery_type = Column(String(10), default="ssq")
    version = Column(String(30), nullable=False)
    file_path = Column(String(255), nullable=False)
    accuracy = Column(Float)
    loss = Column(Float)
    is_active = Column(Boolean, default=False)
    training_config = Column(JSON)
    created_at = Column(DateTime, default=datetime.now)


class ExperimentRecord(Base):
    """实验记录表"""
    __tablename__ = "experiment_records"

    id = Column(Integer, primary_key=True, autoincrement=True)
    experiment_name = Column(String(100), nullable=False)
    lottery_type = Column(String(10), default="ssq")
    model_name = Column(String(50), nullable=False)
    period = Column(String(20), nullable=False)
    prediction = Column(JSON)
    actual = Column(JSON)
    match_count = Column(Integer)
    score = Column(Float)
    remarks = Column(Text)
    created_at = Column(DateTime, default=datetime.now)


class SystemLog(Base):
    """系统日志表"""
    __tablename__ = "system_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    level = Column(String(10), nullable=False)
    lottery_type = Column(String(10), default="ssq")
    module = Column(String(50), nullable=False)
    message = Column(Text, nullable=False)
    data = Column(JSON)
    created_at = Column(DateTime, default=datetime.now)


class MemoryRecord(Base):
    """知识记忆记录表"""
    __tablename__ = "memory_records"

    id = Column(Integer, primary_key=True, autoincrement=True)
    memory_type = Column(String(30), nullable=False)  # prediction/pattern/model
    lottery_type = Column(String(10), default="ssq")
    content = Column(JSON, nullable=False)
    embedding = Column(JSON)  # 向量存储（简化版）
    period = Column(String(20))
    score = Column(Float)     # 记忆评分
    tags = Column(JSON)       # 标签
    created_at = Column(DateTime, default=datetime.now)


class EvolutionState(Base):
    """
    进化状态持久化表
    保存自学习进化的核心成果：融合权重、模型可信度、评分/命中追踪
    每个 (lottery_type) 一行，确保重启后可恢复学习成果
    """
    __tablename__ = "evolution_state"

    id = Column(Integer, primary_key=True, autoincrement=True)
    lottery_type = Column(String(10), default="ssq", unique=True, nullable=False, index=True)

    # 进化周期统计
    total_iterations = Column(Integer, default=0)
    last_evolution_at = Column(DateTime, nullable=True)

    # 融合权重 (JSON: {"XGBoost": 0.18, "LSTM": 0.16, ...})
    fusion_weights = Column(JSON, nullable=False)

    # 模型可信度 (JSON: {"XGBoost": 0.72, "LSTM": 0.65, ...})
    model_credibility = Column(JSON, nullable=False)

    # 模型历史评分追踪 (JSON: {"XGBoost": [0.15, 0.18, ...], ...}) — 最近100条
    model_scores = Column(JSON, nullable=False)

    # 模型历史命中追踪 (JSON: {"XGBoost": [1, 2, 0, ...], ...}) — 最近100条
    model_hits = Column(JSON, nullable=False)

    # 反馈引擎迭代计数
    feedback_iteration = Column(Integer, default=0)

    # 反馈历史记录数
    feedback_count = Column(Integer, default=0)

    # 元数据
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    created_at = Column(DateTime, default=datetime.now)


class EvolutionHistory(Base):
    """
    进化周期历史记录表
    每次进化周期完成后写入一条记录
    """
    __tablename__ = "evolution_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    lottery_type = Column(String(10), default="ssq", index=True)

    # 进化周期信息
    iteration = Column(Integer, nullable=False)
    status = Column(String(20), nullable=False)  # completed / no_new_data / error
    matched_count = Column(Integer, default=0)

    # 权重快照 (进化前后的权重对比)
    old_weights = Column(JSON, nullable=True)
    new_weights = Column(JSON, nullable=True)

    # 模型表现快照
    model_performance = Column(JSON, nullable=True)

    # 可信度更新
    credibility_updates = Column(JSON, nullable=True)

    # 模型更新信息
    model_updates = Column(JSON, nullable=True)

    # 耗时（秒）
    duration_seconds = Column(Float, nullable=True)

    # 错误信息
    error_message = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.now, index=True)
