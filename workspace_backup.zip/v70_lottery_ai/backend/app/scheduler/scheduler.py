"""
V70 彩票AI工作台 - 定时任务调度器
自动执行每日数据更新、预测、训练、自学习进化等任务
"""
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from loguru import logger
from app.config.settings import settings
from app.orchestrator.workflow import orchestrator
from app.training.trainer import ModelTrainer
from app.training.experiment import ExperimentManager, ExperimentConfig


scheduler = BackgroundScheduler()


def start_scheduler():
    """启动定时任务调度器"""

    # 每日数据更新任务
    scheduler.add_job(
        daily_data_update,
        CronTrigger(
            hour=settings.SCHEDULE_UPDATE_HOUR,
            minute=settings.SCHEDULE_UPDATE_MINUTE,
        ),
        id="daily_data_update",
        name="每日数据更新",
        replace_existing=True,
    )

    # 每日预测任务（数据更新后）
    scheduler.add_job(
        daily_prediction,
        CronTrigger(
            hour=settings.SCHEDULE_UPDATE_HOUR,
            minute=settings.SCHEDULE_UPDATE_MINUTE + 5,
        ),
        id="daily_prediction",
        name="每日预测",
        replace_existing=True,
    )

    # 每日自学习进化任务（预测后、数据更新后）
    scheduler.add_job(
        daily_self_evolution,
        CronTrigger(
            hour=settings.SCHEDULE_UPDATE_HOUR,
            minute=settings.SCHEDULE_UPDATE_MINUTE + 10,
        ),
        id="daily_self_evolution",
        name="每日自学习进化",
        replace_existing=True,
    )

    # 每周模型训练任务 - 调用真实训练器
    scheduler.add_job(
        weekly_training,
        CronTrigger(day_of_week="mon", hour=2, minute=0),
        id="weekly_training",
        name="每周模型训练",
        replace_existing=True,
    )

    # 每周实验评估任务
    scheduler.add_job(
        weekly_experiment_eval,
        CronTrigger(day_of_week="mon", hour=4, minute=0),
        id="weekly_experiment_eval",
        name="每周实验评估",
        replace_existing=True,
    )

    # 系统健康检查
    scheduler.add_job(
        health_check,
        CronTrigger(minute="*/30"),
        id="health_check",
        name="健康检查",
        replace_existing=True,
    )

    scheduler.start()
    logger.info("定时任务调度器已启动（含自学习进化任务）")


def stop_scheduler():
    """停止调度器"""
    scheduler.shutdown()
    logger.info("定时任务调度器已停止")


async def daily_data_update():
    """每日数据更新任务"""
    logger.info("[定时任务] 开始每日数据更新")
    try:
        from app.data_center.collector import DataCollector
        from app.database.db import get_db
        from app.core.alerting import alert_manager, AlertLevel, AlertCategory

        for lottery_type in settings.SUPPORTED_LOTTERY_TYPES:
            collector = DataCollector(lottery_type=lottery_type)
            async for session in get_db():
                db = session
                break
            try:
                result = await collector.sync_latest(db)
                if result:
                    logger.info(f"[定时任务] {lottery_type} 数据已更新: {result.period}")
                    alert_manager.report_data_collection_result(
                        success=True, lottery_type=lottery_type,
                    )
                else:
                    logger.info(f"[定时任务] {lottery_type} 数据已是最新")
            except Exception as e:
                alert_manager.report_data_collection_result(
                    success=False, lottery_type=lottery_type, detail=str(e),
                )
            finally:
                pass  # db session managed by caller

        logger.info("[定时任务] 数据更新完成")
    except Exception as e:
        logger.error(f"[定时任务] 数据更新失败: {e}")
        from app.core.alerting import alert_manager
        alert_manager.report_scheduler_task("daily_data_update", False, str(e))


async def daily_prediction():
    """每日预测任务"""
    logger.info("[定时任务] 开始每日预测")
    try:
        from app.database.db import get_db
        from app.core.alerting import alert_manager
        async for session in get_db():
            db = session
            break

        for lottery_type in settings.SUPPORTED_LOTTERY_TYPES:
            try:
                await orchestrator.run_full_pipeline(
                    db_session=db, lottery_type=lottery_type
                )
                logger.info(f"[定时任务] {lottery_type} 预测完成")
            except Exception as e:
                logger.error(f"[定时任务] {lottery_type} 预测失败: {e}")
                alert_manager.report_scheduler_task(
                    f"daily_prediction:{lottery_type}", False, str(e),
                )

        logger.info("[定时任务] 每日预测完成")
    except Exception as e:
        logger.error(f"[定时任务] 预测失败: {e}")
        from app.core.alerting import alert_manager
        alert_manager.report_scheduler_task("daily_prediction", False, str(e))


async def daily_self_evolution():
    """
    每日自学习进化任务
    在数据更新和预测后执行，自动完成:
    1. 将预测结果与最新开奖数据匹配
    2. 计算各模型命中率
    3. 动态调整模型可信度和融合权重
    """
    logger.info("[定时任务] 开始每日自学习进化")
    try:
        from app.database.db import get_db
        from app.self_learning.evolution_engine import evolution_engine

        async for session in get_db():
            db = session
            break

        for lottery_type in settings.SUPPORTED_LOTTERY_TYPES:
            try:
                result = await evolution_engine.run_evolution_cycle(
                    db=db,
                    orchestrator=orchestrator,
                    lottery_type=lottery_type,
                )
                logger.info(
                    f"[定时任务] {lottery_type} 进化完成: "
                    f"匹配{result.get('matched_count', 0)}条, "
                    f"状态={result.get('status', 'unknown')}"
                )
                if result.get("new_weights"):
                    logger.info(
                        f"[定时任务] {lottery_type} 新权重: "
                        + " | ".join(
                            f"{k}={v:.3f}" for k, v in result["new_weights"].items()
                        )
                    )
            except Exception as e:
                logger.error(f"[定时任务] {lottery_type} 进化失败: {e}")

        logger.info("[定时任务] 每日自学习进化完成")
    except Exception as e:
        logger.error(f"[定时任务] 自学习进化失败: {e}")


async def weekly_training():
    """
    每周模型训练任务
    调用 ModelTrainer 进行真实训练闭环:
    1. 从数据库提取历史数据
    2. 构建特征和标签
    3. 训练全部 6 个模型
    4. 评估模型表现
    5. 保存模型检查点
    """
    logger.info("[定时任务] 开始每周模型训练")
    try:
        from app.database.db import get_db
        from datetime import datetime

        async for session in get_db():
            db = session
            break

        for lottery_type in settings.SUPPORTED_LOTTERY_TYPES:
            logger.info(f"[定时任务] 训练 {lottery_type} 模型...")

            trainer = ModelTrainer(window_size=100, db=db)

            # 训练全部模型
            training_results = await trainer.train_all_models(
                lottery_type=lottery_type,
                epochs=100,
            )

            if "error" in training_results:
                logger.error(f"[定时任务] {lottery_type} 训练失败: {training_results['error']}")
                continue

            # 评估模型
            eval_results = await trainer.evaluate_all_models(
                lottery_type=lottery_type,
                test_periods=50,
            )

            # 保存模型检查点
            version = f"v{datetime.now().strftime('%Y%m%d')}"
            save_result = await trainer.save_all_models(
                version=version,
                lottery_type=lottery_type,
            )

            # 更新 Orchestrator 中的模型权重 (基于评估结果)
            _update_model_weights(eval_results)

            logger.info(
                f"[定时任务] {lottery_type} 训练完成: "
                f"版本={version}, 模型数={len(save_result.get('models_saved', []))}"
            )

        logger.info("[定时任务] 模型训练完成")
    except Exception as e:
        logger.error(f"[定时任务] 训练失败: {e}")


async def weekly_experiment_eval():
    """
    每周实验评估任务
    运行 A/B 实验对比不同配置
    """
    logger.info("[定时任务] 开始每周实验评估")
    try:
        manager = ExperimentManager()

        for lottery_type in settings.SUPPORTED_LOTTERY_TYPES:
            # 运行默认配置实验
            default_exp_id = manager.create_experiment(
                f"weekly_default_{lottery_type}",
                ExperimentManager.default_config(lottery_type),
            )
            await manager.run_experiment(default_exp_id)

            # 运行轻量配置实验 (对比)
            light_exp_id = manager.create_experiment(
                f"weekly_lightweight_{lottery_type}",
                ExperimentManager.lightweight_config(lottery_type),
            )
            await manager.run_experiment(light_exp_id)

            # 对比实验结果
            comparison = manager.compare_experiments([default_exp_id, light_exp_id])
            logger.info(
                f"[定时任务] {lottery_type} 实验对比: "
                f"best_f1={comparison['summary']['best_f1']}"
            )

        logger.info("[定时任务] 实验评估完成")
    except Exception as e:
        logger.error(f"[定时任务] 实验评估失败: {e}")


def _update_model_weights(eval_results: dict):
    """
    根据评估结果动态更新 Orchestrator 中的模型权重
    """
    models = eval_results.get("models", {})
    if not models:
        return

    # 计算各模型的 F1 分数
    f1_scores = {}
    for name, metrics in models.items():
        if isinstance(metrics, dict):
            f1_scores[name] = metrics.get("f1", 0)

    total_f1 = sum(f1_scores.values())
    if total_f1 <= 0:
        return

    # 按 F1 归一化权重
    new_weights = {
        name: score / total_f1
        for name, score in f1_scores.items()
    }

    # 更新融合引擎权重
    try:
        from app.orchestrator.workflow import orchestrator
        orchestrator.fusion_engine.update_weights(new_weights)
        logger.info(f"模型权重已更新: {new_weights}")
    except Exception as e:
        logger.warning(f"更新融合引擎权重失败: {e}")


def health_check():
    """系统健康检查（真实检测）"""
    import asyncio
    from app.core.alerting import alert_manager

    async def _check():
        health = await alert_manager.check_system_health()
        if health.get("status") != "healthy":
            logger.warning(f"[健康检查] 系统状态异常: {health.get('status')}")
            for check_name, check_result in health.get("checks", {}).items():
                if not check_result.get("ok", True):
                    logger.warning(f"  - {check_name}: {check_result}")
        else:
            logger.debug(f"[健康检查] 系统健康 (告警: {health.get('checks', {}).get('alerts', {}).get('unresolved', 0)} 条未解决)")

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(_check())
        else:
            loop.run_until_complete(_check())
    except Exception as e:
        logger.error(f"[健康检查] 执行失败: {e}")
