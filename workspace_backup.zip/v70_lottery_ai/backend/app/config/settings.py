"""
V70 彩票AI工作台 - 配置管理
使用 pydantic-settings 从环境变量和 .env 文件读取配置
"""
from pydantic_settings import BaseSettings
from typing import List, Optional
from pathlib import Path


class Settings(BaseSettings):
    """应用配置 — 所有配置项均支持通过环境变量覆盖"""

    # ===== 应用 =====
    APP_NAME: str = "V70 彩票AI工作台"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    # ===== 安全密钥（无默认值，必须从环境变量或 .env 读取） =====
    SECRET_KEY: Optional[str] = None

    # ===== 数据库 =====
    DATABASE_URL: str = "sqlite+aiosqlite:///./data/v70.db"

    # ===== CORS =====
    CORS_ORIGINS: List[str] = ["*"]

    # ===== AI模型权重配置（可通过环境变量覆盖） =====
    XGBOOST_WEIGHT: float = 0.18
    LSTM_WEIGHT: float = 0.16
    TRANSFORMER_WEIGHT: float = 0.20
    PPO_WEIGHT: float = 0.12
    STATISTIC_WEIGHT: float = 0.18
    BEHAVIOR_WEIGHT: float = 0.16

    # ===== 模型持久化目录 =====
    MODEL_SAVE_DIR: str = "./model_checkpoints"

    # ===== 候选方案生成 =====
    CANDIDATE_COUNT: int = 10000
    TOP_RESULTS: int = 10

    # ===== 调度配置 =====
    SCHEDULE_UPDATE_HOUR: int = 8
    SCHEDULE_UPDATE_MINUTE: int = 0

    # ===== 数据采集 =====
    LOTTERY_TYPE: str = "ssq"  # 双色球
    SUPPORTED_LOTTERY_TYPES: list = ["ssq", "dlt", "k8"]
    HISTORY_WINDOW: int = 100

    # ===== 外部API密钥（敏感信息，从环境变量读取） =====
    API_KEY_LOTTERY: Optional[str] = None
    API_KEY_AI_SERVICE: Optional[str] = None

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        # 允许额外环境变量
        extra = "ignore"

    def get_model_dir(self, model_name: str) -> Path:
        """获取指定模型的保存目录"""
        model_dir = Path(self.MODEL_SAVE_DIR) / model_name
        model_dir.mkdir(parents=True, exist_ok=True)
        return model_dir


settings = Settings()
