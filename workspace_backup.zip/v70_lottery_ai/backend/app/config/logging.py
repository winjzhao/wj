"""
V70 彩票AI工作台 - 日志配置
"""
import sys
from loguru import logger


def setup_logging():
    """配置日志系统"""
    logger.remove()  # 移除默认handler

    logger.add(
        sys.stdout,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
               "<level>{level: <8}</level> | "
               "<cyan>{name}</cyan>:<cyan>{function}</cyan> - "
               "<level>{message}</level>",
        level="DEBUG",
        colorize=True,
    )

    logger.add(
        "logs/v70_{time:YYYY-MM-DD}.log",
        rotation="00:00",
        retention="30 days",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function} - {message}",
        level="INFO",
    )

    return logger
