"""
V70 彩票AI工作台 - 经验检索器
从记忆库中检索相关历史经验
"""
from typing import Dict, List, Any
from app.memory_center.memory import global_memory, MemoryEntry
from loguru import logger


class ExperienceRetriever:
    """经验检索器"""

    def __init__(self):
        self.memory = global_memory

    def retrieve_relevant_experiences(self, current_context: Dict,
                                       top_k: int = 5) -> Dict[str, Any]:
        """
        检索与当前上下文相关的历史经验
        """
        # 1. 相似走势检索
        similar_predictions = self.memory.retrieve_similar(
            current_context, top_k=top_k
        )

        # 2. 检索模型经验
        model_experiences = {}
        for model_name in ["Transformer", "PPO", "Statistic", "Behavior"]:
            model_experiences[model_name] = \
                self.memory.get_model_best_strategies(model_name)

        # 3. 组织检索结果
        experiences = []
        for mem in similar_predictions:
            experiences.append({
                "period": mem.period,
                "score": mem.score,
                "content": mem.content,
                "tags": mem.tags,
            })

        logger.info(f"经验检索: 找到 {len(experiences)} 条相关经验")

        return {
            "similar_predictions": experiences,
            "model_best_strategies": model_experiences,
            "total_experiences": len(experiences),
        }
