"""
V70 彩票AI工作台 - 知识记忆中心
存储和管理AI的长期经验
"""
import numpy as np
from typing import Dict, List, Any, Optional
from datetime import datetime
from loguru import logger


class MemoryEntry:
    """记忆条目"""

    def __init__(self, memory_type: str, content: Dict, period: str = "",
                 score: float = 0.0, tags: List[str] = None):
        self.memory_type = memory_type
        self.content = content
        self.period = period
        self.score = score
        self.tags = tags or []
        self.created_at = datetime.now()
        self.access_count = 0


class KnowledgeMemory:
    """知识记忆库"""

    def __init__(self):
        self.memories: List[MemoryEntry] = []
        self.pattern_memory: Dict[str, List] = {}  # 模式记忆
        self.model_memory: Dict[str, List] = {}    # 模型经验记忆

    def store_prediction(self, period: str, prediction: Dict,
                         actual: Dict = None, score: float = 0.0):
        """存储预测记录"""
        entry = MemoryEntry(
            memory_type="prediction",
            content={
                "prediction": prediction,
                "actual": actual,
            },
            period=period,
            score=score,
            tags=["prediction", f"period_{period}"],
        )
        self.memories.append(entry)
        self._prune_old_memories("prediction", max_keep=1000)

    def store_pattern(self, pattern_name: str, pattern_data: Dict):
        """存储模式"""
        if pattern_name not in self.pattern_memory:
            self.pattern_memory[pattern_name] = []
        self.pattern_memory[pattern_name].append({
            "data": pattern_data,
            "timestamp": datetime.now(),
        })
        # 限制每种模式最多保留100条
        if len(self.pattern_memory[pattern_name]) > 100:
            self.pattern_memory[pattern_name] = \
                self.pattern_memory[pattern_name][-100:]

    def store_model_experience(self, model_name: str, experience: Dict):
        """存储模型经验（内存 + SQLite 持久化）"""
        if model_name not in self.model_memory:
            self.model_memory[model_name] = []
        self.model_memory[model_name].append({
            "experience": experience,
            "timestamp": datetime.now(),
        })
        if len(self.model_memory[model_name]) > 200:
            self.model_memory[model_name] = \
                self.model_memory[model_name][-200:]

        # 高分经验写入数据库持久化
        score = experience.get("score", 0)
        if score >= 0.15:
            self._persist_to_db(
                memory_type="model",
                content=experience,
                period=experience.get("period", ""),
                score=score,
                tags=["model", f"model_{model_name}"],
            )

    def _persist_to_db(self, memory_type: str, content: Dict, period: str = "",
                       score: float = 0.0, tags: List[str] = None):
        """
        将记忆异步写入 SQLite memory_records 表
        使用同步方式调用（在内存操作完成后再异步写库）
        """
        try:
            import asyncio
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # 在运行中的事件循环中创建任务
                asyncio.ensure_future(self._async_persist_to_db(
                    memory_type, content, period, score, tags
                ))
        except RuntimeError:
            # 没有事件循环，跳过持久化
            pass
        except Exception as e:
            logger.debug(f"[记忆库] 持久化调度失败: {e}")

    async def _async_persist_to_db(self, memory_type: str, content: Dict,
                                   period: str = "", score: float = 0.0,
                                   tags: List[str] = None):
        """异步写入 memory_records 表"""
        try:
            from app.database.db import AsyncSessionLocal
            from app.self_learning.persistence import persistence

            async with AsyncSessionLocal() as db:
                await persistence.save_memory(
                    db=db,
                    memory_type=memory_type,
                    content=content,
                    period=period,
                    score=score,
                    tags=tags,
                )
        except Exception as e:
            logger.debug(f"[记忆库] 数据库写入失败: {e}")

    def retrieve_similar(self, current_data: Dict, top_k: int = 5) -> List[MemoryEntry]:
        """检索相似的历史经验"""
        scored = []
        for mem in self.memories:
            if mem.memory_type != "prediction":
                continue
            # 简化版相似度计算
            similarity = self._calculate_similarity(current_data, mem.content)
            scored.append((similarity, mem))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [mem for _, mem in scored[:top_k]]

    def retrieve_by_period(self, period: str) -> List[MemoryEntry]:
        """按期号检索"""
        return [m for m in self.memories if m.period == period]

    def retrieve_by_tag(self, tag: str) -> List[MemoryEntry]:
        """按标签检索"""
        return [m for m in self.memories if tag in m.tags]

    def get_model_best_strategies(self, model_name: str) -> List[Dict]:
        """获取模型最佳策略"""
        if model_name not in self.model_memory:
            return []
        experiences = self.model_memory[model_name]
        # 按score排序
        sorted_exp = sorted(experiences,
                            key=lambda x: x["experience"].get("score", 0),
                            reverse=True)
        return [e["experience"] for e in sorted_exp[:10]]

    def get_statistics(self) -> Dict:
        """获取记忆库统计信息"""
        prediction_count = sum(1 for m in self.memories if m.memory_type == "prediction")
        pattern_count = sum(len(v) for v in self.pattern_memory.values())
        model_exp_count = sum(len(v) for v in self.model_memory.values())

        return {
            "total_predictions": prediction_count,
            "total_patterns": pattern_count,
            "model_experiences": model_exp_count,
            "memory_types": {
                "prediction": prediction_count,
                "pattern": pattern_count,
                "model": model_exp_count,
            },
        }

    def _calculate_similarity(self, data1: Dict, data2: Dict) -> float:
        """计算相似度（简化版）"""
        # 比较红球分布的相似性
        if "prediction" in data2 and "red_probs" in data2["prediction"]:
            probs = np.array(data2["prediction"]["red_probs"])
            # 返回概率分布的峰度作为相似度代理
            return float(1.0 / (1.0 + np.std(probs)))
        return 0.0

    def _prune_old_memories(self, memory_type: str, max_keep: int):
        """清理旧记忆"""
        type_memories = [m for m in self.memories if m.memory_type == memory_type]
        if len(type_memories) > max_keep:
            # 保留最新的和高分的
            type_memories.sort(key=lambda x: x.score, reverse=True)
            keep = set(id(m) for m in type_memories[:max_keep])
            self.memories = [m for m in self.memories
                            if m.memory_type != memory_type or id(m) in keep]


# 全局记忆库实例
global_memory = KnowledgeMemory()
