"""
V70 彩票AI工作台 - 工具函数
"""
import numpy as np
from typing import List, Tuple, Optional
from datetime import datetime
from app.core.lottery_schema import get_schema


def calculate_match_count(
    prediction_main: List[int],
    actual_main: List[int],
    prediction_bonus: Optional[List[List[int]]] = None,
    actual_bonus: Optional[List[List[int]]] = None,
    lottery_type: str = "ssq",
) -> Tuple[int, bool, int, int]:
    """
    计算命中数（通用版本）
    返回: (总命中数, 是否命中蓝球, 主球命中数, 附加球命中数)
    """
    match_main = len(set(prediction_main) & set(actual_main))

    match_bonus_total = 0
    has_bonus_match = False
    if prediction_bonus and actual_bonus:
        for pred_b, act_b in zip(prediction_bonus, actual_bonus):
            matches = len(set(pred_b) & set(act_b))
            match_bonus_total += matches
            if matches > 0:
                has_bonus_match = True

    total = match_main + match_bonus_total
    return total, has_bonus_match, match_main, match_bonus_total


def calculate_match_count_ssq(prediction: List[int], actual: List[int]) -> Tuple[int, bool]:
    """计算命中数（SSQ向后兼容）"""
    match_reds = len(set(prediction[:6]) & set(actual[:6]))
    match_blue = 1 if len(prediction) > 6 and len(actual) > 6 and prediction[6] == actual[6] else 0
    return match_reds + match_blue, match_blue > 0


def calculate_prize_level(match_count: int, match_blue: bool, lottery_type: str = "ssq") -> str:
    """计算中奖等级（通用版本）"""
    if lottery_type == "ssq":
        if match_count == 7:
            return "一等奖"
        elif match_count == 6 and not match_blue:
            return "二等奖"
        elif match_count == 6:
            return "三等奖"
        elif match_count == 5:
            return "四等奖"
        elif match_count == 4:
            return "五等奖"
        elif match_blue:
            return "六等奖"
        else:
            return "未中奖"
    elif lottery_type == "dlt":
        if match_count >= 7:
            return "一等奖"
        elif match_count == 6:
            return "二等奖"
        elif match_count == 5:
            return "三等奖"
        elif match_count == 4:
            return "四等奖"
        elif match_count == 3:
            return "五等奖"
        elif match_count == 2:
            return "六等奖"
        elif match_count == 1:
            return "七等奖"
        else:
            return "未中奖"
    elif lottery_type == "k8":
        if match_count >= 18:
            return "一等奖"
        elif match_count >= 16:
            return "二等奖"
        elif match_count >= 14:
            return "三等奖"
        elif match_count >= 12:
            return "四等奖"
        elif match_count >= 10:
            return "五等奖"
        elif match_count >= 8:
            return "六等奖"
        elif match_count >= 5:
            return "七等奖"
        else:
            return "未中奖"
    else:
        return "未中奖"


def format_period(period: str) -> str:
    """格式化期号"""
    return f"第{period}期"


def get_current_period() -> str:
    """获取当前期号（模拟）"""
    now = datetime.now()
    # 假设每周二、四、日开奖
    return f"{now.year}{now.strftime('%j')}"
