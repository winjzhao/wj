"""
V70 彩票AI工作台 - 自定义异常
"""


class V70BaseException(Exception):
    """基础异常"""
    def __init__(self, message: str, code: int = 500):
        self.message = message
        self.code = code
        super().__init__(self.message)


class DataNotFoundException(V70BaseException):
    """数据未找到"""
    def __init__(self, message: str = "数据未找到"):
        super().__init__(message, code=404)


class ModelNotTrainedException(V70BaseException):
    """模型未训练"""
    def __init__(self, model_name: str):
        super().__init__(f"模型 {model_name} 尚未训练", code=400)


class FusionFailedException(V70BaseException):
    """融合失败"""
    def __init__(self, message: str = "模型融合失败"):
        super().__init__(message, code=500)


class PredictionFailedException(V70BaseException):
    """预测失败"""
    def __init__(self, message: str = "预测失败"):
        super().__init__(message, code=500)


class ValidationException(V70BaseException):
    """数据验证异常"""
    def __init__(self, message: str = "数据验证失败"):
        super().__init__(message, code=422)
