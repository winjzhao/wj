"""
V70 彩票AI工作台 - 异常检测与告警中心 (AlertManager)
负责系统健康监控、异常检测、告警推送

监控维度：
1. 数据完整性 — 数据缺口、采集失败、数据过期
2. 预测质量 — 分数突降、模型全部低分
3. 系统健康 — DB 连接、API 可达性、调度器状态
4. 模型健康 — 降级、退役、训练失败
"""

import asyncio
from enum import Enum
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from collections import deque
from loguru import logger


class AlertLevel(str, Enum):
    """告警级别"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AlertCategory(str, Enum):
    """告警类别"""
    DATA_INTEGRITY = "data_integrity"    # 数据完整性
    PREDICTION_QUALITY = "prediction_quality"  # 预测质量
    SYSTEM_HEALTH = "system_health"      # 系统健康
    MODEL_HEALTH = "model_health"        # 模型健康
    SCHEDULER = "scheduler"              # 调度器


class Alert:
    """告警事件"""

    def __init__(
        self,
        level: AlertLevel,
        category: AlertCategory,
        title: str,
        detail: str,
        data: Dict = None,
    ):
        self.id = id(self)
        self.level = level
        self.category = category
        self.title = title
        self.detail = detail
        self.data = data or {}
        self.created_at = datetime.now()
        self.acknowledged = False
        self.resolved_at: Optional[datetime] = None

    def resolve(self):
        self.resolved_at = datetime.now()

    def to_dict(self) -> Dict:
        return {
            "id": str(self.id),
            "level": self.level.value,
            "category": self.category.value,
            "title": self.title,
            "detail": self.detail,
            "data": self.data,
            "created_at": self.created_at.isoformat(),
            "acknowledged": self.acknowledged,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }


class AlertManager:
    """
    告警管理中心

    特性：
    - 告警去重：相同类型的告警在冷却期内不重复发送
    - 告警升级：持续未解决的告警自动升级级别
    - 多通道推送：日志 + 数据库 SystemLog + 内存队列（供前端轮询）
    - 趋势检测：分数突降、连续失败等模式识别
    """

    # 告警冷却时间（秒），防止重复告警
    COOLDOWN_SECONDS = {
        AlertLevel.INFO: 600,      # 10分钟
        AlertLevel.WARNING: 300,   # 5分钟
        AlertLevel.ERROR: 120,     # 2分钟
        AlertLevel.CRITICAL: 60,   # 1分钟
    }

    # 告警升级阈值（秒），未解决的告警超过此时间自动升级
    ESCALATION_THRESHOLD = 3600  # 1小时

    def __init__(self):
        self.alerts: deque = deque(maxlen=200)  # 最近 200 条告警
        self.active_alerts: Dict[str, Alert] = {}  # 当前未解决的告警
        self._last_alert_time: Dict[str, datetime] = {}  # 防重复 key → 上次发送时间
        self._cooldown_overrides: Dict[str, int] = {}    # 冷却时间覆盖

        # 趋势检测缓存
        self._prediction_scores: deque = deque(maxlen=50)
        self._data_gap_detected_at: Optional[datetime] = None
        self._consecutive_failures: Dict[str, int] = {}  # 各类操作连续失败次数

    # ============================================================
    # 告警发送
    # ============================================================

    def send_alert(
        self,
        level: AlertLevel,
        category: AlertCategory,
        title: str,
        detail: str,
        data: Dict = None,
        dedup_key: str = None,
    ) -> Optional[Alert]:
        """
        发送告警

        Args:
            level: 告警级别
            category: 告警类别
            title: 简短标题
            detail: 详细信息
            data: 附加数据
            dedup_key: 去重键（相同 key 在冷却期内不重复发送）

        Returns:
            Alert 对象，如果被去重则返回 None
        """
        # 去重检查
        dedup_key = dedup_key or f"{category.value}:{title}"
        cooldown = self._cooldown_overrides.get(dedup_key, self.COOLDOWN_SECONDS[level])

        last_time = self._last_alert_time.get(dedup_key)
        if last_time and (datetime.now() - last_time).total_seconds() < cooldown:
            return None

        self._last_alert_time[dedup_key] = datetime.now()

        # 创建告警
        alert = Alert(level, category, title, detail, data)
        self.alerts.append(alert)
        self.active_alerts[alert.id] = alert

        # 日志输出
        log_msg = f"[告警] [{level.value.upper()}] [{category.value}] {title}: {detail}"
        if level == AlertLevel.CRITICAL:
            logger.critical(log_msg)
        elif level == AlertLevel.ERROR:
            logger.error(log_msg)
        elif level == AlertLevel.WARNING:
            logger.warning(log_msg)
        else:
            logger.info(log_msg)

        # 异步写入 SystemLog 表
        asyncio.ensure_future(self._persist_alert_to_db(alert))

        return alert

    async def _persist_alert_to_db(self, alert: Alert):
        """将告警持久化到 SystemLog 表"""
        try:
            from app.database.db import AsyncSessionLocal
            from app.database.models import SystemLog

            async with AsyncSessionLocal() as db:
                log_entry = SystemLog(
                    level=alert.level.value.upper(),
                    module=f"alerting:{alert.category.value}",
                    message=f"{alert.title}: {alert.detail}",
                    data=alert.to_dict(),
                )
                db.add(log_entry)
                await db.commit()
        except Exception as e:
            logger.debug(f"[告警] 持久化到数据库失败: {e}")

    # ============================================================
    # 数据完整性检测
    # ============================================================

    def check_data_integrity(
        self,
        latest_period: Optional[str] = None,
        expected_period: Optional[str] = None,
        days_since_last_draw: int = 0,
    ) -> List[Alert]:
        """
        检测数据完整性

        Args:
            latest_period: 数据库中最新的期号
            expected_period: 预期的最新期号（根据开奖日历）
            days_since_last_draw: 距上次开奖天数
        """
        alerts = []

        # 1. 数据过期检测
        if days_since_last_draw > 3:
            alerts.append(self.send_alert(
                AlertLevel.WARNING,
                AlertCategory.DATA_INTEGRITY,
                "数据可能过期",
                f"最新开奖数据距今 {days_since_last_draw} 天，正常应为 1-3 天",
                {"days_since_last_draw": days_since_last_draw},
                dedup_key="data:stale",
            ))

        if days_since_last_draw > 7:
            alerts.append(self.send_alert(
                AlertLevel.CRITICAL,
                AlertCategory.DATA_INTEGRITY,
                "数据严重过期",
                f"最新开奖数据距今 {days_since_last_draw} 天，数据采集可能已停止",
                {"days_since_last_draw": days_since_last_draw},
                dedup_key="data:critical_stale",
            ))

        # 2. 数据缺口检测
        if latest_period and expected_period and latest_period != expected_period:
            alerts.append(self.send_alert(
                AlertLevel.WARNING,
                AlertCategory.DATA_INTEGRITY,
                "可能存在数据缺口",
                f"最新期号={latest_period}, 预期={expected_period}",
                {"latest": latest_period, "expected": expected_period},
                dedup_key="data:gap",
            ))

        return [a for a in alerts if a is not None]

    def report_data_collection_result(
        self, success: bool, lottery_type: str, detail: str = "",
    ):
        """报告数据采集结果"""
        key = f"data_collect:{lottery_type}"

        if not success:
            self._consecutive_failures[key] = self._consecutive_failures.get(key, 0) + 1
            failures = self._consecutive_failures[key]

            if failures == 1:
                self.send_alert(
                    AlertLevel.WARNING,
                    AlertCategory.DATA_INTEGRITY,
                    f"{lottery_type} 数据采集失败",
                    detail or "外部 API 不可达",
                    dedup_key=f"data:collect_fail:{lottery_type}",
                )
            elif failures >= 3:
                self.send_alert(
                    AlertLevel.ERROR,
                    AlertCategory.DATA_INTEGRITY,
                    f"{lottery_type} 数据采集连续失败 {failures} 次",
                    f"请检查外部数据源可用性: {detail}",
                    dedup_key=f"data:collect_consecutive_fail:{lottery_type}",
                )
        else:
            self._consecutive_failures[key] = 0

    # ============================================================
    # 预测质量检测
    # ============================================================

    def check_prediction_quality(
        self,
        current_scores: Dict[str, float],
        historical_avg: Dict[str, float] = None,
    ) -> List[Alert]:
        """
        检测预测质量

        Args:
            current_scores: 当前各模型分数 {"XGBoost": 0.15, ...}
            historical_avg: 历史平均分数
        """
        alerts = []

        if not current_scores:
            return alerts

        # 记录分数趋势
        avg_score = sum(current_scores.values()) / max(len(current_scores), 1)
        self._prediction_scores.append(avg_score)

        # 1. 所有模型分数同时暴跌
        if len(current_scores) >= 3:
            low_count = sum(1 for s in current_scores.values() if s < 0.05)
            if low_count >= len(current_scores) * 0.7:  # 70% 以上模型低分
                alerts.append(self.send_alert(
                    AlertLevel.ERROR,
                    AlertCategory.PREDICTION_QUALITY,
                    "预测质量异常",
                    f"{low_count}/{len(current_scores)} 个模型分数 < 0.05，可能存在系统性问题",
                    {"scores": current_scores},
                    dedup_key="pred:all_low",
                ))

        # 2. 分数趋势下降
        if len(self._prediction_scores) >= 10:
            recent_5 = list(self._prediction_scores)[-5:]
            earlier_5 = list(self._prediction_scores)[-10:-5]
            if sum(recent_5) / 5 < sum(earlier_5) / 5 * 0.7:  # 下降 30%
                alerts.append(self.send_alert(
                    AlertLevel.WARNING,
                    AlertCategory.PREDICTION_QUALITY,
                    "预测分数趋势下降",
                    f"最近 5 轮平均分下降超过 30%",
                    {"recent_avg": sum(recent_5) / 5, "earlier_avg": sum(earlier_5) / 5},
                    dedup_key="pred:trend_down",
                ))

        # 3. 单个模型分数异常
        if historical_avg:
            for model, score in current_scores.items():
                hist = historical_avg.get(model, 0.15)
                if hist > 0 and score < hist * 0.4:  # 低于历史 40%
                    self.send_alert(
                        AlertLevel.WARNING,
                        AlertCategory.PREDICTION_QUALITY,
                        f"{model} 分数异常下降",
                        f"当前={score:.3f}, 历史平均={hist:.3f}",
                        dedup_key=f"pred:model_low:{model}",
                    )

        return [a for a in alerts if a is not None]

    # ============================================================
    # 系统健康检测
    # ============================================================

    async def check_system_health(self, db=None) -> Dict[str, Any]:
        """
        综合系统健康检查

        返回健康状态和各维度详情
        """
        health = {
            "status": "healthy",
            "checked_at": datetime.now().isoformat(),
            "checks": {},
        }

        # 1. 数据库连接
        db_ok = await self._check_database(db)
        health["checks"]["database"] = {"ok": db_ok, "message": "连接正常" if db_ok else "连接失败"}
        if not db_ok:
            health["status"] = "unhealthy"
            self.send_alert(
                AlertLevel.CRITICAL,
                AlertCategory.SYSTEM_HEALTH,
                "数据库连接失败",
                "无法连接到数据库",
                dedup_key="sys:db_fail",
            )

        # 2. 数据新鲜度
        data_fresh = await self._check_data_freshness(db)
        health["checks"]["data_freshness"] = data_fresh

        # 3. 告警统计
        unresolved = len(self.active_alerts)
        health["checks"]["alerts"] = {
            "total_alerts": len(self.alerts),
            "unresolved": unresolved,
        }
        if unresolved > 10:
            health["status"] = "degraded"

        return health

    async def _check_database(self, db=None) -> bool:
        """检查数据库连接"""
        try:
            if db:
                from sqlalchemy import text
                await db.execute(text("SELECT 1"))
                return True
            else:
                from app.database.db import AsyncSessionLocal
                async with AsyncSessionLocal() as session:
                    from sqlalchemy import text
                    await session.execute(text("SELECT 1"))
                return True
        except Exception as e:
            logger.error(f"[健康检查] 数据库连接失败: {e}")
            return False

    async def _check_data_freshness(self, db=None) -> Dict:
        """检查数据新鲜度"""
        try:
            if db is None:
                from app.database.db import AsyncSessionLocal
                async with AsyncSessionLocal() as session:
                    return await self._query_data_freshness(session)
            return await self._query_data_freshness(db)
        except Exception as e:
            return {"ok": False, "message": str(e)}

    async def _query_data_freshness(self, db) -> Dict:
        from sqlalchemy import text, select
        from app.database.models import LotteryDraw

        result = await db.execute(
            select(LotteryDraw.draw_date).order_by(LotteryDraw.draw_date.desc()).limit(1)
        )
        latest = result.scalar_one_or_none()

        if latest:
            days_ago = (datetime.now() - latest).days
            if days_ago <= 2:
                return {"ok": True, "days_since_last": days_ago, "status": "fresh"}
            elif days_ago <= 4:
                return {"ok": True, "days_since_last": days_ago, "status": "stale"}
            else:
                return {"ok": False, "days_since_last": days_ago, "status": "expired"}
        return {"ok": False, "message": "无开奖数据"}

    # ============================================================
    # 调度器状态
    # ============================================================

    def report_scheduler_task(
        self, task_name: str, success: bool, detail: str = "",
    ):
        """报告调度器任务执行结果"""
        key = f"scheduler:{task_name}"

        if not success:
            self._consecutive_failures[key] = self._consecutive_failures.get(key, 0) + 1
            failures = self._consecutive_failures[key]

            level = AlertLevel.WARNING if failures < 3 else AlertLevel.ERROR
            self.send_alert(
                level,
                AlertCategory.SCHEDULER,
                f"定时任务失败: {task_name}",
                f"连续失败 {failures} 次: {detail}",
                dedup_key=f"sched:fail:{task_name}",
            )
        else:
            self._consecutive_failures[key] = 0

    # ============================================================
    # 告警查询与管理
    # ============================================================

    def get_recent_alerts(self, limit: int = 50, level: str = None) -> List[Dict]:
        """获取最近告警"""
        alerts = list(self.alerts)
        if level:
            alerts = [a for a in alerts if a.level.value == level]
        return [a.to_dict() for a in alerts[-limit:]]

    def get_active_alerts(self) -> List[Dict]:
        """获取当前未解决的告警"""
        return [a.to_dict() for a in self.active_alerts.values() if not a.resolved_at]

    def acknowledge_alert(self, alert_id: str) -> bool:
        """确认告警"""
        for alert in self.active_alerts.values():
            if str(alert.id) == alert_id:
                alert.acknowledged = True
                return True
        return False

    def resolve_alert(self, alert_id: str) -> bool:
        """解决告警"""
        for alert in self.active_alerts.values():
            if str(alert.id) == alert_id:
                alert.resolve()
                # 从活跃列表中移除
                self.active_alerts.pop(alert.id, None)
                return True
        return False

    def resolve_by_category(self, category: AlertCategory) -> int:
        """按类别批量解决告警"""
        resolved = 0
        to_remove = []
        for alert_id, alert in self.active_alerts.items():
            if alert.category == category and not alert.resolved_at:
                alert.resolve()
                to_remove.append(alert_id)
                resolved += 1
        for aid in to_remove:
            self.active_alerts.pop(aid, None)
        return resolved

    def get_summary(self) -> Dict:
        """获取告警摘要"""
        by_level = {"info": 0, "warning": 0, "error": 0, "critical": 0}
        by_category = {}

        for alert in self.alerts:
            by_level[alert.level.value] = by_level.get(alert.level.value, 0) + 1
            by_category[alert.category.value] = by_category.get(alert.category.value, 0) + 1

        return {
            "total_alerts": len(self.alerts),
            "active_alerts": len(self.active_alerts),
            "by_level": by_level,
            "by_category": by_category,
            "consecutive_failures": dict(self._consecutive_failures),
        }


# 全局告警管理器实例
alert_manager = AlertManager()
