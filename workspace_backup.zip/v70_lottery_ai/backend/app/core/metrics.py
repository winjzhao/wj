"""
V70 彩票AI工作台 - 监控指标收集器
纯内存实现，不依赖外部监控库
"""
import time
import threading
from collections import deque
from typing import Dict, List, Optional, Any


class MetricsCollector:
    """内存指标收集器（单例）"""

    def __init__(self):
        self._lock = threading.Lock()

        # API 请求计数
        self._request_count: int = 0
        self._request_count_by_path: Dict[str, int] = {}
        self._request_count_by_method: Dict[str, int] = {}

        # API 响应时间（最近 100 次，滑动窗口）
        self._response_times: deque = deque(maxlen=100)

        # 模型预测耗时（按模型名称）
        self._prediction_times: Dict[str, deque] = {}

        # 错误统计
        self._error_count: int = 0
        self._error_count_by_status: Dict[int, int] = {}
        self._recent_errors: deque = deque(maxlen=20)  # 最近 20 条错误

        # 最近一次预测时间
        self._last_prediction_time: Optional[float] = None
        self._last_prediction_period: Optional[str] = None

        # 启动时间
        self._start_time: float = time.time()

    # ---- 请求计数 ----

    def record_request(self, method: str, path: str):
        """记录一次 API 请求"""
        with self._lock:
            self._request_count += 1
            self._request_count_by_method[method] = \
                self._request_count_by_method.get(method, 0) + 1
            self._request_count_by_path[path] = \
                self._request_count_by_path.get(path, 0) + 1

    # ---- 响应时间 ----

    def record_response_time(self, method: str, path: str, elapsed_ms: float):
        """记录一次 API 响应时间（毫秒）"""
        with self._lock:
            self._response_times.append(elapsed_ms)

    # ---- 模型预测 ----

    def record_prediction(self, model_name: str, elapsed_ms: float, period: str = ""):
        """记录一次模型预测"""
        with self._lock:
            if model_name not in self._prediction_times:
                self._prediction_times[model_name] = deque(maxlen=100)
            self._prediction_times[model_name].append(elapsed_ms)
            self._last_prediction_time = time.time()
            self._last_prediction_period = period

    # ---- 错误统计 ----

    def record_error(self, status_code: int, message: str, path: str = ""):
        """记录一次错误"""
        with self._lock:
            self._error_count += 1
            self._error_count_by_status[status_code] = \
                self._error_count_by_status.get(status_code, 0) + 1
            self._recent_errors.append({
                "timestamp": time.time(),
                "status_code": status_code,
                "message": str(message)[:200],  # 截断过长消息
                "path": path,
            })

    # ---- 查询方法 ----

    def get_request_stats(self) -> Dict[str, Any]:
        """获取请求统计"""
        with self._lock:
            avg_response_time = 0.0
            if self._response_times:
                avg_response_time = sum(self._response_times) / len(self._response_times)
            return {
                "total_requests": self._request_count,
                "requests_by_method": dict(self._request_count_by_method),
                "requests_by_path": dict(self._request_count_by_path),
                "avg_response_time_ms": round(avg_response_time, 2),
                "response_time_sample_count": len(self._response_times),
            }

    def get_prediction_stats(self) -> Dict[str, Any]:
        """获取预测统计"""
        with self._lock:
            model_stats = {}
            for model_name, times in self._prediction_times.items():
                if times:
                    model_stats[model_name] = {
                        "count": len(times),
                        "avg_time_ms": round(sum(times) / len(times), 2),
                        "last_time_ms": round(times[-1], 2),
                    }
                else:
                    model_stats[model_name] = {
                        "count": 0,
                        "avg_time_ms": 0,
                        "last_time_ms": 0,
                    }
            return {
                "models": model_stats,
                "last_prediction_time": self._last_prediction_time,
                "last_prediction_period": self._last_prediction_period,
            }

    def get_error_stats(self) -> Dict[str, Any]:
        """获取错误统计"""
        with self._lock:
            return {
                "total_errors": self._error_count,
                "errors_by_status": dict(self._error_count_by_status),
                "recent_errors": list(self._recent_errors),
            }

    def get_uptime_seconds(self) -> float:
        """获取运行时间（秒）"""
        return time.time() - self._start_time

    def get_all_metrics(self) -> Dict[str, Any]:
        """获取所有指标快照"""
        return {
            "uptime_seconds": round(self.get_uptime_seconds(), 2),
            "requests": self.get_request_stats(),
            "predictions": self.get_prediction_stats(),
            "errors": self.get_error_stats(),
        }

    def reset(self):
        """重置所有指标（谨慎使用）"""
        with self._lock:
            self._request_count = 0
            self._request_count_by_path.clear()
            self._request_count_by_method.clear()
            self._response_times.clear()
            self._prediction_times.clear()
            self._error_count = 0
            self._error_count_by_status.clear()
            self._recent_errors.clear()
            self._last_prediction_time = None
            self._last_prediction_period = None
            self._start_time = time.time()


# 全局单例
metrics = MetricsCollector()
