"""
V70 彩票AI工作台 - 彩票类型配置
定义各彩票类型的号码结构，提供统一的维度查询接口
"""

from typing import Dict, List, Any, Optional

LOTTERY_SCHEMAS: Dict[str, Dict[str, Any]] = {
    "ssq": {
        "name": "双色球",
        "name_en": "SSQ",
        "main_balls": {"count": 6, "range": (1, 33), "label": "红球"},
        "bonus_balls": [{"count": 1, "range": (1, 16), "label": "蓝球"}],
        "main_dim": 33,
        "bonus_dims": [16],
        "main_count": 6,
        "total_bonus_count": 1,
    },
    "dlt": {
        "name": "大乐透",
        "name_en": "DLT",
        "main_balls": {"count": 5, "range": (1, 35), "label": "前区"},
        "bonus_balls": [{"count": 2, "range": (1, 12), "label": "后区"}],
        "main_dim": 35,
        "bonus_dims": [12],
        "main_count": 5,
        "total_bonus_count": 2,
    },
    "k8": {
        "name": "快乐8",
        "name_en": "K8",
        "main_balls": {"count": 20, "range": (1, 80), "label": "选号"},
        "bonus_balls": [],
        "main_dim": 80,
        "bonus_dims": [],
        "main_count": 20,
        "total_bonus_count": 0,
    },
}

SUPPORTED_TYPES: List[str] = list(LOTTERY_SCHEMAS.keys())


def get_schema(lottery_type: str) -> Dict[str, Any]:
    """
    获取指定彩票类型的配置

    Args:
        lottery_type: 彩票类型 ("ssq", "dlt", "k8")

    Returns:
        配置字典

    Raises:
        ValueError: 如果类型不支持
    """
    lottery_type = lottery_type.lower()
    if lottery_type not in LOTTERY_SCHEMAS:
        raise ValueError(
            f"不支持的彩票类型: '{lottery_type}'，支持的类型: {SUPPORTED_TYPES}"
        )
    return LOTTERY_SCHEMAS[lottery_type]


def get_all_types() -> List[str]:
    """获取所有支持的彩票类型列表"""
    return SUPPORTED_TYPES.copy()


def get_main_dim(lottery_type: str) -> int:
    """获取主球区概率向量维度"""
    return get_schema(lottery_type)["main_dim"]


def get_bonus_dims(lottery_type: str) -> List[int]:
    """获取附加球区概率向量维度列表"""
    return get_schema(lottery_type)["bonus_dims"]


def get_main_count(lottery_type: str) -> int:
    """获取主球区选号个数"""
    return get_schema(lottery_type)["main_count"]


def get_total_bonus_count(lottery_type: str) -> int:
    """获取附加球区总选号个数"""
    return get_schema(lottery_type)["total_bonus_count"]


def get_main_range(lottery_type: str) -> tuple:
    """获取主球区号码范围 (min, max)"""
    return get_schema(lottery_type)["main_balls"]["range"]


def get_bonus_ranges(lottery_type: str) -> List[tuple]:
    """获取附加球区号码范围列表 [(min, max), ...]"""
    return [b["range"] for b in get_schema(lottery_type)["bonus_balls"]]


def get_bonus_counts(lottery_type: str) -> List[int]:
    """获取各附加球区选号个数"""
    return [b["count"] for b in get_schema(lottery_type)["bonus_balls"]]


def get_total_dim(lottery_type: str) -> int:
    """获取概率向量总维度 (主球区 + 所有附加球区)"""
    schema = get_schema(lottery_type)
    return schema["main_dim"] + sum(schema["bonus_dims"])


def validate_main_balls(lottery_type: str, balls: List[int]) -> bool:
    """校验主球区号码是否合法"""
    schema = get_schema(lottery_type)
    cfg = schema["main_balls"]
    expected_count = cfg["count"]
    lo, hi = cfg["range"]

    if len(balls) != expected_count:
        return False
    if len(set(balls)) != len(balls):
        return False
    if not all(lo <= b <= hi for b in balls):
        return False
    return True


def validate_bonus_balls(lottery_type: str, balls_list: List[List[int]]) -> bool:
    """校验附加球区号码是否合法"""
    schema = get_schema(lottery_type)
    bonus_cfgs = schema["bonus_balls"]

    if len(balls_list) != len(bonus_cfgs):
        return False

    for balls, cfg in zip(balls_list, bonus_cfgs):
        lo, hi = cfg["range"]
        expected_count = cfg["count"]

        if len(balls) != expected_count:
            return False
        if len(set(balls)) != len(balls):
            return False
        if not all(lo <= b <= hi for b in balls):
            return False
    return True


def validate_balls(lottery_type: str, main_balls: List[int],
                   bonus_balls_list: List[List[int]]) -> bool:
    """完整校验号码是否合法（主球+附加球）"""
    return (validate_main_balls(lottery_type, main_balls) and
            validate_bonus_balls(lottery_type, bonus_balls_list))
