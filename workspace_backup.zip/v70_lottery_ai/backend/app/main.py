"""
V70 彩票AI工作台 - 主入口
FastAPI 应用启动文件
"""
import json
import sys
import time
from pathlib import Path
from typing import Any

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from starlette.responses import JSONResponse as StarletteJSONResponse
from contextlib import asynccontextmanager
from loguru import logger
from sqlalchemy.exc import SQLAlchemyError

from app.config.settings import settings
from app.config.logging import setup_logging
from app.database.db import init_db, close_db, AsyncSessionLocal
from app.api.routes import api_router
from app.core.metrics import metrics


class UTF8JSONResponse(StarletteJSONResponse):
    """自定义 JSON 响应，确保中文不被转义为 \\uXXXX"""
    def render(self, content: Any) -> bytes:
        return json.dumps(
            content,
            ensure_ascii=False,
            allow_nan=False,
            indent=None,
            separators=(",", ":"),
        ).encode("utf-8")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    setup_logging()
    await init_db()

    # 启动时加载最新模型检查点
    await _load_latest_checkpoints()

    # 启动时恢复自学习进化成果（权重、可信度、评分追踪）
    await _restore_evolution_state()

    # 启动调度器
    from app.scheduler.scheduler import start_scheduler
    start_scheduler()
    yield
    await close_db()


async def _load_latest_checkpoints():
    """启动时自动加载所有模型的最新检查点"""
    try:
        from app.orchestrator.workflow import orchestrator
        from app.training.pipeline import TrainingPipeline

        pipeline = TrainingPipeline()

        async with AsyncSessionLocal() as db_session:
            loaded_count = 0
            for name, model in orchestrator.models.items():
                # 对所有支持的彩票类型尝试加载
                for lt in settings.SUPPORTED_LOTTERY_TYPES:
                    try:
                        success = await pipeline.load_latest_checkpoint(model, lt, db_session)
                        if success:
                            loaded_count += 1
                    except Exception as e:
                        logger.debug(f"  加载 {name}/{lt} 检查点跳过: {e}")

        logger.info(f"启动检查点加载完成: {loaded_count} 个模型已恢复")
    except Exception as e:
        logger.warning(f"启动时加载检查点失败（可能是首次启动）: {e}")


async def _restore_evolution_state():
    """
    启动时从 SQLite 恢复自学习进化成果
    包括融合权重、模型可信度、评分追踪、进化历史、记忆库
    """
    try:
        from app.orchestrator.workflow import orchestrator
        from app.self_learning.evolution_engine import evolution_engine

        async with AsyncSessionLocal() as db_session:
            restored_any = False
            for lt in settings.SUPPORTED_LOTTERY_TYPES:
                try:
                    success = await evolution_engine.restore_from_database(
                        db=db_session,
                        orchestrator=orchestrator,
                        lottery_type=lt,
                    )
                    if success:
                        restored_any = True
                except Exception as e:
                    logger.warning(f"恢复进化状态失败 ({lt}): {e}")

        if restored_any:
            logger.info(
                f"进化状态恢复完成: "
                f"weights={orchestrator.fusion_engine.base_weights}"
            )
        else:
            logger.info("无已保存的进化状态，使用默认权重启动")
    except Exception as e:
        logger.warning(f"启动时恢复进化状态失败（可能是首次启动）: {e}")


app = FastAPI(
    title="V70 彩票AI工作台",
    description="基于多模型融合的彩票AI分析平台",
    version="1.0.0",
    lifespan=lifespan,
    default_response_class=UTF8JSONResponse,
)

# CORS 配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# 全局请求日志 + 指标收集中间件
# ============================================================
@app.middleware("http")
async def request_logging_and_metrics_middleware(request: Request, call_next):
    """记录每个请求的方法、路径、耗时、状态码，并收集指标"""
    start_time = time.time()
    method = request.method
    path = request.url.path

    # 记录请求计数
    metrics.record_request(method, path)

    response = await call_next(request)

    elapsed_ms = (time.time() - start_time) * 1000
    status_code = response.status_code

    # 记录响应时间
    metrics.record_response_time(method, path, elapsed_ms)

    # 记录错误
    if status_code >= 400:
        metrics.record_error(status_code, "", path)

    # 请求日志
    log_msg = f"{method} {path} -> {status_code} ({elapsed_ms:.1f}ms)"
    if status_code >= 500:
        logger.error(log_msg)
    elif status_code >= 400:
        logger.warning(log_msg)
    else:
        logger.info(log_msg)

    return response


# ============================================================
# 全局异常处理器
# ============================================================
@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    """处理值错误"""
    logger.warning(f"ValueError on {request.url.path}: {exc}")
    return UTF8JSONResponse(
        status_code=400,
        content={
            "detail": "请求参数无效",
            "message": str(exc) if settings.DEBUG else "参数验证失败",
        },
    )


@app.exception_handler(KeyError)
async def key_error_handler(request: Request, exc: KeyError):
    """处理键错误"""
    logger.warning(f"KeyError on {request.url.path}: {exc}")
    return UTF8JSONResponse(
        status_code=400,
        content={
            "detail": "缺少必要字段",
            "message": str(exc) if settings.DEBUG else "请求数据不完整",
        },
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """处理 HTTP 异常"""
    logger.warning(f"HTTPException {exc.status_code} on {request.url.path}: {exc.detail}")
    return UTF8JSONResponse(
        status_code=exc.status_code,
        content={
            "detail": exc.detail,
            "status_code": exc.status_code,
        },
    )


@app.exception_handler(SQLAlchemyError)
async def db_exception_handler(request: Request, exc: SQLAlchemyError):
    """处理数据库异常（不暴露内部细节）"""
    logger.error(f"Database error on {request.url.path}: {exc}")

    # 触发数据库告警
    from app.core.alerting import alert_manager, AlertLevel, AlertCategory
    alert_manager.send_alert(
        AlertLevel.ERROR,
        AlertCategory.SYSTEM_HEALTH,
        "数据库操作失败",
        f"{request.method} {request.url.path}: {exc}",
        dedup_key="sys:db_error",
    )

    return UTF8JSONResponse(
        status_code=500,
        content={
            "detail": "数据库操作失败",
            "message": "内部服务错误，请稍后重试",
        },
    )


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """通用异常处理器（兜底）"""
    logger.error(f"Unhandled exception on {request.url.path}: {exc}", exc_info=True)

    # 触发未知错误告警
    from app.core.alerting import alert_manager, AlertLevel, AlertCategory
    alert_manager.send_alert(
        AlertLevel.ERROR,
        AlertCategory.SYSTEM_HEALTH,
        "未处理异常",
        f"{request.method} {request.url.path}: {type(exc).__name__}",
        dedup_key=f"sys:unhandled:{type(exc).__name__}",
    )

    return UTF8JSONResponse(
        status_code=500,
        content={
            "detail": "服务器内部错误",
            "message": "内部服务错误，请稍后重试",
        },
    )


# 注册路由
app.include_router(api_router, prefix="/api/v1")


@app.get("/")
async def root():
    return {
        "name": "V70 彩票AI工作台",
        "version": "1.0.0",
        "status": "running",
    }


@app.get("/health")
async def health_check():
    """真实健康检查（不再是硬编码 healthy）"""
    try:
        from app.core.alerting import alert_manager
        health = await alert_manager.check_system_health()
        return health
    except Exception as e:
        logger.error(f"健康检查失败: {e}")
        return {"status": "unhealthy", "error": str(e)}
