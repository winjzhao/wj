"""
V70 彩票AI工作台 - 数据解析器
将原始数据解析为结构化数据，支持多种彩票类型
"""
from typing import List, Dict, Any
from app.core.lottery_schema import get_schema


class DataParser:
    """数据解析器 - 通用多类型解析"""

    @staticmethod
    def parse_draw(raw: Dict[str, Any]) -> Dict[str, Any]:
        """
        解析单条开奖数据（通用版本）
        
        自动识别数据来源格式:
        1. 中彩网API格式: {code, date, red: "1,2,3,...", blue: "1", ...}
        2. 体彩网API格式: {lotteryDrawNum, lotteryDrawResult: "1 2 3 4 5 6 7", ...}
        3. 旧版SSQ格式: {period, red1..red6, blue, ...}
        4. 通用格式: {period, main_balls: [...], bonus_balls: [[...], ...]}
        
        优先使用通用字段，回退到兼容解析。
        """
        lottery_type = raw.get("lottery_type", "ssq")

        # 如果已有通用字段，直接返回
        if "main_balls" in raw and "bonus_balls" in raw:
            return {
                "period": str(raw.get("period", raw.get("code", ""))),
                "draw_date": raw.get("draw_date", ""),
                "lottery_type": lottery_type,
                "main_balls": raw["main_balls"],
                "bonus_balls": raw["bonus_balls"],
            }

        # 中彩网格式: red="07,11,14,16,27,28", blue="06"
        if "red" in raw and isinstance(raw["red"], str):
            return DataParser._parse_cwl_format(raw, lottery_type)

        # 体彩网格式: lotteryDrawResult="01 02 03 04 05 06 07"
        if "lotteryDrawResult" in raw:
            return DataParser._parse_sporttery_format(raw, lottery_type)

        # 旧版SSQ格式
        return DataParser._parse_legacy_ssq(raw)

    @staticmethod
    def _parse_cwl_format(raw: Dict[str, Any], lottery_type: str) -> Dict[str, Any]:
        """解析中彩网API格式"""
        red_str = raw.get("red", "")
        main_balls = (
            [int(x.strip()) for x in red_str.split(",") if x.strip()]
            if red_str
            else []
        )

        blue_str = raw.get("blue", "")
        bonus_balls_list = []
        if blue_str:
            bonus_nums = [int(x.strip()) for x in blue_str.split(",") if x.strip()]
            if bonus_nums:
                bonus_balls_list = [bonus_nums]

        return {
            "period": str(raw.get("code", "")),
            "draw_date": raw.get("date", ""),
            "lottery_type": lottery_type,
            "main_balls": main_balls,
            "bonus_balls": bonus_balls_list,
        }

    @staticmethod
    def _parse_sporttery_format(raw: Dict[str, Any], lottery_type: str) -> Dict[str, Any]:
        """解析体彩网API格式 (大乐透)"""
        result_str = raw.get("lotteryDrawResult", "")
        nums = [int(x) for x in result_str.split() if x.strip()]

        main_balls = sorted(nums[:5]) if len(nums) >= 5 else nums
        bonus_balls_list = [sorted(nums[5:7])] if len(nums) >= 7 else []

        return {
            "period": str(raw.get("lotteryDrawNum", "")),
            "draw_date": raw.get("lotteryDrawTime", ""),
            "lottery_type": "dlt",
            "main_balls": main_balls,
            "bonus_balls": bonus_balls_list,
        }

    @staticmethod
    def _parse_legacy_ssq(raw: Dict[str, Any]) -> Dict[str, Any]:
        """解析旧版SSQ格式 (向后兼容)"""
        return {
            "period": str(raw.get("period", "")),
            "draw_date": raw.get("draw_date", ""),
            "lottery_type": "ssq",
            "main_balls": sorted([
                int(raw.get("red1", 0)),
                int(raw.get("red2", 0)),
                int(raw.get("red3", 0)),
                int(raw.get("red4", 0)),
                int(raw.get("red5", 0)),
                int(raw.get("red6", 0)),
            ]),
            "bonus_balls": [[int(raw.get("blue", 0))]],
        }

    @staticmethod
    def parse_batch(raw_list: List[Dict]) -> List[Dict]:
        """批量解析"""
        return [DataParser.parse_draw(item) for item in raw_list]
