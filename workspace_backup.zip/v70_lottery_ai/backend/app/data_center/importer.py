"""
V70 彩票AI工作台 - 历史数据导入器
"""
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from loguru import logger
from app.database.models import LotteryDraw
from app.core.lottery_schema import get_schema
from datetime import datetime, timedelta
import random


class DataImporter:
    """历史数据导入器 - 用于初始化/导入大量历史数据"""

    @staticmethod
    async def import_mock_data(db: AsyncSession, count: int = 500, lottery_type: str = "ssq"):
        """导入模拟数据（用于开发测试）"""
        schema = get_schema(lottery_type)
        main_count = schema["main_count"]
        main_lo, main_hi = schema["main_balls"]["range"]
        main_range = list(range(main_lo, main_hi + 1))

        bonus_cfgs = schema["bonus_balls"]
        total_bonus_count = sum(b["count"] for b in bonus_cfgs)

        random.seed(42)
        draws = []

        base_date = datetime(2024, 1, 1)

        for i in range(count):
            period = f"2024{str(i+1).zfill(3)}"

            # 检查是否已存在
            result = await db.execute(
                select(LotteryDraw).where(
                    LotteryDraw.period == period,
                    LotteryDraw.lottery_type == lottery_type,
                )
            )
            if result.scalar_one_or_none():
                continue

            # 生成随机主球区号码
            main_balls = sorted(random.sample(main_range, main_count))

            # 生成随机附加球
            bonus_balls_list = []
            for cfg in bonus_cfgs:
                lo, hi = cfg["range"]
                count_b = cfg["count"]
                bonus_range = list(range(lo, hi + 1))
                balls = sorted(random.sample(bonus_range, count_b))
                bonus_balls_list.append(balls)

            draw_date = base_date + timedelta(days=i * 3)

            # 构建 LotteryDraw 参数
            draw_kwargs = {
                "period": period,
                "draw_date": draw_date,
                "lottery_type": lottery_type,
                "main_balls_json": main_balls,
                "bonus_balls_json": bonus_balls_list,
                "red_sum": sum(main_balls),
                "span": max(main_balls) - min(main_balls),
                "odd_count": sum(1 for r in main_balls if r % 2 == 1),
            }

            # 填充 main_ball 列
            main_cols = [
                "main_ball1", "main_ball2", "main_ball3", "main_ball4",
                "main_ball5", "main_ball6", "main_ball7", "main_ball8",
                "main_ball9", "main_ball10", "main_ball11", "main_ball12",
                "main_ball13", "main_ball14", "main_ball15", "main_ball16",
                "main_ball17", "main_ball18", "main_ball19", "main_ball20",
            ]
            for j, val in enumerate(main_balls[:20]):
                draw_kwargs[main_cols[j]] = val

            # 填充 bonus_ball 列
            bonus_cols = ["bonus_ball1", "bonus_ball2"]
            bonus_idx = 0
            for b_list in bonus_balls_list:
                for val in b_list:
                    if bonus_idx < len(bonus_cols):
                        draw_kwargs[bonus_cols[bonus_idx]] = val
                        bonus_idx += 1

            # 向后兼容 SSQ
            if lottery_type == "ssq":
                for j, val in enumerate(main_balls[:6]):
                    draw_kwargs[f"red{j+1}"] = val
                if bonus_balls_list and bonus_balls_list[0]:
                    draw_kwargs["blue"] = bonus_balls_list[0][0]

            # 分区统计
            if lottery_type == "ssq":
                draw_kwargs["zone1_count"] = sum(1 for r in main_balls if 1 <= r <= 11)
                draw_kwargs["zone2_count"] = sum(1 for r in main_balls if 12 <= r <= 22)
                draw_kwargs["zone3_count"] = sum(1 for r in main_balls if 23 <= r <= 33)

            draw = LotteryDraw(**draw_kwargs)
            db.add(draw)
            draws.append(draw)

        await db.commit()
        logger.info(f"已导入 {len(draws)} 条模拟历史数据 ({lottery_type})")
        return draws
