"""
V70 彩票AI工作台 - 数据采集器
负责从外部数据源采集彩票开奖数据
支持: 双色球(SSQ)、快乐8(K8) - 中彩网API
      大乐透(DLT) - 中彩网/体彩网API
"""
import httpx
import asyncio
import re
from datetime import datetime
from typing import Optional, List, Dict, Any
from loguru import logger
from app.database.models import LotteryDraw
from app.core.lottery_schema import get_schema, validate_main_balls, validate_bonus_balls
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select


# ============================================================
# 真实数据源 API 配置
# ============================================================

# 中彩网 (中国福利彩票) - 支持 SSQ, K8, QLC, 3D
CWL_API_BASE = "https://www.cwl.gov.cn/cwl_admin/front/cwlkj/search/kjxx/findDrawNotice"

# 彩票类型 -> API name 参数映射
CWL_NAME_MAP = {
    "ssq": "ssq",      # 双色球
    "k8":  "kl8",      # 快乐8
    "dlt": "dlt",      # 大乐透 (体彩，中彩网可能没有，用备用API)
}

# 体彩网API (大乐透)
SPORTTERY_DLT_API = "https://webapi.sporttery.cn/gateway/lottery/getHistoryPageListV1.qry"


class DataCollector:
    """数据采集器 - 从真实API采集彩票开奖数据"""

    def __init__(self, lottery_type: str = "ssq"):
        self.lottery_type = lottery_type
        self._schema = get_schema(lottery_type)

    # ============================================================
    # 中彩网 API - 双色球 & 快乐8
    # ============================================================

    async def _fetch_from_cwl(
        self, page_no: int = 1, page_size: int = 50
    ) -> Optional[Dict[str, Any]]:
        """
        从中彩网API获取开奖数据
        
        API 响应格式:
        {
            "state": 0,
            "message": "查询成功",
            "total": 2036,
            "pageNum": 204,
            "pageNo": 1,
            "result": [
                {
                    "name": "双色球",
                    "code": "2026078",
                    "date": "2026-07-09(四)",
                    "week": "四",
                    "red": "07,11,14,16,27,28",      // 逗号分隔的主球区号码
                    "blue": "06",                      // 逗号分隔的附加球号码(可能为空)
                    "sales": "355852948",
                    "poolmoney": "285632700",
                    "prizegrades": [...]
                },
                ...
            ]
        }
        """
        api_name = CWL_NAME_MAP.get(self.lottery_type)
        if not api_name:
            return None

        params = {
            "name": api_name,
            "pageNo": page_no,
            "pageSize": page_size,
            "systemType": "PC",
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.get(CWL_API_BASE, params=params)
                resp.raise_for_status()
                data = resp.json()

                if data.get("state") == 0:
                    logger.info(
                        f"[中彩网] {self.lottery_type}: "
                        f"第{page_no}页, 共{data.get('total', 0)}条记录"
                    )
                    return data
                else:
                    logger.error(f"[中彩网] API返回错误: {data.get('message')}")
                    return None

        except httpx.HTTPError as e:
            logger.error(f"[中彩网] HTTP请求失败: {e}")
            return None
        except Exception as e:
            logger.error(f"[中彩网] 请求异常: {e}")
            return None

    def _parse_cwl_draw(self, raw: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        解析中彩网单条开奖数据为通用格式
        
        Args:
            raw: 中彩网API返回的单条原始数据
            
        Returns:
            通用格式的开奖数据dict, 或 None
        """
        try:
            period = raw.get("code", "")
            if not period:
                return None

            # 解析日期 "2026-07-09(四)" -> datetime
            date_str = raw.get("date", "")
            date_match = re.match(r"(\d{4}-\d{2}-\d{2})", date_str)
            if date_match:
                draw_date = datetime.strptime(date_match.group(1), "%Y-%m-%d")
            else:
                draw_date = datetime.now()

            # 解析主球区号码 (逗号分隔的字符串)
            red_str = raw.get("red", "")
            main_balls = []
            if red_str:
                main_balls = [int(x.strip()) for x in red_str.split(",") if x.strip()]

            # 解析附加球号码
            blue_str = raw.get("blue", "")
            bonus_balls_list = []
            if blue_str:
                bonus_nums = [int(x.strip()) for x in blue_str.split(",") if x.strip()]
                # 中彩网 API 的 blue 字段格式因彩种而异:
                # - SSQ: "06" (单个蓝球)
                # - K8: "" (空)
                # 对于 SSQ, 将其包装为 [[blue]]
                if bonus_nums:
                    bonus_balls_list = [bonus_nums]

            # 解析销售额和奖池 (可选) — poolmoney 可能是浮点数
            sales = int(float(raw.get("sales", 0))) if raw.get("sales") else 0
            pool_money = int(float(raw.get("poolmoney", 0))) if raw.get("poolmoney") else 0

            return {
                "period": period,
                "draw_date": draw_date.isoformat(),
                "lottery_type": self.lottery_type,
                "main_balls": main_balls,
                "bonus_balls": bonus_balls_list,
                "sales": sales,
                "pool_money": pool_money,
                "raw_date": raw.get("date", ""),
                "week": raw.get("week", ""),
            }

        except Exception as e:
            logger.error(f"[中彩网] 解析数据失败 (期号={raw.get('code', '?')}): {e}")
            return None

    # ============================================================
    # 体彩网 API - 大乐透 (备用)
    # ============================================================

    async def _fetch_dlt_from_sporttery(
        self, page_no: int = 1, page_size: int = 50
    ) -> Optional[Dict[str, Any]]:
        """
        从体彩网API获取大乐透数据
        
        注意: 此API可能需要特定的 headers/cookies 才能访问，
        如果不可用则回退到模拟数据。
        """
        params = {
            "gameNo": 85,       # 85 = 大乐透
            "provinceId": 0,
            "pageSize": page_size,
            "isVerify": 1,
            "pageNo": page_no,
        }
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            "Referer": "https://www.lottery.gov.cn/",
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.get(
                    SPORTTERY_DLT_API, params=params, headers=headers
                )
                resp.raise_for_status()
                data = resp.json()
                logger.info(
                    f"[体彩网] DLT: 第{page_no}页, "
                    f"共{data.get('value', {}).get('total', 0)}条"
                )
                return data
        except httpx.HTTPError as e:
            logger.warning(f"[体彩网] DLT API 不可用 ({e}), 将使用模拟数据")
            return None
        except Exception as e:
            logger.warning(f"[体彩网] DLT 请求异常: {e}")
            return None

    def _parse_sporttery_dlt_draw(self, raw: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        解析体彩网大乐透单条数据
        
        体彩网 API 格式 (value.list[]):
        {
            "lotteryDrawNum": "2026078",
            "lotteryDrawTime": "2026-07-08",
            "lotteryDrawResult": "01 02 03 04 05 06 07",  // 前5+后2, 空格分隔
            ...
        }
        """
        try:
            period = raw.get("lotteryDrawNum", "")
            if not period:
                return None

            draw_date_str = raw.get("lotteryDrawTime", "")
            if draw_date_str:
                draw_date = datetime.strptime(draw_date_str, "%Y-%m-%d")
            else:
                draw_date = datetime.now()

            # 解析号码: "01 02 03 04 05 06 07" -> 前区5个 + 后区2个
            result_str = raw.get("lotteryDrawResult", "")
            nums = [int(x) for x in result_str.split() if x.strip()]
            
            # 前区5个, 后区2个
            main_balls = sorted(nums[:5]) if len(nums) >= 5 else nums
            bonus_balls_list = [sorted(nums[5:7])] if len(nums) >= 7 else []

            return {
                "period": period,
                "draw_date": draw_date.isoformat(),
                "lottery_type": "dlt",
                "main_balls": main_balls,
                "bonus_balls": bonus_balls_list,
                "raw_date": draw_date_str,
            }

        except Exception as e:
            logger.error(f"[体彩网] 解析DLT数据失败: {e}")
            return None

    # ============================================================
    # 公开接口
    # ============================================================

    async def fetch_latest(self) -> Optional[dict]:
        """
        获取最新一期开奖数据
        """
        if self.lottery_type in ("ssq", "k8"):
            return await self._fetch_latest_from_cwl()
        elif self.lottery_type == "dlt":
            return await self._fetch_latest_dlt()
        else:
            logger.warning(f"不支持的彩票类型: {self.lottery_type}")
            return None

    async def _fetch_latest_from_cwl(self) -> Optional[dict]:
        """从中彩网获取最新一期"""
        data = await self._fetch_from_cwl(page_no=1, page_size=1)
        if data and data.get("result"):
            return self._parse_cwl_draw(data["result"][0])
        return None

    async def _fetch_latest_dlt(self) -> Optional[dict]:
        """获取最新大乐透"""
        # 先尝试体彩网
        data = await self._fetch_dlt_from_sporttery(page_no=1, page_size=1)
        if data:
            value = data.get("value", {})
            results = value.get("list", [])
            if results:
                return self._parse_sporttery_dlt_draw(results[0])

        # 体彩网不可用，尝试中彩网(可能不支持)
        cwl_data = await self._fetch_from_cwl(page_no=1, page_size=1)
        if cwl_data and cwl_data.get("result"):
            return self._parse_cwl_draw(cwl_data["result"][0])

        logger.warning("[DLT] 所有真实数据源不可用")
        return None

    async def fetch_history(
        self, page_count: int = 10, page_size: int = 50
    ) -> List[dict]:
        """
        批量获取历史开奖数据
        
        Args:
            page_count: 获取多少页
            page_size: 每页多少条 (中彩网最大50)
        
        Returns:
            解析后的开奖数据列表
        """
        all_draws = []

        if self.lottery_type in ("ssq", "k8"):
            for page in range(1, page_count + 1):
                data = await self._fetch_from_cwl(page_no=page, page_size=page_size)
                if data and data.get("result"):
                    for item in data["result"]:
                        parsed = self._parse_cwl_draw(item)
                        if parsed:
                            all_draws.append(parsed)
                # 避免请求过快
                await asyncio.sleep(0.5)

        elif self.lottery_type == "dlt":
            # 先尝试体彩网
            for page in range(1, page_count + 1):
                data = await self._fetch_dlt_from_sporttery(
                    page_no=page, page_size=page_size
                )
                if data:
                    value = data.get("value", {})
                    for item in value.get("list", []):
                        parsed = self._parse_sporttery_dlt_draw(item)
                        if parsed:
                            all_draws.append(parsed)
                await asyncio.sleep(0.5)

            # 如果体彩网没数据，尝试中彩网
            if not all_draws:
                for page in range(1, page_count + 1):
                    data = await self._fetch_from_cwl(
                        page_no=page, page_size=page_size
                    )
                    if data and data.get("result"):
                        for item in data["result"]:
                            parsed = self._parse_cwl_draw(item)
                            if parsed:
                                all_draws.append(parsed)
                    await asyncio.sleep(0.5)

        logger.info(
            f"[采集] {self.lottery_type}: 共获取 {len(all_draws)} 条历史数据"
        )
        return all_draws

    # ============================================================
    # 数据保存
    # ============================================================

    async def parse_and_save(
        self, raw_data: dict, db: AsyncSession
    ) -> Optional[LotteryDraw]:
        """解析原始数据并保存到数据库"""
        try:
            lottery_type = raw_data.get("lottery_type", self.lottery_type)
            schema = get_schema(lottery_type)
            main_lo = schema["main_balls"]["range"][0]
            main_hi = schema["main_balls"]["range"][1]

            main_balls = raw_data.get("main_balls", raw_data.get("reds", []))
            bonus_balls_list = raw_data.get("bonus_balls", [])

            # 检查是否已存在
            result = await db.execute(
                select(LotteryDraw).where(
                    LotteryDraw.period == raw_data["period"],
                    LotteryDraw.lottery_type == lottery_type,
                )
            )
            if result.scalar_one_or_none():
                logger.debug(f"数据已存在，跳过: 期号 {raw_data['period']} ({lottery_type})")
                return None

            draw_date_str = raw_data.get("draw_date", "")
            if draw_date_str:
                draw_date = datetime.fromisoformat(draw_date_str)
            else:
                draw_date = datetime.now()

            # 构建 LotteryDraw 参数
            draw_kwargs = {
                "period": raw_data["period"],
                "draw_date": draw_date,
                "lottery_type": lottery_type,
                "main_balls_json": main_balls,
                "bonus_balls_json": bonus_balls_list,
            }

            # 填充 main_ball 列
            main_cols = [
                "main_ball1", "main_ball2", "main_ball3", "main_ball4",
                "main_ball5", "main_ball6", "main_ball7", "main_ball8",
                "main_ball9", "main_ball10", "main_ball11", "main_ball12",
                "main_ball13", "main_ball14", "main_ball15", "main_ball16",
                "main_ball17", "main_ball18", "main_ball19", "main_ball20",
            ]
            for i, val in enumerate(main_balls[:20]):
                draw_kwargs[main_cols[i]] = val

            # 填充 bonus_ball 列
            bonus_cols = ["bonus_ball1", "bonus_ball2"]
            bonus_idx = 0
            for b_list in bonus_balls_list:
                for val in b_list:
                    if bonus_idx < len(bonus_cols):
                        draw_kwargs[bonus_cols[bonus_idx]] = val
                        bonus_idx += 1

            # 向后兼容 SSQ
            if lottery_type == "ssq":
                for i, val in enumerate(main_balls[:6]):
                    draw_kwargs[f"red{i+1}"] = val
                if bonus_balls_list and bonus_balls_list[0]:
                    draw_kwargs["blue"] = bonus_balls_list[0][0]

            # 统计信息
            draw_kwargs["red_sum"] = sum(main_balls)
            draw_kwargs["span"] = max(main_balls) - min(main_balls)
            draw_kwargs["odd_count"] = sum(1 for r in main_balls if r % 2 == 1)

            # 分区统计
            if lottery_type == "ssq":
                draw_kwargs["zone1_count"] = sum(1 for r in main_balls if 1 <= r <= 11)
                draw_kwargs["zone2_count"] = sum(1 for r in main_balls if 12 <= r <= 22)
                draw_kwargs["zone3_count"] = sum(1 for r in main_balls if 23 <= r <= 33)

            draw = LotteryDraw(**draw_kwargs)
            db.add(draw)
            await db.commit()
            logger.info(f"数据保存成功: 期号 {draw.period} ({lottery_type})")
            return draw

        except Exception as e:
            await db.rollback()
            logger.error(f"数据解析保存失败: {e}")
            return None

    async def sync_latest(self, db: AsyncSession) -> Optional[LotteryDraw]:
        """
        同步最新一期数据: 抓取 + 解析 + 保存
        """
        raw = await self.fetch_latest()
        if raw:
            return await self.parse_and_save(raw, db)
        return None

    async def sync_history(
        self, db: AsyncSession, page_count: int = 10
    ) -> int:
        """
        批量同步历史数据
        Returns: 成功保存的条数
        """
        draws = await self.fetch_history(page_count=page_count)
        saved = 0
        for d in draws:
            result = await self.parse_and_save(d, db)
            if result:
                saved += 1
        return saved

    # ============================================================
    # 数据验证
    # ============================================================

    def validate_data(self, data: dict, lottery_type: str = None) -> bool:
        """验证数据有效性"""
        lt = lottery_type or self.lottery_type
        if not data:
            return False

        main_balls = data.get("main_balls", data.get("reds", []))
        if not validate_main_balls(lt, main_balls):
            return False

        bonus_balls = data.get("bonus_balls", [])
        if bonus_balls:
            if not validate_bonus_balls(lt, bonus_balls):
                return False
        else:
            blue = data.get("blue", None)
            if blue is not None:
                schema = get_schema(lt)
                bonus_cfgs = schema["bonus_balls"]
                if bonus_cfgs:
                    lo, hi = bonus_cfgs[0]["range"]
                    if not (lo <= blue <= hi):
                        return False

        return True


class DataValidator:
    """数据校验器"""

    @staticmethod
    def check_consistency(draw: LotteryDraw) -> bool:
        """检查数据一致性"""
        schema = get_schema(draw.lottery_type)
        main_balls = draw.get_main_balls()
        if not validate_main_balls(draw.lottery_type, main_balls):
            return False
        bonus_balls = draw.get_bonus_balls()
        if bonus_balls:
            if not validate_bonus_balls(draw.lottery_type, bonus_balls):
                return False
        return True

    @staticmethod
    def check_duplicate(db_session, period: str):
        """检查重复数据"""
        pass


class DataCleaner:
    """数据清洗器"""

    @staticmethod
    def clean_main_balls(raw_balls: list, lottery_type: str = "ssq") -> list:
        schema = get_schema(lottery_type)
        lo, hi = schema["main_balls"]["range"]
        count = schema["main_count"]
        balls = [int(r) for r in raw_balls if lo <= int(r) <= hi]
        return sorted(set(balls))[:count]

    @staticmethod
    def clean_bonus_balls(raw_bonus: list, lottery_type: str = "ssq") -> list:
        schema = get_schema(lottery_type)
        result = []
        for cfg, raw in zip(schema["bonus_balls"], raw_bonus):
            lo, hi = cfg["range"]
            count = cfg["count"]
            if isinstance(raw, list):
                balls = [int(r) for r in raw if lo <= int(r) <= hi]
                result.append(sorted(set(balls))[:count])
            else:
                val = int(raw)
                if lo <= val <= hi:
                    result.append([val])
                else:
                    result.append([])
        return result

    @staticmethod
    def clean_reds(raw_reds: list) -> list:
        return DataCleaner.clean_main_balls(raw_reds, "ssq")

    @staticmethod
    def clean_blue(raw_blue) -> int:
        blue = int(raw_blue)
        return max(1, min(16, blue))
