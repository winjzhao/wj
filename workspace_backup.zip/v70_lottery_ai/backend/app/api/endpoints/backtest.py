"""
V70 彩票AI工作台 - 回测中心API
提供完整的回测功能：运行回测、查看结果、模型对比
"""
from fastapi import APIRouter, HTTPException, Query, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func

from app.database.db import get_db
from app.database.models import LotteryDraw, Prediction, ExperimentRecord, EvolutionHistory
from app.core.utils import calculate_match_count
from app.core.lottery_schema import get_schema
from app.orchestrator.workflow import orchestrator

router = APIRouter()

# 简单的内存缓存，用于存储回测结果
_backtest_cache: Dict[str, Dict[str, Any]] = {}


class BacktestRunRequest(BaseModel):
    """运行回测请求"""
    lottery_type: str = "ssq"
    periods: int = 50
    force_rerun: bool = False


class BacktestCompareRequest(BaseModel):
    """模型对比请求"""
    lottery_type: str = "ssq"
    model_a: str
    model_b: str
    periods: int = 50


def _get_cache_key(lottery_type: str, periods: int) -> str:
    """生成缓存键"""
    return f"{lottery_type}_{periods}"


@router.post("/run", summary="运行完整回测", description="对指定彩票类型进行完整的历史数据回测，返回各模型的表现评分、准确率趋势和详细命中统计。")
async def run_backtest(
    request: BacktestRunRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    运行完整回测
    从数据库读取历史预测和开奖数据，计算真实的命中率和模型表现
    """
    cache_key = _get_cache_key(request.lottery_type, request.periods)

    # 检查缓存
    if not request.force_rerun and cache_key in _backtest_cache:
        return {
            "status": "ok",
            "source": "cache",
            **{k: v for k, v in _backtest_cache[cache_key].items() if k != "_raw"},
        }

    try:
        # 查询预测记录
        result = await db.execute(
            select(Prediction)
            .where(Prediction.lottery_type == request.lottery_type)
            .order_by(desc(Prediction.created_at))
            .limit(request.periods)
        )
        predictions = result.scalars().all()

        if not predictions:
            return {
                "status": "no_data",
                "lottery_type": request.lottery_type,
                "total_periods": 0,
                "accuracy_trend": [],
                "model_performance": {},
                "detail": [],
                "message": "暂无预测记录，请先运行预测",
            }

        # 收集期号并查询开奖数据
        periods = list(set(p.period for p in predictions))
        result = await db.execute(
            select(LotteryDraw)
            .where(
                LotteryDraw.lottery_type == request.lottery_type,
                LotteryDraw.period.in_(periods),
            )
        )
        draws_by_period = {d.period: d for d in result.scalars().all()}

        # 按模型分组统计
        model_stats: Dict[str, dict] = {}
        detail_records = []
        accuracy_trend = []

        for pred in predictions:
            draw = draws_by_period.get(pred.period)
            if not draw:
                continue

            pred_main = pred.main_balls if pred.main_balls else []
            actual_main = draw.get_main_balls()
            pred_bonus = pred.bonus_balls if pred.bonus_balls else None
            actual_bonus = draw.get_bonus_balls()

            total_match, has_bonus, match_main, match_bonus = calculate_match_count(
                prediction_main=pred_main,
                actual_main=actual_main,
                prediction_bonus=pred_bonus,
                actual_bonus=actual_bonus,
                lottery_type=request.lottery_type,
            )

            # 按模型聚合
            model_name = pred.model_name
            if model_name not in model_stats:
                model_stats[model_name] = {
                    "total_matches": 0,
                    "total_main_matches": 0,
                    "total_bonus_matches": 0,
                    "bonus_hit_count": 0,
                    "count": 0,
                    "period_matches": [],
                }

            model_stats[model_name]["total_matches"] += total_match
            model_stats[model_name]["total_main_matches"] += match_main
            model_stats[model_name]["total_bonus_matches"] += match_bonus
            model_stats[model_name]["bonus_hit_count"] += 1 if has_bonus else 0
            model_stats[model_name]["count"] += 1
            model_stats[model_name]["period_matches"].append(total_match)

            detail_records.append({
                "period": pred.period,
                "model": model_name,
                "match_main": match_main,
                "match_bonus": match_bonus,
                "total_match": total_match,
                "has_bonus": has_bonus,
            })
            accuracy_trend.append(total_match)

        # 构建模型表现
        model_performance = {}
        for model_name, stats in model_stats.items():
            if stats["count"] > 0:
                avg_hit = stats["total_matches"] / stats["count"]
                avg_main = stats["total_main_matches"] / stats["count"]
                avg_bonus = stats["total_bonus_matches"] / stats["count"]

                # 趋势判断
                if len(stats["period_matches"]) >= 4:
                    quarter = max(1, len(stats["period_matches"]) // 4)
                    first_q = sum(stats["period_matches"][:quarter])
                    last_q = sum(stats["period_matches"][-quarter:])
                    if last_q > first_q * 1.1:
                        trend = "improving"
                    elif last_q < first_q * 0.9:
                        trend = "declining"
                    else:
                        trend = "stable"
                else:
                    trend = "stable"

                model_performance[model_name] = {
                    "avg_total_match": round(avg_hit, 3),
                    "avg_main_match": round(avg_main, 3),
                    "avg_bonus_match": round(avg_bonus, 3),
                    "bonus_hit_rate": round(stats["bonus_hit_count"] / stats["count"], 3),
                    "trend": trend,
                    "sample_count": stats["count"],
                }

        avg_score = round(sum(accuracy_trend) / len(accuracy_trend), 3) if accuracy_trend else 0

        # 缓存结果
        response = {
            "status": "ok",
            "lottery_type": request.lottery_type,
            "total_periods": len(detail_records),
            "avg_score": avg_score,
            "accuracy_trend": [round(x, 2) for x in accuracy_trend],
            "model_performance": model_performance,
            "detail": detail_records,
        }

        _backtest_cache[cache_key] = {
            **response,
            "_raw": {"predictions": predictions, "draws_by_period": draws_by_period},
        }

        return response

    except Exception as e:
        logger.error(f"回测运行失败: {e}")
        raise HTTPException(status_code=500, detail=f"回测运行失败: {str(e)}")


@router.get("/results", summary="获取回测结果", description="获取最近一次回测的缓存结果。")
async def get_backtest_results(
    lottery_type: str = Query("ssq", description="彩票类型"),
    periods: int = Query(50, description="回测期数"),
):
    """获取缓存回测结果"""
    cache_key = _get_cache_key(lottery_type, periods)

    if cache_key in _backtest_cache:
        cached = _backtest_cache[cache_key]
        return {
            "status": "ok",
            "source": "cache",
            **{k: v for k, v in cached.items() if k != "_raw"},
        }

    return {
        "status": "not_found",
        "message": f"未找到 {lottery_type} 的 {periods} 期回测结果，请先运行 POST /backtest/run",
        "lottery_type": lottery_type,
        "total_periods": 0,
        "accuracy_trend": [],
        "model_performance": {},
        "detail": [],
    }


@router.post("/compare", summary="模型对比", description="对比两个模型在指定期数内的回测表现。")
async def compare_models(
    request: BacktestCompareRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    对比两个模型
    分别查询两个模型的预测记录，与开奖数据匹配后比较表现
    """
    try:
        # 分别查询两个模型的预测记录
        result_a = await db.execute(
            select(Prediction)
            .where(
                Prediction.lottery_type == request.lottery_type,
                Prediction.model_name == request.model_a,
            )
            .order_by(desc(Prediction.created_at))
            .limit(request.periods)
        )
        preds_a = {p.period: p for p in result_a.scalars().all()}

        result_b = await db.execute(
            select(Prediction)
            .where(
                Prediction.lottery_type == request.lottery_type,
                Prediction.model_name == request.model_b,
            )
            .order_by(desc(Prediction.created_at))
            .limit(request.periods)
        )
        preds_b = {p.period: p for p in result_b.scalars().all()}

        # 找出两者共有的期号
        common_periods = set(preds_a.keys()) & set(preds_b.keys())

        if not common_periods:
            return {
                "status": "no_common_data",
                "message": f"模型 {request.model_a} 和 {request.model_b} 没有共同时期的预测记录",
                "model_a": request.model_a,
                "model_b": request.model_b,
            }

        # 查询对应的开奖数据
        result = await db.execute(
            select(LotteryDraw)
            .where(
                LotteryDraw.lottery_type == request.lottery_type,
                LotteryDraw.period.in_(list(common_periods)),
            )
        )
        draws_by_period = {d.period: d for d in result.scalars().all()}

        # 分别计算两个模型的命中
        stats_a = {"total_matches": 0, "count": 0}
        stats_b = {"total_matches": 0, "count": 0}
        period_comparison = []

        for period in sorted(common_periods):
            draw = draws_by_period.get(period)
            if not draw:
                continue

            pred_a = preds_a[period]
            pred_b = preds_b[period]
            actual_main = draw.get_main_balls()
            actual_bonus = draw.get_bonus_balls()

            match_a, _, _, _ = calculate_match_count(
                prediction_main=pred_a.main_balls if pred_a.main_balls else [],
                actual_main=actual_main,
                prediction_bonus=pred_a.bonus_balls if pred_a.bonus_balls else None,
                actual_bonus=actual_bonus,
                lottery_type=request.lottery_type,
            )

            match_b, _, _, _ = calculate_match_count(
                prediction_main=pred_b.main_balls if pred_b.main_balls else [],
                actual_main=actual_main,
                prediction_bonus=pred_b.bonus_balls if pred_b.bonus_balls else None,
                actual_bonus=actual_bonus,
                lottery_type=request.lottery_type,
            )

            stats_a["total_matches"] += match_a
            stats_a["count"] += 1
            stats_b["total_matches"] += match_b
            stats_b["count"] += 1

            period_comparison.append({
                "period": period,
                f"{request.model_a}_match": match_a,
                f"{request.model_b}_match": match_b,
                "diff": match_a - match_b,
            })

        avg_a = round(stats_a["total_matches"] / stats_a["count"], 3) if stats_a["count"] > 0 else 0
        avg_b = round(stats_b["total_matches"] / stats_b["count"], 3) if stats_b["count"] > 0 else 0

        return {
            "status": "ok",
            "lottery_type": request.lottery_type,
            "model_a": {
                "name": request.model_a,
                "avg_match": avg_a,
                "total_matches": stats_a["total_matches"],
                "sample_count": stats_a["count"],
            },
            "model_b": {
                "name": request.model_b,
                "avg_match": avg_b,
                "total_matches": stats_b["total_matches"],
                "sample_count": stats_b["count"],
            },
            "comparison": {
                "winner": request.model_a if avg_a > avg_b else (request.model_b if avg_b > avg_a else "tie"),
                "diff": round(abs(avg_a - avg_b), 3),
                "a_wins": sum(1 for p in period_comparison if p["diff"] > 0),
                "b_wins": sum(1 for p in period_comparison if p["diff"] < 0),
                "ties": sum(1 for p in period_comparison if p["diff"] == 0),
            },
            "period_details": period_comparison,
        }

    except Exception as e:
        logger.error(f"模型对比失败: {e}")
        raise HTTPException(status_code=500, detail=f"模型对比失败: {str(e)}")


@router.delete("/cache", summary="清除回测缓存", description="清除所有内存中的回测缓存数据。")
async def clear_backtest_cache():
    """清除回测缓存"""
    count = len(_backtest_cache)
    _backtest_cache.clear()
    return {"status": "ok", "cleared_count": count}
