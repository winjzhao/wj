"""
V70 彩票AI工作台 - 模型管理API
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from app.orchestrator.workflow import orchestrator

router = APIRouter()


class ModelWeightUpdate(BaseModel):
    """模型权重更新"""
    xgboost: Optional[float] = None
    lstm: Optional[float] = None
    transformer: Optional[float] = None
    ppo: Optional[float] = None
    statistic: Optional[float] = None
    behavior: Optional[float] = None


@router.get("/list", summary="获取模型列表", description="获取所有AI模型的信息列表，包含名称、版本、可信度评分和训练状态。")
async def list_models():
    """获取所有模型列表"""
    models_info = []
    for name, model in orchestrator.models.items():
        models_info.append(model.get_info())
    return {"models": models_info}


@router.get("/{model_name}", summary="获取模型详情", description="根据模型名称获取单个模型的详细信息，包括版本、可信度、训练状态和历史表现。")
async def get_model_detail(model_name: str):
    """获取模型详情"""
    model = orchestrator.models.get(model_name)
    if not model:
        raise HTTPException(status_code=404, detail=f"模型 {model_name} 不存在")
    return model.get_info()


@router.post("/{model_name}/train", summary="训练指定模型", description="对指定的AI模型进行训练，使用模拟特征和目标数据，返回训练损失和更新后的可信度。")
async def train_model(model_name: str):
    """训练指定模型"""
    model = orchestrator.models.get(model_name)
    if not model:
        raise HTTPException(status_code=404, detail=f"模型 {model_name} 不存在")

    import numpy as np
    features = np.random.randn(100).astype(np.float32)
    targets = np.random.randn(49).astype(np.float32)

    loss = model.train(features, targets)
    return {
        "model": model_name,
        "loss": loss,
        "credibility": model.credibility_score,
        "status": "trained",
    }


@router.post("/train-all", summary="训练所有模型", description="对所有6个AI模型（XGBoost、LSTM、Transformer、PPO、Statistic、Behavior）进行批量训练。")
async def train_all_models():
    """训练所有模型"""
    results = {}
    import numpy as np

    for name, model in orchestrator.models.items():
        features = np.random.randn(100).astype(np.float32)
        targets = np.random.randn(49).astype(np.float32)
        loss = model.train(features, targets)
        results[name] = {
            "loss": loss,
            "credibility": model.credibility_score,
        }

    return {"results": results, "status": "completed"}


@router.post("/weights", summary="更新模型权重", description="更新融合引擎中各模型的基础权重。支持部分更新（只传需要修改的模型权重）。权重用于多模型融合时的加权平均。")
async def update_weights(update: ModelWeightUpdate):
    """更新模型权重"""
    if update.xgboost is not None:
        orchestrator.fusion_engine.base_weights["XGBoost"] = update.xgboost
    if update.lstm is not None:
        orchestrator.fusion_engine.base_weights["LSTM"] = update.lstm
    if update.transformer is not None:
        orchestrator.fusion_engine.base_weights["Transformer"] = update.transformer
    if update.ppo is not None:
        orchestrator.fusion_engine.base_weights["PPO"] = update.ppo
    if update.statistic is not None:
        orchestrator.fusion_engine.base_weights["Statistic"] = update.statistic
    if update.behavior is not None:
        orchestrator.fusion_engine.base_weights["Behavior"] = update.behavior

    return {
        "message": "权重已更新",
        "weights": orchestrator.fusion_engine.base_weights,
    }


@router.get("/weights/current", summary="获取当前权重", description="获取融合引擎当前的模型基础权重配置，这些权重决定各模型在最终预测中的贡献度。")
async def get_current_weights():
    """获取当前权重"""
    return {"weights": orchestrator.fusion_engine.base_weights}
