"""
V70 彩票AI工作台 - 自学习进化API
提供手动触发进化、查看进化状态、代码自优化管理、回滚等接口
支持从 SQLite 持久化读写进化数据
"""
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from loguru import logger

from app.self_learning.evolution_engine import evolution_engine
from app.orchestrator.workflow import orchestrator
from app.config.settings import settings

router = APIRouter()


class EvolutionTriggerRequest(BaseModel):
    """触发进化请求"""
    lottery_type: Optional[str] = None
    period: Optional[str] = None


class EvolutionStatusResponse(BaseModel):
    """进化状态响应"""
    total_iterations: int
    last_evolution_at: Optional[str]
    feedback_report: Dict[str, Any]
    recent_matches: List[Dict[str, Any]]
    model_performance: Dict[str, Dict[str, Any]]
    current_weights: Dict[str, float]


@router.post("/trigger", summary="手动触发自学习进化", description="立即运行一次完整的自学习进化周期，匹配预测与开奖结果，更新模型权重。")
async def trigger_evolution(request: EvolutionTriggerRequest = EvolutionTriggerRequest()):
    """手动触发自学习进化"""
    try:
        from app.database.db import get_db
        async for session in get_db():
            db = session
            break

        result = await evolution_engine.run_evolution_cycle(
            db=db,
            orchestrator=orchestrator,
            lottery_type=request.lottery_type,
        )

        return {
            "status": "ok",
            "result": result,
        }
    except Exception as e:
        logger.error(f"手动触发进化失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status", response_model=EvolutionStatusResponse, summary="获取进化状态", description="查看自学习引擎的当前状态，包括各模型表现、进化历史、当前权重。")
async def get_evolution_status():
    """获取自学习进化状态"""
    status = evolution_engine.get_evolution_status()
    status["current_weights"] = orchestrator.fusion_engine.base_weights
    return status


@router.get("/history", summary="获取进化历史", description="查看自学习进化的历史记录（优先从数据库读取）。")
async def get_evolution_history(
    limit: int = Query(20, description="返回记录数"),
    lottery_type: str = Query("ssq", description="彩票类型"),
):
    """获取进化历史（优先从数据库读取持久化记录）"""
    try:
        from app.database.db import get_db
        from app.self_learning.persistence import persistence

        async for session in get_db():
            db = session
            break

        db_count = await persistence.get_evolution_history_count(db, lottery_type)

        if db_count > 0:
            # 从数据库读取持久化历史
            db_history = await persistence.get_evolution_history(db, lottery_type, limit)
            return {
                "total": db_count,
                "history": db_history,
                "source": "database",
            }

    except Exception as e:
        logger.warning(f"从数据库读取进化历史失败: {e}，回退到内存")

    # 回退到内存历史
    return {
        "total": len(evolution_engine.evolution_history),
        "history": evolution_engine.get_evolution_history(limit=limit),
        "source": "memory",
    }


@router.get("/models/performance", summary="各模型表现", description="查看各AI模型近期的命中率、评分、趋势等表现数据。")
async def get_model_performance(
    window: int = Query(30, description="统计窗口（最近N条记录）"),
):
    """获取各模型近期表现"""
    perf = evolution_engine.matcher.get_model_performance(window=window)

    # 补充当前权重和可信度
    for name in perf:
        if name in orchestrator.models:
            perf[name]["credibility"] = round(
                orchestrator.models[name].credibility_score, 4
            )
        if name in orchestrator.fusion_engine.base_weights:
            perf[name]["weight"] = orchestrator.fusion_engine.base_weights[name]

    return {
        "window": window,
        "models": perf,
    }


@router.post("/weights/reset", summary="重置权重", description="将融合权重重置为默认值，同时清除数据库中的进化状态。")
async def reset_weights():
    """重置融合权重为默认值"""
    orchestrator.fusion_engine.base_weights = {
        "XGBoost": settings.XGBOOST_WEIGHT,
        "LSTM": settings.LSTM_WEIGHT,
        "Transformer": settings.TRANSFORMER_WEIGHT,
        "PPO": settings.PPO_WEIGHT,
        "Statistic": settings.STATISTIC_WEIGHT,
        "Behavior": settings.BEHAVIOR_WEIGHT,
    }

    # 同时清除数据库中的进化状态
    try:
        from app.database.db import get_db
        from app.self_learning.persistence import persistence

        async for session in get_db():
            db = session
            break

        for lt in settings.SUPPORTED_LOTTERY_TYPES:
            await persistence.reset_evolution_state(db, lt)
    except Exception as e:
        logger.warning(f"清除数据库进化状态失败: {e}")

    return {
        "status": "ok",
        "weights": orchestrator.fusion_engine.base_weights,
    }


@router.post("/reset", summary="重置进化引擎", description="清除所有进化历史数据（含数据库），从零开始重新学习。")
async def reset_evolution():
    """重置进化引擎（含数据库持久化数据）"""
    evolution_engine.feedback.reset()
    evolution_engine.matcher.match_history.clear()
    evolution_engine.evolution_history.clear()
    evolution_engine.total_iterations = 0

    # 清除数据库中的进化数据
    try:
        from app.database.db import get_db
        from app.self_learning.persistence import persistence

        async for session in get_db():
            db = session
            break

        for lt in settings.SUPPORTED_LOTTERY_TYPES:
            await persistence.reset_evolution_state(db, lt)
            await persistence.reset_evolution_history(db, lt)
    except Exception as e:
        logger.warning(f"清除数据库进化数据失败: {e}")

    return {"status": "ok", "message": "进化引擎已重置（含数据库），将从零开始学习"}


# ============================================================
# 代码自优化 API
# ============================================================

@router.get("/code/changes", summary="查看代码变更历史", description="查看进化引擎自动写入源代码的所有变更记录。")
async def get_code_changes():
    """查看代码自优化的变更历史"""
    from app.self_learning.code_writer import code_writer
    return {
        "total": len(code_writer.change_log),
        "changes": code_writer.list_changes(),
    }


@router.get("/code/backups", summary="查看代码备份", description="查看进化引擎自动创建的代码备份文件列表。")
async def get_code_backups():
    """查看代码备份文件"""
    from app.self_learning.code_writer import code_writer
    backups = code_writer.list_backups()
    return {
        "total": len(backups),
        "backups": backups,
    }


@router.post("/code/rollback", summary="回滚代码变更", description="将进化引擎写入的代码变更回滚到变更前状态。")
async def rollback_code_change(
    change_id: Optional[int] = Query(None, description="变更ID，不指定则回滚最近一次"),
):
    """回滚代码变更"""
    from app.self_learning.code_writer import code_writer
    result = code_writer.rollback(change_id=change_id)
    return result


class CodeOptimizeRequest(BaseModel):
    """手动触发代码优化请求"""
    dry_run: bool = Query(False, description="仅模拟，不实际写入代码")
    force: bool = Query(False, description="强制执行，跳过稳定性检查")


@router.post("/code/optimize", summary="手动触发代码优化", description="手动触发进化引擎分析当前状态并优化源代码。")
async def trigger_code_optimization(
    dry_run: bool = Query(False, description="仅模拟"),
    force: bool = Query(False, description="强制执行"),
):
    """手动触发代码自优化"""
    from app.self_learning.code_writer import code_writer

    if not force:
        is_stable, stability = evolution_engine._check_weight_stability()
        if not is_stable:
            return {
                "action": "skip",
                "reason": f"权重未收敛 (stability={stability:.3f})",
                "hint": "使用 force=true 强制执行",
            }

    improvement = evolution_engine._compute_improvement_from_history()
    evolved_weights = dict(orchestrator.fusion_engine.base_weights)

    result = code_writer.auto_optimize_from_evolution(
        evolved_weights=evolved_weights,
        validation_rounds=min(len(evolution_engine._weight_snapshots), 10),
        avg_improvement=improvement,
        dry_run=dry_run,
    )

    return result


# ============================================================
# 模型管理 API
# ============================================================

@router.get("/models/status", summary="获取模型状态", description="查看所有模型的运行状态（active/degraded/retired等）及 A/B 对比结果。")
async def get_models_status():
    """获取模型管理状态"""
    return evolution_engine.model_manager.get_summary()


@router.get("/models/compare", summary="A/B 模型对比", description="对所有模型进行两两对比，返回性能排名。")
async def compare_all_models(
    window: int = Query(20, description="对比窗口大小"),
):
    """全量模型 A/B 对比"""
    results = evolution_engine.model_manager.compare_all_models(window=window)
    return {
        "total_comparisons": len(results),
        "comparisons": results,
    }


@router.post("/models/{model_name}/retire", summary="淘汰模型", description="手动将指定模型标记为退役状态，不再参与预测。")
async def retire_model(model_name: str, reason: str = Query("手动淘汰", description="淘汰原因")):
    """手动淘汰模型"""
    evolution_engine.model_manager.retire_model(model_name, reason)
    return {"status": "ok", "model": model_name, "action": "retired", "reason": reason}


@router.post("/models/{model_name}/reactivate", summary="重新激活模型", description="将已退役模型重新激活（冷启动模式）。")
async def reactivate_model(model_name: str):
    """重新激活模型"""
    evolution_engine.model_manager.reactivate_model(model_name)
    return {"status": "ok", "model": model_name, "action": "reactivated"}


@router.post("/models/retrain-degraded", summary="重训练降级模型", description="自动检测并重训练所有处于降级状态的模型。")
async def retrain_degraded_models():
    """自动重训练降级模型"""
    try:
        from app.database.db import get_db
        async for session in get_db():
            db = session
            break

        results = await evolution_engine.model_manager.auto_retrain_degraded_models(
            orchestrator=orchestrator,
            db=db,
        )
        return {"status": "ok", "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 告警管理 API
# ============================================================

@router.get("/alerts", summary="获取告警列表", description="查看系统告警历史，支持按级别过滤。")
async def get_alerts(
    limit: int = Query(50, description="返回数量"),
    level: Optional[str] = Query(None, description="告警级别过滤: info/warning/error/critical"),
):
    """获取告警列表"""
    from app.core.alerting import alert_manager
    return {
        "total": len(alert_manager.alerts),
        "active": len(alert_manager.active_alerts),
        "alerts": alert_manager.get_recent_alerts(limit=limit, level=level),
    }


@router.get("/alerts/summary", summary="获取告警摘要", description="查看告警统计摘要。")
async def get_alerts_summary():
    """获取告警摘要"""
    from app.core.alerting import alert_manager
    return alert_manager.get_summary()


@router.post("/alerts/{alert_id}/acknowledge", summary="确认告警", description="标记告警为已确认。")
async def acknowledge_alert(alert_id: str):
    """确认告警"""
    from app.core.alerting import alert_manager
    ok = alert_manager.acknowledge_alert(alert_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"告警 {alert_id} 不存在")
    return {"status": "ok", "alert_id": alert_id}


@router.post("/alerts/{alert_id}/resolve", summary="解决告警", description="标记告警为已解决。")
async def resolve_alert(alert_id: str):
    """解决告警"""
    from app.core.alerting import alert_manager
    ok = alert_manager.resolve_alert(alert_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"告警 {alert_id} 不存在")
    return {"status": "ok", "alert_id": alert_id}


@router.get("/health/full", summary="完整健康检查", description="执行全面的系统健康检查（DB连接、数据新鲜度等）。")
async def full_health_check():
    """全面健康检查"""
    from app.core.alerting import alert_manager
    health = await alert_manager.check_system_health()
    return health
