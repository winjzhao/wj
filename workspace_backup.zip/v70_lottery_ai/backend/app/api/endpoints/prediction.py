"""
V70 彩票AI工作台 - 预测中心API
"""
import numpy as np
from fastapi import APIRouter, HTTPException, Query, Depends
from pydantic import BaseModel
from typing import List, Optional
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc

from app.orchestrator.workflow import orchestrator
from app.memory_center.memory import global_memory
from app.core.lottery_schema import get_all_types, get_schema
from app.database.db import get_db
from app.database.models import LotteryDraw, Prediction, ExperimentRecord
from app.core.utils import calculate_match_count
from app.self_learning.match_engine import ResultMatcher, MatchResult

router = APIRouter()


class PredictionRequest(BaseModel):
    """预测请求"""
    lottery_type: str = "ssq"
    use_memory: bool = True


class PredictionResponse(BaseModel):
    """预测响应"""
    status: str
    lottery_type: str
    candidates: List[dict]
    final_score: float
    model_contributions: dict
    risk_assessment: dict
    fusion_count: int


class BacktestRequest(BaseModel):
    """回测请求"""
    lottery_type: str = "ssq"
    periods: int = 50


class BacktestResponse(BaseModel):
    """回测响应"""
    lottery_type: str
    total_periods: int
    avg_score: float
    accuracy_trend: List[float]
    model_performance: dict


@router.post("/generate", response_model=PredictionResponse)
async def generate_prediction(
    request: PredictionRequest = PredictionRequest(),
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """
    生成AI预测方案
    运行完整预测流程: 特征生成 → 模型预测 → 融合 → 候选方案 → 保存结果
    """
    # 请求体中的 lottery_type 优先于查询参数
    effective_type = request.lottery_type if request.lottery_type != "ssq" or lottery_type == "ssq" else lottery_type
    if request.lottery_type == "ssq" and lottery_type != "ssq":
        effective_type = lottery_type

    try:
        ctx = await orchestrator.run_full_pipeline(db_session=db, lottery_type=effective_type)

        if ctx.state.value == "error":
            raise HTTPException(status_code=500, detail=ctx.error_message)

        # 确保 candidates 中的值都是 Python 原生类型
        clean_candidates = []
        for c in ctx.candidates[:10]:
            clean = {}
            for k, v in c.items():
                if isinstance(v, (np.integer,)):
                    clean[k] = int(v)
                elif isinstance(v, (np.floating,)):
                    clean[k] = float(v)
                elif isinstance(v, list):
                    clean[k] = [int(x) if isinstance(x, (np.integer,)) else float(x) if isinstance(x, (np.floating,)) else x for x in v]
                elif isinstance(v, np.ndarray):
                    clean[k] = v.tolist()
                else:
                    clean[k] = v
            clean_candidates.append(clean)

        return PredictionResponse(
            status=ctx.state.value,
            lottery_type=effective_type,
            candidates=clean_candidates,
            final_score=ctx.fusion_result.final_score if ctx.fusion_result else 0,
            model_contributions=ctx.fusion_result.model_contributions if ctx.fusion_result else {},
            risk_assessment=ctx.risk_assessment,
            fusion_count=orchestrator.fusion_engine.fusion_count,
        )
    except Exception as e:
        logger.error(f"预测生成失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/latest", summary="获取最新预测结果", description="获取最近一次AI预测的结果，包含候选号码、模型贡献度、风险评估等信息。")
async def get_latest_prediction(
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
):
    """获取最新预测结果"""
    ctx = orchestrator.current_context
    if not ctx or ctx.state.value == "error":
        return {"status": "no_prediction", "message": "暂无预测记录", "lottery_type": lottery_type}

    return {
        "status": ctx.state.value,
        "lottery_type": getattr(ctx, "lottery_type", lottery_type),
        "candidates": ctx.candidates[:10] if ctx.candidates else [],
        "final_score": ctx.fusion_result.final_score if ctx.fusion_result else 0,
        "model_contributions": ctx.fusion_result.model_contributions if ctx.fusion_result else {},
        "risk_assessment": ctx.risk_assessment,
        "started_at": ctx.started_at.isoformat() if ctx.started_at else None,
        "completed_at": ctx.completed_at.isoformat() if ctx.completed_at else None,
    }


@router.get("/history", summary="获取预测历史", description="获取历史预测记录列表，支持按彩票类型过滤和分页。")
async def get_prediction_history(
    limit: int = 20,
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
):
    """获取预测历史"""
    memories = [
        m for m in global_memory.memories
        if m.memory_type == "prediction"
        and getattr(m, "lottery_type", "ssq") == lottery_type
    ]
    memories.sort(key=lambda x: x.created_at, reverse=True)
    return {
        "lottery_type": lottery_type,
        "total": len(memories),
        "predictions": [
            {
                "period": m.period,
                "score": m.score,
                "created_at": m.created_at.isoformat(),
            }
            for m in memories[:limit]
        ],
    }


@router.post("/backtest", response_model=BacktestResponse, summary="运行回测", description="对指定彩票类型进行历史数据回测，返回各模型的表现评分和准确率趋势。")
async def run_backtest(
    request: BacktestRequest = BacktestRequest(),
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """运行回测 - 使用真实的预测记录和历史开奖数据"""
    effective_type = request.lottery_type if request.lottery_type != "ssq" or lottery_type == "ssq" else lottery_type
    if request.lottery_type == "ssq" and lottery_type != "ssq":
        effective_type = lottery_type

    try:
        # 查询该彩票类型的预测记录（按时间倒序）
        result = await db.execute(
            select(Prediction)
            .where(Prediction.lottery_type == effective_type)
            .order_by(desc(Prediction.created_at))
            .limit(request.periods)
        )
        predictions = result.scalars().all()

        if not predictions:
            # 没有预测记录，返回空数据
            return BacktestResponse(
                lottery_type=effective_type,
                total_periods=0,
                avg_score=0,
                accuracy_trend=[],
                model_performance={
                    "XGBoost": {"avg_score": 0, "trend": "no_data"},
                    "LSTM": {"avg_score": 0, "trend": "no_data"},
                    "Transformer": {"avg_score": 0, "trend": "no_data"},
                    "PPO": {"avg_score": 0, "trend": "no_data"},
                    "Statistic": {"avg_score": 0, "trend": "no_data"},
                    "Behavior": {"avg_score": 0, "trend": "no_data"},
                },
            )

        # 收集所有期号
        periods = list(set(p.period for p in predictions))

        # 批量查询对应的开奖数据
        result = await db.execute(
            select(LotteryDraw)
            .where(
                LotteryDraw.lottery_type == effective_type,
                LotteryDraw.period.in_(periods),
            )
        )
        draws_by_period = {d.period: d for d in result.scalars().all()}

        # 按模型名称分组，计算命中率
        model_stats = {}  # model_name -> {"hits": [], "total_matches": int, "count": int}
        accuracy_trend = []  # 每期的命中数（用于趋势图）

        for pred in predictions:
            draw = draws_by_period.get(pred.period)
            if not draw:
                continue

            # 获取预测的主球和附加球
            pred_main = pred.main_balls if pred.main_balls else []
            actual_main = draw.get_main_balls()
            pred_bonus = pred.bonus_balls if pred.bonus_balls else None
            actual_bonus = draw.get_bonus_balls()

            # 计算命中数
            total_match, has_bonus, match_main, match_bonus = calculate_match_count(
                prediction_main=pred_main,
                actual_main=actual_main,
                prediction_bonus=pred_bonus,
                actual_bonus=actual_bonus,
                lottery_type=effective_type,
            )

            # 按模型聚合
            model_name = pred.model_name
            if model_name not in model_stats:
                model_stats[model_name] = {"total_matches": 0, "count": 0, "period_matches": []}

            model_stats[model_name]["total_matches"] += total_match
            model_stats[model_name]["count"] += 1
            model_stats[model_name]["period_matches"].append(total_match)

            accuracy_trend.append(total_match)

        # 构建模型表现数据
        model_performance = {}
        all_known_models = ["XGBoost", "LSTM", "Transformer", "PPO", "Statistic", "Behavior"]

        for model_name in all_known_models:
            if model_name in model_stats and model_stats[model_name]["count"] > 0:
                stats = model_stats[model_name]
                avg_hit = stats["total_matches"] / stats["count"]

                # 判断趋势
                if len(stats["period_matches"]) >= 2:
                    first_half = sum(stats["period_matches"][:len(stats["period_matches"]) // 2])
                    second_half = sum(stats["period_matches"][len(stats["period_matches"]) // 2:])
                    if second_half > first_half:
                        trend = "improving"
                    elif second_half < first_half:
                        trend = "declining"
                    else:
                        trend = "stable"
                else:
                    trend = "stable"

                model_performance[model_name] = {
                    "avg_score": round(avg_hit, 2),
                    "trend": trend,
                    "sample_count": stats["count"],
                }
            else:
                model_performance[model_name] = {
                    "avg_score": 0,
                    "trend": "no_data",
                    "sample_count": 0,
                }

        # 计算总体平均分
        avg_score = round(sum(accuracy_trend) / len(accuracy_trend), 2) if accuracy_trend else 0

        # 如果 accuracy_trend 少于请求的 periods，补齐
        padded_trend = list(accuracy_trend)
        if len(padded_trend) < request.periods:
            padded_trend = [0] * (request.periods - len(padded_trend)) + padded_trend
        # 如果多于请求的 periods，只取最近的
        elif len(padded_trend) > request.periods:
            padded_trend = padded_trend[-request.periods:]

        return BacktestResponse(
            lottery_type=effective_type,
            total_periods=len(accuracy_trend),
            avg_score=avg_score,
            accuracy_trend=[round(x, 2) for x in padded_trend],
            model_performance=model_performance,
        )

    except Exception as e:
        logger.error(f"回测失败: {e}")
        return BacktestResponse(
            lottery_type=effective_type,
            total_periods=0,
            avg_score=0,
            accuracy_trend=[],
            model_performance={
                "XGBoost": {"avg_score": 0, "trend": "error"},
                "LSTM": {"avg_score": 0, "trend": "error"},
                "Transformer": {"avg_score": 0, "trend": "error"},
                "PPO": {"avg_score": 0, "trend": "error"},
                "Statistic": {"avg_score": 0, "trend": "error"},
                "Behavior": {"avg_score": 0, "trend": "error"},
            },
        )


# ============================================================
# 预测 vs 开奖 对比 API
# ============================================================

@router.get("/compare", summary="预测与开奖对比", description="获取已匹配的预测记录，包含预测号码、实际开奖号码和命中对比。")
async def get_prediction_comparison(
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    limit: int = Query(20, description="返回条数"),
    db: AsyncSession = Depends(get_db),
):
    """
    获取预测 vs 实际开奖的逐期对比数据
    返回已匹配（status='matched'）的预测记录，包含完整对比信息
    """
    try:
        result = await db.execute(
            select(Prediction)
            .where(
                Prediction.lottery_type == lottery_type,
                Prediction.status == "matched",
            )
            .order_by(desc(Prediction.matched_at))
            .limit(limit)
        )
        predictions = result.scalars().all()

        items = []
        for p in predictions:
            items.append({
                "id": p.id,
                "period": p.period,
                "lottery_type": p.lottery_type,
                "model_name": p.model_name,
                "predicted_main": p.main_balls,
                "predicted_bonus": p.bonus_balls,
                "actual_main": p.actual_main_balls,
                "actual_bonus": p.actual_bonus_balls,
                "match_main_count": p.match_main_count,
                "match_bonus_count": p.match_bonus_count,
                "match_total": p.match_total,
                "match_hit_rate": p.match_hit_rate,
                "score": p.score,
                "matched_at": p.matched_at.isoformat() if p.matched_at else None,
                "created_at": p.created_at.isoformat() if p.created_at else None,
            })

        # 汇总统计
        total_predictions = len(items)
        avg_hit = round(
            sum(it["match_total"] for it in items if it["match_total"] is not None) / max(total_predictions, 1), 2
        )
        avg_hit_rate = round(
            sum(it["match_hit_rate"] for it in items if it["match_hit_rate"] is not None) / max(total_predictions, 1), 4
        )

        return {
            "lottery_type": lottery_type,
            "total": total_predictions,
            "avg_hit": avg_hit,
            "avg_hit_rate": avg_hit_rate,
            "comparisons": items,
        }

    except Exception as e:
        logger.error(f"获取对比数据失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/compare/{period}", summary="单期预测与开奖对比", description="获取指定期号的预测与开奖对比详情。")
async def get_period_comparison(
    period: str,
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """
    获取指定期号的所有预测 vs 开奖对比
    同时返回预测号码和实际开奖号码，计算命中详情
    """
    try:
        # 查询该期的所有预测
        pred_result = await db.execute(
            select(Prediction).where(
                Prediction.period == period,
                Prediction.lottery_type == lottery_type,
            )
        )
        predictions = pred_result.scalars().all()

        # 查询该期的开奖数据
        draw_result = await db.execute(
            select(LotteryDraw).where(
                LotteryDraw.period == period,
                LotteryDraw.lottery_type == lottery_type,
            )
        )
        draw = draw_result.scalar_one_or_none()

        if not draw:
            return {
                "period": period,
                "lottery_type": lottery_type,
                "has_draw": False,
                "predictions": [],
            }

        actual_main = draw.get_main_balls()
        actual_bonus = draw.get_bonus_balls()

        pred_items = []
        for p in predictions:
            # 计算命中（如果还没被匹配引擎处理）
            if p.match_total is not None:
                main_hits = p.match_main_count
                bonus_hits = p.match_bonus_count
                total_hits = p.match_total
                hit_rate = p.match_hit_rate
            else:
                pred_main = p.main_balls if isinstance(p.main_balls, list) else []
                pred_bonus = p.bonus_balls if isinstance(p.bonus_balls, list) else [[]]
                total_hits, _, main_hits, bonus_hits = calculate_match_count(
                    prediction_main=pred_main,
                    actual_main=actual_main,
                    prediction_bonus=pred_bonus,
                    actual_bonus=actual_bonus,
                    lottery_type=lottery_type,
                )
                schema = get_schema(lottery_type)
                main_count = schema["main_count"]
                total_bonus_count = sum(b["count"] for b in schema["bonus_balls"])
                total_count = main_count + total_bonus_count
                hit_rate = round(total_hits / total_count, 4) if total_count > 0 else 0

            pred_items.append({
                "id": p.id,
                "model_name": p.model_name,
                "predicted_main": p.main_balls,
                "predicted_bonus": p.bonus_balls,
                "match_main_count": main_hits,
                "match_bonus_count": bonus_hits,
                "match_total": total_hits,
                "match_hit_rate": hit_rate,
                "score": p.score,
                "status": p.status,
            })

        return {
            "period": period,
            "lottery_type": lottery_type,
            "has_draw": True,
            "actual_main": actual_main,
            "actual_bonus": actual_bonus,
            "predictions": pred_items,
        }

    except Exception as e:
        logger.error(f"获取期号对比失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))
