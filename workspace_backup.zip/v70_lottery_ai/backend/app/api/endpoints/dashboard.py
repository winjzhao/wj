"""
V70 彩票AI工作台 - 仪表盘API
"""
from fastapi import APIRouter, Query, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func
from loguru import logger

from app.orchestrator.workflow import orchestrator
from app.database.db import get_db
from app.database.models import LotteryDraw, EvolutionHistory, Prediction
from app.memory_center.memory import global_memory
from app.core.lottery_schema import get_schema

router = APIRouter()


@router.get("/overview", summary="仪表盘概览", description="获取系统仪表盘概览数据，包含系统状态、最新预测得分、模型贡献度、候选方案数、风险评估和记忆库统计。")
async def get_overview(
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
):
    """获取仪表盘概览"""
    status = orchestrator.get_status()

    return {
        "lottery_type": lottery_type,
        "system_state": status["state"],
        "final_score": status.get("final_score", 0),
        "model_contributions": status.get("model_contributions", {}),
        "candidates_count": status.get("candidates_count", 0),
        "risk": status.get("risk", {}),
        "models": status["models"],
        "fusion_count": status["fusion"]["fusion_count"],
        "memory": status["memory"],
    }


@router.get("/stats", summary="统计数据", description="获取系统的统计数据，包含总预测次数、活跃模型数、记忆库条目数和系统运行时长。")
async def get_stats(
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
):
    """获取统计数据"""
    return {
        "lottery_type": lottery_type,
        "total_predictions": orchestrator.fusion_engine.fusion_count,
        "active_models": len(orchestrator.models),
        "memory_entries": sum(
            1 for m in global_memory.memories
        ),
        "system_uptime": "running",
    }


@router.get("/charts/model-performance", summary="模型表现图表", description="获取各AI模型近30期的表现趋势数据，用于前端绘制折线图展示模型准确率变化。")
async def get_model_performance(
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """获取模型表现图表数据 - 从数据库evolution_history表查询真实数据"""
    try:
        # 查询 evolution_history 表最近30条记录
        result = await db.execute(
            select(EvolutionHistory)
            .where(EvolutionHistory.lottery_type == lottery_type)
            .order_by(desc(EvolutionHistory.created_at))
            .limit(30)
        )
        records = result.scalars().all()

        if not records:
            # 数据库没有进化历史，返回空数据
            return {
                "lottery_type": lottery_type,
                "labels": [],
                "datasets": [],
                "message": "暂无进化历史数据",
            }

        # 反转顺序，使日期从早到晚
        records = list(reversed(records))

        # 构建标签（使用进化迭代次数或创建时间）
        labels = []
        for r in records:
            if r.created_at:
                labels.append(r.created_at.strftime("%m-%d %H:%M"))
            else:
                labels.append(f"Iter {r.iteration}")

        # 收集所有模型名称
        all_models = set()
        for r in records:
            if r.model_performance and isinstance(r.model_performance, dict):
                all_models.update(r.model_performance.keys())

        # 为每个模型构建数据序列
        model_colors = {
            "Transformer": "#4CAF50",
            "PPO": "#2196F3",
            "Statistic": "#FF9800",
            "Behavior": "#9C27B0",
            "XGBoost": "#E91E63",
            "LSTM": "#00BCD4",
        }

        datasets = []
        for model_name in sorted(all_models):
            data = []
            for r in records:
                if r.model_performance and isinstance(r.model_performance, dict):
                    perf = r.model_performance.get(model_name, {})
                    if isinstance(perf, dict):
                        # 尝试提取准确率/评分
                        score = perf.get("accuracy", perf.get("score", perf.get("avg_score", 0)))
                        data.append(round(float(score), 2) if score else 0)
                    elif isinstance(perf, (int, float)):
                        data.append(round(float(perf), 2))
                    else:
                        data.append(0)
                else:
                    data.append(0)

            color = model_colors.get(model_name, "#999999")
            datasets.append({
                "label": model_name,
                "data": data,
                "borderColor": color,
            })

        return {
            "lottery_type": lottery_type,
            "labels": labels,
            "datasets": datasets,
        }

    except Exception as e:
        logger.error(f"获取模型表现图表数据失败: {e}")
        return {
            "lottery_type": lottery_type,
            "labels": [],
            "datasets": [],
            "error": str(e),
        }


@router.get("/charts/hot-numbers", summary="冷热号分析", description="获取各号码的出现频率分布数据，用于前端绘制冷热号柱状图。包含热号阈值(3.5)和冷号阈值(2.5)。")
async def get_hot_numbers(
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """获取冷热号图表数据 - 从数据库lottery_draws表计算真实频率"""
    try:
        # 查询最近100条开奖数据
        result = await db.execute(
            select(LotteryDraw)
            .where(LotteryDraw.lottery_type == lottery_type)
            .order_by(desc(LotteryDraw.draw_date))
            .limit(100)
        )
        draws = result.scalars().all()

        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]

        if not draws:
            return {
                "lottery_type": lottery_type,
                "labels": [str(i) for i in range(1, main_dim + 1)],
                "frequency": [0] * main_dim,
                "hot_threshold": 3.5,
                "cold_threshold": 2.5,
                "message": "暂无开奖数据",
            }

        # 统计每个号码出现的次数
        total_draws = len(draws)
        frequency_count = {i: 0 for i in range(1, main_dim + 1)}

        for draw in draws:
            main_balls = draw.get_main_balls()
            for ball in main_balls:
                if ball and 1 <= ball <= main_dim:
                    frequency_count[ball] += 1

        # 计算频率（百分比）
        freq = []
        for i in range(1, main_dim + 1):
            percentage = (frequency_count[i] / total_draws * 100) if total_draws > 0 else 0
            freq.append(round(percentage, 2))

        return {
            "lottery_type": lottery_type,
            "labels": [str(i) for i in range(1, main_dim + 1)],
            "frequency": freq,
            "hot_threshold": 3.5,
            "cold_threshold": 2.5,
            "total_draws_analyzed": total_draws,
        }

    except Exception as e:
        logger.error(f"获取冷热号数据失败: {e}")
        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]
        return {
            "lottery_type": lottery_type,
            "labels": [str(i) for i in range(1, main_dim + 1)],
            "frequency": [0] * main_dim,
            "hot_threshold": 3.5,
            "cold_threshold": 2.5,
            "error": str(e),
        }
