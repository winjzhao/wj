"""
V70 彩票AI工作台 - 数据中心API
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.database.db import get_db
from app.database.models import LotteryDraw, Prediction, ExperimentRecord
from app.data_center.importer import DataImporter
from app.core.lottery_schema import get_schema
from loguru import logger

router = APIRouter()


@router.get("/draws", summary="获取开奖数据", description="获取开奖数据列表，支持按彩票类型过滤、分页和排序（按期号倒序）。返回号码详情和统计信息。")
async def get_draws(
    limit: int = 50,
    offset: int = 0,
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """获取开奖数据列表"""
    result = await db.execute(
        select(LotteryDraw)
        .where(LotteryDraw.lottery_type == lottery_type)
        .order_by(LotteryDraw.period.desc())
        .offset(offset)
        .limit(limit)
    )
    draws = result.scalars().all()

    return {
        "lottery_type": lottery_type,
        "total": len(draws),
        "draws": [
            {
                "period": d.period,
                "lottery_type": d.lottery_type,
                "draw_date": d.draw_date.isoformat() if d.draw_date else None,
                "main_balls": d.get_main_balls(),
                "bonus_balls": d.get_bonus_balls(),
                "reds": d.get_reds(),
                "blue": d.blue,
                "red_sum": d.red_sum,
                "span": d.span,
            }
            for d in draws
        ],
    }


@router.get("/draws/{period}", summary="按期号查询", description="根据期号和彩票类型获取单条开奖数据详情，包含号码分布、和值、跨度、奇偶比、三区分布等统计信息。")
async def get_draw_by_period(
    period: str,
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """按期号获取开奖数据"""
    result = await db.execute(
        select(LotteryDraw).where(
            LotteryDraw.period == period,
            LotteryDraw.lottery_type == lottery_type,
        )
    )
    draw = result.scalar_one_or_none()
    if not draw:
        raise HTTPException(status_code=404, detail=f"期号 {period} ({lottery_type}) 不存在")

    return {
        "period": draw.period,
        "lottery_type": draw.lottery_type,
        "draw_date": draw.draw_date.isoformat() if draw.draw_date else None,
        "main_balls": draw.get_main_balls(),
        "bonus_balls": draw.get_bonus_balls(),
        "reds": draw.get_reds(),
        "blue": draw.blue,
        "red_sum": draw.red_sum,
        "span": draw.span,
        "odd_count": draw.odd_count,
        "zone1_count": draw.zone1_count,
        "zone2_count": draw.zone2_count,
        "zone3_count": draw.zone3_count,
    }


@router.get("/stats", summary="数据统计", description="获取数据中心的统计信息，包含总开奖期数、最新期号和最新开奖日期。")
async def get_data_stats(
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """获取数据统计"""
    result = await db.execute(
        select(func.count(LotteryDraw.id)).where(
            LotteryDraw.lottery_type == lottery_type
        )
    )
    total = result.scalar()

    # 最近数据
    result = await db.execute(
        select(LotteryDraw)
        .where(LotteryDraw.lottery_type == lottery_type)
        .order_by(LotteryDraw.period.desc())
        .limit(1)
    )
    latest = result.scalar_one_or_none()

    return {
        "lottery_type": lottery_type,
        "total_draws": total,
        "latest_period": latest.period if latest else None,
        "latest_date": latest.draw_date.isoformat() if latest and latest.draw_date else None,
    }


@router.post("/import-mock", summary="导入模拟数据", description="导入指定数量的模拟开奖数据到数据库，用于开发和测试。默认导入500条SSQ数据。")
async def import_mock_data(
    count: int = 500,
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """导入模拟数据（开发测试用）"""
    await DataImporter.import_mock_data(db, count, lottery_type=lottery_type)
    return {"message": f"已导入 {count} 条模拟数据", "lottery_type": lottery_type}


@router.get("/experiments", summary="获取实验记录", description="获取历史实验记录列表，包含实验名称、模型名、期号、命中数和评分。支持按彩票类型过滤和分页。")
async def get_experiments(
    limit: int = 20,
    lottery_type: str = Query("ssq", description="彩票类型: ssq, dlt, k8"),
    db: AsyncSession = Depends(get_db),
):
    """获取实验记录"""
    result = await db.execute(
        select(ExperimentRecord)
        .where(ExperimentRecord.lottery_type == lottery_type)
        .order_by(ExperimentRecord.created_at.desc())
        .limit(limit)
    )
    experiments = result.scalars().all()

    return {
        "lottery_type": lottery_type,
        "total": len(experiments),
        "experiments": [
            {
                "id": e.id,
                "name": e.experiment_name,
                "model": e.model_name,
                "period": e.period,
                "match_count": e.match_count,
                "score": e.score,
                "created_at": e.created_at.isoformat() if e.created_at else None,
            }
            for e in experiments
        ],
    }
