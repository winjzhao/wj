"""
V70 彩票AI工作台 - 系统中心API
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text, select, func, desc
from app.orchestrator.workflow import orchestrator
from app.config.settings import settings
from app.database.db import get_db
from app.core.metrics import metrics
import psutil
import os
import datetime

router = APIRouter()


@router.get("/status")
async def get_system_status():
    """获取系统运行状态（增强版）"""
    status = orchestrator.get_status()

    # 系统资源
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')

    # 数据库连接状态
    db_status = await _check_database()

    # 模型加载状态
    model_statuses = {}
    for model_name in status.get("models", {}):
        model_statuses[model_name] = {
            "loaded": True,
            "weight": orchestrator.fusion_engine.base_weights.get(model_name, 0),
        }

    # 监控指标
    all_metrics = metrics.get_all_metrics()
    error_stats = metrics.get_error_stats()

    return {
        "status": "healthy" if db_status["connected"] else "degraded",
        "system_state": status["state"],
        "current_period": status.get("current_period", ""),
        "uptime_seconds": all_metrics["uptime_seconds"],

        # 模型状态
        "models": {
            "active_count": len(status.get("models", {})),
            "details": model_statuses,
            "fusion_count": status["fusion"]["fusion_count"],
        },

        # 数据库状态
        "database": db_status,

        # 系统资源
        "resources": {
            "cpu_percent": cpu_percent,
            "memory_percent": memory.percent,
            "memory_used_mb": round(memory.used / 1024 / 1024, 2),
            "memory_total_mb": round(memory.total / 1024 / 1024, 2),
            "disk_percent": disk.percent,
        },

        # 请求统计
        "request_stats": all_metrics["requests"],

        # 预测统计
        "prediction_stats": {
            "models": all_metrics["predictions"]["models"],
            "last_prediction_time": all_metrics["predictions"]["last_prediction_time"],
            "last_prediction_period": all_metrics["predictions"]["last_prediction_period"],
        },

        # 错误统计
        "error_stats": {
            "total_errors": error_stats["total_errors"],
            "recent_errors": list(error_stats["recent_errors"])[-5:],  # 最近5条
        },

        # 调度器与版本
        "scheduler": "running",
        "api_version": "1.0.0",
    }


async def _check_database() -> dict:
    """检查数据库连接状态"""
    try:
        from app.database.db import engine
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
            await conn.commit()
        return {
            "connected": True,
            "type": settings.DATABASE_URL.split("://")[0] if "://" in settings.DATABASE_URL else "unknown",
        }
    except Exception as e:
        return {
            "connected": False,
            "error": str(e)[:200] if settings.DEBUG else "连接失败",
        }


@router.get("/metrics")
async def get_detailed_metrics():
    """获取详细监控指标"""
    return {
        "timestamp": datetime.datetime.now().isoformat(),
        "metrics": metrics.get_all_metrics(),
    }


@router.get("/logs", summary="最近日志", description="获取系统最近的运行日志，默认返回20条。每条日志包含时间戳、级别、模块和消息内容。")
async def get_recent_logs(limit: int = 20):
    """获取最近日志"""
    # 简化版 - 返回模拟日志
    return {
        "logs": [
            {
                "timestamp": "2024-01-15T08:00:00",
                "level": "INFO",
                "module": "orchestrator",
                "message": "每日数据更新完成",
            },
            {
                "timestamp": "2024-01-15T08:01:00",
                "level": "INFO",
                "module": "orchestrator",
                "message": "开始预测流程",
            },
            {
                "timestamp": "2024-01-15T08:02:00",
                "level": "INFO",
                "module": "fusion",
                "message": "融合决策完成, 评分: 88.7",
            },
            {
                "timestamp": "2024-01-15T08:03:00",
                "level": "INFO",
                "module": "orchestrator",
                "message": "预测结果已保存",
            },
        ][:limit],
    }


@router.get("/workflow-status", summary="工作流状态", description="获取当前工作流各步骤的实时状态，包含每步是否完成、执行时间等信息。")
async def get_workflow_status(
    lottery_type: str = "ssq",
    db: AsyncSession = Depends(get_db),
):
    """
    获取工作流各步骤状态
    结合 orchestrator 当前状态和数据库记录，返回每个步骤的完成状态和时间
    """
    from app.database.models import Prediction
    from sqlalchemy import select, func, desc

    now = datetime.datetime.now()
    today = now.strftime("%Y-%m-%d")

    # 查询今日预测记录
    pred_result = await db.execute(
        select(Prediction)
        .where(
            Prediction.lottery_type == lottery_type,
            func.date(Prediction.created_at) == today,
        )
        .order_by(desc(Prediction.created_at))
    )
    today_preds = pred_result.scalars().all()

    # 查询今日已匹配的预测
    matched_result = await db.execute(
        select(Prediction)
        .where(
            Prediction.lottery_type == lottery_type,
            Prediction.status == "matched",
            func.date(Prediction.matched_at) == today,
        )
    )
    matched_preds = matched_result.scalars().all()

    # orchestrator 当前状态
    orch_status = orchestrator.get_status()
    orch_state = orch_status.get("state", "idle")
    orch_period = orch_status.get("current_period", "")

    # 根据实际数据确定各步骤状态
    has_preds = len(today_preds) > 0
    has_matched = len(matched_preds) > 0
    saved_count = len(today_preds)
    matched_count = len(matched_preds)

    # 格式化时间
    def fmt_time(dt):
        if dt is None:
            return "-"
        return dt.strftime("%H:%M")

    # 获取各步骤时间
    first_pred_time = today_preds[-1].created_at if today_preds else None
    last_pred_time = today_preds[0].created_at if today_preds else None
    first_match_time = matched_preds[-1].matched_at if matched_preds else None

    # 确定各步骤状态
    # 数据更新/检查/特征生成/模型预测/Fusion融合/候选生成 - 如果今天有预测，说明已完成
    pipeline_done = has_preds or orch_state in ("completed", "save", "waiting", "feedback")

    steps = [
        {
            "name": "数据更新",
            "status": "completed" if pipeline_done else "pending",
            "time": fmt_time(first_pred_time) if first_pred_time else "08:00",
        },
        {
            "name": "数据检查",
            "status": "completed" if pipeline_done else "pending",
            "time": fmt_time(first_pred_time) if first_pred_time else "08:00",
        },
        {
            "name": "特征生成",
            "status": "completed" if pipeline_done else "pending",
            "time": fmt_time(first_pred_time) if first_pred_time else "08:01",
        },
        {
            "name": "模型预测",
            "status": "completed" if pipeline_done else "pending",
            "time": fmt_time(first_pred_time) if first_pred_time else "08:01",
        },
        {
            "name": "Fusion融合",
            "status": "completed" if pipeline_done else "pending",
            "time": fmt_time(first_pred_time) if first_pred_time else "08:02",
        },
        {
            "name": "候选生成",
            "status": "completed" if pipeline_done else "pending",
            "time": fmt_time(first_pred_time) if first_pred_time else "08:02",
        },
        {
            "name": "回测评分",
            "status": "completed" if has_preds else ("running" if pipeline_done else "pending"),
            "time": fmt_time(last_pred_time) if last_pred_time else ("08:03" if pipeline_done else "-"),
        },
        {
            "name": "保存结果",
            "status": "completed" if has_preds else "pending",
            "time": fmt_time(last_pred_time) if last_pred_time else "-",
            "detail": f"已保存 {saved_count} 条预测" if saved_count > 0 else "待保存",
        },
        {
            "name": "等待开奖",
            "status": "completed" if has_matched else ("pending" if has_preds else "pending"),
            "time": fmt_time(first_match_time) if first_match_time else "-",
            "detail": f"已开奖 {matched_count} 期" if matched_count > 0 else ("等待开奖" if has_preds else "待执行"),
        },
        {
            "name": "反馈学习",
            "status": "completed" if has_matched else "pending",
            "time": fmt_time(first_match_time) if first_match_time else "-",
            "detail": f"已匹配 {matched_count} 条" if matched_count > 0 else "待反馈",
        },
    ]

    return {
        "lottery_type": lottery_type,
        "orchestrator_state": orch_state,
        "current_period": orch_period,
        "today_predictions": saved_count,
        "today_matched": matched_count,
        "steps": steps,
        "last_updated": now.isoformat(),
    }


@router.get("/config", summary="系统配置", description="获取当前系统配置信息，包含应用名称、版本、支持的彩票类型、模型权重、候选方案数量、调度时间等。")
async def get_config():
    """获取系统配置"""
    from app.config.settings import settings
    from app.core.lottery_schema import get_all_types
    return {
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "lottery_type": settings.LOTTERY_TYPE,
        "supported_lottery_types": get_all_types(),
        "model_weights": orchestrator.fusion_engine.base_weights,
        "candidate_count": settings.CANDIDATE_COUNT,
        "top_results": settings.TOP_RESULTS,
        "schedule": {
            "update_hour": settings.SCHEDULE_UPDATE_HOUR,
            "update_minute": settings.SCHEDULE_UPDATE_MINUTE,
        },
    }


@router.get("/version", summary="版本信息与升级", description="获取当前版本信息、更新日志和可用升级。")
async def get_version_info():
    """获取版本信息与升级状态"""
    # 版本号
    major, minor, patch = (settings.APP_VERSION or "1.0.0").split(".")

    # 版本历史（changelog）
    changelog = [
        {
            "version": "1.3.0",
            "date": "2026-07-10",
            "title": "工作流状态实时监控",
            "changes": [
                "系统中心工作流状态改为实时数据驱动",
                "新增预测自动保存到数据库",
                "新增预测vs开奖对比页面",
                "新增版本升级模块",
            ],
            "type": "feature",
        },
        {
            "version": "1.2.0",
            "date": "2026-07-08",
            "title": "AI自学习进化引擎",
            "changes": [
                "实现6模型自学习进化系统",
                "支持模型权重动态调整",
                "新增告警中心",
                "优化融合引擎评分算法",
            ],
            "type": "feature",
        },
        {
            "version": "1.1.0",
            "date": "2026-07-05",
            "title": "多彩票类型支持",
            "changes": [
                "新增快乐8(K8)和大乐透(DLT)支持",
                "统一彩票Schema架构",
                "优化数据采集器",
                "新增实时数据源",
            ],
            "type": "feature",
        },
        {
            "version": "1.0.0",
            "date": "2026-07-01",
            "title": "V70 初始版本发布",
            "changes": [
                "双色球(SSQ) AI预测",
                "6模型融合架构: XGBoost/LSTM/Transformer/PPO/Statistic/Behavior",
                "Fusion融合引擎",
                "风险评估系统",
                "Flutter移动端App",
            ],
            "type": "major",
        },
    ]

    # 检查是否有可用更新（模拟，实际可对接更新服务器）
    latest_version = "1.3.0"
    current_version = settings.APP_VERSION or "1.0.0"

    def version_tuple(v: str) -> tuple:
        try:
            parts = v.split(".")
            return tuple(int(p) for p in parts[:3])
        except Exception:
            return (0, 0, 0)

    has_update = version_tuple(latest_version) > version_tuple(current_version)

    return {
        "current_version": current_version,
        "latest_version": latest_version,
        "has_update": has_update,
        "update_available": has_update,
        "update_url": "https://codebuddy.ai/v70-lottery-ai" if has_update else None,
        "release_date": "2026-07-10",
        "changelog": changelog,
        "check_time": datetime.datetime.now().isoformat(),
    }
