"""
V70 彩票AI工作台 - API路由汇总
"""
import json
from typing import Any
from fastapi import APIRouter
from starlette.responses import JSONResponse as StarletteJSONResponse
from app.api.endpoints import prediction, dashboard, models, system, data, evolution, backtest


class UTF8JSONResponse(StarletteJSONResponse):
    """确保中文不被转义为 \\uXXXX"""
    def render(self, content: Any) -> bytes:
        return json.dumps(
            content,
            ensure_ascii=False,
            allow_nan=False,
            indent=None,
            separators=(",", ":"),
        ).encode("utf-8")


api_router = APIRouter(default_response_class=UTF8JSONResponse)

api_router.include_router(
    prediction.router,
    prefix="/prediction",
    tags=["预测中心"],
)
api_router.include_router(
    dashboard.router,
    prefix="/dashboard",
    tags=["仪表盘"],
)
api_router.include_router(
    models.router,
    prefix="/models",
    tags=["模型管理"],
)
api_router.include_router(
    system.router,
    prefix="/system",
    tags=["系统中心"],
)
api_router.include_router(
    data.router,
    prefix="/data",
    tags=["数据中心"],
)
api_router.include_router(
    evolution.router,
    prefix="/evolution",
    tags=["自学习进化"],
)
api_router.include_router(
    backtest.router,
    prefix="/backtest",
    tags=["回测中心"],
)
