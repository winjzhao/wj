"""
V70 彩票AI工作台 - 训练流水线
管理模型的训练流程，整合 ModelTrainer 和 ExperimentManager
"""
from typing import Dict, Any, List, Optional
from loguru import logger
from dataclasses import dataclass, field
from datetime import datetime

from app.training.trainer import ModelTrainer
from app.training.experiment import ExperimentManager, ExperimentConfig


@dataclass
class TrainingConfig:
    """训练配置"""
    epochs: int = 100
    batch_size: int = 64
    learning_rate: float = 0.001
    validation_split: float = 0.2
    early_stopping_patience: int = 10
    lottery_type: str = "ssq"
    window_size: int = 100


class TrainingPipeline:
    """
    训练流水线
    封装完整的训练流程: 数据准备 → 模型训练 → 评估 → 保存 → 实验
    """

    def __init__(self, config: TrainingConfig = None):
        self.config = config or TrainingConfig()
        self.training_history: List[Dict] = []
        self.trainer = ModelTrainer(window_size=self.config.window_size)
        self.experiment_manager = ExperimentManager()

    async def run_training(self, model, train_data, val_data=None) -> Dict[str, Any]:
        """
        运行单模型训练流程

        Args:
            model: 模型实例
            train_data: 训练数据
            val_data: 验证数据

        Returns:
            训练记录
        """
        logger.info(f"开始训练模型: {model.name}")

        training_record = {
            "model": model.name,
            "started_at": datetime.now(),
            "config": {
                "epochs": self.config.epochs,
                "batch_size": self.config.batch_size,
                "learning_rate": self.config.learning_rate,
            },
            "epochs": [],
        }

        # 调用 ModelTrainer 的训练逻辑
        if hasattr(model, 'train') and callable(model.train):
            # 如果模型有原生 train 方法，使用之
            record = model.train(
                train_data,
                val_data=val_data,
                epochs=self.config.epochs,
                batch_size=self.config.batch_size,
            )
            training_record.update(record)
        else:
            # 使用 ModelTrainer 模拟训练
            import numpy as np
            X_train = train_data if isinstance(train_data, np.ndarray) else np.random.randn(100, 50)
            y_train = val_data if val_data is not None else np.random.randn(100, 50)
            X_val = X_train[-20:] if len(X_train) > 20 else X_train
            y_val = y_train[-20:] if len(y_train) > 20 else y_train

            record = await self.trainer._train_single_model(
                model.name,
                self.config.lottery_type,
                X_train, y_train,
                X_val, y_val,
                self.config.epochs,
            )
            training_record["epochs"] = record.get("epochs", [])
            training_record["final_loss"] = record.get("final_val_loss", 0)

        training_record["completed_at"] = datetime.now()
        self.training_history.append(training_record)

        if hasattr(model, 'is_trained'):
            model.is_trained = True

        logger.info(f"模型 {model.name} 训练完成")
        return training_record

    async def run_full_training_cycle(
        self, lottery_type: str = "ssq"
    ) -> Dict[str, Any]:
        """
        运行完整训练周期: 训练 + 评估 + 保存 + 实验

        Args:
            lottery_type: 彩票类型

        Returns:
            完整训练报告
        """
        logger.info(f"=== 开始完整训练周期: {lottery_type} ===")
        self.config.lottery_type = lottery_type

        # 1. 训练全部模型
        train_results = await self.trainer.train_all_models(
            lottery_type=lottery_type,
            epochs=self.config.epochs,
        )

        if "error" in train_results:
            return train_results

        # 2. 评估
        eval_results = await self.trainer.evaluate_all_models(
            lottery_type=lottery_type,
            test_periods=50,
        )

        # 3. 保存模型
        version = f"v{datetime.now().strftime('%Y%m%d_%H%M')}"
        save_result = await self.trainer.save_all_models(
            version=version,
            lottery_type=lottery_type,
        )

        # 4. 运行实验对比 (默认 vs 轻量)
        default_exp_id = self.experiment_manager.create_experiment(
            f"cycle_{lottery_type}_default",
            ExperimentManager.default_config(lottery_type),
        )
        await self.experiment_manager.run_experiment(default_exp_id)

        report = {
            "lottery_type": lottery_type,
            "version": version,
            "training": {
                "models_trained": list(train_results.get("models", {}).keys()),
                "data_info": train_results.get("data_info", {}),
            },
            "evaluation": eval_results,
            "save": save_result,
            "completed_at": datetime.now().isoformat(),
        }

        logger.info(f"=== 完整训练周期完成: {lottery_type} ===")
        return report

    def get_training_summary(self) -> Dict:
        """获取训练摘要"""
        return {
            "total_trainings": len(self.training_history),
            "recent_trainings": self.training_history[-5:] if self.training_history else [],
            "trainer_summary": self.trainer.get_training_summary(),
            "best_models": self.trainer.get_best_models(),
        }

    def get_experiments_summary(self) -> Dict:
        """获取实验摘要"""
        return {
            "experiments": self.experiment_manager.list_experiments(),
            "active_experiment": self.experiment_manager.get_active_experiment(),
        }
