"""
V70 彩票AI工作台 - A/B 实验框架
支持多实验并行、结果对比、配置管理
"""
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field, asdict
from enum import Enum
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database.models import ExperimentRecord
from app.database.db import get_db
from app.training.trainer import ModelTrainer


class ExperimentStatus(Enum):
    """实验状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ExperimentConfig:
    """实验配置"""
    # 模型组合
    enabled_models: List[str] = field(default_factory=lambda: [
        "XGBoost", "LSTM", "Transformer", "PPO", "Statistic", "Behavior"
    ])

    # 模型权重 (归一化后)
    model_weights: Dict[str, float] = field(default_factory=dict)

    # 特征集
    feature_set: str = "full"  # "full" | "basic_only" | "trend_only" | "pattern_only"

    # 训练参数
    window_size: int = 100
    epochs: int = 100
    batch_size: int = 64
    learning_rate: float = 0.001

    # 数据配置
    train_ratio: float = 0.70
    val_ratio: float = 0.15
    test_ratio: float = 0.15

    # 彩票类型
    lottery_type: str = "ssq"

    # 是否启用样本均衡
    balance_samples: bool = True


@dataclass
class ExperimentResult:
    """实验结果"""
    experiment_id: str = ""
    experiment_name: str = ""
    status: ExperimentStatus = ExperimentStatus.PENDING
    config: Optional[ExperimentConfig] = None

    # 训练结果
    training_results: Dict[str, Any] = field(default_factory=dict)

    # 评估指标
    metrics: Dict[str, Dict[str, float]] = field(default_factory=dict)

    # 元数据
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_seconds: float = 0.0
    error_message: str = ""


class ExperimentManager:
    """A/B 实验管理器"""

    def __init__(self, db: Optional[AsyncSession] = None):
        self._db = db
        self._experiments: Dict[str, ExperimentResult] = {}
        self._active_experiment_id: Optional[str] = None

    # ============================================================
    # 实验创建
    # ============================================================

    def create_experiment(
        self, name: str, config: ExperimentConfig = None
    ) -> str:
        """
        创建新实验

        Args:
            name: 实验名称
            config: 实验配置

        Returns:
            experiment_id
        """
        experiment_id = f"exp_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"

        if config is None:
            config = ExperimentConfig()

        result = ExperimentResult(
            experiment_id=experiment_id,
            experiment_name=name,
            config=config,
            status=ExperimentStatus.PENDING,
        )

        self._experiments[experiment_id] = result
        logger.info(f"实验已创建: [{experiment_id}] {name}")
        logger.info(f"  模型: {config.enabled_models}")
        logger.info(f"  特征集: {config.feature_set}")
        logger.info(f"  窗口: {config.window_size}, Epochs: {config.epochs}")

        return experiment_id

    # ============================================================
    # 实验运行
    # ============================================================

    async def run_experiment(self, experiment_id: str) -> ExperimentResult:
        """
        运行实验

        Args:
            experiment_id: 实验ID

        Returns:
            实验结果
        """
        result = self._experiments.get(experiment_id)
        if result is None:
            raise ValueError(f"实验不存在: {experiment_id}")

        result.status = ExperimentStatus.RUNNING
        result.started_at = datetime.now()
        self._active_experiment_id = experiment_id

        config = result.config
        logger.info(f"=== 开始运行实验: [{experiment_id}] {result.experiment_name} ===")

        try:
            # 1. 初始化训练器
            trainer = ModelTrainer(
                window_size=config.window_size,
                db=self._db,
            )

            # 2. 准备数据
            X, y = await trainer.prepare_training_data(
                lottery_type=config.lottery_type,
                periods=500,
            )

            if X.size == 0:
                raise ValueError("训练数据不足")

            # 3. 数据集分割
            datasets = trainer.split_dataset(
                X, y,
                train_ratio=config.train_ratio,
                val_ratio=config.val_ratio,
                test_ratio=config.test_ratio,
            )

            # 4. 样本均衡
            if config.balance_samples:
                X_train, y_train = trainer.balance_samples(
                    datasets["X_train"], datasets["y_train"]
                )
            else:
                X_train, y_train = datasets["X_train"], datasets["y_train"]

            # 5. 仅训练启用的模型
            training_results = {}
            for model_name in config.enabled_models:
                logger.info(f"  训练模型: {model_name} (特征集={config.feature_set})")
                record = await trainer._train_single_model(
                    model_name, config.lottery_type,
                    X_train, y_train,
                    datasets["X_val"], datasets["y_val"],
                    config.epochs,
                )
                training_results[model_name] = record

            # 6. 评估
            eval_results = await trainer.evaluate_all_models(
                lottery_type=config.lottery_type,
                test_periods=50,
            )

            result.training_results = training_results
            result.metrics = eval_results.get("models", {})
            result.status = ExperimentStatus.COMPLETED

        except Exception as e:
            result.status = ExperimentStatus.FAILED
            result.error_message = str(e)
            logger.error(f"实验失败: {e}")

        result.completed_at = datetime.now()
        result.duration_seconds = (
            result.completed_at - result.started_at
        ).total_seconds()

        # 持久化到数据库
        await self._save_experiment_to_db(result)

        logger.info(
            f"实验完成: [{experiment_id}] 状态={result.status.value}, "
            f"耗时={result.duration_seconds:.1f}s"
        )

        self._active_experiment_id = None
        return result

    # ============================================================
    # 实验对比
    # ============================================================

    def compare_experiments(self, ids: List[str]) -> Dict[str, Any]:
        """
        对比多个实验的结果

        Args:
            ids: 实验ID列表

        Returns:
            对比报告
        """
        experiments = []
        for exp_id in ids:
            result = self._experiments.get(exp_id)
            if result is None:
                logger.warning(f"实验不存在: {exp_id}")
                continue
            experiments.append(result)

        if not experiments:
            return {"error": "没有可对比的实验"}

        # 收集各实验的评估指标
        comparison = {
            "experiments": [],
            "summary": {
                "best_f1": {"experiment": "", "value": 0.0},
                "best_precision": {"experiment": "", "value": 0.0},
                "best_recall": {"experiment": "", "value": 0.0},
            },
            "model_comparison": {},  # {model_name: {exp_id: metrics}}
            "config_comparison": [],
        }

        for exp in experiments:
            exp_info = {
                "experiment_id": exp.experiment_id,
                "name": exp.experiment_name,
                "status": exp.status.value,
                "duration_seconds": exp.duration_seconds,
                "config": asdict(exp.config) if exp.config else {},
            }

            # 汇总各模型的指标
            avg_f1 = 0.0
            avg_precision = 0.0
            avg_recall = 0.0
            model_count = 0

            for model_name, metrics in exp.metrics.items():
                if isinstance(metrics, dict):
                    f1 = metrics.get("f1", 0)
                    precision = metrics.get("precision@k", 0)
                    recall = metrics.get("recall", 0)

                    avg_f1 += f1
                    avg_precision += precision
                    avg_recall += recall
                    model_count += 1

                    # 按模型汇总
                    if model_name not in comparison["model_comparison"]:
                        comparison["model_comparison"][model_name] = {}
                    comparison["model_comparison"][model_name][exp.experiment_id] = {
                        "f1": f1,
                        "precision@k": precision,
                        "recall": recall,
                    }

            if model_count > 0:
                avg_f1 /= model_count
                avg_precision /= model_count
                avg_recall /= model_count

            exp_info["avg_metrics"] = {
                "f1": round(avg_f1, 4),
                "precision@k": round(avg_precision, 4),
                "recall": round(avg_recall, 4),
            }

            comparison["experiments"].append(exp_info)

            # 更新最佳值
            if avg_f1 > comparison["summary"]["best_f1"]["value"]:
                comparison["summary"]["best_f1"] = {
                    "experiment": exp.experiment_name, "value": round(avg_f1, 4)
                }
            if avg_precision > comparison["summary"]["best_precision"]["value"]:
                comparison["summary"]["best_precision"] = {
                    "experiment": exp.experiment_name, "value": round(avg_precision, 4)
                }
            if avg_recall > comparison["summary"]["best_recall"]["value"]:
                comparison["summary"]["best_recall"] = {
                    "experiment": exp.experiment_name, "value": round(avg_recall, 4)
                }

        # 配置对比
        config_keys = ["window_size", "epochs", "feature_set", "enabled_models"]
        for key in config_keys:
            values = {}
            for exp in experiments:
                if exp.config:
                    values[exp.experiment_name] = getattr(exp.config, key, None)
            comparison["config_comparison"].append({"parameter": key, "values": values})

        logger.info(f"实验对比完成: {len(experiments)} 个实验")
        return comparison

    # ============================================================
    # 实验管理
    # ============================================================

    def get_experiment(self, experiment_id: str) -> Optional[ExperimentResult]:
        """获取实验"""
        return self._experiments.get(experiment_id)

    def list_experiments(self) -> List[Dict[str, Any]]:
        """列出所有实验"""
        return [
            {
                "experiment_id": exp_id,
                "name": result.experiment_name,
                "status": result.status.value,
                "duration_seconds": result.duration_seconds,
            }
            for exp_id, result in self._experiments.items()
        ]

    def get_active_experiment(self) -> Optional[str]:
        """获取当前活跃实验ID"""
        return self._active_experiment_id

    # ============================================================
    # 持久化
    # ============================================================

    async def _save_experiment_to_db(self, result: ExperimentResult):
        """将实验结果保存到数据库"""
        db = self._db
        if db is None:
            try:
                async for session in get_db():
                    db = session
                    break
            except Exception:
                logger.warning("无法获取数据库连接，跳过持久化")
                return

        try:
            for model_name, metrics in result.metrics.items():
                if not isinstance(metrics, dict):
                    continue

                record = ExperimentRecord(
                    experiment_name=result.experiment_name,
                    lottery_type=result.config.lottery_type if result.config else "ssq",
                    model_name=model_name,
                    period=datetime.now().strftime("%Y%m%d"),
                    prediction={
                        "experiment_id": result.experiment_id,
                        "config": asdict(result.config) if result.config else {},
                    },
                    actual={"metrics": metrics},
                    match_count=0,
                    score=metrics.get("f1", 0),
                    remarks=(
                        f"Status={result.status.value}, "
                        f"Duration={result.duration_seconds:.1f}s"
                    ),
                )
                db.add(record)

            await db.commit()
            logger.info(f"实验结果已持久化: {result.experiment_id}")

        except Exception as e:
            await db.rollback()
            logger.error(f"持久化实验失败: {e}")

    # ============================================================
    # 预定义实验配置
    # ============================================================

    @staticmethod
    def default_config(lottery_type: str = "ssq") -> ExperimentConfig:
        """默认配置 - 全模型，全特征"""
        return ExperimentConfig(
            enabled_models=["XGBoost", "LSTM", "Transformer", "PPO", "Statistic", "Behavior"],
            feature_set="full",
            lottery_type=lottery_type,
            window_size=100,
            epochs=100,
        )

    @staticmethod
    def lightweight_config(lottery_type: str = "ssq") -> ExperimentConfig:
        """轻量配置 - 仅3个核心模型"""
        return ExperimentConfig(
            enabled_models=["XGBoost", "LSTM", "Statistic"],
            feature_set="full",
            lottery_type=lottery_type,
            window_size=50,
            epochs=50,
        )

    @staticmethod
    def high_weight_xgboost_config(lottery_type: str = "ssq") -> ExperimentConfig:
        """高权重 XGBoost 实验"""
        return ExperimentConfig(
            enabled_models=["XGBoost", "LSTM", "Transformer", "PPO", "Statistic", "Behavior"],
            model_weights={
                "XGBoost": 0.30,
                "LSTM": 0.15,
                "Transformer": 0.15,
                "PPO": 0.10,
                "Statistic": 0.15,
                "Behavior": 0.15,
            },
            feature_set="full",
            lottery_type=lottery_type,
            window_size=100,
            epochs=120,
        )

    @staticmethod
    def trend_focused_config(lottery_type: str = "ssq") -> ExperimentConfig:
        """趋势特征专注实验"""
        return ExperimentConfig(
            enabled_models=["LSTM", "Transformer", "PPO"],
            feature_set="trend_only",
            lottery_type=lottery_type,
            window_size=200,
            epochs=100,
        )

    @staticmethod
    def statistic_focused_config(lottery_type: str = "ssq") -> ExperimentConfig:
        """统计特征专注实验"""
        return ExperimentConfig(
            enabled_models=["XGBoost", "Statistic", "Behavior"],
            feature_set="basic_only",
            lottery_type=lottery_type,
            window_size=100,
            epochs=80,
        )

    @staticmethod
    def no_balance_config(lottery_type: str = "ssq") -> ExperimentConfig:
        """不启用样本均衡的对比实验"""
        config = ExperimentConfig(
            lottery_type=lottery_type,
            window_size=100,
            epochs=100,
            balance_samples=False,
        )
        return config


# 全局实验管理器实例
experiment_manager = ExperimentManager()
