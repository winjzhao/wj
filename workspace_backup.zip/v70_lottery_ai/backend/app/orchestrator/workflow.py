"""
V70 彩票AI工作台 - 统一调度引擎 (Orchestrator)
按固定流程调度所有模块协同工作
"""
import asyncio
from enum import Enum
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
from loguru import logger

from app.data_center.collector import DataCollector
from app.data_center.parser import DataParser
from app.ai_core.features.builder import FeatureBuilder
from app.ai_core.features.encoder import FeatureEncoder
from app.ai_core.models.statistic import StatisticModel
from app.ai_core.models.transformer import TransformerModel
from app.ai_core.models.ppo import PPOModel
from app.ai_core.models.behavior import BehaviorModel
from app.ai_core.models.xgboost_model import XGBoostModel
from app.ai_core.models.lstm_model import LSTMModel
from app.fusion_engine.fusion import FusionEngine, ModelOutput
from app.fusion_engine.risk_control import RiskController
from app.memory_center.memory import global_memory
from app.memory_center.retriever import ExperienceRetriever
from app.core.lottery_schema import get_schema


class WorkflowState(Enum):
    """工作流状态"""
    IDLE = "idle"
    DATA_UPDATE = "data_update"
    DATA_CHECK = "data_check"
    FEATURE_GEN = "feature_gen"
    MODEL_PREDICT = "model_predict"
    FUSION = "fusion"
    CANDIDATE_GEN = "candidate_gen"
    BACKTEST = "backtest"
    SCORING = "scoring"
    SAVE = "save"
    WAITING = "waiting"
    FEEDBACK = "feedback"
    UPDATE_MODEL = "update_model"
    COMPLETED = "completed"
    ERROR = "error"


@dataclass
class WorkflowContext:
    """工作流上下文"""
    state: WorkflowState = WorkflowState.IDLE
    current_period: str = ""
    lottery_type: str = "ssq"
    draws: list = field(default_factory=list)
    features: Any = None
    predictions: dict = field(default_factory=dict)
    fusion_result: Any = None
    candidates: list = field(default_factory=list)
    risk_assessment: dict = field(default_factory=dict)
    error_message: str = ""
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class Orchestrator:
    """
    统一调度器
    流程: 数据更新 → 数据检查 → 特征生成 → 模型预测 → Fusion融合
         → 候选方案生成 → 回测 → 评分 → 保存 → 等待开奖 → 反馈学习
    """

    def __init__(self):
        self.state = WorkflowState.IDLE
        self.collector = DataCollector()
        self.parser = DataParser()
        self.feature_builder = FeatureBuilder(window_size=100)
        self.encoder = FeatureEncoder()

        # AI模型
        self.models = {
            "XGBoost": XGBoostModel(),
            "LSTM": LSTMModel(),
            "Transformer": TransformerModel(),
            "PPO": PPOModel(),
            "Statistic": StatisticModel(),
            "Behavior": BehaviorModel(),
        }

        self.fusion_engine = FusionEngine()
        self.risk_controller = RiskController()
        self.experience_retriever = ExperienceRetriever()
        self.current_context: Optional[WorkflowContext] = None

    async def run_full_pipeline(self, db_session=None, lottery_type: str = "ssq") -> WorkflowContext:
        """运行完整预测流程"""
        ctx = WorkflowContext(started_at=datetime.now(), lottery_type=lottery_type)
        self.current_context = ctx

        try:
            # Step 1: 数据检查
            ctx.state = WorkflowState.DATA_CHECK
            logger.info(f"=== Step 1: 数据检查 ({lottery_type}) ===")
            if db_session:
                # 从数据库获取最新期号
                latest_period = await self._get_latest_period(db_session, lottery_type)
                if latest_period:
                    ctx.current_period = latest_period
                    logger.info(f"  当前最新期号: {latest_period}")
            await asyncio.sleep(0.1)

            # Step 2: 特征生成
            ctx.state = WorkflowState.FEATURE_GEN
            logger.info(f"=== Step 2: 特征生成 ({lottery_type}) ===")
            if ctx.draws:
                features = self.feature_builder.build_features(ctx.draws, lottery_type=lottery_type)
                ctx.features = features
            else:
                # 使用随机特征（开发阶段）
                ctx.features = self._generate_mock_features(lottery_type)

            # Step 3: 模型预测
            ctx.state = WorkflowState.MODEL_PREDICT
            logger.info(f"=== Step 3: 模型预测 ({lottery_type}) ===")
            for name, model in self.models.items():
                try:
                    prediction = model.predict(ctx.features, lottery_type=lottery_type)
                    ctx.predictions[name] = prediction
                    logger.info(f"  模型 [{name}] 预测完成, 置信度={prediction['confidence']:.3f}")
                except Exception as e:
                    logger.error(f"  模型 [{name}] 预测失败: {e}")

            # Step 4: 融合决策
            ctx.state = WorkflowState.FUSION
            logger.info(f"=== Step 4: 融合决策 ({lottery_type}) ===")
            model_outputs = []
            for name, pred in ctx.predictions.items():
                mo = ModelOutput(
                    name=name,
                    red_probs=pred.get("red_probs", pred.get("main_probs", [])),
                    blue_probs=pred.get("blue_probs", pred.get("bonus_probs", [])),
                    confidence=pred["confidence"],
                    credibility=self.models[name].credibility_score,
                )
                model_outputs.append(mo)

            fusion_result = self.fusion_engine.fuse(model_outputs, lottery_type=lottery_type)
            ctx.fusion_result = fusion_result

            # Step 5: 候选方案生成
            ctx.state = WorkflowState.CANDIDATE_GEN
            logger.info(f"=== Step 5: 候选方案 ({lottery_type}) ===")
            ctx.candidates = fusion_result.candidates

            # Step 6: 风险评估
            ctx.state = WorkflowState.SCORING
            logger.info(f"=== Step 6: 风险评估 ({lottery_type}) ===")
            ctx.risk_assessment = self.risk_controller.assess_risk(ctx.candidates)

            # Step 7: 保存结果
            ctx.state = WorkflowState.SAVE
            logger.info(f"=== Step 7: 保存结果 ({lottery_type}) ===")

            # 确定预测的目标期号
            target_period = ctx.current_period or "current"
            if db_session and ctx.current_period and ctx.current_period != "current":
                # 预测下一期（期号+1）
                target_period = self._next_period(ctx.current_period)

            # 7a. 写入数据库 predictions 表（供后续反馈匹配使用）
            saved_to_db = False
            if db_session:
                try:
                    for candidate in ctx.candidates[:3]:
                        main_balls = candidate["main_balls"]
                        bonus_balls = candidate.get("bonus_balls", [])
                        await self._save_prediction_to_db(
                            db_session, target_period, lottery_type,
                            "fusion", main_balls, bonus_balls,
                            candidate["score"], fusion_result.model_contributions,
                        )
                    # 同时保存各模型独立的预测
                    for name, pred in ctx.predictions.items():
                        top_main = self._top_n_from_probs(
                            pred.get("red_probs", pred.get("main_probs", [])),
                            lottery_type, is_main=True,
                        )
                        top_bonus = self._top_n_from_probs(
                            pred.get("blue_probs", pred.get("bonus_probs", [])),
                            lottery_type, is_main=False,
                        )
                        await self._save_prediction_to_db(
                            db_session, target_period, lottery_type,
                            name, top_main, top_bonus,
                            pred.get("confidence", 0.5), None,
                        )
                    saved_to_db = True
                    logger.info(f"  预测结果已写入数据库: 期号={target_period}")
                except Exception as e:
                    logger.warning(f"  写入数据库失败 (非致命): {e}")

            # 7b. 存储到记忆库
            schema = get_schema(lottery_type)
            for candidate in ctx.candidates[:3]:
                prediction_data = {
                    "main_balls": candidate["main_balls"],
                    "score": candidate["score"],
                }
                if "bonus_balls" in candidate:
                    prediction_data["bonus_balls"] = candidate["bonus_balls"]

                global_memory.store_prediction(
                    period=target_period,
                    prediction=prediction_data,
                    score=candidate["score"],
                )

            # Step 8: 完成
            ctx.state = WorkflowState.COMPLETED
            ctx.completed_at = datetime.now()
            duration = (ctx.completed_at - ctx.started_at).total_seconds()
            logger.info(f"=== 流程完成 ({lottery_type}), 耗时 {duration:.2f}s, 写入DB={saved_to_db} ===")

        except Exception as e:
            ctx.state = WorkflowState.ERROR
            ctx.error_message = str(e)
            logger.error(f"流程执行失败: {e}")

        return ctx

    def get_status(self) -> Dict[str, Any]:
        """获取当前状态"""
        status = {
            "state": self.state.value,
            "models": {name: m.get_info() for name, m in self.models.items()},
            "fusion": self.fusion_engine.get_engine_status(),
            "memory": global_memory.get_statistics(),
            "risk": self.risk_controller.get_risk_report(),
        }
        if self.current_context:
            status["current_period"] = self.current_context.current_period
            status["lottery_type"] = self.current_context.lottery_type
            if self.current_context.fusion_result:
                status["final_score"] = self.current_context.fusion_result.final_score
                status["model_contributions"] = self.current_context.fusion_result.model_contributions
                status["candidates_count"] = len(self.current_context.candidates)
        return status

    async def _get_latest_period(self, db_session, lottery_type: str) -> Optional[str]:
        """从数据库获取最新期号"""
        try:
            from app.database.models import LotteryDraw
            from sqlalchemy import select, desc
            result = await db_session.execute(
                select(LotteryDraw.period)
                .where(LotteryDraw.lottery_type == lottery_type)
                .order_by(desc(LotteryDraw.draw_date))
                .limit(1)
            )
            row = result.first()
            return row[0] if row else None
        except Exception as e:
            logger.warning(f"获取最新期号失败: {e}")
            return None

    def _next_period(self, current_period: str) -> str:
        """计算下一期号（简单+1）"""
        try:
            num = int(current_period)
            return str(num + 1)
        except ValueError:
            return current_period

    async def _save_prediction_to_db(
        self, db_session, period: str, lottery_type: str,
        model_name: str, main_balls: list, bonus_balls: list,
        score: float, weights: Optional[dict] = None,
    ):
        """保存预测结果到数据库"""
        from app.database.models import Prediction
        pred = Prediction(
            period=period,
            lottery_type=lottery_type,
            model_name=model_name,
            model_version="auto",
            main_balls=main_balls,
            bonus_balls=bonus_balls if bonus_balls else None,
            score=score,
            probability=score / 100.0 if score else 0.5,
            confidence=score / 100.0 if score else 0.5,
            weights=weights,
            status="pending",
        )
        db_session.add(pred)
        await db_session.commit()

    def _top_n_from_probs(self, probs: list, lottery_type: str,
                          is_main: bool = True) -> list:
        """从概率向量中取Top-N号码"""
        import numpy as np
        from app.core.lottery_schema import get_schema
        schema = get_schema(lottery_type)
        if is_main:
            count = schema["main_count"]
            lo = schema["main_balls"]["range"][0]
        else:
            total_bonus = sum(b["count"] for b in schema["bonus_balls"])
            count = total_bonus
            lo = schema["bonus_balls"][0]["range"][0]

        if not probs or len(probs) == 0:
            return list(range(lo, lo + count))

        arr = np.array(probs[:count]) if len(probs) >= count else np.array(probs)
        if len(arr) < count:
            arr = np.pad(arr, (0, count - len(arr)), 'constant', constant_values=0)

        top_indices = np.argsort(arr)[-count:][::-1]
        result = [int(i) + lo for i in top_indices]
        result.sort()
        return result

    def _generate_mock_features(self, lottery_type: str = "ssq") -> Any:
        """生成模拟特征（开发阶段）"""
        import numpy as np
        from app.core.lottery_schema import get_total_dim
        total_dim = get_total_dim(lottery_type)
        return np.random.randn(max(100, total_dim + 20)).astype(np.float32)


# 全局编排器实例
orchestrator = Orchestrator()
