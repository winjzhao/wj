"""
V70 彩票AI工作台 - AI模型基类
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
import os
from pathlib import Path
import numpy as np
from loguru import logger


class BaseAIModel(ABC):
    """AI模型抽象基类"""

    def __init__(self, name: str, version: str = "1.0"):
        self.name = name
        self.version = version
        self.is_trained = False
        self.performance_history: List[float] = []
        self.credibility_score: float = 0.5  # 可信度评分

    @abstractmethod
    def predict(self, features: np.ndarray, lottery_type: str = "ssq") -> Dict[str, Any]:
        """
        预测接口
        返回: {
            "main_probs": 主球区概率向量,
            "bonus_probs": 附加球区概率向量,
            "red_probs": 红球概率向量 (向后兼容),
            "blue_probs": 蓝球概率向量 (向后兼容),
            "confidence": 置信度
        }
        """
        pass

    @abstractmethod
    def train(self, features: np.ndarray, targets: np.ndarray) -> float:
        """训练接口，返回loss"""
        pass

    @abstractmethod
    def save(self, path: str) -> None:
        """保存模型到指定路径"""
        pass

    @abstractmethod
    def load(self, path: str) -> None:
        """从指定路径加载模型"""
        pass

    def get_save_path(self, base_dir: str, lottery_type: str = "ssq") -> str:
        """生成统一的模型保存路径: {base_dir}/{model_name}/{lottery_type}_{version}.pt"""
        model_dir = Path(base_dir) / self.name
        model_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{lottery_type}_{self.version}.pt"
        return str(model_dir / filename)

    def get_load_candidates(self, base_dir: str) -> List[str]:
        """获取该模型在base_dir下的所有检查点文件路径（按修改时间倒序）"""
        model_dir = Path(base_dir) / self.name
        if not model_dir.exists():
            return []
        files = sorted(model_dir.glob("*.pt"), key=os.path.getmtime, reverse=True)
        return [str(f) for f in files]

    def update_credibility(self, recent_performance: float):
        """更新模型可信度"""
        self.performance_history.append(recent_performance)
        if len(self.performance_history) > 20:
            self.performance_history = self.performance_history[-20:]

        # 基于历史表现计算可信度
        if self.performance_history:
            mean_perf = np.mean(self.performance_history)
            std_perf = np.std(self.performance_history) if len(self.performance_history) > 1 else 0.1
            # 表现越稳定、均值越高 -> 可信度越高
            self.credibility_score = mean_perf / (1.0 + std_perf)
            self.credibility_score = min(1.0, max(0.1, self.credibility_score))

    def get_info(self) -> Dict:
        """获取模型信息"""
        return {
            "name": self.name,
            "version": self.version,
            "is_trained": self.is_trained,
            "credibility_score": round(self.credibility_score, 4),
            "performance_avg": round(np.mean(self.performance_history), 4) if self.performance_history else 0,
        }
