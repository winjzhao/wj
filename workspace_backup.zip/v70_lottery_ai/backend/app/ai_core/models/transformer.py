"""
V70 彩票AI工作台 - Transformer预测模型
使用自注意力机制学习号码序列的时序依赖关系
"""
import numpy as np
from typing import Dict, Any
from pathlib import Path
from app.ai_core.models.base import BaseAIModel
from app.core.lottery_schema import get_schema, get_total_dim
from loguru import logger


class TransformerModel(BaseAIModel):
    """
    Transformer 时序预测模型
    使用多头自注意力机制捕捉号码序列中的复杂模式
    """

    def __init__(self, d_model: int = 64, n_heads: int = 4, n_layers: int = 2):
        super().__init__("Transformer", "V2.0")
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_layers = n_layers

        # 模拟权重（实际部署时使用PyTorch模型）
        self.weights = {
            "attention": np.random.randn(d_model, d_model) * 0.02,
            "fc1": np.random.randn(d_model, d_model) * 0.02,
        }
        # 动态输出权重，在 predict 时按 lottery_type 调整
        self._output_weights_cache: Dict[str, np.ndarray] = {}
        self.sequence_memory = []

    def _get_output_weights(self, lottery_type: str) -> np.ndarray:
        """获取或创建对应彩票类型的输出权重矩阵"""
        if lottery_type not in self._output_weights_cache:
            total_dim = get_total_dim(lottery_type)
            self._output_weights_cache[lottery_type] = np.random.randn(self.d_model, total_dim) * 0.02
        return self._output_weights_cache[lottery_type]

    def _self_attention(self, x: np.ndarray) -> np.ndarray:
        """简化版自注意力计算"""
        # x shape: (seq_len, d_model)
        Q = x @ self.weights["attention"]
        K = x @ self.weights["attention"]
        V = x @ self.weights["attention"]

        scores = Q @ K.T / np.sqrt(self.d_model)
        attn_weights = self._softmax(scores)
        output = attn_weights @ V
        return output

    def _softmax(self, x: np.ndarray, axis: int = -1) -> np.ndarray:
        """Softmax"""
        e_x = np.exp(x - np.max(x, axis=axis, keepdims=True))
        return e_x / e_x.sum(axis=axis, keepdims=True)

    def predict(self, features: np.ndarray, lottery_type: str = "ssq") -> Dict[str, Any]:
        """
        使用Transformer预测
        features: 包含序列特征的向量
        lottery_type: 彩票类型
        """
        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]
        bonus_dims = schema["bonus_dims"]
        total_bonus_dim = sum(bonus_dims)
        total_dim = main_dim + total_bonus_dim

        # 提取序列部分
        total_input_dim = len(features)

        # 模拟Transformer前向传播
        hidden = features[:self.d_model] if total_input_dim >= self.d_model else np.pad(features, (0, max(0, self.d_model - total_input_dim)))

        # 通过多层网络
        for _ in range(self.n_layers):
            hidden = self._self_attention(hidden.reshape(1, -1)).flatten()
            hidden = np.tanh(hidden)

        # 输出层 - 动态维度
        fc2 = self._get_output_weights(lottery_type)
        logits = hidden[:self.d_model] @ fc2
        main_logits = logits[:main_dim]
        bonus_logits = logits[main_dim:main_dim + total_bonus_dim] if total_bonus_dim > 0 else np.array([])

        main_probs = self._softmax(main_logits)

        # 拆分附加球概率
        if total_bonus_dim > 0:
            bonus_probs = self._softmax(bonus_logits)
        else:
            bonus_probs = np.array([])

        # 向后兼容
        red_probs = main_probs if lottery_type == "ssq" else np.zeros(33)
        blue_probs = bonus_probs if lottery_type == "ssq" else (bonus_probs if len(bonus_dims) == 1 and bonus_dims[0] == 16 else np.zeros(16))

        # 置信度
        confidence = float(1.0 / (1.0 + np.std(main_probs)))

        return {
            "main_probs": main_probs.tolist(),
            "bonus_probs": bonus_probs.tolist() if total_bonus_dim > 0 else [],
            "red_probs": red_probs.tolist() if isinstance(red_probs, np.ndarray) else (red_probs if isinstance(red_probs, list) else main_probs.tolist()),
            "blue_probs": blue_probs.tolist() if isinstance(blue_probs, np.ndarray) else (blue_probs if isinstance(blue_probs, list) else (bonus_probs.tolist() if total_bonus_dim > 0 else [])),
            "confidence": confidence,
            "model": self.name,
            "version": self.version,
        }

    def train(self, features: np.ndarray, targets: np.ndarray) -> float:
        """训练Transformer（模拟）"""
        # 模拟训练过程
        loss = np.random.random() * 0.5
        self.is_trained = True
        self.update_credibility(1.0 - loss)
        logger.info(f"[{self.name}] 训练完成, loss={loss:.4f}")
        return float(loss)

    def save(self, path: str) -> None:
        """保存Transformer模型权重（使用pickle存储numpy数组）"""
        from pathlib import Path
        import pickle
        Path(path).parent.mkdir(parents=True, exist_ok=True)

        save_data = {
            "name": self.name,
            "version": self.version,
            "is_trained": self.is_trained,
            "d_model": self.d_model,
            "n_heads": self.n_heads,
            "n_layers": self.n_layers,
            "credibility_score": self.credibility_score,
            "performance_history": self.performance_history,
            "weights": self.weights,
            "output_weights_cache": self._output_weights_cache,
        }
        with open(path, "wb") as f:
            pickle.dump(save_data, f)
        logger.info(f"[Transformer] 模型已保存到 {path}")

    def load(self, path: str) -> None:
        """从指定路径加载Transformer模型"""
        import pickle
        with open(path, "rb") as f:
            checkpoint = pickle.load(f)

        self.version = checkpoint.get("version", self.version)
        self.is_trained = checkpoint.get("is_trained", False)
        self.d_model = checkpoint.get("d_model", self.d_model)
        self.n_heads = checkpoint.get("n_heads", self.n_heads)
        self.n_layers = checkpoint.get("n_layers", self.n_layers)
        self.credibility_score = checkpoint.get("credibility_score", 0.5)
        self.performance_history = checkpoint.get("performance_history", [])
        self.weights = checkpoint.get("weights", self.weights)
        self._output_weights_cache = checkpoint.get("output_weights_cache", {})
        logger.info(f"[Transformer] 模型已从 {path} 加载")
