"""
V70 彩票AI工作台 - 统计模型
基于历史统计规律进行预测（频率分析、冷热号、遗漏分析）
"""
import numpy as np
from typing import Dict, Any
from app.ai_core.models.base import BaseAIModel
from app.core.lottery_schema import get_schema
from loguru import logger


class StatisticModel(BaseAIModel):
    """统计预测模型 - 基于历史频率分析"""

    def __init__(self, window: int = 100):
        super().__init__("Statistic", "V2.0")
        self.window = window
        self.hot_threshold = 0.7  # 热号阈值
        self.cold_threshold = 0.3  # 冷号阈值
        # 频率数组缓存，按 lottery_type
        self._freq_cache: Dict[str, Dict[str, np.ndarray]] = {}
        self._missing_cache: Dict[str, np.ndarray] = {}

    def _ensure_freq_cache(self, lottery_type: str):
        """确保频率缓存已初始化"""
        if lottery_type not in self._freq_cache:
            schema = get_schema(lottery_type)
            main_dim = schema["main_dim"]
            bonus_dims = schema["bonus_dims"]
            total_bonus_dim = sum(bonus_dims)
            self._freq_cache[lottery_type] = {
                "main_freq": np.ones(main_dim) / main_dim,
                "bonus_freq": np.ones(total_bonus_dim) / max(total_bonus_dim, 1) if total_bonus_dim > 0 else np.array([]),
            }
        if lottery_type not in self._missing_cache:
            schema = get_schema(lottery_type)
            self._missing_cache[lottery_type] = np.zeros(schema["main_dim"], dtype=np.int32)

    @property
    def red_freq(self):
        """向后兼容: SSQ红球频率"""
        self._ensure_freq_cache("ssq")
        return self._freq_cache["ssq"]["main_freq"]

    @property
    def blue_freq(self):
        """向后兼容: SSQ蓝球频率"""
        self._ensure_freq_cache("ssq")
        return self._freq_cache["ssq"]["bonus_freq"]

    @property
    def missing_counts(self):
        """向后兼容: SSQ遗漏计数"""
        self._ensure_freq_cache("ssq")
        return self._missing_cache["ssq"]

    def predict(self, features: np.ndarray, lottery_type: str = "ssq") -> Dict[str, Any]:
        """
        基于统计频率预测
        features: 包含频率特征的部分
        lottery_type: 彩票类型
        """
        self._ensure_freq_cache(lottery_type)
        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]
        bonus_dims = schema["bonus_dims"]
        total_bonus_dim = sum(bonus_dims)
        total_dim = main_dim + total_bonus_dim

        # 从特征中提取频率信息
        if len(features) >= total_dim:
            main_freq = features[:main_dim]
            bonus_freq = features[main_dim:main_dim + total_bonus_dim] if total_bonus_dim > 0 else np.array([])
        else:
            main_freq = self._freq_cache[lottery_type]["main_freq"]
            bonus_freq = self._freq_cache[lottery_type]["bonus_freq"]

        # 计算热度加权概率
        missing = self._missing_cache.get(lottery_type, np.zeros(main_dim, dtype=np.int32))
        main_probs = self._calculate_probs(main_freq, missing)
        if total_bonus_dim > 0:
            bonus_probs = bonus_freq / (bonus_freq.sum() + 1e-8)
        else:
            bonus_probs = np.array([])

        # 置信度基于频率分布的熵
        confidence = self._calculate_confidence(main_probs)

        # 向后兼容
        if lottery_type == "ssq":
            red_probs = main_probs
            blue_probs = bonus_probs
        else:
            red_probs = np.zeros(33)
            blue_probs = bonus_probs if total_bonus_dim == 16 else np.zeros(16)

        return {
            "main_probs": main_probs.tolist(),
            "bonus_probs": bonus_probs.tolist() if total_bonus_dim > 0 else [],
            "red_probs": red_probs.tolist(),
            "blue_probs": blue_probs.tolist(),
            "confidence": confidence,
            "model": self.name,
            "version": self.version,
        }

    def _calculate_probs(self, freq: np.ndarray, missing: np.ndarray) -> np.ndarray:
        """计算概率，考虑频率和遗漏"""
        n = len(freq)
        # 频率归一化
        freq_norm = freq / (freq.sum() + 1e-8)

        # 遗漏加权（遗漏越久，出现概率微调）
        if len(missing) == n and missing.sum() > 0:
            missing_weight = missing / (missing.max() + 1)
            missing_weight = 1.0 + 0.1 * missing_weight
        else:
            missing_weight = np.ones(n)

        probs = freq_norm * missing_weight
        probs = probs / probs.sum()
        return probs

    def _calculate_confidence(self, probs: np.ndarray) -> float:
        """基于熵计算置信度"""
        eps = 1e-8
        probs = np.clip(probs, eps, 1.0)
        probs = probs / probs.sum()
        entropy = -np.sum(probs * np.log(probs))
        max_entropy = np.log(len(probs))
        # 熵越小，分布越集中，置信度越高
        return float(1.0 - entropy / max_entropy)

    def update_frequency(self, main_balls: list, bonus_balls: list = None, lottery_type: str = "ssq", window: int = 100):
        """更新频率统计（通用）"""
        self._ensure_freq_cache(lottery_type)
        cache = self._freq_cache[lottery_type]
        for r in main_balls:
            cache["main_freq"][r - 1] += 1
        if bonus_balls:
            for b in bonus_balls:
                if isinstance(b, list):
                    for bb in b:
                        cache["bonus_freq"][bb - 1] += 1
                else:
                    cache["bonus_freq"][b - 1] += 1
        cache["main_freq"] = cache["main_freq"] / cache["main_freq"].sum()
        if len(cache["bonus_freq"]) > 0:
            cache["bonus_freq"] = cache["bonus_freq"] / cache["bonus_freq"].sum()

    def train(self, features: np.ndarray, targets: np.ndarray) -> float:
        """训练（更新统计参数）"""
        self.is_trained = True
        return 0.0

    def save(self, path: str) -> None:
        """保存统计模型参数（使用pickle）"""
        from pathlib import Path
        import pickle
        Path(path).parent.mkdir(parents=True, exist_ok=True)

        save_data = {
            "name": self.name,
            "version": self.version,
            "is_trained": self.is_trained,
            "window": self.window,
            "hot_threshold": self.hot_threshold,
            "cold_threshold": self.cold_threshold,
            "credibility_score": self.credibility_score,
            "performance_history": self.performance_history,
            "freq_cache": self._freq_cache,
            "missing_cache": self._missing_cache,
        }
        with open(path, "wb") as f:
            pickle.dump(save_data, f)
        logger.info(f"[Statistic] 统计参数已保存到 {path}")

    def load(self, path: str) -> None:
        """从指定路径加载统计模型参数"""
        import pickle
        with open(path, "rb") as f:
            checkpoint = pickle.load(f)

        self.version = checkpoint.get("version", self.version)
        self.is_trained = checkpoint.get("is_trained", False)
        self.window = checkpoint.get("window", self.window)
        self.hot_threshold = checkpoint.get("hot_threshold", self.hot_threshold)
        self.cold_threshold = checkpoint.get("cold_threshold", self.cold_threshold)
        self.credibility_score = checkpoint.get("credibility_score", 0.5)
        self.performance_history = checkpoint.get("performance_history", [])
        self._freq_cache = checkpoint.get("freq_cache", {})
        self._missing_cache = checkpoint.get("missing_cache", {})
        logger.info(f"[Statistic] 统计参数已从 {path} 加载")

    def get_hot_cold_analysis(self, lottery_type: str = "ssq") -> Dict:
        """冷热号分析"""
        self._ensure_freq_cache(lottery_type)
        main_freq = self._freq_cache[lottery_type]["main_freq"]
        median_freq = np.median(main_freq)
        hot_numbers = [i + 1 for i, f in enumerate(main_freq) if f > self.hot_threshold * median_freq * 2]
        cold_numbers = [i + 1 for i, f in enumerate(main_freq) if f < self.cold_threshold * median_freq]
        missing = self._missing_cache.get(lottery_type, np.zeros(len(main_freq), dtype=np.int32))
        return {
            "hot_numbers": hot_numbers,
            "cold_numbers": cold_numbers,
            "missing_counts": missing.tolist(),
        }
