"""
V70 彩票AI工作台 - 行为分析模型
分析历史号码的"行为模式"，如连号、重号、跳号等规律
"""
import numpy as np
from typing import Dict, Any, List
from app.ai_core.models.base import BaseAIModel
from app.core.lottery_schema import get_schema


class BehaviorModel(BaseAIModel):
    """行为分析模型 - 号码行为模式识别"""

    def __init__(self):
        super().__init__("Behavior", "V1.0")
        self.consecutive_patterns = []  # 连号模式
        self.repeat_patterns = []       # 重号模式
        self.skip_patterns = []         # 跳号模式

    def predict(self, features: np.ndarray, lottery_type: str = "ssq") -> Dict[str, Any]:
        """
        基于行为模式预测
        lottery_type: 彩票类型
        """
        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]
        bonus_dims = schema["bonus_dims"]
        total_bonus_dim = sum(bonus_dims)

        # 从特征中提取频率
        if len(features) >= main_dim:
            main_freq = features[:main_dim]
        else:
            main_freq = np.ones(main_dim) / main_dim

        if total_bonus_dim > 0 and len(features) >= main_dim + total_bonus_dim:
            bonus_freq = features[main_dim:main_dim + total_bonus_dim]
        elif total_bonus_dim > 0:
            bonus_freq = np.ones(total_bonus_dim) / total_bonus_dim
        else:
            bonus_freq = np.array([])

        # 连号倾向
        consecutive_bonus = self._analyze_consecutive(main_freq)
        # 重号倾向
        repeat_bonus = self._analyze_repeat(main_freq)
        # 跳号倾向
        skip_bonus = self._analyze_skip(main_freq)

        # 综合行为概率
        main_probs = main_freq * (1.0 + 0.1 * consecutive_bonus + 0.05 * repeat_bonus + 0.05 * skip_bonus)
        main_probs = main_probs / main_probs.sum()

        if total_bonus_dim > 0:
            bonus_probs = bonus_freq / bonus_freq.sum()
        else:
            bonus_probs = np.array([])

        # 向后兼容
        if lottery_type == "ssq":
            red_probs = main_probs
            blue_probs = bonus_probs
        else:
            red_probs = np.zeros(33)
            blue_probs = bonus_probs if total_bonus_dim == 16 else np.zeros(16)

        return {
            "main_probs": main_probs.tolist(),
            "bonus_probs": bonus_probs.tolist() if total_bonus_dim > 0 else [],
            "red_probs": red_probs.tolist(),
            "blue_probs": blue_probs.tolist(),
            "confidence": 0.6,  # 行为模型置信度一般
            "model": self.name,
            "version": self.version,
            "patterns": {
                "consecutive_bonus": consecutive_bonus.tolist(),
                "repeat_bonus": repeat_bonus.tolist(),
                "skip_bonus": skip_bonus.tolist(),
            },
        }

    def _analyze_consecutive(self, freq: np.ndarray) -> np.ndarray:
        """分析连号模式 - 相邻号码组出现概率"""
        n = len(freq)
        bonus = np.ones(n)
        for i in range(n - 1):
            # 相邻号码对同时高频出现，给予加权
            pair_score = (freq[i] + freq[i + 1]) / 2
            bonus[i] += pair_score * 0.3
            bonus[i + 1] += pair_score * 0.3
        return bonus

    def _analyze_repeat(self, freq: np.ndarray) -> np.ndarray:
        """分析重号模式 - 号码重复出现概率"""
        bonus = np.ones(len(freq))
        high_freq_mask = freq > np.median(freq)
        bonus[high_freq_mask] += 0.2
        return bonus

    def _analyze_skip(self, freq: np.ndarray) -> np.ndarray:
        """分析跳号模式 - 间隔号码出现规律"""
        n = len(freq)
        bonus = np.ones(n)
        for skip in [1, 2, 3]:
            for i in range(n - skip):
                if freq[i] > np.median(freq) and freq[i + skip] > np.median(freq):
                    bonus[i] += 0.05
                    bonus[i + skip] += 0.05
        return bonus

    def save(self, path: str) -> None:
        """保存行为模型参数（使用pickle）"""
        from pathlib import Path
        import pickle
        Path(path).parent.mkdir(parents=True, exist_ok=True)

        save_data = {
            "name": self.name,
            "version": self.version,
            "is_trained": self.is_trained,
            "credibility_score": self.credibility_score,
            "performance_history": self.performance_history,
            "consecutive_patterns": self.consecutive_patterns,
            "repeat_patterns": self.repeat_patterns,
            "skip_patterns": self.skip_patterns,
        }
        with open(path, "wb") as f:
            pickle.dump(save_data, f)
        logger.info(f"[Behavior] 行为模式参数已保存到 {path}")

    def load(self, path: str) -> None:
        """从指定路径加载行为模型参数"""
        import pickle
        with open(path, "rb") as f:
            checkpoint = pickle.load(f)

        self.version = checkpoint.get("version", self.version)
        self.is_trained = checkpoint.get("is_trained", False)
        self.credibility_score = checkpoint.get("credibility_score", 0.5)
        self.performance_history = checkpoint.get("performance_history", [])
        self.consecutive_patterns = checkpoint.get("consecutive_patterns", [])
        self.repeat_patterns = checkpoint.get("repeat_patterns", [])
        self.skip_patterns = checkpoint.get("skip_patterns", [])
        logger.info(f"[Behavior] 行为模式参数已从 {path} 加载")

    def train(self, features: np.ndarray, targets: np.ndarray) -> float:
        self.is_trained = True
        return 0.0
