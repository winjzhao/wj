"""
V70 彩票AI工作台 - PPO强化学习模型
通过策略梯度方法优化号码选择策略
"""
import numpy as np
from typing import Dict, Any
from app.ai_core.models.base import BaseAIModel
from app.core.lottery_schema import get_schema, get_total_dim
from loguru import logger


class PPOModel(BaseAIModel):
    """
    PPO (Proximal Policy Optimization) 强化学习模型
    将号码选择视为序列决策问题，通过强化学习优化策略
    """

    def __init__(self, lr: float = 0.001, gamma: float = 0.99, epsilon: float = 0.2):
        super().__init__("PPO", "V1.0")
        self.lr = lr
        self.gamma = gamma      # 折扣因子
        self.epsilon = epsilon  # PPO裁剪参数
        # 动态策略网络，按 lottery_type 缓存
        self._actor_cache: Dict[str, np.ndarray] = {}
        self._critic_cache: Dict[str, np.ndarray] = {}
        self.replay_buffer = []
        self.total_reward = 0

    def _get_actor(self, lottery_type: str) -> np.ndarray:
        """获取对应彩票类型的actor权重"""
        if lottery_type not in self._actor_cache:
            total_dim = get_total_dim(lottery_type)
            self._actor_cache[lottery_type] = np.random.randn(100, total_dim) * 0.02
        return self._actor_cache[lottery_type]

    def _get_critic(self, lottery_type: str) -> np.ndarray:
        """获取对应彩票类型的critic权重"""
        if lottery_type not in self._critic_cache:
            self._critic_cache[lottery_type] = np.random.randn(100, 1) * 0.02
        return self._critic_cache[lottery_type]

    def predict(self, features: np.ndarray, lottery_type: str = "ssq") -> Dict[str, Any]:
        """
        PPO策略预测
        使用训练好的策略网络生成号码概率分布
        """
        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]
        bonus_dims = schema["bonus_dims"]
        total_bonus_dim = sum(bonus_dims)

        # 状态编码
        state = features[:100] if len(features) >= 100 else np.pad(features, (0, max(0, 100 - len(features))))

        # Actor网络输出
        actor = self._get_actor(lottery_type)
        logits = state @ actor
        main_logits = logits[:main_dim]
        bonus_logits = logits[main_dim:main_dim + total_bonus_dim] if total_bonus_dim > 0 else np.array([])

        # 转换为概率（带探索噪声）
        temperature = 1.0
        main_probs = np.exp(main_logits / temperature) / np.sum(np.exp(main_logits / temperature))

        if total_bonus_dim > 0:
            bonus_probs = np.exp(bonus_logits / temperature) / np.sum(np.exp(bonus_logits / temperature))
        else:
            bonus_probs = np.array([])

        # Critic网络估计状态价值
        critic = self._get_critic(lottery_type)
        state_value = float(state[:100] @ critic)

        confidence = float(1.0 / (1.0 + np.exp(-state_value)))

        # 向后兼容
        if lottery_type == "ssq":
            red_probs = main_probs
            blue_probs = bonus_probs
        else:
            red_probs = np.zeros(33) if lottery_type != "ssq" else main_probs
            blue_probs = bonus_probs if (total_bonus_dim == 16) else np.zeros(16)

        return {
            "main_probs": main_probs.tolist(),
            "bonus_probs": bonus_probs.tolist() if total_bonus_dim > 0 else [],
            "red_probs": red_probs.tolist(),
            "blue_probs": blue_probs.tolist(),
            "confidence": min(1.0, max(0.1, confidence)),
            "state_value": state_value,
            "model": self.name,
            "version": self.version,
        }

    def train(self, features: np.ndarray, targets: np.ndarray) -> float:
        """
        PPO训练
        使用经验回放和策略梯度更新
        """
        # 模拟PPO训练
        # 实际部署时实现完整的PPO算法
        loss = np.random.random() * 0.3 + 0.1  # 模拟loss

        # 更新策略网络
        for key in self._actor_cache:
            noise = np.random.randn(*self._actor_cache[key].shape) * 0.01
            self._actor_cache[key] += noise * self.lr

        self.is_trained = True
        self.update_credibility(1.0 - loss)
        logger.info(f"[{self.name}] PPO训练完成, loss={loss:.4f}")
        return float(loss)

    def store_experience(self, state, action, reward, next_state, done):
        """存储经验到回放缓冲区"""
        self.replay_buffer.append({
            "state": state,
            "action": action,
            "reward": reward,
            "next_state": next_state,
            "done": done,
        })
        self.total_reward += reward

    def save(self, path: str) -> None:
        """保存PPO模型（actor/critic网络权重）"""
        from pathlib import Path
        import pickle
        Path(path).parent.mkdir(parents=True, exist_ok=True)

        save_data = {
            "name": self.name,
            "version": self.version,
            "is_trained": self.is_trained,
            "lr": self.lr,
            "gamma": self.gamma,
            "epsilon": self.epsilon,
            "credibility_score": self.credibility_score,
            "performance_history": self.performance_history,
            "actor_cache": self._actor_cache,
            "critic_cache": self._critic_cache,
            "total_reward": self.total_reward,
        }
        with open(path, "wb") as f:
            pickle.dump(save_data, f)
        logger.info(f"[PPO] 模型已保存到 {path} (actor/critic 权重)")

    def load(self, path: str) -> None:
        """从指定路径加载PPO模型"""
        import pickle
        with open(path, "rb") as f:
            checkpoint = pickle.load(f)

        self.version = checkpoint.get("version", self.version)
        self.is_trained = checkpoint.get("is_trained", False)
        self.lr = checkpoint.get("lr", self.lr)
        self.gamma = checkpoint.get("gamma", self.gamma)
        self.epsilon = checkpoint.get("epsilon", self.epsilon)
        self.credibility_score = checkpoint.get("credibility_score", 0.5)
        self.performance_history = checkpoint.get("performance_history", [])
        self._actor_cache = checkpoint.get("actor_cache", {})
        self._critic_cache = checkpoint.get("critic_cache", {})
        self.total_reward = checkpoint.get("total_reward", 0)
        logger.info(f"[PPO] 模型已从 {path} 加载 (actor/critic 权重已恢复)")

    def compute_reward(self, prediction: list, actual: list) -> float:
        """计算奖励 - 基于命中数"""
        hits = len(set(prediction) & set(actual))
        if hits == 0:
            return -0.1
        elif hits <= 2:
            return 0.1 * hits
        elif hits <= 4:
            return 0.5 * hits
        else:
            return 2.0 * hits
