"""
V70 彩票AI工作台 - 特征工程构建器
从原始开奖数据构建AI模型可用的特征向量
"""
import numpy as np
from typing import List, Dict, Any, Optional
from loguru import logger
from app.core.lottery_schema import get_schema


class FeatureBuilder:
    """特征构建器"""

    # 基础特征维度定义
    FEATURE_DIMS = {
        "basic": 12,       # 基础统计特征
        "trend": 20,       # 趋势特征
        "pattern": 15,     # 模式特征
    }

    def __init__(self, window_size: int = 100):
        self.window_size = window_size

    def build_features(self, draws: List[Dict], lottery_type: str = "ssq") -> np.ndarray:
        """构建完整特征向量"""
        if len(draws) < self.window_size:
            logger.warning(f"数据不足: {len(draws)} < {self.window_size}")
            return np.array([])

        recent_draws = draws[-self.window_size:]

        # 获取彩票类型配置
        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]
        bonus_dims = schema["bonus_dims"]
        total_bonus_dim = sum(bonus_dims)

        features = np.concatenate([
            self._build_basic_features(recent_draws, lottery_type),
            self._build_trend_features(recent_draws, lottery_type),
            self._build_pattern_features(recent_draws, lottery_type),
            self._build_frequency_features(recent_draws, lottery_type),
        ])

        return features

    def _get_main_balls_key(self, lottery_type: str) -> str:
        """获取主球区字段名"""
        return "main_balls" if lottery_type != "ssq" else "reds"

    def _get_bonus_balls_key(self, lottery_type: str) -> str:
        """获取附加球区字段名"""
        return "bonus_balls" if lottery_type != "ssq" else "blue"

    def _build_basic_features(self, draws: List[Dict], lottery_type: str = "ssq") -> np.ndarray:
        """基础统计特征"""
        schema = get_schema(lottery_type)
        main_count = schema["main_count"]
        main_key = self._get_main_balls_key(lottery_type)
        bonus_key = self._get_bonus_balls_key(lottery_type)

        # 获取主球区数据
        main_list = []
        for d in draws:
            balls = d.get(main_key, d.get("reds", []))
            if balls:
                main_list.append(balls)

        features = []

        # 主球区统计 - 使用前main_count个位置
        if main_list:
            for i in range(min(main_count, len(main_list[0]) if main_list else 0)):
                col = [r[i] for r in main_list if i < len(r)]
                if col:
                    features.extend([
                        np.mean(col[-20:]) if len(col) >= 20 else np.mean(col),
                        np.std(col[-20:]) if len(col) >= 2 else 0,
                    ])
                else:
                    features.extend([0, 0])
        else:
            features.extend([0, 0] * min(main_count, 6))

        # 附加球统计
        bonus_list = []
        for d in draws:
            b = d.get(bonus_key, d.get("blue", None))
            if b is not None:
                if isinstance(b, list):
                    # bonus_balls 是二维列表
                    bonus_list.append(b)
                else:
                    bonus_list.append(b)

        if bonus_list:
            if isinstance(bonus_list[0], list):
                # 二维列表 - 展平
                flat_bonus = []
                for b in bonus_list:
                    flat_bonus.extend(b)
                if flat_bonus:
                    features.extend([
                        np.mean(flat_bonus[-20:]) if len(flat_bonus) >= 20 else np.mean(flat_bonus),
                        np.std(flat_bonus[-20:]) if len(flat_bonus) >= 2 else 0,
                    ])
                else:
                    features.extend([0, 0])
            else:
                features.extend([
                    np.mean(bonus_list[-20:]) if len(bonus_list) >= 20 else np.mean(bonus_list),
                    np.std(bonus_list[-20:]) if len(bonus_list) >= 2 else 0,
                ])
        else:
            features.extend([0, 0])

        return np.array(features, dtype=np.float32)

    def _build_trend_features(self, draws: List[Dict], lottery_type: str = "ssq") -> np.ndarray:
        """趋势特征"""
        schema = get_schema(lottery_type)
        main_count = schema["main_count"]
        main_key = self._get_main_balls_key(lottery_type)

        main_list = []
        for d in draws:
            balls = d.get(main_key, d.get("reds", []))
            if balls:
                main_list.append(balls)

        features = []

        if main_list:
            n_positions = min(main_count, len(main_list[0]) if main_list else 0)
            for i in range(n_positions):
                col = [r[i] for r in main_list if i < len(r)]
                if len(col) >= 5:
                    # 移动平均趋势
                    ma5 = np.convolve(col[-10:], np.ones(5) / 5, mode='valid')
                    features.extend([
                        ma5[-1] if len(ma5) > 0 else 0,
                        ma5[-1] - ma5[0] if len(ma5) > 1 else 0,  # 趋势方向
                    ])
                else:
                    features.extend([0, 0])
        else:
            features.extend([0, 0] * min(main_count, 6))

        # 和值趋势
        sums = [sum(r) for r in main_list]
        if len(sums) >= 5:
            ma5_sum = np.convolve(sums[-10:], np.ones(5) / 5, mode='valid')
            features.extend([
                ma5_sum[-1] if len(ma5_sum) > 0 else 0,
                ma5_sum[-1] - ma5_sum[0] if len(ma5_sum) > 1 else 0,
            ])
        else:
            features.extend([0, 0])

        # 奇偶比趋势
        odd_ratios = [sum(1 for r in balls if r % 2 == 1) / max(len(balls), 1) for balls in main_list]
        if len(odd_ratios) >= 5:
            ma5_odd = np.convolve(odd_ratios[-10:], np.ones(5) / 5, mode='valid')
            features.extend([
                ma5_odd[-1] if len(ma5_odd) > 0 else 0.5,
            ])
        else:
            features.append(0.5)

        return np.array(features, dtype=np.float32)

    def _build_pattern_features(self, draws: List[Dict], lottery_type: str = "ssq") -> np.ndarray:
        """模式特征"""
        main_key = self._get_main_balls_key(lottery_type)

        main_list = []
        for d in draws:
            balls = d.get(main_key, d.get("reds", []))
            if balls:
                main_list.append(balls)

        features = []

        if main_list:
            # 和值分布
            sums = [sum(balls) for balls in main_list[-50:]]
            sum_bins = [0] * 5
            for s in sums:
                if s < 70:
                    sum_bins[0] += 1
                elif s < 100:
                    sum_bins[1] += 1
                elif s < 130:
                    sum_bins[2] += 1
                elif s < 150:
                    sum_bins[3] += 1
                else:
                    sum_bins[4] += 1
            features.extend([b / max(len(sums), 1) for b in sum_bins])

            # 跨度分布
            spans = [max(balls) - min(balls) for balls in main_list[-50:]]
            span_bins = [0] * 5
            for sp in spans:
                if sp < 15:
                    span_bins[0] += 1
                elif sp < 20:
                    span_bins[1] += 1
                elif sp < 25:
                    span_bins[2] += 1
                elif sp < 30:
                    span_bins[3] += 1
                else:
                    span_bins[4] += 1
            features.extend([b / max(len(spans), 1) for b in span_bins])

            # 奇偶模式
            main_count = len(main_list[0]) if main_list else 6
            odd_counts = [sum(1 for r in balls if r % 2 == 1) for balls in main_list[-50:]]
            odd_bins = [0] * 5
            for oc in odd_counts:
                idx = min(4, max(0, oc - 1))
                odd_bins[idx] += 1
            features.extend([b / max(len(odd_counts), 1) for b in odd_bins])
        else:
            features.extend([0.0] * 15)

        return np.array(features, dtype=np.float32)

    def _build_frequency_features(self, draws: List[Dict], lottery_type: str = "ssq") -> np.ndarray:
        """频率特征 - 根据彩票类型动态计算维度"""
        schema = get_schema(lottery_type)
        main_dim = schema["main_dim"]
        bonus_dims = schema["bonus_dims"]
        total_bonus_dim = sum(bonus_dims)
        main_lo = schema["main_balls"]["range"][0]
        main_key = self._get_main_balls_key(lottery_type)
        bonus_key = self._get_bonus_balls_key(lottery_type)

        main_freq = np.zeros(main_dim, dtype=np.float32)
        bonus_freq = np.zeros(total_bonus_dim, dtype=np.float32) if total_bonus_dim > 0 else np.array([], dtype=np.float32)

        for d in draws[-self.window_size:]:
            main_balls = d.get(main_key, d.get("reds", []))
            for r in main_balls:
                idx = r - main_lo
                if 0 <= idx < main_dim:
                    main_freq[idx] += 1

            bonus_data = d.get(bonus_key, d.get("blue", None))
            if bonus_data is not None:
                if isinstance(bonus_data, list) and bonus_data and isinstance(bonus_data[0], list):
                    # bonus_balls 是二维列表
                    bonus_offset = 0
                    for cfg, b_list in zip(schema["bonus_balls"], bonus_data):
                        lo = cfg["range"][0]
                        sub_dim = cfg["range"][1] - lo + 1
                        for b in b_list:
                            idx = b - lo
                            if 0 <= idx < sub_dim and bonus_offset + idx < total_bonus_dim:
                                bonus_freq[bonus_offset + idx] += 1
                        bonus_offset += sub_dim
                elif isinstance(bonus_data, (int, float)):
                    b = int(bonus_data)
                    if total_bonus_dim > 0:
                        lo = schema["bonus_balls"][0]["range"][0]
                        idx = b - lo
                        if 0 <= idx < total_bonus_dim:
                            bonus_freq[idx] += 1

        # 归一化
        main_freq = main_freq / max(self.window_size, 1)
        if total_bonus_dim > 0:
            bonus_freq = bonus_freq / max(self.window_size, 1)

        # 返回主球频率 + 附加球频率
        if total_bonus_dim > 0:
            return np.concatenate([main_freq, bonus_freq])
        return main_freq

    @staticmethod
    def draws_to_dict_list(draws) -> List[Dict]:
        """将数据库对象转换为字典列表"""
        result = []
        for d in draws:
            result.append({
                "period": d.period,
                "draw_date": d.draw_date.isoformat() if hasattr(d.draw_date, 'isoformat') else str(d.draw_date),
                "lottery_type": getattr(d, "lottery_type", "ssq"),
                "reds": d.get_reds(),
                "main_balls": d.get_main_balls(),
                "blue": d.blue,
                "bonus_balls": d.get_bonus_balls(),
            })
        return result
