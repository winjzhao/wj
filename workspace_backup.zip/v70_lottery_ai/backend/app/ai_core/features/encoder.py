"""
V70 彩票AI工作台 - 特征编码器
将原始号码转换为模型输入格式
"""
import numpy as np
from typing import List, Tuple


class FeatureEncoder:
    """特征编码器"""

    @staticmethod
    def one_hot_encode(reds: List[int], blue: int) -> np.ndarray:
        """
        One-Hot编码
        红球: 33位, 蓝球: 16位, 共49位
        """
        vec = np.zeros(49, dtype=np.float32)
        for r in reds:
            if 1 <= r <= 33:
                vec[r-1] = 1.0
        if 1 <= blue <= 16:
            vec[33 + blue - 1] = 1.0
        return vec

    @staticmethod
    def multi_hot_sequence(sequence: List[Tuple[List[int], int]], window: int = 10) -> np.ndarray:
        """
        序列编码 - 最近N期的多热编码
        shape: (window, 49)
        """
        seq = sequence[-window:]
        result = np.zeros((window, 49), dtype=np.float32)
        for i, (reds, blue) in enumerate(seq):
            result[i] = FeatureEncoder.one_hot_encode(reds, blue)
        return result

    @staticmethod
    def decode_reds(prediction: np.ndarray, top_k: int = 6) -> List[int]:
        """
        从预测概率解码红球
        prediction: 33维概率分布
        """
        indices = np.argsort(prediction[:33])[::-1][:top_k]
        return sorted([int(i) + 1 for i in indices])

    @staticmethod
    def decode_blue(prediction: np.ndarray) -> int:
        """
        从预测概率解码蓝球
        prediction: 16维概率分布
        """
        return int(np.argmax(prediction[33:49])) + 1
