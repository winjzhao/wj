"""
AI 模型单元测试
测试每个模型的 predict() 和 train() 接口
"""
import pytest
import numpy as np

from app.ai_core.models.base import BaseAIModel
from app.ai_core.models.xgboost_model import XGBoostModel
from app.ai_core.models.lstm_model import LSTMModel
from app.ai_core.models.transformer import TransformerModel
from app.ai_core.models.ppo import PPOModel
from app.ai_core.models.statistic import StatisticModel
from app.ai_core.models.behavior import BehaviorModel


# 彩票类型列表
LOTTERY_TYPES = ["ssq", "dlt", "k8"]


# ============================================================
# 辅助函数
# ============================================================

def validate_prediction_output(prediction: dict, lottery_type: str):
    """验证预测输出的格式和类型"""
    assert isinstance(prediction, dict)
    assert "main_probs" in prediction
    assert "bonus_probs" in prediction
    assert "red_probs" in prediction
    assert "blue_probs" in prediction
    assert "confidence" in prediction
    assert "model" in prediction
    assert "version" in prediction

    # main_probs 必须是列表
    assert isinstance(prediction["main_probs"], list)
    # bonus_probs 必须是列表
    assert isinstance(prediction["bonus_probs"], list)
    # confidence 必须是 float
    assert isinstance(prediction["confidence"], float)
    assert 0.0 <= prediction["confidence"] <= 1.0

    # 验证概率和近似为1
    if prediction["main_probs"]:
        total = sum(prediction["main_probs"])
        assert abs(total - 1.0) < 0.01, f"main_probs sum = {total}"


def get_expected_main_dim(lottery_type: str) -> int:
    """获取期望的主球区维度"""
    dims = {"ssq": 33, "dlt": 35, "k8": 80}
    return dims[lottery_type]


def get_expected_total_dim(lottery_type: str) -> int:
    """获取期望的总维度"""
    dims = {"ssq": 49, "dlt": 47, "k8": 80}
    return dims[lottery_type]


# ============================================================
# XGBoost 模型测试
# ============================================================

class TestXGBoostModel:
    """XGBoost 模型测试"""

    @pytest.fixture
    def model(self):
        return XGBoostModel()

    def test_model_initialization(self, model):
        """测试模型初始化"""
        assert model.name == "XGBoost"
        assert model.version == "V1.0"
        assert model.is_trained == False
        assert model.credibility_score == 0.5
        assert model.n_estimators == 100
        assert model.max_depth == 6
        assert model.learning_rate == 0.1

    def test_get_info(self, model):
        """测试 get_info 方法"""
        info = model.get_info()
        assert info["name"] == "XGBoost"
        assert "version" in info
        assert "is_trained" in info
        assert "credibility_score" in info

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_format(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 predict() 输出格式 - 各种彩票类型"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        features = features_map[lottery_type]
        prediction = model.predict(features, lottery_type=lottery_type)
        validate_prediction_output(prediction, lottery_type)

    def test_predict_main_probs_dimension(self, model, sample_features_ssq):
        """测试 SSQ predict main_probs 维度"""
        prediction = model.predict(sample_features_ssq, lottery_type="ssq")
        assert len(prediction["main_probs"]) == 33
        assert len(prediction["red_probs"]) == 33

    def test_predict_bonus_probs_dimension(self, model, sample_features_ssq):
        """测试 SSQ predict bonus_probs 维度"""
        prediction = model.predict(sample_features_ssq, lottery_type="ssq")
        assert len(prediction["bonus_probs"]) == 16
        assert len(prediction["blue_probs"]) == 16

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_main_probs_sum(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 main_probs 概率和为1"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        if prediction["main_probs"]:
            assert abs(sum(prediction["main_probs"]) - 1.0) < 0.01

    def test_predict_with_1d_features(self, model):
        """测试一维特征输入"""
        features = np.random.randn(50).astype(np.float32)
        prediction = model.predict(features, lottery_type="ssq")
        validate_prediction_output(prediction, "ssq")

    def test_train_returns_float(self, model):
        """测试 train() 返回类型"""
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        loss = model.train(features, targets)
        assert isinstance(loss, float)
        assert loss >= 0

    def test_train_sets_trained_flag(self, model):
        """测试训练后 is_trained 为 True"""
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        model.train(features, targets)
        assert model.is_trained == True

    def test_feature_importance(self, model):
        """测试特征重要性"""
        # 未训练时
        result = model.get_feature_importance("ssq")
        assert "message" in result  # 应该返回提示信息

        # 训练后
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        model.train(features, targets)


# ============================================================
# LSTM 模型测试
# ============================================================

class TestLSTMModel:
    """LSTM 模型测试"""

    @pytest.fixture
    def model(self):
        return LSTMModel()

    def test_model_initialization(self, model):
        """测试模型初始化"""
        assert model.name == "LSTM"
        assert model.version == "V1.0"
        assert model.hidden_dim == 128
        assert model.num_layers == 2
        assert model.seq_len == 30

    def test_get_info(self, model):
        """测试 get_info"""
        info = model.get_info()
        assert info["name"] == "LSTM"

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_format(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 predict() 输出格式"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        validate_prediction_output(prediction, lottery_type)

    def test_predict_main_probs_dimension(self, model, sample_features_ssq):
        """测试 SSQ main_probs 维度"""
        prediction = model.predict(sample_features_ssq, lottery_type="ssq")
        assert len(prediction["main_probs"]) == 33

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_main_probs_sum(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 main_probs 概率和为1"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        if prediction["main_probs"]:
            assert abs(sum(prediction["main_probs"]) - 1.0) < 0.01

    def test_train_returns_float(self, model):
        """测试 train() 返回类型"""
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        loss = model.train(features, targets)
        assert isinstance(loss, float)

    def test_train_sets_trained_flag(self, model):
        """测试训练后 is_trained 为 True"""
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        model.train(features, targets)
        assert model.is_trained == True


# ============================================================
# Transformer 模型测试
# ============================================================

class TestTransformerModel:
    """Transformer 模型测试"""

    @pytest.fixture
    def model(self):
        return TransformerModel()

    def test_model_initialization(self, model):
        """测试模型初始化"""
        assert model.name == "Transformer"
        assert model.version == "V2.0"
        assert model.d_model == 64
        assert model.n_heads == 4
        assert model.n_layers == 2

    def test_get_info(self, model):
        """测试 get_info"""
        info = model.get_info()
        assert info["name"] == "Transformer"

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_format(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 predict() 输出格式"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        validate_prediction_output(prediction, lottery_type)

    def test_predict_main_probs_dimension(self, model, sample_features_ssq):
        """测试 SSQ main_probs 维度"""
        prediction = model.predict(sample_features_ssq, lottery_type="ssq")
        assert len(prediction["main_probs"]) == 33

    def test_predict_confidence_range(self, model, sample_features_ssq):
        """测试置信度范围"""
        prediction = model.predict(sample_features_ssq, lottery_type="ssq")
        assert 0.0 <= prediction["confidence"] <= 1.0

    def test_train_returns_float(self, model):
        """测试 train() 返回类型"""
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        loss = model.train(features, targets)
        assert isinstance(loss, float)

    def test_train_sets_trained_flag(self, model):
        """测试训练后 is_trained 为 True"""
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        model.train(features, targets)
        assert model.is_trained == True


# ============================================================
# PPO 模型测试
# ============================================================

class TestPPOModel:
    """PPO 模型测试"""

    @pytest.fixture
    def model(self):
        return PPOModel()

    def test_model_initialization(self, model):
        """测试模型初始化"""
        assert model.name == "PPO"
        assert model.version == "V1.0"
        assert model.lr == 0.001
        assert model.gamma == 0.99
        assert model.epsilon == 0.2

    def test_get_info(self, model):
        """测试 get_info"""
        info = model.get_info()
        assert info["name"] == "PPO"

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_format(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 predict() 输出格式"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        validate_prediction_output(prediction, lottery_type)

    def test_predict_state_value(self, model, sample_features_ssq):
        """测试 predict 包含 state_value"""
        prediction = model.predict(sample_features_ssq, lottery_type="ssq")
        assert "state_value" in prediction
        assert isinstance(prediction["state_value"], float)

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_main_probs_sum(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 main_probs 概率和为1"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        if prediction["main_probs"]:
            assert abs(sum(prediction["main_probs"]) - 1.0) < 0.01

    def test_train_returns_float(self, model):
        """测试 train() 返回类型"""
        features = np.random.randn(10, 100).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        loss = model.train(features, targets)
        assert isinstance(loss, float)

    def test_train_sets_trained_flag(self, model):
        """测试训练后 is_trained 为 True"""
        features = np.random.randn(10, 100).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        model.train(features, targets)
        assert model.is_trained == True

    def test_store_experience(self, model):
        """测试经验存储"""
        state = np.random.randn(100)
        action = np.array([1, 5, 12, 18, 25, 30])
        model.store_experience(state, action, 0.5, state, False)
        assert len(model.replay_buffer) == 1

    def test_compute_reward(self, model):
        """测试奖励计算"""
        prediction = [1, 5, 12, 18, 25, 30]
        actual = [1, 5, 12, 20, 28, 33]
        reward = model.compute_reward(prediction, actual)
        assert isinstance(reward, float)
        # 命中3个，应该是 0.5 * 3 = 1.5
        assert reward > 0


# ============================================================
# Statistic 模型测试
# ============================================================

class TestStatisticModel:
    """统计模型测试"""

    @pytest.fixture
    def model(self):
        return StatisticModel()

    def test_model_initialization(self, model):
        """测试模型初始化"""
        assert model.name == "Statistic"
        assert model.version == "V2.0"
        assert model.window == 100
        assert model.hot_threshold == 0.7
        assert model.cold_threshold == 0.3

    def test_get_info(self, model):
        """测试 get_info"""
        info = model.get_info()
        assert info["name"] == "Statistic"

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_format(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 predict() 输出格式"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        validate_prediction_output(prediction, lottery_type)

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_main_probs_sum(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 main_probs 概率和为1"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        if prediction["main_probs"]:
            assert abs(sum(prediction["main_probs"]) - 1.0) < 0.01

    def test_train_returns_float(self, model):
        """测试 train() 返回类型"""
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        loss = model.train(features, targets)
        assert isinstance(loss, float)

    def test_update_frequency(self, model):
        """测试频率更新"""
        model.update_frequency([1, 5, 12, 18, 25, 30], [[8]], lottery_type="ssq")
        # 更新后频率应该发生变化
        assert model._freq_cache["ssq"]["main_freq"][0] > 0
        assert model._freq_cache["ssq"]["bonus_freq"][7] > 0

    def test_get_hot_cold_analysis(self, model):
        """测试冷热号分析"""
        result = model.get_hot_cold_analysis("ssq")
        assert "hot_numbers" in result
        assert "cold_numbers" in result
        assert "missing_counts" in result
        assert isinstance(result["hot_numbers"], list)
        assert isinstance(result["cold_numbers"], list)

    def test_hot_cold_analysis_all_types(self, model):
        """测试所有彩票类型的冷热号分析"""
        for lottery_type in LOTTERY_TYPES:
            result = model.get_hot_cold_analysis(lottery_type)
            assert "hot_numbers" in result
            assert "cold_numbers" in result


# ============================================================
# Behavior 模型测试
# ============================================================

class TestBehaviorModel:
    """行为模型测试"""

    @pytest.fixture
    def model(self):
        return BehaviorModel()

    def test_model_initialization(self, model):
        """测试模型初始化"""
        assert model.name == "Behavior"
        assert model.version == "V1.0"

    def test_get_info(self, model):
        """测试 get_info"""
        info = model.get_info()
        assert info["name"] == "Behavior"

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_format(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 predict() 输出格式"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        validate_prediction_output(prediction, lottery_type)

    def test_predict_contains_patterns(self, model, sample_features_ssq):
        """测试 predict 包含行为模式数据"""
        prediction = model.predict(sample_features_ssq, lottery_type="ssq")
        assert "patterns" in prediction
        patterns = prediction["patterns"]
        assert "consecutive_bonus" in patterns
        assert "repeat_bonus" in patterns
        assert "skip_bonus" in patterns

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_predict_main_probs_sum(self, model, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试 main_probs 概率和为1"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
        if prediction["main_probs"]:
            assert abs(sum(prediction["main_probs"]) - 1.0) < 0.01

    def test_confidence_fixed(self, model, sample_features_ssq):
        """测试 Behavior 模型置信度固定为 0.6"""
        prediction = model.predict(sample_features_ssq, lottery_type="ssq")
        assert prediction["confidence"] == 0.6

    def test_train_returns_float(self, model):
        """测试 train() 返回类型"""
        features = np.random.randn(10, 50).astype(np.float32)
        targets = np.random.randn(10, 49).astype(np.float32)
        loss = model.train(features, targets)
        assert isinstance(loss, float)
        assert loss == 0.0  # Behavior 模型不真正训练


# ============================================================
# 模型输入输出形状一致性测试
# ============================================================

class TestModelShapeConsistency:
    """模型输入输出形状一致性测试"""

    MODELS = [
        XGBoostModel(),
        LSTMModel(),
        TransformerModel(),
        PPOModel(),
        StatisticModel(),
        BehaviorModel(),
    ]

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_all_models_main_probs_dimension(self, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试所有模型 main_probs 维度一致"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        expected_dim = get_expected_main_dim(lottery_type)

        for model in self.MODELS:
            prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
            assert len(prediction["main_probs"]) == expected_dim, \
                f"{model.name} main_probs dimension mismatch: expected {expected_dim}, got {len(prediction['main_probs'])}"

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_all_models_output_keys(self, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试所有模型输出包含相同的必需键"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}
        required_keys = {"main_probs", "bonus_probs", "red_probs", "blue_probs", "confidence", "model", "version"}

        for model in self.MODELS:
            prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
            assert required_keys.issubset(prediction.keys()), \
                f"{model.name} missing keys: {required_keys - set(prediction.keys())}"

    @pytest.mark.parametrize("lottery_type", LOTTERY_TYPES)
    def test_all_models_confidence_range(self, lottery_type, sample_features_ssq, sample_features_dlt, sample_features_k8):
        """测试所有模型置信度在 [0, 1] 范围内"""
        features_map = {"ssq": sample_features_ssq, "dlt": sample_features_dlt, "k8": sample_features_k8}

        for model in self.MODELS:
            prediction = model.predict(features_map[lottery_type], lottery_type=lottery_type)
            assert 0.0 <= prediction["confidence"] <= 1.0, \
                f"{model.name} confidence out of range: {prediction['confidence']}"

    def test_all_models_train_returns_float(self):
        """测试所有模型 train() 返回 float"""
        for model in self.MODELS:
            features = np.random.randn(10, 50).astype(np.float32)
            targets = np.random.randn(10, 49).astype(np.float32)
            loss = model.train(features, targets)
            assert isinstance(loss, float), f"{model.name} train did not return float: {type(loss)}"

    def test_all_models_have_required_methods(self):
        """测试所有模型都有必需的方法"""
        required_methods = ["predict", "train", "save", "load", "get_info", "update_credibility"]
        for model in self.MODELS:
            for method in required_methods:
                assert hasattr(model, method), f"{model.name} missing method: {method}"
                assert callable(getattr(model, method)), f"{model.name}.{method} is not callable"
