"""
预测端点测试
"""
import pytest
import pytest_asyncio
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_generate_prediction_normal(client: AsyncClient):
    """测试生成预测（正常请求）"""
    response = await client.post(
        "/api/v1/prediction/generate",
        json={"lottery_type": "ssq", "use_memory": True},
    )
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert "lottery_type" in data
    assert "candidates" in data
    assert "final_score" in data
    assert "model_contributions" in data
    assert "risk_assessment" in data
    assert "fusion_count" in data


@pytest.mark.asyncio
async def test_generate_prediction_dlt(client: AsyncClient):
    """测试生成大乐透预测"""
    response = await client.post(
        "/api/v1/prediction/generate",
        json={"lottery_type": "dlt", "use_memory": False},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "dlt"


@pytest.mark.asyncio
async def test_generate_prediction_k8(client: AsyncClient):
    """测试生成快乐8预测"""
    response = await client.post(
        "/api/v1/prediction/generate",
        json={"lottery_type": "k8", "use_memory": False},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "k8"


@pytest.mark.asyncio
async def test_generate_prediction_default(client: AsyncClient):
    """测试生成预测（默认参数）"""
    response = await client.post("/api/v1/prediction/generate")
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "ssq"


@pytest.mark.asyncio
async def test_generate_prediction_with_query_param(client: AsyncClient):
    """测试通过查询参数指定彩票类型"""
    response = await client.post(
        "/api/v1/prediction/generate?lottery_type=dlt",
        json={"use_memory": False},
    )
    assert response.status_code == 200


@pytest.mark.asyncio
async def test_get_latest_prediction(client: AsyncClient):
    """测试获取最新预测"""
    response = await client.get("/api/v1/prediction/latest")
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert "lottery_type" in data


@pytest.mark.asyncio
async def test_get_latest_prediction_no_data(client: AsyncClient):
    """测试无预测记录时获取最新预测"""
    response = await client.get("/api/v1/prediction/latest?lottery_type=dlt")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "no_prediction"


@pytest.mark.asyncio
async def test_get_prediction_history(client: AsyncClient):
    """测试预测历史"""
    response = await client.get("/api/v1/prediction/history")
    assert response.status_code == 200
    data = response.json()
    assert "lottery_type" in data
    assert "total" in data
    assert "predictions" in data


@pytest.mark.asyncio
async def test_get_prediction_history_with_limit(client: AsyncClient):
    """测试预测历史（限制条数）"""
    response = await client.get("/api/v1/prediction/history?limit=5&lottery_type=ssq")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data["predictions"], list)


@pytest.mark.asyncio
async def test_run_backtest(client: AsyncClient):
    """测试回测"""
    response = await client.post(
        "/api/v1/prediction/backtest",
        json={"lottery_type": "ssq", "periods": 30},
    )
    assert response.status_code == 200
    data = response.json()
    assert "lottery_type" in data
    assert "total_periods" in data
    assert data["total_periods"] == 30
    assert "avg_score" in data
    assert "accuracy_trend" in data
    assert len(data["accuracy_trend"]) == 30
    assert "model_performance" in data


@pytest.mark.asyncio
async def test_run_backtest_dlt(client: AsyncClient):
    """测试大乐透回测"""
    response = await client.post(
        "/api/v1/prediction/backtest",
        json={"lottery_type": "dlt", "periods": 10},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["total_periods"] == 10


@pytest.mark.asyncio
async def test_run_backtest_default(client: AsyncClient):
    """测试回测（默认参数）"""
    response = await client.post("/api/v1/prediction/backtest")
    assert response.status_code == 200
    data = response.json()
    assert data["total_periods"] == 50


@pytest.mark.asyncio
async def test_invalid_lottery_type_generate(client: AsyncClient):
    """测试无效彩票类型 - 预测生成"""
    response = await client.post(
        "/api/v1/prediction/generate",
        json={"lottery_type": "invalid_type", "use_memory": False},
    )
    # 无效类型会抛出异常，但可能返回 500
    assert response.status_code in [400, 422, 500]
