"""
仪表盘端点测试
"""
import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_get_overview(client: AsyncClient):
    """测试获取仪表盘概览"""
    response = await client.get("/api/v1/dashboard/overview")
    assert response.status_code == 200
    data = response.json()
    assert "lottery_type" in data
    assert "system_state" in data
    assert "final_score" in data
    assert "model_contributions" in data
    assert "candidates_count" in data
    assert "risk" in data
    assert "models" in data
    assert "fusion_count" in data
    assert "memory" in data


@pytest.mark.asyncio
async def test_get_overview_dlt(client: AsyncClient):
    """测试获取大乐透概览"""
    response = await client.get("/api/v1/dashboard/overview?lottery_type=dlt")
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "dlt"


@pytest.mark.asyncio
async def test_get_overview_k8(client: AsyncClient):
    """测试获取快乐8概览"""
    response = await client.get("/api/v1/dashboard/overview?lottery_type=k8")
    assert response.status_code == 200
    assert response.json()["lottery_type"] == "k8"


@pytest.mark.asyncio
async def test_get_stats(client: AsyncClient):
    """测试获取统计数据"""
    response = await client.get("/api/v1/dashboard/stats")
    assert response.status_code == 200
    data = response.json()
    assert "lottery_type" in data
    assert "total_predictions" in data
    assert "active_models" in data
    assert "memory_entries" in data
    assert "system_uptime" in data


@pytest.mark.asyncio
async def test_get_stats_with_type(client: AsyncClient):
    """测试获取指定类型统计数据"""
    response = await client.get("/api/v1/dashboard/stats?lottery_type=dlt")
    assert response.status_code == 200
    assert response.json()["lottery_type"] == "dlt"


@pytest.mark.asyncio
async def test_get_model_performance(client: AsyncClient):
    """测试获取模型表现图表数据"""
    response = await client.get("/api/v1/dashboard/charts/model-performance")
    assert response.status_code == 200
    data = response.json()
    assert "lottery_type" in data
    assert "labels" in data
    assert len(data["labels"]) == 30
    assert "datasets" in data
    assert len(data["datasets"]) == 4
    for dataset in data["datasets"]:
        assert "label" in dataset
        assert "data" in dataset
        assert "borderColor" in dataset
        assert len(dataset["data"]) == 30


@pytest.mark.asyncio
async def test_get_model_performance_dlt(client: AsyncClient):
    """测试获取大乐透模型表现"""
    response = await client.get(
        "/api/v1/dashboard/charts/model-performance?lottery_type=dlt"
    )
    assert response.status_code == 200
    assert response.json()["lottery_type"] == "dlt"


@pytest.mark.asyncio
async def test_get_hot_numbers(client: AsyncClient):
    """测试获取冷热号图表数据"""
    response = await client.get("/api/v1/dashboard/charts/hot-numbers")
    assert response.status_code == 200
    data = response.json()
    assert "lottery_type" in data
    assert "labels" in data
    assert "frequency" in data
    assert "hot_threshold" in data
    assert "cold_threshold" in data
    assert len(data["labels"]) == len(data["frequency"])


@pytest.mark.asyncio
async def test_get_hot_numbers_dlt(client: AsyncClient):
    """测试获取大乐透冷热号"""
    response = await client.get("/api/v1/dashboard/charts/hot-numbers?lottery_type=dlt")
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "dlt"
    assert len(data["labels"]) == 35  # DLT 主球区 35


@pytest.mark.asyncio
async def test_get_hot_numbers_k8(client: AsyncClient):
    """测试获取快乐8冷热号"""
    response = await client.get("/api/v1/dashboard/charts/hot-numbers?lottery_type=k8")
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "k8"
    assert len(data["labels"]) == 80  # K8 主球区 80
