"""
数据中心端点测试
"""
import pytest
import pytest_asyncio
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime

from app.database.models import LotteryDraw


@pytest_asyncio.fixture
async def seed_draws(test_session: AsyncSession):
    """向测试数据库填充开奖数据"""
    draws = [
        LotteryDraw(
            period="2024001",
            lottery_type="ssq",
            draw_date=datetime(2024, 1, 1),
            red1=1, red2=5, red3=12, red4=18, red5=25, red6=30,
            blue=8,
            red_sum=91, span=29, odd_count=2,
            zone1_count=2, zone2_count=2, zone3_count=2,
        ),
        LotteryDraw(
            period="2024002",
            lottery_type="ssq",
            draw_date=datetime(2024, 1, 3),
            red1=2, red2=8, red3=15, red4=20, red5=27, red6=33,
            blue=12,
            red_sum=105, span=31, odd_count=3,
            zone1_count=2, zone2_count=2, zone3_count=2,
        ),
        LotteryDraw(
            period="2024003",
            lottery_type="ssq",
            draw_date=datetime(2024, 1, 5),
            red1=3, red2=10, red3=17, red4=22, red5=28, red6=31,
            blue=5,
            red_sum=111, span=28, odd_count=3,
            zone1_count=1, zone2_count=3, zone3_count=2,
        ),
    ]
    test_session.add_all(draws)
    await test_session.commit()
    return draws


@pytest.mark.asyncio
async def test_get_draws_empty(client: AsyncClient, test_app):
    """测试获取开奖数据（空数据库）"""
    response = await client.get("/api/v1/data/draws")
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "ssq"
    assert "total" in data
    assert "draws" in data


@pytest.mark.asyncio
async def test_get_draws_with_data(client: AsyncClient, test_app, seed_draws):
    """测试获取开奖数据（有数据）"""
    response = await client.get("/api/v1/data/draws")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] == 3
    assert len(data["draws"]) == 3


@pytest.mark.asyncio
async def test_get_draws_with_limit(client: AsyncClient, test_app, seed_draws):
    """测试获取开奖数据（限制条数）"""
    response = await client.get("/api/v1/data/draws?limit=2")
    assert response.status_code == 200
    data = response.json()
    assert len(data["draws"]) <= 2


@pytest.mark.asyncio
async def test_get_draws_dlt(client: AsyncClient, test_app, seed_draws):
    """测试获取大乐透开奖数据（空）"""
    response = await client.get("/api/v1/data/draws?lottery_type=dlt")
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "dlt"
    assert data["total"] == 0


@pytest.mark.asyncio
async def test_get_draw_by_period(client: AsyncClient, test_app, seed_draws):
    """测试按期号查询"""
    response = await client.get("/api/v1/data/draws/2024001")
    assert response.status_code == 200
    data = response.json()
    assert data["period"] == "2024001"
    assert data["lottery_type"] == "ssq"
    assert "main_balls" in data
    assert "bonus_balls" in data
    assert "reds" in data
    assert "blue" in data


@pytest.mark.asyncio
async def test_get_draw_by_period_not_found(client: AsyncClient, test_app, seed_draws):
    """测试按期号查询（不存在）"""
    response = await client.get("/api/v1/data/draws/9999999")
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_get_draw_by_period_wrong_type(client: AsyncClient, test_app, seed_draws):
    """测试按期号查询（类型不匹配）"""
    response = await client.get("/api/v1/data/draws/2024001?lottery_type=dlt")
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_get_data_stats(client: AsyncClient, test_app, seed_draws):
    """测试获取数据统计"""
    response = await client.get("/api/v1/data/stats")
    assert response.status_code == 200
    data = response.json()
    assert data["lottery_type"] == "ssq"
    assert data["total_draws"] == 3
    assert data["latest_period"] == "2024003"
    assert data["latest_date"] is not None


@pytest.mark.asyncio
async def test_get_data_stats_empty_type(client: AsyncClient, test_app, seed_draws):
    """测试获取不存在的类型统计"""
    response = await client.get("/api/v1/data/stats?lottery_type=dlt")
    assert response.status_code == 200
    data = response.json()
    assert data["total_draws"] == 0


@pytest.mark.asyncio
async def test_get_experiments(client: AsyncClient, test_app):
    """测试获取实验记录"""
    response = await client.get("/api/v1/data/experiments")
    assert response.status_code == 200
    data = response.json()
    assert "lottery_type" in data
    assert "total" in data
    assert "experiments" in data
