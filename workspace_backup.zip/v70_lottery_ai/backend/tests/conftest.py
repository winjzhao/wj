"""
测试配置文件 - fixtures 和测试基础设施
"""
import pytest
import pytest_asyncio
import numpy as np
import sys
from pathlib import Path
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport

from app.database.models import Base
from app.database.db import get_db


# ============================================================
# 测试数据库
# ============================================================

TEST_DATABASE_URL = "sqlite+aiosqlite:///./data/test_v70.db"


@pytest_asyncio.fixture(scope="function")
async def test_engine():
    """创建测试数据库引擎"""
    engine = create_async_engine(TEST_DATABASE_URL, echo=False, future=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture(scope="function")
async def test_session(test_engine):
    """创建测试数据库会话"""
    AsyncSessionLocal = async_sessionmaker(
        test_engine, class_=AsyncSession, expire_on_commit=False
    )
    async with AsyncSessionLocal() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture(scope="function")
async def test_app(test_engine):
    """创建测试用 FastAPI 应用"""
    from app.main import app

    # 覆盖数据库依赖
    AsyncSessionLocal = async_sessionmaker(
        test_engine, class_=AsyncSession, expire_on_commit=False
    )

    async def override_get_db():
        async with AsyncSessionLocal() as session:
            try:
                yield session
            finally:
                await session.close()

    app.dependency_overrides[get_db] = override_get_db
    yield app
    app.dependency_overrides.clear()


@pytest_asyncio.fixture(scope="function")
async def client(test_app):
    """FastAPI TestClient fixture"""
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest.fixture(autouse=True)
def reset_orchestrator():
    """每个测试前重置 orchestrator 状态，确保测试隔离"""
    from app.orchestrator.workflow import orchestrator
    orchestrator.current_context = None
    yield


# ============================================================
# 模拟数据 fixtures
# ============================================================

@pytest.fixture
def sample_features_ssq():
    """SSQ 模拟特征向量"""
    return np.random.randn(120).astype(np.float32)


@pytest.fixture
def sample_features_dlt():
    """DLT 模拟特征向量"""
    return np.random.randn(120).astype(np.float32)


@pytest.fixture
def sample_features_k8():
    """K8 模拟特征向量"""
    return np.random.randn(200).astype(np.float32)


@pytest.fixture
def sample_draws():
    """模拟开奖数据列表"""
    draws = []
    for i in range(50):
        draws.append({
            "period": f"2024{i+1:03d}",
            "draw_date": datetime(2024, 1, 1 + i),
            "lottery_type": "ssq",
            "reds": sorted(np.random.choice(range(1, 34), 6, replace=False).tolist()),
            "blue": int(np.random.choice(range(1, 17), 1)[0]),
            "red_sum": 0,
            "span": 0,
            "odd_count": 0,
            "zone1_count": 0,
            "zone2_count": 0,
            "zone3_count": 0,
        })
    return draws


@pytest.fixture
def mock_prediction():
    """模拟预测结果"""
    return {
        "main_probs": np.random.dirichlet(np.ones(33)).tolist(),
        "bonus_probs": np.random.dirichlet(np.ones(16)).tolist(),
        "red_probs": np.random.dirichlet(np.ones(33)).tolist(),
        "blue_probs": np.random.dirichlet(np.ones(16)).tolist(),
        "confidence": 0.75,
        "model": "TestModel",
        "version": "V1.0",
    }


@pytest.fixture
def mock_draw_data():
    """模拟开奖数据（用于数据库填充）"""
    return {
        "period": "2024001",
        "draw_date": datetime(2024, 1, 1),
        "lottery_type": "ssq",
        "red1": 1, "red2": 5, "red3": 12, "red4": 18, "red5": 25, "red6": 30,
        "blue": 8,
        "red_sum": 91, "span": 29, "odd_count": 2,
        "zone1_count": 2, "zone2_count": 2, "zone3_count": 2,
    }
