"""
模型管理端点测试
"""
import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_list_models(client: AsyncClient):
    """测试模型列表"""
    response = await client.get("/api/v1/models/list")
    assert response.status_code == 200
    data = response.json()
    assert "models" in data
    assert isinstance(data["models"], list)
    # 应该有 6 个模型
    model_names = [m["name"] for m in data["models"]]
    assert len(model_names) >= 1
    for model in data["models"]:
        assert "name" in model
        assert "version" in model
        assert "credibility_score" in model


@pytest.mark.asyncio
async def test_get_model_detail_valid(client: AsyncClient):
    """测试模型详情（有效模型名）"""
    for model_name in ["XGBoost", "LSTM", "Transformer", "PPO", "Statistic", "Behavior"]:
        response = await client.get(f"/api/v1/models/{model_name}")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == model_name
        assert "version" in data
        assert "credibility_score" in data
        assert "is_trained" in data


@pytest.mark.asyncio
async def test_get_model_detail_not_found(client: AsyncClient):
    """测试模型详情（不存在的模型）"""
    response = await client.get("/api/v1/models/NonExistentModel")
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_train_model_valid(client: AsyncClient):
    """测试训练指定模型"""
    response = await client.post("/api/v1/models/XGBoost/train")
    assert response.status_code == 200
    data = response.json()
    assert data["model"] == "XGBoost"
    assert "loss" in data
    assert "credibility" in data
    assert data["status"] == "trained"


@pytest.mark.asyncio
async def test_train_model_not_found(client: AsyncClient):
    """测试训练不存在的模型"""
    response = await client.post("/api/v1/models/InvalidModel/train")
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_train_all_models(client: AsyncClient):
    """测试训练所有模型"""
    response = await client.post("/api/v1/models/train-all")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "completed"
    assert "results" in data
    assert len(data["results"]) == 6


@pytest.mark.asyncio
async def test_update_weights(client: AsyncClient):
    """测试更新权重"""
    response = await client.post(
        "/api/v1/models/weights",
        json={
            "xgboost": 0.25,
            "lstm": 0.15,
            "transformer": 0.20,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["message"] == "权重已更新"
    assert "weights" in data


@pytest.mark.asyncio
async def test_update_weights_partial(client: AsyncClient):
    """测试部分更新权重"""
    response = await client.post(
        "/api/v1/models/weights",
        json={"ppo": 0.15},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["weights"]["PPO"] == 0.15


@pytest.mark.asyncio
async def test_get_current_weights(client: AsyncClient):
    """测试获取当前权重"""
    response = await client.get("/api/v1/models/weights/current")
    assert response.status_code == 200
    data = response.json()
    assert "weights" in data
    assert isinstance(data["weights"], dict)


@pytest.mark.asyncio
async def test_update_and_verify_weights(client: AsyncClient):
    """测试更新权重后验证"""
    # 先更新
    update_resp = await client.post(
        "/api/v1/models/weights",
        json={"statistic": 0.30, "behavior": 0.20},
    )
    assert update_resp.status_code == 200

    # 再获取验证
    get_resp = await client.get("/api/v1/models/weights/current")
    assert get_resp.status_code == 200
    assert get_resp.json()["weights"]["Statistic"] == 0.30
    assert get_resp.json()["weights"]["Behavior"] == 0.20


@pytest.mark.asyncio
async def test_train_lstm_model(client: AsyncClient):
    """测试训练LSTM模型"""
    response = await client.post("/api/v1/models/LSTM/train")
    assert response.status_code == 200
    data = response.json()
    assert data["model"] == "LSTM"
    assert "loss" in data


@pytest.mark.asyncio
async def test_train_transformer_model(client: AsyncClient):
    """测试训练Transformer模型"""
    response = await client.post("/api/v1/models/Transformer/train")
    assert response.status_code == 200
    data = response.json()
    assert data["model"] == "Transformer"
