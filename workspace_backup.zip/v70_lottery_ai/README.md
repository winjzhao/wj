# V70 彩票AI工作台

基于多模型融合的彩票AI分析平台，采用 **FastAPI + Flutter** 技术栈，集成 6 个 AI 模型协同预测。

> 详细文档：
> - [系统架构文档](docs/architecture.md)
> - [AI模型说明](docs/models.md)
> - [API 文档](http://localhost:8000/docs) (启动后端后访问)

## 系统架构

```
+-------------------------------------------------------+
|                     Flutter APP                         |
|          (仪表盘 / 预测中心 / 模型管理 / 系统中心)        |
+---------------------------+-----------------------------+
                            | REST API (HTTP/WebSocket)
+---------------------------v-----------------------------+
|                   FastAPI 后端服务                       |
|                                                        |
|  +------------+ +------------+ +--------------------+  |
|  |  数据中心   | |  AI核心    | |   融合决策引擎       |  |
|  |            | |            | |                    |  |
|  | collector  | | Transformer| | Fusion Engine      |  |
|  | parser     | | PPO        | | Bayesian权重       |  |
|  | importer   | | Statistic  | | 候选方案生成        |  |
|  | cleaner    | | Behavior   | | 风险控制            |  |
|  +------------+ +------------+ +--------------------+  |
|                                                        |
|  +------------+ +------------+ +--------------------+  |
|  |  记忆中心   | |  调度引擎   | |   多Agent协调       |  |
|  |            | |            | |                    |  |
|  | 知识记忆   | |Orchestrator| | TrendAnalyzer      |  |
|  | 经验检索   | | Workflow   | | PatternFinder      |  |
|  | 向量存储   | | 定时任务   | | RiskManager        |  |
|  +------------+ +------------+ +--------------------+  |
|                                                        |
|                SQLite 数据库                             |
+-------------------------------------------------------+
```

## 技术栈

| 层级 | 技术 |
|------|------|
| 后端框架 | Python 3.11, FastAPI |
| AI/ML | NumPy, SciPy, scikit-learn, PyTorch, XGBoost |
| 数据库 | SQLite (aiosqlite), SQLAlchemy ORM |
| 任务调度 | APScheduler |
| 前端框架 | Flutter 3.x, Provider 状态管理 |
| 图表 | fl_chart |
| 部署 | Docker, Docker Compose, Nginx |
| 测试 | pytest, pytest-asyncio, flutter_test |

## 快速开始

### 环境要求

- Python 3.10+
- Flutter 3.x (仅前端)
- Docker (可选，用于容器化部署)

### 后端启动

```bash
# 1. 进入后端目录
cd backend

# 2. 创建虚拟环境（推荐）
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

# 3. 安装依赖
pip install -r requirements.txt

# 4. 启动服务
python run.py

# 服务运行在 http://localhost:8000
# API文档: http://localhost:8000/docs
# 健康检查: http://localhost:8000/health
```

### Flutter APP

```bash
# 1. 进入 Flutter 目录
cd flutter_app

# 2. 安装依赖
flutter pub get

# 3. 运行
flutter run

# 4. 运行测试
flutter test
```

### Docker 部署

```bash
# 在项目根目录下执行

# 构建并启动所有服务
docker-compose up -d

# 查看后端日志
docker-compose logs -f backend

# 查看前端日志
docker-compose logs -f frontend

# 停止所有服务
docker-compose down

# 重新构建并启动
docker-compose up -d --build
```

部署后访问：
- 前端页面: http://localhost
- 后端 API: http://localhost:8000
- API 文档: http://localhost:8000/docs

## 项目结构

```
v70_lottery_ai/
├── backend/                    # FastAPI 后端
│   ├── app/
│   │   ├── main.py             # 应用入口
│   │   ├── api/                # API 路由层
│   │   ├── ai_core/            # AI 核心（模型、Agent）
│   │   │   ├── models/         # 6个AI模型实现
│   │   │   └── agents/         # 多Agent协调
│   │   ├── core/               # 核心工具（配置、日志、告警）
│   │   ├── data_center/        # 数据中心（采集、解析、清洗）
│   │   ├── database/           # 数据库 ORM 模型
│   │   ├── fusion_engine/      # 融合决策引擎
│   │   ├── memory_center/      # 知识记忆库
│   │   ├── orchestrator/       # 统一调度引擎
│   │   ├── scheduler/          # 定时任务
│   │   ├── self_learning/      # 自学习进化
│   │   └── training/           # 模型训练
│   ├── requirements.txt        # Python 依赖
│   └── run.py                  # 启动脚本
├── flutter_app/                # Flutter 前端
│   ├── lib/
│   │   ├── main.dart           # 应用入口
│   │   ├── api/                # API 客户端
│   │   ├── pages/              # 页面（仪表盘、预测、模型、数据、系统）
│   │   ├── providers/          # 状态管理
│   │   ├── services/           # 服务层
│   │   └── theme/              # 主题配置
│   ├── test/                   # 测试文件
│   ├── Dockerfile              # Flutter Web 构建镜像
│   └── nginx.conf              # Nginx 配置
├── data/                       # 数据存储目录
├── logs/                       # 日志目录
├── docs/                       # 项目文档
├── Dockerfile                  # 后端 Docker 镜像
├── docker-compose.yml          # Docker Compose 编排
├── .dockerignore               # Docker 忽略文件
└── README.md                   # 项目说明
```

## 核心模块

### 1. 数据中心 (data_center)
- 数据采集 (collector) — 从外部API获取开奖数据
- 数据解析 (parser) — 多格式数据解析
- 数据校验 (validator) — 数据完整性校验
- 历史导入 (importer) — 批量历史数据导入
- 数据清洗 (cleaner) — 数据规范化

### 2. AI核心 (ai_core)
- **特征工程**: 特征构建 + 编码器
- **Transformer模型**: 自注意力时序预测
- **PPO模型**: 强化学习策略优化
- **统计模型**: 频率/冷热/遗漏分析
- **行为模型**: 连号/重号/跳号模式
- **多Agent协调**: TrendAnalyzer, PatternFinder, RiskManager, Strategist

### 3. 融合决策引擎 (fusion_engine)
- 多模型加权融合
- 贝叶斯权重动态调整
- 候选方案生成与排序
- 风险控制

### 4. 知识记忆库 (memory_center)
- 预测记录存储
- 模式记忆
- 模型经验积累
- 相似走势检索

### 5. 统一调度引擎 (orchestrator)
- 完整预测工作流
- 状态机管理
- 流程编排

### 6. 定时任务 (scheduler)
- 每日数据更新
- 每日AI预测
- 每周模型训练
- 系统健康检查

### 7. 自学习进化 (self_learning)
- 模型权重自动进化
- 表现监控与告警
- 模型退役/重激活

## API 接口

| 模块 | 端点 | 方法 | 说明 |
|------|------|------|------|
| 预测中心 | `/api/v1/prediction/generate` | POST | 生成AI预测 |
| 预测中心 | `/api/v1/prediction/latest` | GET | 获取最新预测 |
| 预测中心 | `/api/v1/prediction/history` | GET | 预测历史 |
| 预测中心 | `/api/v1/prediction/backtest` | POST | 运行回测 |
| 仪表盘 | `/api/v1/dashboard/overview` | GET | 系统概览 |
| 仪表盘 | `/api/v1/dashboard/stats` | GET | 统计数据 |
| 仪表盘 | `/api/v1/dashboard/charts/model-performance` | GET | 模型表现图表 |
| 仪表盘 | `/api/v1/dashboard/charts/hot-numbers` | GET | 冷热号分析 |
| 模型管理 | `/api/v1/models/list` | GET | 模型列表 |
| 模型管理 | `/api/v1/models/{name}` | GET | 模型详情 |
| 模型管理 | `/api/v1/models/{name}/train` | POST | 训练模型 |
| 模型管理 | `/api/v1/models/train-all` | POST | 训练所有模型 |
| 模型管理 | `/api/v1/models/weights` | POST | 更新权重 |
| 模型管理 | `/api/v1/models/weights/current` | GET | 获取当前权重 |
| 系统中心 | `/api/v1/system/status` | GET | 系统状态 |
| 系统中心 | `/api/v1/system/logs` | GET | 最近日志 |
| 系统中心 | `/api/v1/system/config` | GET | 系统配置 |
| 数据中心 | `/api/v1/data/draws` | GET | 开奖数据列表 |
| 数据中心 | `/api/v1/data/draws/{period}` | GET | 按期号查询 |
| 数据中心 | `/api/v1/data/stats` | GET | 数据统计 |
| 数据中心 | `/api/v1/data/import-mock` | POST | 导入模拟数据 |
| 数据中心 | `/api/v1/data/experiments` | GET | 实验记录 |
| 根路径 | `/` | GET | 应用信息 |
| 健康检查 | `/health` | GET | 健康状态 |

## 模型融合策略

```
最终概率 = Σ(模型概率 × 模型可信度 × 基础权重)

6模型融合:
- XGBoost
- LSTM
- Transformer
- PPO
- Statistic
- Behavior

权重根据历史表现动态调整，表现越稳定可信度越高。
```

## 候选方案生成流程

1. 基于融合概率分布采样 10,000 组候选
2. 结构筛选（和值/跨度/奇偶/三区）
3. 低撞过滤（去重）
4. 多维评分（概率+结构+历史+稳定性）
5. 保留 TOP 方案

## 运行测试

```bash
# 后端测试
cd backend
pytest
pytest --cov=app --cov-report=html

# Flutter 测试
cd flutter_app
flutter test
```

## 免责声明

本项目仅用于技术学习和研究目的。彩票开奖是随机事件，AI模型无法保证预测准确性。请理性对待，切勿沉迷。
