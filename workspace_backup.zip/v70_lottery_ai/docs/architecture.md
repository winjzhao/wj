# V70 彩票AI工作台 - 系统架构文档

## 1. 概述

V70 彩票AI工作台是一个基于多模型融合的彩票AI分析平台，采用 **FastAPI + Flutter** 技术栈，支持双色球(SSQ)、大乐透(DLT)、快乐8(K8)三种彩票类型的AI预测分析。

## 2. 系统架构图

```
┌──────────────────────────────────────────────────────────────────┐
│                        Flutter 移动端                             │
│   仪表盘 | 预测中心 | 模型管理 | 系统中心 | 数据中心               │
└───────────────────────────┬──────────────────────────────────────┘
                            │ HTTP REST API (JSON)
┌───────────────────────────▼──────────────────────────────────────┐
│                    FastAPI 后端服务 (port 8000)                    │
│                                                                   │
│  ┌─────────────────┐  ┌──────────────────┐  ┌─────────────────┐ │
│  │   API 层         │  │   编排层          │  │   调度层        │ │
│  │                  │  │                   │  │                 │ │
│  │ /api/v1/         │  │  Orchestrator     │  │  APScheduler    │ │
│  │  ├─ prediction   │──│  WorkflowContext  │──│  每日数据更新   │ │
│  │  ├─ models       │  │  State Machine    │  │  每日AI预测     │ │
│  │  ├─ dashboard    │  │                   │  │  每周模型训练   │ │
│  │  ├─ data         │  └────────┬──────────┘  │  健康检查       │ │
│  │  └─ system       │           │             └─────────────────┘ │
│  └─────────────────┘           │                                   │
│                                 │                                   │
│  ┌─────────────────────────────▼───────────────────────────────┐ │
│  │                       核心处理层                              │ │
│  │                                                              │ │
│  │  ┌───────────┐  ┌────────────┐  ┌──────────────────────┐   │ │
│  │  │ 数据中心   │  │  AI核心     │  │  融合决策引擎         │   │ │
│  │  │           │  │            │  │                      │   │ │
│  │  │ collector │  │ Transformer│  │  FusionEngine        │   │ │
│  │  │ parser    │  │ LSTM       │  │  - 贝叶斯权重调整    │   │ │
│  │  │ validator │  │ XGBoost    │  │  - 候选方案生成      │   │ │
│  │  │ importer  │  │ PPO        │  │  - 风险控制          │   │ │
│  │  │ cleaner   │  │ Statistic  │  │  - 评分排序          │   │ │
│  │  │           │  │ Behavior   │  │                      │   │ │
│  │  └───────────┘  └────────────┘  └──────────────────────┘   │ │
│  │                                                              │ │
│  │  ┌───────────┐  ┌──────────────────────────────────────┐   │ │
│  │  │ 记忆中心   │  │  配置 & 工具层                        │   │ │
│  │  │           │  │                                      │   │ │
│  │  │ 知识记忆  │  │  settings.py  - Pydantic Settings     │   │ │
│  │  │ 经验检索  │  │  logging.py   - Loguru 日志           │   │ │
│  │  │ 预测存储  │  │  lottery_schema.py - 彩票类型配置     │   │ │
│  │  └───────────┘  └──────────────────────────────────────┘   │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                 │                                  │
│                    ┌────────────▼────────────┐                     │
│                    │    SQLite 数据库         │                     │
│                    │    (aiosqlite 异步)      │                     │
│                    │                         │                     │
│                    │  - lottery_draws        │                     │
│                    │  - predictions          │                     │
│                    │  - features             │                     │
│                    │  - model_checkpoints    │                     │
│                    │  - experiment_records   │                     │
│                    │  - system_logs          │                     │
│                    │  - memory_records       │                     │
│                    └─────────────────────────┘                     │
└────────────────────────────────────────────────────────────────────┘
```

## 3. 数据流

### 3.1 预测流程

```
数据采集 ──→ 数据解析 ──→ 特征生成 ──→ 多模型预测 ──→ 融合决策 ──→ 候选方案
    │            │            │              │              │            │
    │            │            │     ┌────────┼────────┐     │            │
    │            │            │     │        │        │     │            │
    ▼            ▼            ▼     ▼        ▼        ▼     ▼            ▼
 Collector   Parser    FeatureBuilder  XGBoost  LSTM    Transformer  FusionEngine
                                     PPO     Statistic Behavior
                                           │
                                           ▼
                                    经验回放/反馈学习 ←── 开奖验证
```

### 3.2 API 请求流程

```
Client Request
    │
    ▼
FastAPI Router (/api/v1/)
    │
    ├─→ prediction/*  ──→ orchestrator.run_full_pipeline()
    ├─→ models/*      ──→ orchestrator.models[].get_info()
    ├─→ dashboard/*   ──→ orchestrator.get_status()
    ├─→ data/*        ──→ DB query (AsyncSession)
    └─→ system/*      ──→ psutil + orchestrator.get_status()
```

## 4. 模块依赖关系

```
main.py
  ├── config/settings.py       (应用配置)
  ├── config/logging.py        (日志配置)
  ├── database/db.py           (数据库连接, init_db, get_db)
  ├── database/models.py       (ORM 模型定义)
  ├── api/routes.py            (API 路由汇总)
  │   ├── api/endpoints/prediction.py
  │   ├── api/endpoints/models.py
  │   ├── api/endpoints/dashboard.py
  │   ├── api/endpoints/data.py
  │   └── api/endpoints/system.py
  ├── orchestrator/workflow.py (编排器)
  │   ├── data_center/*
  │   ├── ai_core/*
  │   │   ├── features/*
  │   │   └── models/*
  │   ├── fusion_engine/*
  │   ├── memory_center/*
  │   └── core/lottery_schema.py
  └── scheduler/scheduler.py   (定时任务)
```

## 5. 数据库表设计

| 表名 | 用途 | 关键字段 |
|------|------|---------|
| `lottery_draws` | 开奖数据 | period, lottery_type, red1-6, blue, main_ball1-20 |
| `features` | 特征数据 | period, feature_type, feature_data(JSON) |
| `predictions` | 预测记录 | period, model_name, main_balls, score, confidence |
| `model_checkpoints` | 模型检查点 | model_name, version, file_path, accuracy, loss |
| `experiment_records` | 实验记录 | experiment_name, model_name, match_count, score |
| `system_logs` | 系统日志 | level, module, message, data(JSON) |
| `memory_records` | 知识记忆 | memory_type, content, embedding, period, score |

## 6. 技术栈

| 层级 | 技术 | 说明 |
|------|------|------|
| API 框架 | FastAPI 0.104 | 异步 Web 框架，自动 OpenAPI 文档 |
| ORM | SQLAlchemy 2.0 | 异步数据库操作 |
| 数据库 | SQLite (aiosqlite) | 轻量级嵌入式数据库 |
| 配置 | Pydantic Settings | 类型安全的配置管理 |
| 日志 | Loguru | 结构化日志 |
| ML/AI | PyTorch, XGBoost, NumPy, SciPy | 深度学习 + 机器学习 |
| 调度 | APScheduler | 定时任务调度 |
| 前端 | Flutter 3.x | 跨平台移动应用 |
| 迁移 | Alembic | 数据库版本管理 |
| 测试 | pytest + pytest-asyncio | 异步测试框架 |

## 7. 部署架构

```
┌─────────────────────────────────────────────┐
│                   Docker Compose              │
│                                               │
│  ┌───────────────┐  ┌──────────────────────┐ │
│  │  backend      │  │  flutter_app (可选)   │ │
│  │  (FastAPI)    │  │                      │ │
│  │  port: 8000   │  │  port: 8080          │ │
│  └───────────────┘  └──────────────────────┘ │
│                                               │
│  Volumes:                                     │
│  - ./backend/data:/app/data  (数据库)         │
│  - ./backend/logs:/app/logs  (日志)           │
└───────────────────────────────────────────────┘
```
