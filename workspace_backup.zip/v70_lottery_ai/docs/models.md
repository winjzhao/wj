# V70 彩票AI工作台 - AI模型说明

## 概述

V70 采用 **6 模型融合** 策略进行彩票号码预测。每个模型从不同角度分析历史数据，生成号码概率分布，最终由融合引擎加权合并。

```
最终概率 = Σ(模型概率 × 模型可信度 × 基础权重)
```

## 模型总览

| 模型 | 类型 | 版本 | 输入 | 输出 | 基础权重 |
|------|------|------|------|------|---------|
| XGBoost | 梯度提升树 | V1.0 | 特征向量 (N,) | main_probs + bonus_probs | 0.18 |
| LSTM | 长短期记忆网络 | V1.0 | 特征向量 (序列) | main_probs + bonus_probs | 0.16 |
| Transformer | 自注意力网络 | V2.0 | 特征向量 (序列) | main_probs + bonus_probs | 0.20 |
| PPO | 强化学习策略 | V1.0 | 特征向量 (状态) | main_probs + bonus_probs + state_value | 0.12 |
| Statistic | 统计频率分析 | V2.0 | 频率特征 | main_probs + bonus_probs | 0.18 |
| Behavior | 行为模式识别 | V1.0 | 频率特征 | main_probs + bonus_probs + patterns | 0.16 |

## 通用接口

所有模型继承自 `BaseAIModel`，实现统一接口：

### predict(features, lottery_type) -> dict

```python
{
    "main_probs": [float, ...],    # 主球区概率分布 (归一化)
    "bonus_probs": [float, ...],   # 附加球区概率分布 (归一化)
    "red_probs": [float, ...],     # 红球概率 (向后兼容SSQ)
    "blue_probs": [float, ...],    # 蓝球概率 (向后兼容SSQ)
    "confidence": float,           # 置信度 [0, 1]
    "model": str,                  # 模型名称
    "version": str,                # 模型版本
}
```

### train(features, targets) -> float

训练模型，返回损失值(loss)。

### save(path) / load(path)

模型持久化（保存/加载）。

---

## 1. XGBoost 模型

### 原理
XGBoost (eXtreme Gradient Boosting) 是一种梯度提升树模型，将每个号码视为独立的二分类/回归问题。通过多棵树迭代拟合残差，擅长捕捉非线性特征交互。

### 参数
| 参数 | 默认值 | 说明 |
|------|--------|------|
| n_estimators | 100 | 树的数量 |
| max_depth | 6 | 树的最大深度 |
| learning_rate | 0.1 | 学习率 |
| subsample | 0.8 | 样本采样率 |
| colsample_bytree | 0.8 | 特征采样率 |
| reg_alpha | 0.1 | L1 正则化 |
| reg_lambda | 1.0 | L2 正则化 |

### 预测流程
1. 特征向量展平 → 确保维度 >= 总号码数
2. 若已训练：XGBoost 回归预测 → 各号码原始分数
3. 若未训练：基于特征的模拟预测
4. 拆分主球区/附加球区 → Softmax 归一化
5. 计算置信度 (基于概率标准差 + 训练奖励)

### 特征重要性
训练后可通过 `get_feature_importance()` 获取 Top-10 特征重要性排名。

---

## 2. LSTM 模型

### 原理
LSTM (Long Short-Term Memory) 是循环神经网络的变体，通过门控机制（遗忘门、输入门、输出门）捕捉历史开奖序列中的长程时序依赖关系。

### 参数
| 参数 | 默认值 | 说明 |
|------|--------|------|
| hidden_dim | 128 | 隐藏层维度 |
| num_layers | 2 | LSTM 层数 |
| seq_len | 30 | 序列长度（回溯期数） |
| dropout | 0.2 | Dropout 比率 |
| bidirectional | True | 双向 LSTM |

### 网络结构
```
输入 (seq_len, feature_dim)
    ↓
双向 LSTM (hidden_dim × num_layers)
    ↓
last_hidden × 0.7 + mean_pool × 0.3
    ↓
Linear(hidden_dim*2, hidden_dim) → ReLU → Dropout
    ↓
Linear(hidden_dim, output_dim) → 输出概率
```

### 预测流程
1. 特征向量重组为时序序列 (seq_len, feature_dim)
2. 若 PyTorch 可用且已训练：前向传播预测
3. 否则：滑动窗口模拟预测（模拟LSTM门控机制）
4. 拆分 → Softmax → 基于熵计算置信度

---

## 3. Transformer 模型

### 原理
使用多头自注意力机制 (Multi-Head Self-Attention) 学习号码序列中的全局依赖关系。相比 LSTM，Transformer 可以直接建模任意位置之间的关联。

### 参数
| 参数 | 默认值 | 说明 |
|------|--------|------|
| d_model | 64 | 模型维度 |
| n_heads | 4 | 注意力头数 |
| n_layers | 2 | Transformer 层数 |

### 注意力计算 (简化版)
```
Q = X @ W_attn
K = X @ W_attn
V = X @ W_attn
Attention(Q, K, V) = softmax(QK^T / √d_k) V
```

### 预测流程
1. 特征向量 → 截取/填充到 d_model 维度
2. 经过 n_layers 层自注意力 + Tanh 激活
3. 全连接层输出 (d_model → total_dim)
4. 拆分 → Softmax → 置信度计算

---

## 4. PPO 模型

### 原理
PPO (Proximal Policy Optimization) 是强化学习算法，将号码选择视为序列决策问题。Actor 网络生成号码概率分布，Critic 网络估计状态价值，通过策略梯度优化。

### 参数
| 参数 | 默认值 | 说明 |
|------|--------|------|
| lr | 0.001 | 学习率 |
| gamma | 0.99 | 折扣因子 |
| epsilon | 0.2 | PPO 裁剪参数 |

### Actor-Critic 架构
```
状态 (100维) ──→ Actor 网络 ──→ 号码概率分布
     │
     └────────→ Critic 网络 ──→ 状态价值 V(s)
```

### 奖励函数
```python
hits = len(set(prediction) & set(actual))
if hits == 0:     reward = -0.1
elif hits <= 2:   reward = 0.1 × hits
elif hits <= 4:   reward = 0.5 × hits
else:             reward = 2.0 × hits
```

### 预测流程
1. 特征编码为状态向量 (100维)
2. Actor 网络输出 logits → 带温度系数的 Softmax
3. Critic 网络估计状态价值 → 置信度
4. 返回概率分布 + state_value

---

## 5. Statistic 模型

### 原理
基于历史开奖数据的统计频率分析，综合以下因素：
- **频率分析**：各号码历史出现频率
- **冷热号**：基于频率中位数的冷热判断
- **遗漏分析**：各号码连续未出现的期数
- **遗漏加权**：遗漏越久，概率微调上升

### 参数
| 参数 | 默认值 | 说明 |
|------|--------|------|
| window | 100 | 统计窗口大小 |
| hot_threshold | 0.7 | 热号阈值 |
| cold_threshold | 0.3 | 冷号阈值 |

### 概率计算公式
```
P(i) = (freq(i) / Σfreq) × (1 + 0.1 × missing_weight(i))
其中 missing_weight(i) = missing_count(i) / max_missing
```

### 辅助功能
- `update_frequency()`: 更新频率统计
- `get_hot_cold_analysis()`: 返回热号、冷号、遗漏列表

---

## 6. Behavior 模型

### 原理
分析历史号码的"行为模式"，识别三种规律：
- **连号模式**：相邻号码对同时出现的倾向
- **重号模式**：高频号码重复出现的概率
- **跳号模式**：间隔号码（间隔1/2/3）的关联出现规律

### 预测流程
1. 从特征提取频率分布
2. 连号分析：相邻号码对加权
3. 重号分析：高频号码加分
4. 跳号分析：间隔号码关联加分
5. 综合：`main_probs = freq × (1 + 0.1×consecutive + 0.05×repeat + 0.05×skip)`
6. 置信度固定为 0.6

### 输出特点
除标准输出外，额外返回 `patterns` 字段：
```python
{
    "patterns": {
        "consecutive_bonus": [...],  # 连号加权
        "repeat_bonus": [...],       # 重号加权
        "skip_bonus": [...],         # 跳号加权
    }
}
```

---

## 彩票类型维度映射

| 类型 | 主球区维度 | 附加球区维度 | 总维度 |
|------|-----------|-------------|--------|
| SSQ (双色球) | 33 | 16 | 49 |
| DLT (大乐透) | 35 | 12 | 47 |
| K8 (快乐8) | 80 | 0 | 80 |
