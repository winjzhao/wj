import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_app/providers/model_provider.dart';
import 'package:flutter_app/providers/lottery_provider.dart';
import '../helpers/mock_data.dart';

void main() {
  group('ModelProvider', () {
    late ModelProvider provider;

    setUp(() {
      provider = ModelProvider();
    });

    tearDown(() {
      provider.dispose();
    });

    group('模型列表初始化', () {
      test('初始状态应为空', () {
        expect(provider.models, isEmpty);
        expect(provider.weights, isEmpty);
        expect(provider.isTraining, false);
        expect(provider.error, null);
      });

      test('init() 应加载模型列表', () async {
        await provider.init();

        expect(provider.models, isNotEmpty);
        expect(provider.models.length, 6);
      });

      test('init() 后模型应有完整的字段', () async {
        await provider.init();

        for (final model in provider.models) {
          expect(model.containsKey('name'), true);
          expect(model.containsKey('version'), true);
          expect(model.containsKey('is_trained'), true);
          expect(model.containsKey('credibility_score'), true);
          expect(model.containsKey('performance_avg'), true);
          expect(model.containsKey('precision'), true);
          expect(model.containsKey('recall'), true);
        }
      });

      test('init() 后模型名称应为 6 个', () async {
        await provider.init();

        final names = provider.models.map((m) => m['name'] as String).toSet();
        expect(names, containsAll(['XGBoost', 'LSTM', 'Transformer', 'PPO', 'Statistic', 'Behavior']));
      });
    });

    group('权重计算', () {
      test('init() 后应有模型权重', () async {
        await provider.init();

        expect(provider.weights, isNotEmpty);
        expect(provider.weights.length, 6);
      });

      test('权重应包含所有模型', () async {
        await provider.init();

        expect(provider.weights.containsKey('XGBoost'), true);
        expect(provider.weights.containsKey('LSTM'), true);
        expect(provider.weights.containsKey('Transformer'), true);
        expect(provider.weights.containsKey('PPO'), true);
        expect(provider.weights.containsKey('Statistic'), true);
        expect(provider.weights.containsKey('Behavior'), true);
      });

      test('权重总和应接近 1.0', () async {
        await provider.init();

        final total = provider.weights.values.fold<double>(0, (a, b) => a + b);
        expect(total, closeTo(1.0, 0.01));
      });

      test('每个权重应在 0 到 1 之间', () async {
        await provider.init();

        for (final weight in provider.weights.values) {
          expect(weight, greaterThan(0));
          expect(weight, lessThan(1));
        }
      });

      test('loadWeights() 应更新权重', () async {
        await provider.init();

        final oldWeights = Map<String, double>.from(provider.weights);
        await provider.loadWeights();

        // loadWeights 可能从 API 获取或回退到本地计算
        expect(provider.weights, isNotEmpty);
      });

      test('updateWeights() 应更新权重并通知', () async {
        await provider.init();

        final newWeights = {
          'XGBoost': 0.25,
          'LSTM': 0.20,
          'Transformer': 0.20,
          'PPO': 0.10,
          'Statistic': 0.15,
          'Behavior': 0.10,
        };

        bool notified = false;
        provider.addListener(() {
          notified = true;
        });

        await provider.updateWeights(newWeights);

        expect(provider.weights['XGBoost'], 0.25);
        expect(provider.weights['LSTM'], 0.20);
        expect(notified, true);
      });
    });

    group('回测功能', () {
      test('模型应有 credibility_score', () async {
        await provider.init();

        for (final model in provider.models) {
          final cred = (model['credibility_score'] as num).toDouble();
          expect(cred, greaterThanOrEqualTo(0.50));
          expect(cred, lessThanOrEqualTo(0.95));
        }
      });

      test('各模型应有不同的表现分数', () async {
        await provider.init();

        final scores = provider.models
            .map((m) => (m['performance_avg'] as num).toDouble())
            .toSet();
        // 至少有 3 个不同的分数 (不同模型应有不同表现)
        expect(scores.length, greaterThanOrEqualTo(3));
      });
    });

    group('训练功能', () {
      test('trainModel() 应设置 isTraining', () async {
        await provider.init();

        // 启动训练（不等待完成）
        final future = provider.trainModel('XGBoost');
        // 立即检查状态
        expect(provider.isTraining, true);

        await future;
        expect(provider.isTraining, false);
      });

      test('trainModel() 完成后应更新模型指标', () async {
        await provider.init();

        final oldPerf = (provider.models[0]['performance_avg'] as num).toDouble();

        await provider.trainModel('XGBoost');

        final newPerf = (provider.models[0]['performance_avg'] as num).toDouble();
        // 训练后性能应有变化
        expect(newPerf, isNotNull);
      });

      test('trainAllModels() 应训练所有模型', () async {
        await provider.init();

        await provider.trainAllModels();

        expect(provider.isTraining, false);
        expect(provider.models, isNotEmpty);
      });

      test('loadModels() 应更新模型列表', () async {
        await provider.init();

        final oldCount = provider.models.length;
        await provider.loadModels();

        // 即使 API 不可用，也应保留现有模型
        expect(provider.models.length, greaterThanOrEqualTo(oldCount));
      });
    });

    group('彩票类型切换', () {
      test('updateLotteryType() 应重新计算模型指标', () async {
        await provider.init();

        final ssqWeights = Map<String, double>.from(provider.weights);

        provider.updateLotteryType(LotteryType.dlt);

        expect(provider.weights, isNotEmpty);
      });

      test('切换后模型数量应保持 6 个', () async {
        await provider.init();

        provider.updateLotteryType(LotteryType.dlt);
        expect(provider.models.length, 6);

        provider.updateLotteryType(LotteryType.k8);
        expect(provider.models.length, 6);
      });
    });
  });
}
