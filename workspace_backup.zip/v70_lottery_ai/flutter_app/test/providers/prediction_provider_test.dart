import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_app/providers/prediction_provider.dart';
import 'package:flutter_app/providers/lottery_provider.dart';
import 'package:flutter_app/providers/model_provider.dart';
import '../helpers/mock_data.dart';

void main() {
  group('PredictionProvider', () {
    late PredictionProvider provider;

    setUp(() {
      provider = PredictionProvider();
    });

    tearDown(() {
      provider.dispose();
    });

    group('初始化加载数据', () {
      test('初始状态应为空', () {
        expect(provider.isGenerating, false);
        expect(provider.latestPrediction, null);
        expect(provider.candidates, isEmpty);
        expect(provider.history, isEmpty);
        expect(provider.backtestResult, null);
        expect(provider.error, null);
        expect(provider.finalScore, 0);
      });

      test('init() 应加载数据并生成预测方案', () async {
        await provider.init();

        // init 后应有预测方案
        expect(provider.latestPrediction, isNotNull);
        expect(provider.candidates, isNotEmpty);
        expect(provider.finalScore, greaterThan(0));
        expect(provider.history, isNotEmpty);
      });

      test('init() 后 modelContributions 应有默认值', () async {
        await provider.init();

        final contributions = provider.modelContributions;
        expect(contributions, isNotEmpty);
        expect(contributions.containsKey('XGBoost'), true);
        expect(contributions.containsKey('LSTM'), true);
      });
    });

    group('生成预测方案', () {
      test('generatePrediction() 应设置 isGenerating', () async {
        // 不等待完成，只检查状态变化
        final future = provider.generatePrediction();
        // 由于 async 立即执行，在下一个 microtask 中检查
        await Future.delayed(Duration.zero);
        // generatePrediction 内部会尝试 API 调用，失败后回退到本地生成
      });

      test('generatePrediction() 完成后 isGenerating 应为 false', () async {
        await provider.generatePrediction();

        expect(provider.isGenerating, false);
        // 本地降级方案会生成数据
        expect(provider.candidates, isNotEmpty);
      });

      test('generatePrediction() 应设置 finalScore > 0', () async {
        await provider.generatePrediction();

        expect(provider.finalScore, greaterThan(0));
      });

      test('generatePrediction() 失败时应回退到本地数据生成', () async {
        // 默认情况下 API 不可用，应自动回退
        await provider.generatePrediction();

        expect(provider.candidates, isNotEmpty);
        expect(provider.latestPrediction, isNotNull);
      });
    });

    group('切换彩票类型', () {
      test('updateLotteryType() 应从 ssq 切换到 dlt', () async {
        await provider.init();

        final ssqCandidates = List<Map<String, dynamic>>.from(provider.candidates);
        expect(ssqCandidates, isNotEmpty);

        provider.updateLotteryType(LotteryType.dlt);

        // 切换后应有新的预测方案
        expect(provider.candidates, isNotEmpty);
      });

      test('updateLotteryType() 应清空之前的结果', () async {
        await provider.init();
        expect(provider.latestPrediction, isNotNull);

        provider.updateLotteryType(LotteryType.k8);

        // backtest 结果应被清空
        expect(provider.backtestResult, null);
      });

      test('切换回 ssq 应有正确的主球数量', () async {
        provider.updateLotteryType(LotteryType.dlt);
        provider.updateLotteryType(LotteryType.ssq);

        await provider.init();

        final candidates = provider.candidates;
        if (candidates.isNotEmpty) {
          final mainBalls = candidates[0]['main_balls'] as List<dynamic>?;
          if (mainBalls != null) {
            // SSQ 有 6 个主球
            expect(mainBalls.length, 6);
          }
        }
      });
    });

    group('历史记录', () {
      test('loadHistory() 应加载预测历史', () async {
        await provider.init();
        await provider.loadHistory();

        expect(provider.history, isNotEmpty);
      });

      test('历史记录应包含 period 字段', () async {
        await provider.init();

        for (final item in provider.history) {
          expect(item.containsKey('period'), true);
        }
      });
    });

    group('回测功能', () {
      test('runBacktest() 完成后 isGenerating 为 false', () async {
        await provider.runBacktest(periods: 30);

        expect(provider.isGenerating, false);
      });

      test('runBacktest() 应生成回测结果', () async {
        await provider.runBacktest(periods: 50);

        expect(provider.backtestResult, isNotNull);
        expect(provider.backtestResult!['avg_score'], isNotNull);
      });

      test('回测结果应包含模型表现', () async {
        await provider.runBacktest(periods: 50);

        final modelPerf = provider.backtestResult!['model_performance'];
        expect(modelPerf, isNotNull);
        expect((modelPerf as Map).containsKey('XGBoost'), true);
      });
    });

    group('绑定 ModelProvider', () {
      test('bindModelProvider() 后 modelContributions 应使用 ModelProvider 权重', () async {
        final modelProvider = ModelProvider();
        await modelProvider.init();

        provider.bindModelProvider(modelProvider);
        await provider.init();

        final contributions = provider.modelContributions;
        expect(contributions, isNotEmpty);
      });

      test('未绑定时 modelContributions 应有默认权重', () async {
        await provider.init();

        final contributions = provider.modelContributions;
        expect(contributions.isNotEmpty, true);
        // 默认权重总和应接近 1.0
        final total = contributions.values.fold<double>(0, (a, b) => a + (b as num).toDouble());
        expect(total, closeTo(1.0, 0.1));
      });
    });
  });
}
