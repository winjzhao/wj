import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_app/providers/lottery_provider.dart';
import '../helpers/mock_data.dart';

void main() {
  group('LotteryType', () {
    group('枚举值', () {
      test('应支持 3 种彩票类型', () {
        expect(LotteryType.values.length, 3);
        expect(LotteryType.values, contains(LotteryType.ssq));
        expect(LotteryType.values, contains(LotteryType.dlt));
        expect(LotteryType.values, contains(LotteryType.k8));
      });
    });

    group('displayName', () {
      test('SSQ 显示名称为双色球', () {
        expect(LotteryType.ssq.displayName, '双色球');
      });

      test('DLT 显示名称为大乐透', () {
        expect(LotteryType.dlt.displayName, '大乐透');
      });

      test('K8 显示名称为快乐8', () {
        expect(LotteryType.k8.displayName, '快乐8');
      });
    });

    group('apiValue', () {
      test('SSQ API 值为 ssq', () {
        expect(LotteryType.ssq.apiValue, 'ssq');
      });

      test('DLT API 值为 dlt', () {
        expect(LotteryType.dlt.apiValue, 'dlt');
      });

      test('K8 API 值为 k8', () {
        expect(LotteryType.k8.apiValue, 'k8');
      });
    });

    group('mainCount', () {
      test('SSQ 主球数量为 6', () {
        expect(LotteryType.ssq.mainCount, 6);
      });

      test('DLT 主球数量为 5', () {
        expect(LotteryType.dlt.mainCount, 5);
      });

      test('K8 主球数量为 20', () {
        expect(LotteryType.k8.mainCount, 20);
      });
    });

    group('mainRange', () {
      test('SSQ 主球范围为 33', () {
        expect(LotteryType.ssq.mainRange, 33);
      });

      test('DLT 主球范围为 35', () {
        expect(LotteryType.dlt.mainRange, 35);
      });

      test('K8 主球范围为 80', () {
        expect(LotteryType.k8.mainRange, 80);
      });
    });

    group('bonusCounts', () {
      test('SSQ 附加球为 1 个', () {
        expect(LotteryType.ssq.bonusCounts, [1]);
      });

      test('DLT 附加球为 2 个', () {
        expect(LotteryType.dlt.bonusCounts, [2]);
      });

      test('K8 无附加球', () {
        expect(LotteryType.k8.bonusCounts, [0]);
      });
    });

    group('bonusRanges', () {
      test('SSQ 蓝球范围为 16', () {
        expect(LotteryType.ssq.bonusRanges, [16]);
      });

      test('DLT 后区范围为 12', () {
        expect(LotteryType.dlt.bonusRanges, [12]);
      });

      test('K8 无附加球范围', () {
        expect(LotteryType.k8.bonusRanges, [0]);
      });
    });

    group('mainColor', () {
      test('SSQ 主色应为红色系', () {
        expect(LotteryType.ssq.mainColor, isNotNull);
      });

      test('K8 主色应不同于 SSQ', () {
        expect(LotteryType.k8.mainColor, isNot(LotteryType.ssq.mainColor));
      });
    });

    group('fromApiValue', () {
      test('fromApiValue("ssq") 返回 ssq', () {
        expect(LotteryProvider.fromApiValue('ssq'), LotteryType.ssq);
      });

      test('fromApiValue("dlt") 返回 dlt', () {
        expect(LotteryProvider.fromApiValue('dlt'), LotteryType.dlt);
      });

      test('fromApiValue("k8") 返回 k8', () {
        expect(LotteryProvider.fromApiValue('k8'), LotteryType.k8);
      });

      test('未知值应返回默认 ssq', () {
        expect(LotteryProvider.fromApiValue('unknown'), LotteryType.ssq);
        expect(LotteryProvider.fromApiValue(''), LotteryType.ssq);
      });
    });
  });

  group('LotteryProvider', () {
    late LotteryProvider provider;

    setUp(() {
      provider = LotteryProvider();
    });

    test('初始类型应为 ssq', () {
      expect(provider.currentType, LotteryType.ssq);
    });

    test('setType() 应切换彩票类型', () {
      provider.setType(LotteryType.dlt);
      expect(provider.currentType, LotteryType.dlt);
    });

    test('setType() 相同类型不触发通知', () {
      bool notified = false;
      provider.addListener(() {
        notified = true;
      });

      provider.setType(LotteryType.ssq); // 已经是 ssq
      expect(notified, false);
    });

    test('setType() 不同类型触发通知', () {
      bool notified = false;
      provider.addListener(() {
        notified = true;
      });

      provider.setType(LotteryType.dlt);
      expect(notified, true);
    });

    test('应支持切换到所有类型', () {
      for (final type in LotteryType.values) {
        provider.setType(type);
        expect(provider.currentType, type);
      }
    });

    test('supportedTypes 应包含 3 种', () {
      expect(LotteryProvider.supportedTypes.length, 3);
    });
  });

  group('配置参数', () {
    test('getBallConfig() 应返回正确的主球配置', () {
      final ssqConfig = LotteryProvider.getBallConfig(LotteryType.ssq);
      expect(ssqConfig['main_count'], 6);
      expect(ssqConfig['main_range'], 33);
      expect(ssqConfig['bonus_counts'], [1]);
      expect(ssqConfig['bonus_ranges'], [16]);
      expect(ssqConfig['main_label'], '红球');
      expect(ssqConfig['bonus_labels'], ['蓝球']);
    });

    test('getBallConfig() DLT 配置正确', () {
      final dltConfig = LotteryProvider.getBallConfig(LotteryType.dlt);
      expect(dltConfig['main_count'], 5);
      expect(dltConfig['main_range'], 35);
      expect(dltConfig['bonus_counts'], [2]);
      expect(dltConfig['bonus_ranges'], [12]);
      expect(dltConfig['main_label'], '前区');
      expect(dltConfig['bonus_labels'], ['后区']);
    });

    test('getBallConfig() K8 配置正确', () {
      final k8Config = LotteryProvider.getBallConfig(LotteryType.k8);
      expect(k8Config['main_count'], 20);
      expect(k8Config['main_range'], 80);
      expect(k8Config['bonus_counts'], [0]);
      expect(k8Config['bonus_ranges'], [0]);
      expect(k8Config['main_label'], '选号');
      expect(k8Config['bonus_labels'], []);
    });
  });
}
