/// 测试辅助 - Mock ApiClient
library mock_api_client;

import 'dart:async';
import 'dart:convert';
import 'package:flutter_app/api/api_client.dart';
import 'package:http/http.dart' as http;

/// Mock HTTP 客户端，用于模拟 API 响应
class MockHttpClient extends http.BaseClient {
  final Map<String, Map<String, dynamic>> _responses = {};
  final List<Map<String, dynamic>> _requestLog = [];
  bool _shouldThrow = false;
  Object? _throwError;

  /// 注册 GET 端点响应
  void registerGet(String path, Map<String, dynamic> response) {
    _responses['GET:$path'] = response;
  }

  /// 注册 POST 端点响应
  void registerPost(String path, Map<String, dynamic> response) {
    _responses['POST:$path'] = response;
  }

  /// 设置是否抛出异常
  void setShouldThrow(bool value, {Object? error}) {
    _shouldThrow = value;
    _throwError = error;
  }

  /// 获取请求日志
  List<Map<String, dynamic>> get requestLog => _requestLog;

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    _requestLog.add({
      'method': request.method,
      'url': request.url.toString(),
      'timestamp': DateTime.now().toIso8601String(),
    });

    if (_shouldThrow) {
      if (_throwError != null) {
        throw _throwError!;
      }
      throw TimeoutException('Mock timeout');
    }

    final key = '${request.method}:${request.url.path}';
    final response = _responses[key];

    if (response != null) {
      return http.StreamedResponse(
        Stream.fromIterable([utf8.encode(jsonEncode(response))]),
        200,
        headers: {'content-type': 'application/json'},
      );
    }

    // 默认返回 404
    return http.StreamedResponse(
      Stream.fromIterable([utf8.encode(jsonEncode({'error': 'not_found'}))]),
      404,
      headers: {'content-type': 'application/json'},
    );
  }
}

/// 创建用于测试的 MockApiClient
class MockApiClient {
  final MockHttpClient mockHttpClient;
  late final ApiClient apiClient;

  MockApiClient() : mockHttpClient = MockHttpClient() {
    // 注意: ApiClient 内部使用 http.Client，无法直接注入 MockHttpClient
    // 在测试中，我们使用 provider 级别的 mock 策略
  }

  /// 设置标准成功响应
  void setupStandardResponses() {
    mockHttpClient.registerGet('/system/status', {
      'system_state': 'running',
      'models_loaded': 6,
      'data_available': true,
    });

    mockHttpClient.registerGet('/prediction/latest', {
      'final_score': 88.7,
      'candidates': [
        {
          'main_balls': [7, 11, 14, 16, 27, 28],
          'bonus_balls': [[6]],
          'score': 92.0,
          'confidence': 0.88,
        },
      ],
    });

    mockHttpClient.registerGet('/models/list', {
      'models': [
        {'name': 'XGBoost', 'version': 'V72.0', 'is_trained': true},
        {'name': 'LSTM', 'version': 'V72.0', 'is_trained': true},
      ],
    });
  }
}
