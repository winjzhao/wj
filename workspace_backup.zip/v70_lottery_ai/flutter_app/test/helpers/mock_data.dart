/// 测试辅助 - Mock 数据和工具函数
library test_helpers;

import 'dart:math';

/// 模拟开奖数据
class MockData {
  /// 生成模拟开奖数据列表
  static List<Map<String, dynamic>> generateDraws({
    int count = 200,
    String lotteryType = 'ssq',
  }) {
    final rng = Random(42);
    final draws = <Map<String, dynamic>>[];

    int mainCount;
    int mainRange;
    List<int> bonusCounts;
    List<int> bonusRanges;

    switch (lotteryType) {
      case 'ssq':
        mainCount = 6;
        mainRange = 33;
        bonusCounts = [1];
        bonusRanges = [16];
        break;
      case 'dlt':
        mainCount = 5;
        mainRange = 35;
        bonusCounts = [2];
        bonusRanges = [12];
        break;
      case 'k8':
        mainCount = 20;
        mainRange = 80;
        bonusCounts = [0];
        bonusRanges = [0];
        break;
      default:
        mainCount = 6;
        mainRange = 33;
        bonusCounts = [1];
        bonusRanges = [16];
    }

    for (int i = 0; i < count; i++) {
      // 生成主球
      final mainBalls = <int>{};
      while (mainBalls.length < mainCount) {
        mainBalls.add(rng.nextInt(mainRange) + 1);
      }

      // 生成附加球
      final bonusBalls = <List<int>>[];
      for (int bi = 0; bi < bonusCounts.length; bi++) {
        if (bonusCounts[bi] > 0) {
          final bSet = <int>{};
          while (bSet.length < bonusCounts[bi]) {
            bSet.add(rng.nextInt(bonusRanges[bi]) + 1);
          }
          bonusBalls.add(bSet.toList()..sort());
        }
      }

      final date = DateTime(2024, 1, 1).add(Duration(days: i * 3));

      draws.add({
        'period': '2024${(i + 1).toString().padLeft(3, '0')}',
        'draw_date': date.toIso8601String(),
        'lottery_type': lotteryType,
        'main_balls': mainBalls.toList()..sort(),
        'bonus_balls': bonusBalls,
        'reds': mainBalls.toList()..sort(),
        'blue': bonusBalls.isNotEmpty && bonusBalls[0].isNotEmpty
            ? bonusBalls[0][0]
            : null,
      });
    }

    return draws;
  }

  /// 生成模拟预测结果
  static Map<String, dynamic> generatePrediction({
    String lotteryType = 'ssq',
    double finalScore = 88.7,
  }) {
    final rng = Random(42);

    int mainCount;
    int mainRange;
    List<int> bonusCounts;
    List<int> bonusRanges;

    switch (lotteryType) {
      case 'ssq':
        mainCount = 6;
        mainRange = 33;
        bonusCounts = [1];
        bonusRanges = [16];
        break;
      case 'dlt':
        mainCount = 5;
        mainRange = 35;
        bonusCounts = [2];
        bonusRanges = [12];
        break;
      case 'k8':
        mainCount = 20;
        mainRange = 80;
        bonusCounts = [0];
        bonusRanges = [0];
        break;
      default:
        mainCount = 6;
        mainRange = 33;
        bonusCounts = [1];
        bonusRanges = [16];
    }

    final candidates = <Map<String, dynamic>>[];
    for (int i = 0; i < 3; i++) {
      final mainBalls = <int>{};
      while (mainBalls.length < mainCount) {
        mainBalls.add(rng.nextInt(mainRange) + 1);
      }

      final bonusBalls = <List<int>>[];
      for (int bi = 0; bi < bonusCounts.length; bi++) {
        if (bonusCounts[bi] > 0) {
          final bSet = <int>{};
          while (bSet.length < bonusCounts[bi]) {
            bSet.add(rng.nextInt(bonusRanges[bi]) + 1);
          }
          bonusBalls.add(bSet.toList()..sort());
        }
      }

      candidates.add({
        'main_balls': mainBalls.toList()..sort(),
        'bonus_balls': bonusBalls,
        'score': 92.0 - i * 5.0 + rng.nextDouble() * 2,
        'probability': 0.35 - i * 0.1,
        'confidence': 0.88 - i * 0.05,
      });
    }

    return {
      'final_score': finalScore,
      'candidates': candidates,
      'model_contributions': {
        'XGBoost': 0.22,
        'LSTM': 0.18,
        'Transformer': 0.20,
        'PPO': 0.12,
        'Statistic': 0.15,
        'Behavior': 0.13,
      },
      'generated_at': DateTime.now().toIso8601String(),
    };
  }

  /// 生成模拟模型列表
  static List<Map<String, dynamic>> generateModels() {
    return [
      {
        'name': 'XGBoost',
        'version': 'V72.0',
        'is_trained': true,
        'credibility_score': 0.82,
        'performance_avg': 78.5,
        'data_periods': 500,
        'precision': 0.28,
        'recall': 0.25,
      },
      {
        'name': 'LSTM',
        'version': 'V72.0',
        'is_trained': true,
        'credibility_score': 0.79,
        'performance_avg': 76.2,
        'data_periods': 500,
        'precision': 0.26,
        'recall': 0.23,
      },
      {
        'name': 'Transformer',
        'version': 'V71.5',
        'is_trained': true,
        'credibility_score': 0.80,
        'performance_avg': 77.8,
        'data_periods': 500,
        'precision': 0.27,
        'recall': 0.24,
      },
      {
        'name': 'PPO',
        'version': 'V71.2',
        'is_trained': true,
        'credibility_score': 0.75,
        'performance_avg': 72.5,
        'data_periods': 500,
        'precision': 0.22,
        'recall': 0.20,
      },
      {
        'name': 'Statistic',
        'version': 'V71.0',
        'is_trained': true,
        'credibility_score': 0.73,
        'performance_avg': 70.8,
        'data_periods': 500,
        'precision': 0.20,
        'recall': 0.18,
      },
      {
        'name': 'Behavior',
        'version': 'V71.3',
        'is_trained': true,
        'credibility_score': 0.77,
        'performance_avg': 74.3,
        'data_periods': 500,
        'precision': 0.24,
        'recall': 0.21,
      },
    ];
  }

  /// 生成模拟回测结果
  static Map<String, dynamic> generateBacktestResult({int periods = 50}) {
    final rng = Random(42);
    final trend = List.generate(periods, (i) => 65.0 + rng.nextDouble() * 30);
    return {
      'avg_score': trend.reduce((a, b) => a + b) / trend.length,
      'accuracy_trend': trend,
      'model_performance': {
        'XGBoost': {'avg_score': 79.2, 'trend': 'improving'},
        'LSTM': {'avg_score': 76.8, 'trend': 'improving'},
        'Transformer': {'avg_score': 74.5, 'trend': 'stable'},
        'PPO': {'avg_score': 70.3, 'trend': 'stable'},
        'Statistic': {'avg_score': 68.8, 'trend': 'stable'},
        'Behavior': {'avg_score': 72.1, 'trend': 'improving'},
      },
    };
  }
}
