import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:flutter_app/providers/app_state.dart';
import 'package:flutter_app/providers/prediction_provider.dart';
import 'package:flutter_app/providers/model_provider.dart';
import 'package:flutter_app/providers/lottery_provider.dart';
import 'package:flutter_app/pages/dashboard_page.dart';

import '../helpers/mock_data.dart';

/// 创建带有所有 Provider 的测试 Widget
Widget createDashboardTestWidget() {
  return MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => LotteryProvider()),
      ChangeNotifierProvider(create: (_) => AppState()),
      ChangeNotifierProvider(create: (_) => PredictionProvider()),
      ChangeNotifierProvider(create: (_) => ModelProvider()),
    ],
    child: MaterialApp(
      theme: ThemeData(
        useMaterial3: true,
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
        cardColor: const Color(0xFF161B22),
      ),
      home: Scaffold(
        body: DashboardPage(),
      ),
    ),
  );
}

void main() {
  group('DashboardPage Widget', () {
    testWidgets('基本渲染 - 应显示仪表盘标题', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());

      // 仪表盘应包含统计卡片
      // 由于 init 在 postFrameCallback 中，先 pump 一帧
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      // 检查统计卡片标签存在
      expect(find.text('融合评分'), findsOneWidget);
      expect(find.text('活跃模型'), findsOneWidget);
      expect(find.text('经验记录'), findsOneWidget);
    });

    testWidgets('应显示模型贡献度区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      // 模型贡献度标题
      expect(find.text('模型贡献度'), findsOneWidget);
    });

    testWidgets('应显示最新预测方案区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      // 最新预测方案标题
      expect(find.text('最新预测方案'), findsOneWidget);
    });

    testWidgets('应显示快速操作区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      expect(find.text('快速操作'), findsOneWidget);
    });

    testWidgets('快速操作区域应有 AI预测 按钮', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      expect(find.text('AI预测'), findsOneWidget);
    });

    testWidgets('快速操作区域应有 历史回测 按钮', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      expect(find.text('历史回测'), findsOneWidget);
    });

    testWidgets('应可滚动', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      // 页面应可滚动（Scrollable 存在）
      expect(find.byType(Scrollable), findsWidgets);
    });

    testWidgets('AI预测按钮可点击', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      // 找到 AI预测 按钮
      final aiButton = find.text('AI预测');
      expect(aiButton, findsOneWidget);

      // 点击按钮不应抛出异常
      await tester.tap(aiButton);
      await tester.pump();
    });

    testWidgets('统计卡片应有图标', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      // 应有至少 3 个图标
      expect(find.byType(Icon), findsWidgets);
    });
  });
}
