import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:flutter_app/providers/app_state.dart';
import 'package:flutter_app/providers/prediction_provider.dart';
import 'package:flutter_app/providers/model_provider.dart';
import 'package:flutter_app/providers/lottery_provider.dart';
import 'package:flutter_app/pages/prediction_page.dart';

/// 创建预测页面的测试 Widget
Widget createPredictionTestWidget() {
  return MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => LotteryProvider()),
      ChangeNotifierProvider(create: (_) => AppState()),
      ChangeNotifierProvider(create: (_) => PredictionProvider()),
      ChangeNotifierProvider(create: (_) => ModelProvider()),
    ],
    child: MaterialApp(
      theme: ThemeData(
        useMaterial3: true,
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
        cardColor: const Color(0xFF161B22),
      ),
      home: Scaffold(
        body: PredictionPage(),
      ),
    ),
  );
}

void main() {
  group('PredictionPage Widget', () {
    testWidgets('基本渲染 - 应显示预测中心标题', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // 预测中心 AppBar 标题
      expect(find.text('预测中心'), findsOneWidget);
    });

    testWidgets('应显示 AI 融合预测引擎 标题', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('AI 融合预测引擎'), findsOneWidget);
    });

    testWidgets('应显示 开始AI预测 按钮', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('开始AI预测'), findsOneWidget);
    });

    testWidgets('开始AI预测 按钮可点击', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      final button = find.text('开始AI预测');
      expect(button, findsOneWidget);

      // 点击不应抛出异常
      await tester.tap(button);
      await tester.pump();
    });

    testWidgets('应显示预测历史区域', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('预测历史'), findsOneWidget);
    });

    testWidgets('应包含刷新按钮', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // 刷新按钮使用 Icons.refresh
      expect(find.byIcon(Icons.refresh), findsOneWidget);
    });

    testWidgets('应包含预测引擎描述文本', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // 应该包含描述文本
      expect(find.textContaining('6模型融合决策'), findsOneWidget);
    });

    testWidgets('应可滚动', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.byType(Scrollable), findsWidgets);
    });

    testWidgets('点击预测按钮后应显示候选方案', (WidgetTester tester) async {
      await tester.pumpWidget(createPredictionTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      final button = find.text('开始AI预测');
      await tester.tap(button);
      await tester.pump();
      await tester.pump(const Duration(seconds: 1));

      // 预测完成后应有结果
      // 候选方案或融合评分
      expect(
        find.text('TOP 候选方案').evaluate().isNotEmpty ||
            find.text('融合评分').evaluate().isNotEmpty,
        true,
      );
    });
  });
}
