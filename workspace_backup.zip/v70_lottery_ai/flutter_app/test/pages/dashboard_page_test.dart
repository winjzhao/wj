import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:flutter_app/providers/app_state.dart';
import 'package:flutter_app/providers/prediction_provider.dart';
import 'package:flutter_app/providers/model_provider.dart';
import 'package:flutter_app/providers/lottery_provider.dart';
import 'package:flutter_app/pages/dashboard_page.dart';

/// 创建带有所有 Provider 的测试 Widget
Widget createDashboardPageTestWidget() {
  return MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => LotteryProvider()),
      ChangeNotifierProvider(create: (_) => AppState()),
      ChangeNotifierProvider(create: (_) => PredictionProvider()),
      ChangeNotifierProvider(create: (_) => ModelProvider()),
    ],
    child: MaterialApp(
      theme: ThemeData(
        useMaterial3: true,
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
        cardColor: const Color(0xFF161B22),
      ),
      home: Scaffold(
        body: DashboardPage(),
      ),
    ),
  );
}

void main() {
  group('DashboardPage Widget', () {
    testWidgets('应显示仪表盘标题区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // 统计卡片标签应存在
      expect(find.text('融合评分'), findsOneWidget);
      expect(find.text('活跃模型'), findsOneWidget);
      expect(find.text('经验记录'), findsOneWidget);
    });

    testWidgets('应显示连接模式指示器', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // 数据源区域应存在
      expect(find.text('数据源'), findsOneWidget);
    });

    testWidgets('应显示本地/云端切换按钮', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('本地'), findsOneWidget);
      expect(find.text('云端'), findsOneWidget);
    });

    testWidgets('应显示模型贡献度区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('模型贡献度'), findsOneWidget);
    });

    testWidgets('应显示最新预测方案区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('最新预测方案'), findsOneWidget);
    });

    testWidgets('应显示快速操作区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('快速操作'), findsOneWidget);
    });

    testWidgets('快速操作区域应有 AI预测 按钮', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('AI预测'), findsOneWidget);
    });

    testWidgets('快速操作区域应有 历史回测 按钮', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('历史回测'), findsOneWidget);
    });

    testWidgets('应显示最新开奖结果区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('最新开奖结果'), findsOneWidget);
    });

    testWidgets('应显示最近开奖数据区域', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // 最近开奖数据标题包含彩票类型
      expect(find.textContaining('最近开奖数据'), findsOneWidget);
    });

    testWidgets('应可滚动', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.byType(Scrollable), findsWidgets);
    });

    testWidgets('统计卡片应有图标', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.byType(Icon), findsWidgets);
    });

    testWidgets('下拉刷新应存在', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // RefreshIndicator 应存在
      expect(find.byType(RefreshIndicator), findsOneWidget);
    });

    testWidgets('AI预测按钮可点击', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      final aiButton = find.text('AI预测');
      expect(aiButton, findsOneWidget);

      await tester.tap(aiButton);
      await tester.pump();
      // 点击不应抛出异常
    });

    testWidgets('历史回测按钮可点击', (WidgetTester tester) async {
      await tester.pumpWidget(createDashboardPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      final backtestButton = find.text('历史回测');
      expect(backtestButton, findsOneWidget);

      await tester.tap(backtestButton);
      await tester.pump();
      // 点击不应抛出异常
    });
  });
}
