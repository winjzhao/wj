import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:flutter_app/providers/app_state.dart';
import 'package:flutter_app/providers/model_provider.dart';
import 'package:flutter_app/providers/lottery_provider.dart';
import 'package:flutter_app/providers/evolution_provider.dart';
import 'package:flutter_app/pages/models_page.dart';

/// 创建带有所有 Provider 的测试 Widget
Widget createModelsPageTestWidget() {
  return MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => LotteryProvider()),
      ChangeNotifierProvider(create: (_) => AppState()),
      ChangeNotifierProvider(create: (_) => ModelProvider()),
      ChangeNotifierProvider(create: (_) => EvolutionProvider()),
    ],
    child: MaterialApp(
      theme: ThemeData(
        useMaterial3: true,
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
        cardColor: const Color(0xFF161B22),
      ),
      home: Scaffold(
        body: ModelsPage(),
      ),
    ),
  );
}

void main() {
  group('ModelsPage Widget', () {
    testWidgets('基本渲染 - 应显示模型管理页面', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // AppBar 标题应包含 "模型管理"
      expect(find.textContaining('模型管理'), findsOneWidget);
    });

    testWidgets('应显示 AppBar 标题', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // 应有 AppBar
      expect(find.byType(AppBar), findsOneWidget);
    });

    testWidgets('应显示全部训练按钮', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('全部训练'), findsOneWidget);
    });

    testWidgets('应显示运行模式横幅', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      // 应显示 "本地推理模式" 或 "后端推理模式"
      final localMode = find.text('本地推理模式');
      final backendMode = find.text('后端推理模式');
      expect(
        localMode.evaluate().isNotEmpty || backendMode.evaluate().isNotEmpty,
        true,
      );
    });

    testWidgets('应显示融合权重配置区域', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('融合权重配置'), findsOneWidget);
    });

    testWidgets('应显示权重配置描述', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(
        find.text('调整各模型在融合决策中的权重占比'),
        findsOneWidget,
      );
    });

    testWidgets('应显示 AI 模型列表标题', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.text('AI 模型列表'), findsOneWidget);
    });

    testWidgets('应可滚动', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      expect(find.byType(Scrollable), findsWidgets);
    });

    testWidgets('全部训练按钮可点击', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 200));

      final trainAllButton = find.text('全部训练');
      expect(trainAllButton, findsOneWidget);

      await tester.tap(trainAllButton);
      await tester.pump();
      // 点击不应抛出异常
    });

    testWidgets('权重区域应包含进度条', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // ModelProvider 加载后应有权重显示
      // 权重区域应至少有一个进度条（LinearProgressIndicator）
      expect(
        find.byType(LinearProgressIndicator).evaluate().isNotEmpty ||
            find.text('融合权重配置').evaluate().isNotEmpty,
        true,
      );
    });

    testWidgets('模型卡片应显示模型名称', (WidgetTester tester) async {
      await tester.pumpWidget(createModelsPageTestWidget());
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));

      // 模型列表加载后应显示模型名称，至少 XGBoost 或显示 "暂无模型数据"
      final hasModels = find.text('XGBoost').evaluate().isNotEmpty;
      final noModels = find.text('暂无模型数据').evaluate().isNotEmpty;
      expect(hasModels || noModels, true);
    });
  });
}
