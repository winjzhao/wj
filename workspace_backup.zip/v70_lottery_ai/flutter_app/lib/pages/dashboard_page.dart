import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../providers/prediction_provider.dart';
import '../providers/model_provider.dart';
import '../providers/lottery_provider.dart';
import '../services/lottery_data_service.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';
import 'comparison_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final LotteryDataService _dataService = LotteryDataService();
  static const int _pageSize = 20;

  final ScrollController _scrollController = ScrollController();
  int _displayedDrawCount = 10;
  bool _isLoadingMoreDraws = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final appState = context.read<AppState>();
      final predictionProvider = context.read<PredictionProvider>();
      if (predictionProvider.candidates.isEmpty) {
        predictionProvider
            .updateLotteryType(context.read<LotteryProvider>().currentType);
      }
      appState.loadSystemStatus();
    });
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      _loadMoreDraws();
    }
  }

  void _loadMoreDraws() {
    if (_isLoadingMoreDraws) return;

    final lotteryProvider = context.read<LotteryProvider>();
    final totalDraws =
        _dataService.getDrawCount(lotteryProvider.currentType.apiValue);
    if (_displayedDrawCount >= totalDraws) return;

    setState(() {
      _isLoadingMoreDraws = true;
    });

    Future.delayed(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      setState(() {
        _displayedDrawCount =
            (_displayedDrawCount + _pageSize).clamp(0, totalDraws);
        _isLoadingMoreDraws = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final predictionProvider = context.watch<PredictionProvider>();
    final modelProvider = context.watch<ModelProvider>();
    final lotteryProvider = context.watch<LotteryProvider>();

    return Scaffold(
      body: RefreshIndicator(
        color: AppTheme.accentBlue,
        backgroundColor: const Color(0xFF21262D),
        onRefresh: () async {
          await appState.loadSystemStatus();
        },
        child: SingleChildScrollView(
          controller: _scrollController,
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildConnectionMode(context, appState),
              const SizedBox(height: 14),
              _buildOverviewCards(context, modelProvider),
              const SizedBox(height: 14),
              _buildModelContribution(context, predictionProvider),
              const SizedBox(height: 14),
              _buildLatestPrediction(
                  context, predictionProvider, lotteryProvider),
              const SizedBox(height: 14),
              _buildQuickActions(context, predictionProvider),
              const SizedBox(height: 14),
              _buildLatestDraws(context),
              const SizedBox(height: 14),
              _buildRecentDraws(context, lotteryProvider),
            ],
          ),
        ),
      ),
    );
  }

  /// 本地 / 云端数据源切换
  Widget _buildConnectionMode(BuildContext context, AppState appState) {
    final isLocal = appState.connectionMode == ConnectionMode.local;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: isLocal
              ? AppTheme.accentGreen.withOpacity(0.3)
              : AppTheme.accentBlue.withOpacity(0.3),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: isLocal
                          ? [
                              AppTheme.accentGreen.withOpacity(0.2),
                              AppTheme.accentGreen.withOpacity(0.05)
                            ]
                          : [
                              AppTheme.accentBlue.withOpacity(0.2),
                              AppTheme.accentBlue.withOpacity(0.05)
                            ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    isLocal ? Icons.phone_android : Icons.cloud,
                    size: 18,
                    color: isLocal ? AppTheme.accentGreen : AppTheme.accentBlue,
                  ),
                ),
                const SizedBox(width: 10),
                const SectionHeader(title: '数据源'),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: (isLocal
                            ? AppTheme.accentGreen
                            : (appState.isBackendConnected
                                ? AppTheme.accentGreen
                                : AppTheme.accentRed))
                        .withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isLocal
                              ? AppTheme.accentGreen
                              : (appState.isBackendConnected
                                  ? AppTheme.accentGreen
                                  : AppTheme.accentRed),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        isLocal
                            ? '本地数据'
                            : (appState.isBackendConnected ? '云端已连接' : '云端未连接'),
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: isLocal
                              ? AppTheme.accentGreen
                              : (appState.isBackendConnected
                                  ? AppTheme.accentGreen
                                  : AppTheme.accentRed),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _SourceToggle(
                    icon: Icons.phone_android,
                    label: '本地',
                    subtitle: '离线数据',
                    isActive: isLocal,
                    activeColor: AppTheme.accentGreen,
                    onTap: () {
                      if (!isLocal) {
                        appState.setConnectionMode(ConnectionMode.local);
                      }
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _SourceToggle(
                    icon: Icons.cloud,
                    label: '云端',
                    subtitle: appState.isBackendConnected ? '已连接' : '未连接',
                    isActive: !isLocal,
                    isConnected: appState.isBackendConnected,
                    activeColor: AppTheme.accentBlue,
                    onTap: () {
                      if (isLocal) {
                        appState.setConnectionMode(ConnectionMode.backend);
                      }
                    },
                  ),
                ),
              ],
            ),
            if (!isLocal) ...[
              const SizedBox(height: 12),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: AppTheme.accentBlue.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: AppTheme.accentBlue.withOpacity(0.2),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(Icons.link, size: 15, color: AppTheme.accentBlue),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        appState.backendUrl,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontFamily: 'monospace',
                              fontSize: 11,
                            ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      height: 28,
                      child: TextButton(
                        onPressed: () =>
                            _showBackendUrlDialog(context, appState),
                        child: const Text('修改',
                            style: TextStyle(fontSize: 11)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showBackendUrlDialog(BuildContext context, AppState appState) {
    final controller = TextEditingController(text: appState.backendUrl);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF161B22),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('后端服务地址',
            style: TextStyle(color: Color(0xFFE6EDF3))),
        content: TextField(
          controller: controller,
          style: const TextStyle(color: Color(0xFFE6EDF3)),
          decoration: InputDecoration(
            labelText: 'API 地址',
            hintText: 'http://192.168.1.100:8000/api/v1',
            hintStyle: const TextStyle(color: Color(0xFF484F58)),
            prefixIcon:
                const Icon(Icons.link, color: Color(0xFF4FC3F7)),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF30363D)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF30363D)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF4FC3F7)),
            ),
          ),
          keyboardType: TextInputType.url,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消',
                style: TextStyle(color: Color(0xFF8B949E))),
          ),
          ElevatedButton(
            onPressed: () {
              appState.setBackendUrl(controller.text.trim());
              Navigator.pop(ctx);
            },
            child: const Text('确认'),
          ),
        ],
      ),
    );
  }

  /// 使用 StatCard 组件的概览卡片
  Widget _buildOverviewCards(
      BuildContext context, ModelProvider modelProvider) {
    final dataService = LotteryDataService();

    String fusionScore;
    if (modelProvider.models.isNotEmpty) {
      double total = 0;
      for (final m in modelProvider.models) {
        total += m.performanceAvg;
      }
      fusionScore = (total / modelProvider.models.length).toStringAsFixed(1);
    } else {
      fusionScore = '88.7';
    }

    final totalDraws = dataService.isLoaded ? dataService.totalDraws : 900;
    final recordDisplay = '$totalDraws';

    return Row(
      children: [
        Expanded(
          child: StatCard(
            icon: Icons.auto_awesome,
            title: '融合评分',
            value: fusionScore,
            gradient: AppTheme.amberGradient,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: StatCard(
            icon: Icons.model_training,
            title: '活跃模型',
            value: '${modelProvider.models.length}',
            gradient: AppTheme.primaryGradient,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: StatCard(
            icon: Icons.memory,
            title: '经验记录',
            value: recordDisplay,
            gradient: AppTheme.purpleGradient,
          ),
        ),
      ],
    );
  }

  /// 使用 ModelContributionChart 组件的模型贡献度
  Widget _buildModelContribution(
      BuildContext context, PredictionProvider provider) {
    final theme = Theme.of(context);
    final contributions = provider.modelContributions;

    final displayContributions = contributions.isNotEmpty
        ? contributions
        : <String, double>{
            'XGBoost': 0.22,
            'LSTM': 0.18,
            'Transformer': 0.20,
            'PPO': 0.12,
            'Statistic': 0.15,
            'Behavior': 0.13,
          };

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionHeader(
              title: '模型贡献度',
              icon: Icons.pie_chart,
              iconColor: Colors.orange,
            ),
            const SizedBox(height: 16),
            ModelContributionChart(
              contributions: displayContributions,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLatestPrediction(BuildContext context,
      PredictionProvider provider, LotteryProvider lotteryProvider) {
    final theme = Theme.of(context);
    final lotteryType = lotteryProvider.currentType;
    final candidates = provider.candidates;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const SectionHeader(
                  title: '最新预测方案',
                  icon: Icons.auto_awesome,
                  iconColor: Color(0xFF4FC3F7),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    gradient: AppTheme.primaryGradient,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '评分: ${provider.finalScore > 0 ? provider.finalScore.toStringAsFixed(1) : "88.7"}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (candidates.isEmpty)
              const EmptyState(
                message: '点击下方「AI预测」按钮生成方案',
                padding: EdgeInsets.all(28),
              )
            else
              ...candidates.take(3).map((candidate) {
                final mainBalls = candidate.mainBalls;
                final bonusBalls = candidate.bonusBalls;
                final score = candidate.score;

                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1F2E),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: const Color(0xFF21262D),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            ...mainBalls.map((r) => LotteryBall(
                                  number: r.toString(),
                                  color: lotteryType.mainColor,
                                )),
                            if (bonusBalls.isNotEmpty) ...[
                              const SizedBox(width: 4),
                              ...bonusBalls.map((b) => LotteryBall(
                                    number: b.toString(),
                                    color: lotteryType.bonusColor,
                                  )),
                            ],
                          ],
                        ),
                      ),
                      Text(
                        '${score.toStringAsFixed(0)}分',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppTheme.accentBlue,
                        ),
                      ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions(
      BuildContext context, PredictionProvider provider) {
    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionHeader(
              title: '快速操作',
              icon: Icons.flash_on,
              iconColor: Color(0xFFB39DDB),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: AppTheme.primaryGradient,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.accentBlue.withOpacity(0.3),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ElevatedButton.icon(
                      onPressed: provider.isGenerating
                          ? null
                          : () => provider.generatePrediction(),
                      icon: provider.isGenerating
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.auto_awesome, color: Colors.white),
                      label: Text(
                        provider.isGenerating ? '生成中...' : 'AI预测',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.transparent,
                        shadowColor: Colors.transparent,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: provider.isGenerating
                        ? null
                        : () async {
                            await provider.runBacktest();
                            if (mounted) {
                              _showBacktestResult(context, provider);
                            }
                          },
                    icon: provider.isGenerating
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.history, size: 18),
                    label: Text(
                      provider.isGenerating ? '回测中...' : '历史回测',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    style: OutlinedButton.styleFrom(
                      primary: Colors.white70,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: const BorderSide(color: Color(0xFF30363D)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            // 预测对比入口
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChangeNotifierProvider.value(
                        value: provider,
                        child: const ComparisonPage(),
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.compare_arrows, size: 18,
                    color: Color(0xFFB39DDB)),
                label: const Text(
                  '预测 vs 开奖 对比',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Color(0xFFB39DDB),
                  ),
                ),
                style: OutlinedButton.styleFrom(
                  primary: const Color(0xFFB39DDB),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  side: BorderSide(
                    color: AppTheme.accentPurple.withOpacity(0.3),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---- 最新开奖结果 ----
  Widget _buildLatestDraws(BuildContext context) {
    final lotteryConfigs = [
      {
        'key': 'ssq',
        'label': '双色球',
        'icon': Icons.circle,
        'mainColor': const Color(0xFFFF6B6B),
        'bonusColor': const Color(0xFF42A5F5),
        'mainLabel': '红球',
        'bonusLabel': '蓝球',
      },
      {
        'key': 'dlt',
        'label': '大乐透',
        'icon': Icons.circle,
        'mainColor': const Color(0xFFFF6B6B),
        'bonusColor': const Color(0xFF42A5F5),
        'mainLabel': '前区',
        'bonusLabel': '后区',
      },
      {
        'key': 'k8',
        'label': '快乐8',
        'icon': Icons.circle,
        'mainColor': AppTheme.accentOrange,
        'bonusColor': AppTheme.accentOrange,
        'mainLabel': '号码',
        'bonusLabel': '',
        'isK8': true,
      },
    ];

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: SectionHeader(
                    title: '最新开奖结果',
                    icon: Icons.emoji_events,
                    iconColor: Color(0xFFFFB300),
                    badge: '官方数据',
                    badgeColor: Color(0xFFFFB300),
                  ),
                ),
                TextButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangeNotifierProvider.value(
                          value: context.read<PredictionProvider>(),
                          child: const ComparisonPage(),
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.compare_arrows,
                      size: 16, color: Color(0xFFB39DDB)),
                  label: const Text(
                    '对比',
                    style: TextStyle(
                      fontSize: 12,
                      color: Color(0xFFB39DDB),
                    ),
                  ),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...lotteryConfigs.map((config) {
              final key = config['key'] as String;
              final draws = _dataService.getDraws(key);
              final latest = draws.isNotEmpty ? draws.first : null;

              if (latest == null) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(
                    children: [
                      _LotteryBadge(label: config['label'] as String),
                      const SizedBox(width: 12),
                      const Text('暂无数据',
                          style: TextStyle(color: Color(0xFF8B949E))),
                    ],
                  ),
                );
              }

              final mainBalls =
                  (latest['main_balls'] as List<dynamic>?)?.cast<int>() ?? [];
              final bonusBalls =
                  (latest['bonus_balls'] as List<dynamic>?)?.cast<int>() ?? [];
              final period = latest['period']?.toString() ?? '';
              final drawDate = latest['draw_date']?.toString() ?? '';

              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1F2E),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: const Color(0xFF21262D),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        _LotteryBadge(label: config['label'] as String),
                        const SizedBox(width: 10),
                        Text(
                          '第$period期',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          drawDate,
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(
                                color: const Color(0xFF8B949E),
                                fontSize: 11,
                              ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    if (config['isK8'] == true)
                      _buildK8BallsGrid(
                          mainBalls, config['mainColor'] as Color)
                    else
                      Row(
                        children: [
                          Text(
                            '${config['mainLabel']}: ',
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(color: const Color(0xFF8B949E)),
                          ),
                          ...mainBalls.map((n) => Padding(
                                padding: const EdgeInsets.only(right: 5),
                                child: LotteryBall(
                                  number: n.toString().padLeft(2, '0'),
                                  color: config['mainColor'] as Color,
                                  size: 30,
                                ),
                              )),
                          if (bonusBalls.isNotEmpty &&
                              config['bonusLabel'] != '') ...[
                            const SizedBox(width: 8),
                            Text(
                              '${config['bonusLabel']}: ',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(color: const Color(0xFF8B949E)),
                            ),
                            ...bonusBalls.map((n) => Padding(
                                  padding: const EdgeInsets.only(right: 5),
                                  child: LotteryBall(
                                    number: n.toString().padLeft(2, '0'),
                                    color: config['bonusColor'] as Color,
                                    size: 30,
                                  ),
                                )),
                          ],
                        ],
                      ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  // ---- 最近开奖数据 ----
  Widget _buildRecentDraws(
      BuildContext context, LotteryProvider lotteryProvider) {
    final theme = Theme.of(context);
    final lotteryType = lotteryProvider.currentType;
    final allDraws = _dataService.getDraws(lotteryType.apiValue);
    final draws = allDraws.take(_displayedDrawCount).toList();
    final totalDraws = _dataService.getDrawCount(lotteryType.apiValue);
    final hasMore = _displayedDrawCount < totalDraws;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            SectionHeader(
              title: '最近开奖数据 — ${lotteryType.displayName}',
              icon: Icons.history,
              iconColor: const Color(0xFF26C6DA),
              badge: '共 $totalDraws 期',
              badgeColor: const Color(0xFF8B949E),
            ),
            const SizedBox(height: 12),
            if (draws.isEmpty)
              const EmptyState(
                message: '暂无数据',
                padding: EdgeInsets.all(24),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: draws.length + (hasMore ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index >= draws.length) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Center(
                        child: _isLoadingMoreDraws
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Color(0xFF4FC3F7)),
                              )
                            : TextButton.icon(
                                onPressed: () => _loadMoreDraws(),
                                icon: const Icon(Icons.expand_more,
                                    size: 18,
                                    color: Color(0xFF4FC3F7)),
                                label: Text(
                                  '加载更多 (${totalDraws - _displayedDrawCount} 条)',
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0xFF4FC3F7)),
                                ),
                              ),
                      ),
                    );
                  }
                  final draw = draws[index];
                  final mainBalls =
                      (draw['main_balls'] as List<dynamic>?)?.cast<int>() ??
                          [];
                  final bonusBalls =
                      (draw['bonus_balls'] as List<dynamic>?)?.cast<int>() ??
                          [];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1F2E),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 100,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '第${draw['period']}期',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xFFD0D7E2),
                                ),
                              ),
                              Text(
                                draw['draw_date']?.toString() ?? '',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  fontSize: 10,
                                  color: const Color(0xFF8B949E),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: lotteryType == LotteryType.k8
                              ? _buildK8BallsGrid(
                                  mainBalls, lotteryType.mainColor)
                              : Wrap(
                                  spacing: 4,
                                  runSpacing: 4,
                                  children: [
                                    ...mainBalls.map((r) => LotteryBall(
                                          number:
                                              r.toString().padLeft(2, '0'),
                                          color: lotteryType.mainColor,
                                          size: 30,
                                        )),
                                    if (bonusBalls.isNotEmpty) ...[
                                      const SizedBox(width: 4),
                                      ...bonusBalls.map((b) => LotteryBall(
                                            number:
                                                b.toString().padLeft(2, '0'),
                                            color: lotteryType.bonusColor,
                                            size: 30,
                                          )),
                                    ],
                                  ],
                                ),
                        ),
                      ],
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildK8BallsGrid(List<int> balls, Color color) {
    final half = (balls.length / 2).ceil();
    final col1 = balls.take(half).toList();
    final col2 = balls.skip(half).toList();

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Wrap(
            spacing: 4,
            runSpacing: 4,
            children: col1
                .map((n) => LotteryBall(
                      number: n.toString().padLeft(2, '0'),
                      color: color,
                      size: 30,
                    ))
                .toList(),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Wrap(
            spacing: 4,
            runSpacing: 4,
            children: col2
                .map((n) => LotteryBall(
                      number: n.toString().padLeft(2, '0'),
                      color: color,
                      size: 30,
                    ))
                .toList(),
          ),
        ),
      ],
    );
  }

  void _showBacktestResult(
      BuildContext context, PredictionProvider provider) {
    final result = provider.backtestResult;
    if (result == null) return;

    final theme = Theme.of(context);
    final avgScore = result.avgScore;
    final modelPerf = result.modelPerformance;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF161B22),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return DraggableScrollableSheet(
          initialChildSize: 0.65,
          maxChildSize: 0.85,
          minChildSize: 0.4,
          expand: false,
          builder: (ctx, scrollController) {
            return SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 36,
                      height: 4,
                      decoration: BoxDecoration(
                        color: const Color(0xFF30363D),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  const SectionHeader(
                    title: '历史回测结果',
                    subtitle: '最近50期模拟预测准确度分析',
                    icon: Icons.history,
                    iconColor: Color(0xFF4FC3F7),
                  ),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          AppTheme.accentBlue.withOpacity(0.1),
                          AppTheme.accentBlue.withOpacity(0.03),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '平均准确度评分',
                          style: theme.textTheme.titleMedium,
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            gradient: AppTheme.primaryGradient,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            avgScore.toStringAsFixed(1),
                            style: theme.textTheme.headlineMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    '各模型表现',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  ...modelPerf.entries.map((entry) {
                    final name = entry.key;
                    final perf = entry.value;
                    final score = perf.avgScore;
                    final trend = perf.trend;
                    final colors = {
                      'XGBoost': const Color(0xFFFF6B6B),
                      'LSTM': const Color(0xFF5C6BC0),
                      'Transformer': const Color(0xFF66BB6A),
                      'PPO': const Color(0xFF42A5F5),
                      'Statistic': const Color(0xFFFFA726),
                      'Behavior': const Color(0xFFAB47BC),
                    };
                    final color = colors[name] ?? Colors.grey;
                    final trendIcon = trend == 'improving'
                        ? Icons.trending_up
                        : Icons.trending_flat;
                    final trendColor = trend == 'improving'
                        ? AppTheme.accentGreen
                        : AppTheme.accentOrange;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: color,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              name,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Text(
                            score.toStringAsFixed(1),
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: color,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(trendIcon, size: 18, color: trendColor),
                        ],
                      ),
                    );
                  }),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('关闭'),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ---- 私有组件 ----

class _SourceToggle extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final bool isActive;
  final bool isConnected;
  final Color activeColor;
  final VoidCallback onTap;

  const _SourceToggle({
    Key? key,
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.isActive,
    this.isConnected = false,
    required this.activeColor,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final borderColor =
        isActive ? activeColor.withOpacity(0.5) : const Color(0xFF30363D);
    final bgColor = isActive
        ? activeColor.withOpacity(0.08)
        : const Color(0xFF1A1F2E);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: borderColor, width: isActive ? 1.5 : 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 20,
              color: isActive ? activeColor : const Color(0xFF8B949E),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                    color: isActive
                        ? const Color(0xFFE6EDF3)
                        : const Color(0xFF8B949E),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 10,
                    color: isConnected
                        ? AppTheme.accentGreen
                        : const Color(0xFF8B949E),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _LotteryBadge extends StatelessWidget {
  final String label;

  const _LotteryBadge({Key? key, required this.label}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = {
      '双色球': const Color(0xFFFF6B6B),
      '大乐透': const Color(0xFF42A5F5),
      '快乐8': AppTheme.accentOrange,
    };
    final color = colors[label] ?? Colors.grey;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.3), width: 0.5),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: color,
        ),
      ),
    );
  }
}
