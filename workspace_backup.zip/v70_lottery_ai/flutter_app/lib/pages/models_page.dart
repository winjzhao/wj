import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/model_provider.dart';
import '../providers/lottery_provider.dart';
import '../providers/app_state.dart';
import '../providers/evolution_provider.dart';
import '../theme/app_theme.dart';

class ModelsPage extends StatefulWidget {
  const ModelsPage({Key? key}) : super(key: key);

  @override
  State<ModelsPage> createState() => _ModelsPageState();
}

class _ModelsPageState extends State<ModelsPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<ModelProvider>();
      provider.loadModels();
      provider.loadWeights();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ModelProvider>();
    final lotteryProvider = context.watch<LotteryProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text('模型管理 - ${lotteryProvider.currentType.displayName}'),
        actions: [
          TextButton.icon(
            onPressed: provider.isTraining
                ? null
                : () => provider.trainAllModels(),
            icon: const Icon(Icons.play_arrow, size: 18),
            label: const Text('全部训练'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildRunModeBanner(context),
            const SizedBox(height: 14),
            _buildWeightsConfig(context, provider),
            const SizedBox(height: 14),
            _buildModelList(context, provider),
          ],
        ),
      ),
    );
  }

  Widget _buildWeightsConfig(BuildContext context, ModelProvider provider) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.purple.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.tune,
                      size: 18, color: Color(0xFFB39DDB)),
                ),
                const SizedBox(width: 10),
                Text(
                  '融合权重配置',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              '调整各模型在融合决策中的权重占比',
              style: theme.textTheme.bodySmall?.copyWith(
                color: const Color(0xFF8B949E),
              ),
            ),
            const SizedBox(height: 16),
            if (provider.weights.isEmpty)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: CircularProgressIndicator(
                      color: Color(0xFF4FC3F7)),
                ),
              )
            else
              ...provider.weights.entries.map((entry) {
                final colors = {
                  'XGBoost': const Color(0xFFFF6B6B),
                  'LSTM': const Color(0xFF5C6BC0),
                  'Transformer': const Color(0xFF66BB6A),
                  'PPO': const Color(0xFF42A5F5),
                  'Statistic': const Color(0xFFFFA726),
                  'Behavior': const Color(0xFFAB47BC),
                };
                final color = colors[entry.key] ?? Colors.grey;

                return Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: color,
                                  borderRadius:
                                      BorderRadius.circular(2),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(entry.key,
                                  style: theme.textTheme.bodyMedium),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 2),
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.12),
                              borderRadius:
                                  BorderRadius.circular(6),
                            ),
                            child: Text(
                              '${(entry.value * 100).toStringAsFixed(0)}%',
                              style: theme.textTheme.bodyMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: color,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: entry.value,
                          backgroundColor:
                              const Color(0xFF21262D),
                          color: color,
                          minHeight: 6,
                        ),
                      ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _buildModelList(BuildContext context, ModelProvider provider) {
    final theme = Theme.of(context);
    final evolutionProvider = context.watch<EvolutionProvider>();
    final evoPerf = evolutionProvider.modelPerformance;

    final modelIcons = {
      'XGBoost': Icons.auto_graph,
      'LSTM': Icons.memory,
      'Transformer': Icons.psychology,
      'PPO': Icons.smart_toy,
      'Statistic': Icons.bar_chart,
      'Behavior': Icons.trending_up,
    };
    final modelColors = {
      'XGBoost': const Color(0xFFFF6B6B),
      'LSTM': const Color(0xFF5C6BC0),
      'Transformer': const Color(0xFF66BB6A),
      'PPO': const Color(0xFF42A5F5),
      'Statistic': const Color(0xFFFFA726),
      'Behavior': const Color(0xFFAB47BC),
    };

    // 构建进化表现查找表
    final evoMap = <String, Map<String, dynamic>>{};
    for (final ep in evoPerf) {
      evoMap[ep['name'] as String] = ep;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12, left: 4),
          child: Text(
            'AI 模型列表',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        if (provider.models.isEmpty)
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: const Color(0xFF161B22),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: const Color(0xFF21262D), width: 0.5),
            ),
            child: const Center(
              child: Text('暂无模型数据',
                  style: TextStyle(color: Color(0xFF8B949E))),
            ),
          )
        else
          ...provider.models.map((model) {
            final name = model.name;
            final version = model.version ?? '';
            final isTrained = model.isTrained;
            final credibility = model.credibility;
            final perfAvg = model.performanceAvg;
            final icon = modelIcons[name] ?? Icons.model_training;
            final color = modelColors[name] ?? Colors.grey;

            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF161B22),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isTrained
                      ? color.withOpacity(0.3)
                      : const Color(0xFF21262D),
                  width: 0.5,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.12),
                            borderRadius:
                                BorderRadius.circular(12),
                          ),
                          child:
                              Icon(icon, color: color, size: 22),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    name,
                                    style: theme
                                        .textTheme.titleSmall
                                        ?.copyWith(
                                            fontWeight:
                                                FontWeight.bold),
                                  ),
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets
                                        .symmetric(
                                        horizontal: 8,
                                        vertical: 3),
                                    decoration: BoxDecoration(
                                      color: isTrained
                                          ? AppTheme
                                              .accentGreen
                                              .withOpacity(0.12)
                                          : AppTheme
                                              .accentOrange
                                              .withOpacity(0.12),
                                      borderRadius:
                                          BorderRadius.circular(
                                              6),
                                    ),
                                    child: Text(
                                      isTrained
                                          ? '已训练'
                                          : '未训练',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight:
                                            FontWeight.w600,
                                        color: isTrained
                                            ? AppTheme
                                                .accentGreen
                                            : AppTheme
                                                .accentOrange,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '版本 $version',
                                style: theme
                                    .textTheme.bodySmall
                                    ?.copyWith(
                                  color: const Color(0xFF8B949E),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.12),
                            borderRadius:
                                BorderRadius.circular(10),
                          ),
                          child: IconButton(
                            icon: const Icon(
                                Icons.play_circle_outline,
                                size: 20),
                            color: color,
                            onPressed: provider.isTraining
                                ? null
                                : () =>
                                    provider.trainModel(name),
                            tooltip: '训练模型',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _ModelStat(
                            label: '可信度',
                            value:
                                '${(credibility * 100).toStringAsFixed(0)}%',
                            color: color,
                            theme: theme,
                          ),
                        ),
                        Container(
                          width: 1,
                          height: 32,
                          color: const Color(0xFF21262D),
                        ),
                        Expanded(
                          child: _ModelStat(
                            label: '历史表现',
                            value:
                                perfAvg.toStringAsFixed(1),
                            color: color,
                            theme: theme,
                          ),
                        ),
                        if (evoMap.containsKey(name)) ...[
                          Container(
                            width: 1,
                            height: 32,
                            color: const Color(0xFF21262D),
                          ),
                          Expanded(
                            child: _ModelStat(
                              label: '进化命中',
                              value:
                                  '${((evoMap[name]!['hit_rate'] as num?)?.toDouble() ?? 0 * 100).toStringAsFixed(0)}%',
                              color: AppTheme.accentGreen,
                              theme: theme,
                            ),
                          ),
                        ],
                        if (provider.isTraining) ...[
                          const SizedBox(width: 12),
                          const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF4FC3F7)),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }

  Widget _buildRunModeBanner(BuildContext context) {
    final theme = Theme.of(context);
    final appState = context.watch<AppState>();
    final isLocal = appState.connectionMode == ConnectionMode.local;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isLocal
              ? [
                  const Color(0xFF00695C).withOpacity(0.15),
                  const Color(0xFF2E7D32).withOpacity(0.05)
                ]
              : [
                  const Color(0xFF1565C0).withOpacity(0.15),
                  const Color(0xFF7B1FA2).withOpacity(0.05)
                ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isLocal
              ? const Color(0xFF00695C).withOpacity(0.25)
              : const Color(0xFF1565C0).withOpacity(0.25),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isLocal
                  ? const Color(0xFF00695C).withOpacity(0.2)
                  : const Color(0xFF1565C0).withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              isLocal ? Icons.phone_android : Icons.cloud,
              color: isLocal
                  ? const Color(0xFF4DB6AC)
                  : const Color(0xFF64B5F6),
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isLocal ? '本地推理模式' : '后端推理模式',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: isLocal
                        ? const Color(0xFF4DB6AC)
                        : const Color(0xFF64B5F6),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  isLocal
                      ? '6个AI模型均在手机端本地运行，使用内嵌真实开奖数据'
                      : '模型通过后端API推理，地址: ${appState.backendUrl}',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: const Color(0xFF8B949E),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: isLocal
                  ? const Color(0xFF00695C).withOpacity(0.2)
                  : const Color(0xFF1565C0).withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isLocal
                        ? AppTheme.accentGreen
                        : AppTheme.accentBlue,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  isLocal ? '本地运行中' : '后端连接中',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: isLocal
                        ? AppTheme.accentGreen
                        : AppTheme.accentBlue,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ModelStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final ThemeData theme;

  const _ModelStat({
    Key? key,
    required this.label,
    required this.value,
    required this.color,
    required this.theme,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: const Color(0xFF8B949E),
            fontSize: 11,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }
}
