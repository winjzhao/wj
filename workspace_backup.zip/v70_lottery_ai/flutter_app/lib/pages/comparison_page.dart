import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/prediction_provider.dart';
import '../providers/lottery_provider.dart';
import '../models/comparison_data.dart';
import '../theme/app_theme.dart';

/// 预测 vs 开奖 对比页面
class ComparisonPage extends StatefulWidget {
  const ComparisonPage({Key? key}) : super(key: key);

  @override
  State<ComparisonPage> createState() => _ComparisonPageState();
}

class _ComparisonPageState extends State<ComparisonPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PredictionProvider>().loadComparison();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PredictionProvider>();
    final lotteryProvider = context.watch<LotteryProvider>();
    final summary = provider.comparisonSummary;
    final isLoading = provider.isLoadingComparison;

    return Scaffold(
      appBar: AppBar(
        title: const Text('预测对比'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF8B949E)),
            onPressed: () => provider.loadComparison(),
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : summary == null || summary.comparisons.isEmpty
              ? const _EmptyComparisonView()
              : SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildSummaryCards(context, summary),
                      const SizedBox(height: 14),
                      _buildComparisonList(context, summary, lotteryProvider),
                    ],
                  ),
                ),
    );
  }

  Widget _buildSummaryCards(BuildContext context, ComparisonSummary summary) {
    return Row(
      children: [
        Expanded(
          child: _SummaryCard(
            title: '对比期数',
            value: '${summary.total}',
            icon: Icons.compare_arrows,
            color: AppTheme.accentBlue,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _SummaryCard(
            title: '平均命中数',
            value: summary.avgHit.toStringAsFixed(1),
            icon: Icons.check_circle,
            color: AppTheme.accentGreen,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _SummaryCard(
            title: '命中率',
            value: '${(summary.avgHitRate * 100).toStringAsFixed(1)}%',
            icon: Icons.trending_up,
            color: AppTheme.accentAmber,
          ),
        ),
      ],
    );
  }

  Widget _buildComparisonList(
    BuildContext context,
    ComparisonSummary summary,
    LotteryProvider lotteryProvider,
  ) {
    final theme = Theme.of(context);
    final lotteryType = lotteryProvider.currentType;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentPurple.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.compare_arrows,
                      size: 18, color: Color(0xFFB39DDB)),
                ),
                const SizedBox(width: 10),
                Text(
                  '预测 vs 开奖 逐期对比',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF21262D),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '共 ${summary.total} 期',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: const Color(0xFF8B949E),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...summary.comparisons.map((item) {
              return _ComparisonItem(
                comparison: item,
                lotteryType: lotteryType,
              );
            }),
          ],
        ),
      ),
    );
  }
}

class _ComparisonItem extends StatelessWidget {
  final PredictionComparison comparison;
  final LotteryType lotteryType;

  const _ComparisonItem({
    Key? key,
    required this.comparison,
    required this.lotteryType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hitRate = (comparison.matchHitRate ?? 0) * 100;
    final totalHits = comparison.matchTotal ?? 0;

    // 命中率颜色
    Color hitColor;
    if (hitRate >= 50) {
      hitColor = AppTheme.accentGreen;
    } else if (hitRate >= 25) {
      hitColor = AppTheme.accentAmber;
    } else {
      hitColor = AppTheme.accentRed;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F2E),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF21262D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 期号 + 命中统计
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.accentBlue.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '第${comparison.period}期',
                  style: theme.textTheme.bodySmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.accentBlue,
                  ),
                ),
              ),
              const Spacer(),
              // 命中统计
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: hitColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle, size: 14, color: hitColor),
                    const SizedBox(width: 4),
                    Text(
                      '命中 $totalHits 球  (${hitRate.toStringAsFixed(0)}%)',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: hitColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // 预测号码行
          _buildBallRow(
            context: context,
            label: 'AI预测',
            mainBalls: comparison.predictedMain,
            bonusBalls: comparison.predictedBonus,
            actualMain: comparison.actualMain,
            actualBonus: comparison.actualBonus,
            isPrediction: true,
          ),
          const SizedBox(height: 6),

          // 实际开奖行
          _buildBallRow(
            context: context,
            label: '实际开奖',
            mainBalls: comparison.actualMain,
            bonusBalls: comparison.actualBonus,
            actualMain: comparison.actualMain,
            actualBonus: comparison.actualBonus,
            isPrediction: false,
          ),

          // 命中详情
          if (comparison.matchMainCount != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                _HitBadge(
                  label: '主球: ${comparison.matchMainCount}',
                  color: AppTheme.accentGreen,
                ),
                const SizedBox(width: 8),
                _HitBadge(
                  label: '附加球: ${comparison.matchBonusCount}',
                  color: AppTheme.accentAmber,
                ),
                if (comparison.modelName.isNotEmpty) ...[
                  const Spacer(),
                  Text(
                    comparison.modelName,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: const Color(0xFF6E7681),
                      fontSize: 10,
                    ),
                  ),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildBallRow({
    required BuildContext context,
    required String label,
    required List<int> mainBalls,
    required List<int> bonusBalls,
    required List<int> actualMain,
    required List<int> actualBonus,
    required bool isPrediction,
  }) {
    final theme = Theme.of(context);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 56,
          child: Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: const Color(0xFF8B949E),
              fontWeight: FontWeight.w600,
              fontSize: 11,
            ),
          ),
        ),
        Expanded(
          child: Wrap(
            spacing: 5,
            runSpacing: 5,
            children: [
              ...mainBalls.map((ball) {
                final isHit =
                    isPrediction && actualMain.contains(ball);
                final isMiss =
                    isPrediction && !actualMain.contains(ball);
                return _ComparisonBall(
                  number: ball,
                  color: lotteryType.mainColor,
                  state: isPrediction
                      ? (isHit
                          ? BallState.hit
                          : BallState.miss)
                      : BallState.actual,
                );
              }),
              if (bonusBalls.isNotEmpty) ...[
                const SizedBox(width: 4),
                ...bonusBalls.map((ball) {
                  final isHit =
                      isPrediction && actualBonus.contains(ball);
                  final isMiss =
                      isPrediction && !actualBonus.contains(ball);
                  return _ComparisonBall(
                    number: ball,
                    color: lotteryType.bonusColor,
                    state: isPrediction
                        ? (isHit
                            ? BallState.hit
                            : BallState.miss)
                        : BallState.actual,
                  );
                }),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

enum BallState { hit, miss, actual }

class _ComparisonBall extends StatelessWidget {
  final int number;
  final Color color;
  final BallState state;
  final double size;

  const _ComparisonBall({
    Key? key,
    required this.number,
    required this.color,
    required this.state,
    this.size = 30,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color bgColor;
    Color textColor;
    double opacity;
    IconData? icon;

    switch (state) {
      case BallState.hit:
        bgColor = AppTheme.accentGreen;
        textColor = Colors.white;
        opacity = 1.0;
        icon = Icons.check;
        break;
      case BallState.miss:
        bgColor = Colors.grey.shade700;
        textColor = Colors.white38;
        opacity = 0.45;
        break;
      case BallState.actual:
        bgColor = color;
        textColor = Colors.white;
        opacity = 0.9;
        break;
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            bgColor.withOpacity(opacity + 0.1 > 1 ? 1 : opacity + 0.1),
            bgColor.withOpacity(opacity),
          ],
          center: const Alignment(-0.3, -0.3),
        ),
        boxShadow: state == BallState.hit
            ? [
                BoxShadow(
                  color: AppTheme.accentGreen.withOpacity(0.4),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ]
            : [],
      ),
      alignment: Alignment.center,
      child: state == BallState.hit
          ? Icon(icon, size: size * 0.45, color: textColor)
          : Text(
              number.toString().padLeft(2, '0'),
              style: TextStyle(
                color: textColor,
                fontWeight: FontWeight.bold,
                fontSize: size * 0.35,
              ),
            ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  const _SummaryCard({
    Key? key,
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF161B22),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 22, color: color),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(
              fontSize: 11,
              color: Color(0xFF8B949E),
            ),
          ),
        ],
      ),
    );
  }
}

class _HitBadge extends StatelessWidget {
  final String label;
  final Color color;

  const _HitBadge({
    Key? key,
    required this.label,
    required this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: color,
        ),
      ),
    );
  }
}

class _EmptyComparisonView extends StatelessWidget {
  const _EmptyComparisonView();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.compare_arrows,
              size: 64, color: Colors.grey.withOpacity(0.3)),
          const SizedBox(height: 16),
          const Text(
            '暂无对比数据',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Color(0xFF8B949E),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            '需要先生成AI预测，等开奖后再进行对比',
            style: TextStyle(
              fontSize: 13,
              color: Color(0xFF6E7681),
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              context.read<PredictionProvider>().loadComparison();
            },
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('刷新'),
            style: ElevatedButton.styleFrom(
              padding:
                  const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
