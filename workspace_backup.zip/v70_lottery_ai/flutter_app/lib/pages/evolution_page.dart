import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/evolution_provider.dart';
import '../providers/lottery_provider.dart';
import '../theme/app_theme.dart';

class EvolutionPage extends StatefulWidget {
  const EvolutionPage({Key? key}) : super(key: key);

  @override
  State<EvolutionPage> createState() => _EvolutionPageState();
}

class _EvolutionPageState extends State<EvolutionPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<EvolutionProvider>();
      final lotteryProvider = context.read<LotteryProvider>();
      provider.updateLotteryType(lotteryProvider.currentType.apiValue);
      provider.loadEvolutionStatus();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<EvolutionProvider>();
    final lotteryProvider = context.watch<LotteryProvider>();

    return Scaffold(
      appBar: AppBar(
        title:
            Text('进化中心 - ${lotteryProvider.currentType.displayName}'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Color(0xFF8B949E)),
            color: const Color(0xFF21262D),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            onSelected: (value) {
              if (value == 'reset_weights') {
                _showConfirmDialog(
                  context,
                  '重置权重',
                  '确定要将融合权重重置为默认值吗？',
                  () => provider.resetWeights(),
                );
              } else if (value == 'reset_all') {
                _showConfirmDialog(
                  context,
                  '重置进化数据',
                  '确定要清除所有进化历史数据，从头开始吗？',
                  () => provider.resetEvolution(),
                );
              }
            },
            itemBuilder: (ctx) => [
              PopupMenuItem(
                value: 'reset_weights',
                child: Row(
                  children: const [
                    Icon(Icons.refresh, size: 18, color: Color(0xFFFFB74D)),
                    SizedBox(width: 10),
                    Text('重置权重'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'reset_all',
                child: Row(
                  children: const [
                    Icon(Icons.delete_outline, size: 18,
                        color: Color(0xFFFF6E6E)),
                    SizedBox(width: 10),
                    Text('清除进化数据'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: provider.isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF4FC3F7)))
          : SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildEvolutionOverview(context, provider),
                  const SizedBox(height: 14),
                  _buildTriggerButton(context, provider),
                  const SizedBox(height: 14),
                  _buildModelPerformance(context, provider),
                  const SizedBox(height: 14),
                  _buildWeightEvolution(context, provider),
                  const SizedBox(height: 14),
                  _buildEvolutionHistory(context, provider),
                ],
              ),
            ),
    );
  }

  // ============================================================
  // 进化概览卡片
  // ============================================================

  Widget _buildEvolutionOverview(
      BuildContext context, EvolutionProvider provider) {
    final theme = Theme.of(context);
    final status = provider.evolutionStatus;
    final lastEvo = status?.lastEvolution?.toIso8601String();
    final totalCycles = status?.totalCycles ?? 0;
    final matchedCount = status?.matchedCount ?? 0;
    final cycleDuration = status?.cycleDurationMs ?? 0;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [
              const Color(0xFF4FC3F7).withOpacity(0.05),
              const Color(0xFFAB47BC).withOpacity(0.03),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF4FC3F7), Color(0xFFAB47BC)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.auto_awesome,
                      size: 22, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '自学习进化引擎',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        lastEvo != null
                            ? '上次进化: ${_formatTime(lastEvo)}'
                            : '等待首次进化...',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: const Color(0xFF8B949E),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: (status != null)
                        ? AppTheme.accentGreen.withOpacity(0.12)
                        : const Color(0xFF484F58).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: (status != null)
                          ? AppTheme.accentGreen.withOpacity(0.3)
                          : const Color(0xFF484F58).withOpacity(0.3),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: (status != null)
                              ? AppTheme.accentGreen
                              : const Color(0xFF484F58),
                          boxShadow: (status != null)
                              ? [
                                  BoxShadow(
                                    color: AppTheme.accentGreen
                                        .withOpacity(0.5),
                                    blurRadius: 4,
                                    spreadRadius: 1,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        (status != null) ? '运行中' : '待启动',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: (status != null)
                              ? AppTheme.accentGreen
                              : const Color(0xFF8B949E),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _OverviewStat(
                    icon: Icons.loop,
                    label: '进化周期',
                    value: '$totalCycles',
                    color: const Color(0xFF4FC3F7),
                    theme: theme,
                  ),
                ),
                Container(width: 1, height: 40, color: const Color(0xFF21262D)),
                Expanded(
                  child: _OverviewStat(
                    icon: Icons.checklist,
                    label: '已匹配',
                    value: '$matchedCount',
                    color: AppTheme.accentGreen,
                    theme: theme,
                  ),
                ),
                Container(width: 1, height: 40, color: const Color(0xFF21262D)),
                Expanded(
                  child: _OverviewStat(
                    icon: Icons.timer_outlined,
                    label: '耗时',
                    value: '${(cycleDuration / 1000).toStringAsFixed(1)}s',
                    color: const Color(0xFFFFB74D),
                    theme: theme,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 手动触发进化按钮
  // ============================================================

  Widget _buildTriggerButton(
      BuildContext context, EvolutionProvider provider) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: provider.isEvolving
            ? null
            : () async {
                final result = await provider.triggerEvolution();
                if (mounted) {
                  final status = result.status;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(status == 'completed'
                          ? '进化完成！权重已更新'
                          : '进化状态: $status'),
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
        icon: provider.isEvolving
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
            : const Icon(Icons.rocket_launch, size: 20),
        label: Text(provider.isEvolving ? '进化中...' : '手动触发进化'),
        style: ElevatedButton.styleFrom(
          primary: const Color(0xFF6C3FA0),
          onPrimary: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
        ),
      ),
    );
  }

  // ============================================================
  // 各模型进化表现
  // ============================================================

  Widget _buildModelPerformance(
      BuildContext context, EvolutionProvider provider) {
    final theme = Theme.of(context);
    final models = provider.modelPerformance;

    final modelColors = {
      'XGBoost': const Color(0xFFFF6B6B),
      'LSTM': const Color(0xFF5C6BC0),
      'Transformer': const Color(0xFF66BB6A),
      'PPO': const Color(0xFF42A5F5),
      'Statistic': const Color(0xFFFFA726),
      'Behavior': const Color(0xFFAB47BC),
    };
    final modelIcons = {
      'XGBoost': Icons.auto_graph,
      'LSTM': Icons.memory,
      'Transformer': Icons.psychology,
      'PPO': Icons.smart_toy,
      'Statistic': Icons.bar_chart,
      'Behavior': Icons.trending_up,
    };
    final trendIcons = {
      'improving': Icons.trending_up,
      'stable': Icons.trending_flat,
      'declining': Icons.trending_down,
    };
    final trendColors = {
      'improving': AppTheme.accentGreen,
      'stable': const Color(0xFFFFB74D),
      'declining': AppTheme.accentRed,
    };
    final trendLabels = {
      'improving': '上升',
      'stable': '稳定',
      'declining': '下降',
    };

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentCyan.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.insights,
                      size: 18, color: Color(0xFF26C6DA)),
                ),
                const SizedBox(width: 10),
                Text(
                  '模型进化表现',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (models.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(
                  child: Text('暂无进化数据，请先触发进化周期',
                      style: TextStyle(color: Color(0xFF8B949E))),
                ),
              )
            else
              ...models.map((model) {
                final name = model['name'] as String? ?? '';
                final color = modelColors[name] ?? Colors.grey;
                final icon = modelIcons[name] ?? Icons.model_training;
                final hitRate =
                    (model['hit_rate'] as num?)?.toDouble() ?? 0;
                final precision =
                    (model['precision'] as num?)?.toDouble() ?? 0;
                final recall =
                    (model['recall'] as num?)?.toDouble() ?? 0;
                final trend = model['trend'] as String? ?? 'stable';
                final matched =
                    model['matched_count'] as int? ?? 0;
                final trendIcon = trendIcons[trend] ?? Icons.trending_flat;
                final trendColor =
                    trendColors[trend] ?? const Color(0xFFFFB74D);
                final trendLabel = trendLabels[trend] ?? '稳定';

                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: color.withOpacity(0.15),
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(icon, color: color, size: 18),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              name,
                              style: theme.textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: trendColor.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(trendIcon,
                                    size: 14, color: trendColor),
                                const SizedBox(width: 4),
                                Text(
                                  trendLabel,
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: trendColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _PerfStat(
                              label: '命中率',
                              value: '${(hitRate * 100).toStringAsFixed(1)}%',
                              color: color),
                          const SizedBox(width: 16),
                          _PerfStat(
                              label: '精准率',
                              value:
                                  '${(precision * 100).toStringAsFixed(1)}%',
                              color: color),
                          const SizedBox(width: 16),
                          _PerfStat(
                              label: '召回率',
                              value:
                                  '${(recall * 100).toStringAsFixed(1)}%',
                              color: color),
                          const Spacer(),
                          _PerfStat(
                              label: '匹配', value: '$matched', color: color),
                        ],
                      ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 权重演变
  // ============================================================

  Widget _buildWeightEvolution(
      BuildContext context, EvolutionProvider provider) {
    final theme = Theme.of(context);
    final weights = provider.currentWeights;

    final modelColors = {
      'XGBoost': const Color(0xFFFF6B6B),
      'LSTM': const Color(0xFF5C6BC0),
      'Transformer': const Color(0xFF66BB6A),
      'PPO': const Color(0xFF42A5F5),
      'Statistic': const Color(0xFFFFA726),
      'Behavior': const Color(0xFFAB47BC),
    };

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.purple.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.show_chart,
                      size: 18, color: Color(0xFFB39DDB)),
                ),
                const SizedBox(width: 10),
                Text(
                  '融合权重 (动态进化)',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppTheme.accentPurple.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text(
                    'EWMA 自适应',
                    style: TextStyle(
                      fontSize: 10,
                      color: Color(0xFFB39DDB),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (weights.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(
                  child: Text('等待权重初始化...',
                      style: TextStyle(color: Color(0xFF8B949E))),
                ),
              )
            else
              ...weights.entries.map((entry) {
                final color = modelColors[entry.key] ?? Colors.grey;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: color,
                                  borderRadius: BorderRadius.circular(2),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(entry.key,
                                  style: theme.textTheme.bodyMedium),
                            ],
                          ),
                          Text(
                            '${(entry.value * 100).toStringAsFixed(1)}%',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: color,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 5),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: entry.value,
                          backgroundColor: const Color(0xFF21262D),
                          color: color,
                          minHeight: 6,
                        ),
                      ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 进化历史
  // ============================================================

  Widget _buildEvolutionHistory(
      BuildContext context, EvolutionProvider provider) {
    final theme = Theme.of(context);
    final history = provider.evolutionHistory;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentOrange.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.history,
                      size: 18, color: Color(0xFFFFB74D)),
                ),
                const SizedBox(width: 10),
                Text(
                  '进化历史',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (history.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(
                  child: Text('暂无进化历史',
                      style: TextStyle(color: Color(0xFF8B949E))),
                ),
              )
            else
              ...history.map((entry) {
                final cycle = entry.cycle;
                final ts = entry.timestamp?.toIso8601String() ?? '';
                final matched = entry.matchedCount;
                final bestModel = entry.bestModel;
                final bestScore = entry.bestScore;

                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF21262D),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: AppTheme.accentBlue.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Text(
                            '#$cycle',
                            style: const TextStyle(
                              color: Color(0xFF4FC3F7),
                              fontWeight: FontWeight.bold,
                              fontSize: 11,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _formatTime(ts),
                              style: theme.textTheme.bodyMedium,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '匹配 $matched 条 | 最佳: $bestModel (${(bestScore * 100).toStringAsFixed(1)}%)',
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: const Color(0xFF8B949E),
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.chevron_right,
                          size: 18, color: Color(0xFF484F58)),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 工具方法
  // ============================================================

  String _formatTime(String iso) {
    try {
      final dt = DateTime.parse(iso);
      return '${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')} '
          '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }

  void _showConfirmDialog(
      BuildContext context, String title, String message, VoidCallback onConfirm) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF161B22),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Text(title,
            style: const TextStyle(color: Color(0xFFE6EDF3))),
        content: Text(message,
            style: const TextStyle(color: Color(0xFF8B949E))),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消',
                style: TextStyle(color: Color(0xFF8B949E))),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              onConfirm();
            },
            style: ElevatedButton.styleFrom(
              primary: AppTheme.accentRed,
              onPrimary: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// 子组件
// ============================================================

class _OverviewStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final ThemeData theme;

  const _OverviewStat({
    Key? key,
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
    required this.theme,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, size: 20, color: color),
        const SizedBox(height: 6),
        Text(
          value,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: const Color(0xFF8B949E),
            fontSize: 11,
          ),
        ),
      ],
    );
  }
}

class _PerfStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _PerfStat({
    Key? key,
    required this.label,
    required this.value,
    required this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 10,
            color: Color(0xFF8B949E),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }
}
