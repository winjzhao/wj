import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../providers/lottery_provider.dart';
import '../services/lottery_data_service.dart';
import '../theme/app_theme.dart';

class DataPage extends StatefulWidget {
  const DataPage({Key? key}) : super(key: key);

  @override
  State<DataPage> createState() => _DataPageState();
}

class _DataPageState extends State<DataPage> {
  final LotteryDataService _dataService = LotteryDataService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppState>().loadSystemStatus();
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final lotteryProvider = context.watch<LotteryProvider>();
    final isLocal = appState.connectionMode == ConnectionMode.local;

    return Scaffold(
      appBar: AppBar(
        title: const Text('数据中心'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDataOverview(context),
            const SizedBox(height: 14),
            _buildDataSourceInfo(context),
            const SizedBox(height: 14),
            _buildDataActions(context, appState, isLocal),
          ],
        ),
      ),
    );
  }

  Widget _buildDataOverview(BuildContext context) {
    final theme = Theme.of(context);
    final ssqCount = _dataService.getDrawCount('ssq');
    final dltCount = _dataService.getDrawCount('dlt');
    final k8Count = _dataService.getDrawCount('k8');
    final total = ssqCount + dltCount + k8Count;

    return Row(
      children: [
        Expanded(
          child: _DataCard(
            icon: Icons.storage,
            value: '$total',
            label: '总数据量',
            gradient: AppTheme.primaryGradient,
            theme: theme,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _DataCard(
            icon: Icons.update,
            value: _dataService.generatedAt.isNotEmpty
                ? _dataService.generatedAt.substring(0, 10)
                : '--',
            label: '数据更新日',
            gradient: AppTheme.amberGradient,
            theme: theme,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _DataCard(
            icon: Icons.verified,
            value: '真实',
            label: '数据来源',
            gradient: const LinearGradient(
              colors: [Color(0xFF69F0AE), Color(0xFF43A047)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            theme: theme,
          ),
        ),
      ],
    );
  }

  Widget _buildDataSourceInfo(BuildContext context) {
    final theme = Theme.of(context);
    final sources = _dataService.dataSources;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentCyan.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.cloud_download,
                      size: 18, color: Color(0xFF26C6DA)),
                ),
                const SizedBox(width: 10),
                Text(
                  '数据采集流程',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildStep(context, '双色球 SSQ', sources['ssq'] ?? '中彩网', true,
                const Color(0xFFFF6B6B)),
            _buildStep(context, '大乐透 DLT', sources['dlt'] ?? '体彩网', true,
                const Color(0xFF42A5F5)),
            _buildStep(context, '快乐8 K8', sources['k8'] ?? '中彩网', true,
                AppTheme.accentOrange),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1F2E),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF21262D)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline,
                      size: 16, color: Color(0xFF8B949E)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '数据来自中国福利彩票和体育彩票官方API，每种彩票包含近300期开奖记录',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: const Color(0xFF8B949E),
                        fontSize: 11,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStep(BuildContext context, String title, String desc,
      bool completed, Color color) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: completed
                  ? color.withOpacity(0.12)
                  : Colors.grey.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: completed
                    ? color.withOpacity(0.3)
                    : Colors.grey.withOpacity(0.2),
              ),
            ),
            child: Icon(
              completed ? Icons.check : Icons.hourglass_empty,
              color: completed ? color : const Color(0xFF8B949E),
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 2),
              Text(desc,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: const Color(0xFF8B949E),
                    fontSize: 12,
                  )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDataActions(
      BuildContext context, AppState appState, bool isLocal) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentPurple.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.settings_applications,
                      size: 18, color: Color(0xFFB39DDB)),
                ),
                const SizedBox(width: 10),
                Text(
                  '数据操作',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: (isLocal
                        ? AppTheme.accentGreen
                        : AppTheme.accentBlue)
                    .withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: (isLocal
                          ? AppTheme.accentGreen
                          : AppTheme.accentBlue)
                      .withOpacity(0.2),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: (isLocal
                              ? AppTheme.accentGreen
                              : AppTheme.accentBlue)
                          .withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      isLocal ? Icons.phone_android : Icons.cloud,
                      size: 20,
                      color: isLocal
                          ? AppTheme.accentGreen
                          : AppTheme.accentBlue,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isLocal ? '当前使用本地数据' : '当前使用云端数据',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          isLocal
                              ? '数据源切换请前往"仪表盘"页面'
                              : '后端地址: ${appState.backendUrl}',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: const Color(0xFF8B949E),
                            fontSize: 11,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: Container(
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.accentBlue.withOpacity(0.3),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ElevatedButton.icon(
                  onPressed: appState.isLoading
                      ? null
                      : () async {
                          await appState.refreshData();
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                appState.isBackendConnected
                                    ? '数据刷新成功'
                                    : isLocal
                                        ? '本地数据已是最新'
                                        : '刷新失败，请检查后端连接',
                              ),
                              duration: const Duration(seconds: 1),
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(10),
                              ),
                            ),
                          );
                        },
                  icon: appState.isLoading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.refresh, color: Colors.white),
                  label: Text(
                    appState.isLoading ? '刷新中...' : '刷新数据',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DataCard extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final LinearGradient gradient;
  final ThemeData theme;

  const _DataCard({
    Key? key,
    required this.icon,
    required this.value,
    required this.label,
    required this.gradient,
    required this.theme,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF161B22),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF21262D)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: gradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(height: 12),
          Text(
            value,
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
              color: const Color(0xFFE6EDF3),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: const Color(0xFF8B949E),
            ),
          ),
        ],
      ),
    );
  }
}
