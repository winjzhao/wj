import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../providers/prediction_provider.dart';
import '../providers/lottery_provider.dart';
import '../theme/app_theme.dart';
import 'comparison_page.dart';

class PredictionPage extends StatefulWidget {
  const PredictionPage({Key? key}) : super(key: key);

  @override
  State<PredictionPage> createState() => _PredictionPageState();
}

class _PredictionPageState extends State<PredictionPage> {
  static const int _pageSize = 20;

  final ScrollController _scrollController = ScrollController();
  final ScrollController _historyScrollController = ScrollController();
  int _displayedCount = 10;
  bool _isLoadingMore = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PredictionProvider>().loadHistory();
    });
    _historyScrollController.addListener(_onHistoryScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _historyScrollController.removeListener(_onHistoryScroll);
    _historyScrollController.dispose();
    super.dispose();
  }

  void _onHistoryScroll() {
    if (_historyScrollController.position.pixels >=
        _historyScrollController.position.maxScrollExtent - 100) {
      _loadMoreHistory();
    }
  }

  void _loadMoreHistory() {
    final provider = context.read<PredictionProvider>();
    if (_isLoadingMore || _displayedCount >= provider.history.length) return;

    setState(() {
      _isLoadingMore = true;
    });

    Future.delayed(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      setState(() {
        _displayedCount = (_displayedCount + _pageSize)
            .clamp(0, provider.history.length);
        _isLoadingMore = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PredictionProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('预测中心'),
        actions: [
          IconButton(
            icon: const Icon(Icons.compare_arrows, color: Color(0xFFB39DDB)),
            tooltip: '预测对比',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChangeNotifierProvider.value(
                    value: provider,
                    child: const ComparisonPage(),
                  ),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF8B949E)),
            onPressed: () => provider.loadHistory(),
          ),
        ],
      ),
      body: SingleChildScrollView(
        controller: _scrollController,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildPredictionGenerator(context, provider),
            const SizedBox(height: 14),
            if (provider.candidates.isNotEmpty) ...[
              _buildCandidatesList(context, provider),
              const SizedBox(height: 14),
            ],
            if (provider.backtestResult != null) ...[
              _buildBacktestResults(context, provider),
              const SizedBox(height: 14),
            ],
            _buildPredictionHistory(context, provider),
          ],
        ),
      ),
    );
  }

  Widget _buildPredictionGenerator(
      BuildContext context, PredictionProvider provider) {
    final theme = Theme.of(context);
    final lotteryProvider = context.watch<LotteryProvider>();
    final lotteryType = lotteryProvider.currentType;

    String lotteryDesc;
    switch (lotteryType) {
      case LotteryType.ssq:
        lotteryDesc =
            '基于 XGBoost + LSTM + Transformer + PPO\n+ 统计 + 行为分析，6模型融合决策';
        break;
      case LotteryType.dlt:
        lotteryDesc = '基于 XGBoost + LSTM + Transformer + PPO\n大乐透6模型融合决策';
        break;
      case LotteryType.k8:
        lotteryDesc = '基于 XGBoost + LSTM + Transformer + PPO\n快乐8六模型融合决策';
        break;
    }

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: AppTheme.accentBlue.withOpacity(0.3),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: AppTheme.primaryGradient,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.accentBlue.withOpacity(0.3),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(
                Icons.auto_awesome,
                size: 36,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              'AI 融合预测引擎',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1F2E),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                lotteryDesc,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: const Color(0xFF8B949E),
                  height: 1.5,
                ),
              ),
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: Container(
                decoration: BoxDecoration(
                  gradient: provider.isGenerating
                      ? const LinearGradient(
                          colors: [Color(0xFF30363D), Color(0xFF21262D)])
                      : AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: provider.isGenerating
                      ? []
                      : [
                          BoxShadow(
                            color: AppTheme.accentBlue.withOpacity(0.3),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                ),
                child: ElevatedButton.icon(
                  onPressed: provider.isGenerating
                      ? null
                      : () => provider.generatePrediction(),
                  icon: provider.isGenerating
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.auto_awesome,
                          size: 22, color: Colors.white),
                  label: Text(
                    provider.isGenerating ? 'AI正在分析...' : '开始AI预测',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ),
            if (provider.finalScore > 0) ...[
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.accentAmber.withOpacity(0.1),
                      AppTheme.accentAmber.withOpacity(0.03),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: AppTheme.accentAmber.withOpacity(0.25),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      '融合评分: ',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xFFE6EDF3),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: AppTheme.amberGradient,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        provider.finalScore.toStringAsFixed(1),
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1A1A1A),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCandidatesList(
      BuildContext context, PredictionProvider provider) {
    final theme = Theme.of(context);
    final lotteryProvider = context.watch<LotteryProvider>();
    final lotteryType = lotteryProvider.currentType;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentAmber.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.emoji_events,
                      size: 18, color: Color(0xFFFFB300)),
                ),
                const SizedBox(width: 10),
                Text(
                  'TOP 候选方案',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF21262D),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '共${provider.candidates.length}组',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: const Color(0xFF8B949E),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...provider.candidates.asMap().entries.map((entry) {
              final idx = entry.key;
              final candidate = entry.value;
              final mainBalls = candidate.mainBalls;
              final bonusBalls = candidate.bonusBalls;
              final score = candidate.score;

              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1F2E),
                  borderRadius: BorderRadius.circular(12),
                  border: idx == 0
                      ? Border.all(
                          color: AppTheme.accentAmber.withOpacity(0.5),
                          width: 1.5,
                        )
                      : Border.all(color: const Color(0xFF21262D)),
                ),
                child: Row(
                  children: [
                    if (idx == 0) ...[
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          gradient: AppTheme.amberGradient,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.star,
                            color: Color(0xFF1A1A1A), size: 16),
                      ),
                      const SizedBox(width: 10),
                    ] else ...[
                      SizedBox(
                        width: 28,
                        child: Text(
                          '#${idx + 1}',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: const Color(0xFF8B949E),
                          ),
                        ),
                      ),
                    ],
                    Expanded(
                      child: Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          ...mainBalls.map((r) => _BallWidget(
                                number: r.toString(),
                                color: lotteryType.mainColor,
                                size: 32,
                              )),
                          if (bonusBalls.isNotEmpty) ...[
                            const SizedBox(width: 2),
                            ...bonusBalls.map((b) => _BallWidget(
                                  number: b.toString(),
                                  color: lotteryType.bonusColor,
                                  size: 32,
                                )),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppTheme.accentBlue.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            '${score.toStringAsFixed(0)}分',
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: AppTheme.accentBlue,
                            ),
                          ),
                        ),
                        if (idx == 0) ...[
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              gradient: AppTheme.amberGradient,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              '推荐',
                              style: TextStyle(
                                fontSize: 10,
                                color: Color(0xFF1A1A1A),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildBacktestResults(
      BuildContext context, PredictionProvider provider) {
    final theme = Theme.of(context);
    final backtest = provider.backtestResult!;
    final trend = backtest.accuracyTrend;
    final modelPerf = backtest.modelPerformance;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentGreen.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.history,
                      size: 18, color: Color(0xFF69F0AE)),
                ),
                const SizedBox(width: 10),
                Text(
                  '回测结果',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: AppTheme.primaryGradient,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '平均分: ${backtest.avgScore.toStringAsFixed(1)}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (trend.isNotEmpty)
              SizedBox(
                height: 200,
                child: LineChart(
                  LineChartData(
                    gridData: FlGridData(
                      show: true,
                      drawVerticalLine: false,
                      horizontalInterval: 10,
                      getDrawingHorizontalLine: (value) => FlLine(
                        color: const Color(0xFF21262D),
                        strokeWidth: 0.5,
                      ),
                    ),
                    titlesData: FlTitlesData(
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 30,
                          getTitlesWidget: (value, meta) => Text(
                            '${value.toInt()}',
                            style: const TextStyle(
                              color: Color(0xFF6E7681),
                              fontSize: 9,
                            ),
                          ),
                          interval: 10,
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 22,
                          getTitlesWidget: (value, meta) {
                            if (value.toInt() % 5 == 0) {
                              return Text(
                                '${value.toInt()}',
                                style: const TextStyle(
                                  color: Color(0xFF6E7681),
                                  fontSize: 9,
                                ),
                              );
                            }
                            return const SizedBox.shrink();
                          },
                        ),
                      ),
                      topTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      rightTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                    ),
                    borderData: FlBorderData(
                      show: true,
                      border: const Border(
                        left: BorderSide(
                            color: Color(0xFF21262D), width: 0.5),
                        bottom: BorderSide(
                            color: Color(0xFF21262D), width: 0.5),
                      ),
                    ),
                    lineBarsData: [
                      LineChartBarData(
                        spots: trend.asMap().entries.map((e) {
                          return FlSpot(e.key.toDouble(), e.value);
                        }).toList(),
                        isCurved: true,
                        color: AppTheme.accentBlue,
                        barWidth: 2.5,
                        dotData: FlDotData(
                          show: true,
                          getDotPainter:
                              (spot, percent, barData, index) =>
                                  FlDotCirclePainter(
                            radius: 2.5,
                            color: AppTheme.accentBlue,
                            strokeWidth: 0,
                          ),
                        ),
                        belowBarData: BarAreaData(
                          show: true,
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              AppTheme.accentBlue.withOpacity(0.15),
                              AppTheme.accentBlue.withOpacity(0.01),
                            ],
                          ),
                        ),
                      ),
                      if (trend.length > 3)
                        LineChartBarData(
                          spots: _computeMovingAverage(trend, 3)
                              .asMap()
                              .entries
                              .map((e) {
                            return FlSpot(
                                e.key.toDouble() + 1, e.value);
                          }).toList(),
                          isCurved: true,
                          color: AppTheme.accentGreen.withOpacity(0.6),
                          barWidth: 1.5,
                          dotData: FlDotData(show: false),
                          dashArray: [5, 5],
                          belowBarData: BarAreaData(show: false),
                        ),
                    ],
                    lineTouchData: LineTouchData(
                      enabled: true,
                      touchTooltipData: LineTouchTooltipData(
                        tooltipBgColor: const Color(0xFF21262D),
                        getTooltipItems: (spots) => spots
                            .map((s) => LineTooltipItem(
                                  '${s.y.toStringAsFixed(1)}',
                                  const TextStyle(
                                    color: Color(0xFF4FC3F7),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ))
                            .toList(),
                      ),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 12),
            ...modelPerf.entries.map((entry) {
              final perf = entry.value;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Text(entry.key,
                          style: theme.textTheme.bodyMedium),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        perf.avgScore.toStringAsFixed(1),
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: (perf.trend == 'improving'
                                ? AppTheme.accentGreen
                                : AppTheme.accentOrange)
                            .withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        perf.trend == 'improving' ? '上升' : '稳定',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: perf.trend == 'improving'
                              ? AppTheme.accentGreen
                              : AppTheme.accentOrange,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildPredictionHistory(
      BuildContext context, PredictionProvider provider) {
    final theme = Theme.of(context);
    final history = provider.history;
    final displayedItems = history.take(_displayedCount).toList();
    final hasMore = _displayedCount < history.length;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentPurple.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.list_alt,
                      size: 18, color: Color(0xFFB39DDB)),
                ),
                const SizedBox(width: 10),
                Text(
                  '预测历史',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (history.isEmpty)
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1F2E),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Text('暂无预测历史',
                      style: TextStyle(color: Color(0xFF8B949E))),
                ),
              )
            else
              ListView.builder(
                controller: _historyScrollController,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: displayedItems.length + (hasMore ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index >= displayedItems.length) {
                    return const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Center(
                        child: SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF4FC3F7)),
                        ),
                      ),
                    );
                  }
                  final item = displayedItems[index];
                  final period = item.riskAssessment['period']?.toString() ?? '-';
                  final score = (item.riskAssessment['score'] as num?)?.toDouble() ?? item.finalScore;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1F2E),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListTile(
                      dense: true,
                      leading: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: AppTheme.accentBlue.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.auto_awesome,
                            size: 16, color: Color(0xFF4FC3F7)),
                      ),
                      title: Text('第$period期'),
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppTheme.accentBlue.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '${score.toStringAsFixed(0)}分',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF4FC3F7),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            if (hasMore && history.length > _pageSize)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Center(
                  child: TextButton.icon(
                    onPressed: _isLoadingMore
                        ? null
                        : () {
                            _loadMoreHistory();
                          },
                    icon: _isLoadingMore
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF4FC3F7)),
                          )
                        : const Icon(Icons.expand_more,
                            size: 18, color: Color(0xFF4FC3F7)),
                    label: Text(
                      _isLoadingMore
                          ? '加载中...'
                          : '加载更多 (${history.length - _displayedCount} 条)',
                      style: const TextStyle(
                          fontSize: 13, color: Color(0xFF4FC3F7)),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

List<double> _computeMovingAverage(List<double> data, int window) {
  if (data.length < window) return data;
  final result = <double>[];
  for (int i = 0; i <= data.length - window; i++) {
    final sum = data.sublist(i, i + window).reduce((a, b) => a + b);
    result.add(sum / window);
  }
  return result;
}

class _BallWidget extends StatelessWidget {
  final String number;
  final Color color;
  final double size;

  const _BallWidget({
    Key? key,
    required this.number,
    required this.color,
    this.size = 36,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withOpacity(0.8), color],
          center: const Alignment(-0.3, -0.3),
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Text(
        number,
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: size * 0.4,
        ),
      ),
    );
  }
}
