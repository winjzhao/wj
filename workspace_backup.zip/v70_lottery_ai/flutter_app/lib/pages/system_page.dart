import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../providers/lottery_provider.dart';
import '../providers/evolution_provider.dart';
import '../services/lottery_data_service.dart';
import '../theme/app_theme.dart';

class SystemPage extends StatefulWidget {
  const SystemPage({Key? key}) : super(key: key);

  @override
  State<SystemPage> createState() => _SystemPageState();
}

class _SystemPageState extends State<SystemPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppState>().loadSystemStatus();
      context.read<EvolutionProvider>().loadEvolutionStatus();
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final lotteryProvider = context.watch<LotteryProvider>();
    final dataService = LotteryDataService();

    return Scaffold(
      appBar: AppBar(
        title: const Text('系统中心'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSystemStatus(context, appState, dataService),
            const SizedBox(height: 14),
            _buildSystemResources(context),
            const SizedBox(height: 14),
            _buildWorkflowStatus(context),
            const SizedBox(height: 14),
            _buildSystemConfig(context, lotteryProvider, dataService),
            const SizedBox(height: 14),
            _buildScheduleTasks(context),
          ],
        ),
      ),
    );
  }

  Widget _buildSystemStatus(BuildContext context, AppState appState,
      LotteryDataService dataService) {
    final theme = Theme.of(context);

    final dataVersion = dataService.isLoaded
        ? '真实数据 V${dataService.generatedAt.substring(0, 10).replaceAll('-', '.')}'
        : 'V71.5';
    final dataSources = dataService.dataSources;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: appState.systemState == 'completed'
                        ? AppTheme.accentGreen
                        : AppTheme.accentOrange,
                    boxShadow: [
                      BoxShadow(
                        color: (appState.systemState == 'completed'
                                ? AppTheme.accentGreen
                                : AppTheme.accentOrange)
                            .withOpacity(0.4),
                        blurRadius: 6,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  '系统运行状态',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: appState.systemState == 'completed'
                        ? AppTheme.accentGreen.withOpacity(0.12)
                        : AppTheme.accentOrange.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    appState.systemState == 'completed' ? 'Running' : 'Idle',
                    style: TextStyle(
                      color: appState.systemState == 'completed'
                          ? AppTheme.accentGreen
                          : AppTheme.accentOrange,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _SystemStat(
                  icon: Icons.dns,
                  label: '数据版本',
                  value: dataVersion,
                  theme: theme,
                ),
                const SizedBox(width: 16),
                _SystemStat(
                  icon: Icons.model_training,
                  label: '当前模型',
                  value: 'Fusion-V71',
                  theme: theme,
                ),
                const SizedBox(width: 16),
                _SystemStat(
                  icon: Icons.task,
                  label: '当前任务',
                  value: 'Predict',
                  theme: theme,
                ),
              ],
            ),
            if (dataSources.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.accentBlue.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: AppTheme.accentBlue.withOpacity(0.15),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(Icons.cloud_download,
                        size: 14, color: AppTheme.accentBlue),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'SSQ: ${dataSources['ssq'] ?? '-'}  |  '
                        'DLT: ${dataSources['dlt'] ?? '-'}  |  '
                        'K8: ${dataSources['k8'] ?? '-'}',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: const Color(0xFF8B949E),
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSystemResources(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentPurple.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.monitor_heart,
                      size: 18, color: Color(0xFFB39DDB)),
                ),
                const SizedBox(width: 10),
                Text(
                  '系统资源',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _ResourceBar(
              label: 'CPU',
              value: 18,
              color: const Color(0xFF42A5F5),
              theme: theme,
            ),
            const SizedBox(height: 14),
            _ResourceBar(
              label: '内存',
              value: 42,
              color: const Color(0xFFAB47BC),
              theme: theme,
              suffix: '420MB / 1GB',
            ),
            const SizedBox(height: 14),
            _ResourceBar(
              label: '磁盘',
              value: 35,
              color: AppTheme.accentGreen,
              theme: theme,
              suffix: '35GB / 100GB',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWorkflowStatus(BuildContext context) {
    final theme = Theme.of(context);
    final appState = context.watch<AppState>();
    final steps = appState.workflowSteps;

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentCyan.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.account_tree,
                      size: 18, color: Color(0xFF26C6DA)),
                ),
                const SizedBox(width: 10),
                Text(
                  '工作流状态',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                // 今日统计
                if (appState.todayPredictions > 0 || appState.todayMatched > 0)
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (appState.todayPredictions > 0) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.accentBlue.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '预测${appState.todayPredictions}条',
                            style: TextStyle(
                              color: AppTheme.accentBlue,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(width: 4),
                      ],
                      if (appState.todayMatched > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.accentGreen.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '已匹配${appState.todayMatched}条',
                            style: TextStyle(
                              color: AppTheme.accentGreen,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                    ],
                  ),
              ],
            ),
            const SizedBox(height: 16),
            if (steps.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Center(
                  child: Text(
                    '等待后端连接...',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: const Color(0xFF6E7681),
                    ),
                  ),
                ),
              )
            else
              ...steps.map((step) {
                final status = step.status;
                Color dotColor;
                IconData icon;

                switch (status) {
                  case 'completed':
                    dotColor = AppTheme.accentGreen;
                    icon = Icons.check_circle;
                    break;
                  case 'running':
                    dotColor = AppTheme.accentBlue;
                    icon = Icons.play_circle;
                    break;
                  default:
                    dotColor = const Color(0xFF484F58);
                    icon = Icons.radio_button_unchecked;
                }

                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Icon(icon, color: dotColor, size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              step.name,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: status == 'pending'
                                    ? const Color(0xFF6E7681)
                                    : null,
                              ),
                            ),
                            if (step.detail != null && step.detail!.isNotEmpty)
                              Text(
                                step.detail!,
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: const Color(0xFF8B949E),
                                  fontSize: 10,
                                ),
                              ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: dotColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          step.time,
                          style: TextStyle(
                            color: dotColor,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
            // 刷新按钮
            if (appState.isBackendConnected)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Align(
                  alignment: Alignment.centerRight,
                  child:                   TextButton.icon(
                    onPressed: () => appState.loadWorkflowStatus(),
                    icon: const Icon(Icons.refresh, size: 14),
                    label: const Text('刷新', style: TextStyle(fontSize: 12)),
                    style: TextButton.styleFrom(
                      primary: AppTheme.accentBlue,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSystemConfig(BuildContext context,
      LotteryProvider lotteryProvider, LotteryDataService dataService) {
    final theme = Theme.of(context);
    final currentType = lotteryProvider.currentType;

    String lotteryTypeDisplay;
    switch (currentType) {
      case LotteryType.ssq:
        lotteryTypeDisplay = '双色球 (SSQ)';
        break;
      case LotteryType.dlt:
        lotteryTypeDisplay = '大乐透 (DLT)';
        break;
      case LotteryType.k8:
        lotteryTypeDisplay = '快乐8 (K8)';
        break;
    }

    final dataWindow = dataService.isLoaded
        ? '最近${dataService.getDrawCount(currentType.apiValue)}期真实数据'
        : '最近100期';

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentOrange.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.settings,
                      size: 18, color: Color(0xFFFFB74D)),
                ),
                const SizedBox(width: 10),
                Text(
                  '系统配置',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _ConfigRow(theme, '应用版本', 'V72 Release 1.0'),
            _ConfigRow(theme, '核心引擎', 'AI分析平台'),
            _ConfigRow(theme, '状态', 'Stable'),
            _ConfigRow(theme, '彩票类型', lotteryTypeDisplay),
            _ConfigRow(theme, '候选方案数', '10,000 → TOP 10'),
            _ConfigRow(theme, '每日更新时间', '08:00'),
            _ConfigRow(theme, '数据窗口', dataWindow),
            const SizedBox(height: 16),
            Text(
              '支持的彩票类型',
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            ...LotteryProvider.supportedTypes.map((type) {
              final isActive = type == currentType;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: [
                    Icon(
                      isActive
                          ? Icons.check_circle
                          : Icons.circle_outlined,
                      size: 16,
                      color: isActive
                          ? AppTheme.accentGreen
                          : const Color(0xFF484F58),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      type.displayName,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight:
                            isActive ? FontWeight.w600 : FontWeight.normal,
                        color: isActive
                            ? AppTheme.accentBlue
                            : null,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildScheduleTasks(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.accentGreen.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.schedule,
                      size: 18, color: Color(0xFF69F0AE)),
                ),
                const SizedBox(width: 10),
                Text(
                  '定时任务',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _ScheduleTask(
              theme: theme,
              name: '每日数据更新',
              schedule: '每天 08:00',
              status: 'active',
            ),
            _ScheduleTask(
              theme: theme,
              name: '每日AI预测',
              schedule: '每天 08:05',
              status: 'active',
            ),
            _ScheduleTask(
              theme: theme,
              name: '每日自学习进化',
              schedule: '每天 08:10',
              status: 'active',
            ),
            _ScheduleTask(
              theme: theme,
              name: '每周模型训练',
              schedule: '每周一 02:00',
              status: 'active',
            ),
            _ScheduleTask(
              theme: theme,
              name: '健康检查',
              schedule: '每30分钟',
              status: 'active',
            ),
          ],
        ),
      ),
    );
  }
}

class _SystemStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final ThemeData theme;

  const _SystemStat({
    Key? key,
    required this.icon,
    required this.label,
    required this.value,
    required this.theme,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppTheme.accentBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 20, color: AppTheme.accentBlue),
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: const Color(0xFF8B949E),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class _ResourceBar extends StatelessWidget {
  final String label;
  final int value;
  final Color color;
  final ThemeData theme;
  final String? suffix;

  const _ResourceBar({
    Key? key,
    required this.label,
    required this.value,
    required this.color,
    required this.theme,
    this.suffix,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: theme.textTheme.bodyMedium),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                suffix ?? '$value%',
                style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: value / 100,
            backgroundColor: const Color(0xFF21262D),
            color: color,
            minHeight: 6,
          ),
        ),
      ],
    );
  }
}

class _ConfigRow extends StatelessWidget {
  final ThemeData theme;
  final String label;
  final String value;

  const _ConfigRow(this.theme, this.label, this.value, {Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: const Color(0xFFB0B8C4),
              )),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: AppTheme.accentBlue.withOpacity(0.06),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              value,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: AppTheme.accentBlue,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScheduleTask extends StatelessWidget {
  final ThemeData theme;
  final String name;
  final String schedule;
  final String status;

  const _ScheduleTask({
    Key? key,
    required this.theme,
    required this.name,
    required this.schedule,
    required this.status,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: status == 'active'
                  ? AppTheme.accentGreen
                  : const Color(0xFF484F58),
              boxShadow: [
                if (status == 'active')
                  BoxShadow(
                    color: AppTheme.accentGreen.withOpacity(0.4),
                    blurRadius: 4,
                    spreadRadius: 1,
                  ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(name, style: theme.textTheme.bodyMedium),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: const Color(0xFF21262D),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              schedule,
              style: theme.textTheme.bodySmall?.copyWith(
                color: const Color(0xFF8B949E),
                fontSize: 11,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
