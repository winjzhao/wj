import 'package:flutter/material.dart';

enum LotteryType { ssq, dlt, k8 }

extension LotteryTypeExtension on LotteryType {
  String get displayName {
    switch (this) {
      case LotteryType.ssq:
        return '双色球';
      case LotteryType.dlt:
        return '大乐透';
      case LotteryType.k8:
        return '快乐8';
    }
  }

  String get apiValue {
    switch (this) {
      case LotteryType.ssq:
        return 'ssq';
      case LotteryType.dlt:
        return 'dlt';
      case LotteryType.k8:
        return 'k8';
    }
  }

  int get mainCount {
    switch (this) {
      case LotteryType.ssq:
        return 6;
      case LotteryType.dlt:
        return 5;
      case LotteryType.k8:
        return 20;
    }
  }

  int get mainRange {
    switch (this) {
      case LotteryType.ssq:
        return 33;
      case LotteryType.dlt:
        return 35;
      case LotteryType.k8:
        return 80;
    }
  }

  List<int> get bonusCounts {
    switch (this) {
      case LotteryType.ssq:
        return [1];
      case LotteryType.dlt:
        return [2];
      case LotteryType.k8:
        return [0];
    }
  }

  List<int> get bonusRanges {
    switch (this) {
      case LotteryType.ssq:
        return [16];
      case LotteryType.dlt:
        return [12];
      case LotteryType.k8:
        return [0];
    }
  }

  String get mainLabel {
    switch (this) {
      case LotteryType.ssq:
        return '红球';
      case LotteryType.dlt:
        return '前区';
      case LotteryType.k8:
        return '选号';
    }
  }

  List<String> get bonusLabels {
    switch (this) {
      case LotteryType.ssq:
        return ['蓝球'];
      case LotteryType.dlt:
        return ['后区'];
      case LotteryType.k8:
        return [];
    }
  }

  Color get mainColor {
    switch (this) {
      case LotteryType.ssq:
        return Colors.red;
      case LotteryType.dlt:
        return Colors.red;
      case LotteryType.k8:
        return Colors.orange;
    }
  }

  Color get bonusColor {
    switch (this) {
      case LotteryType.ssq:
        return Colors.blue;
      case LotteryType.dlt:
        return Colors.blue;
      case LotteryType.k8:
        return Colors.orange;
    }
  }
}

class LotteryProvider extends ChangeNotifier {
  LotteryType _currentType = LotteryType.ssq;

  LotteryType get currentType => _currentType;

  void setType(LotteryType type) {
    if (_currentType != type) {
      _currentType = type;
      notifyListeners();
    }
  }

  static LotteryType fromApiValue(String value) {
    switch (value) {
      case 'ssq':
        return LotteryType.ssq;
      case 'dlt':
        return LotteryType.dlt;
      case 'k8':
        return LotteryType.k8;
      default:
        return LotteryType.ssq;
    }
  }

  static List<LotteryType> get supportedTypes =>
      [LotteryType.ssq, LotteryType.dlt, LotteryType.k8];

  static Map<String, dynamic> getBallConfig(LotteryType type) {
    return {
      'main_count': type.mainCount,
      'main_range': type.mainRange,
      'bonus_counts': type.bonusCounts,
      'bonus_ranges': type.bonusRanges,
      'main_label': type.mainLabel,
      'bonus_labels': type.bonusLabels,
    };
  }
}
