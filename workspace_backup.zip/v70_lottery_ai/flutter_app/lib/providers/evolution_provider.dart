import 'package:flutter/material.dart';
import '../api/api_service.dart';
import '../models/evolution_data.dart';
import '../models/alert_data.dart';

/// 自学习进化 Provider
/// 优先从后端 API 获取数据，失败时降级到本地模拟
class EvolutionProvider extends ChangeNotifier {
  // 进化状态
  EvolutionStatus? _evolutionStatus;
  List<EvolutionHistory> _evolutionHistory = [];
  List<Map<String, dynamic>> _modelPerformance = [];
  Map<String, double> _currentWeights = {};
  List<ModelStatus> _modelStatuses = [];
  List<AlertInfo> _alerts = [];
  AlertSummary? _alertSummary;

  bool _isEvolving = false;
  bool _isLoading = false;
  String? _error;
  String _lotteryType = 'ssq';

  // Getters
  EvolutionStatus? get evolutionStatus => _evolutionStatus;
  List<EvolutionHistory> get evolutionHistory => _evolutionHistory;
  List<Map<String, dynamic>> get modelPerformance => _modelPerformance;
  Map<String, double> get currentWeights => _currentWeights;
  List<ModelStatus> get modelStatuses => _modelStatuses;
  List<AlertInfo> get alerts => _alerts;
  AlertSummary? get alertSummary => _alertSummary;
  bool get isEvolving => _isEvolving;
  bool get isLoading => _isLoading;
  String? get error => _error;

  void updateLotteryType(String lotteryType) {
    _lotteryType = lotteryType;
  }

  // ============================================================
  // 进化 API 方法
  // ============================================================

  /// 触发手动进化周期
  Future<EvolutionStatus> triggerEvolution() async {
    _isEvolving = true;
    _error = null;
    notifyListeners();

    try {
      final result = await apiService.api.triggerEvolution(lotteryType: _lotteryType);
      _evolutionStatus = EvolutionStatus.fromJson(result);

      // 进化完成后刷新状态
      await _loadEvolutionStatus();
      await _loadModelPerformance();

      _isEvolving = false;
      notifyListeners();
      return _evolutionStatus!;
    } catch (e) {
      _error = e.toString();
      _isEvolving = false;
      notifyListeners();

      // 离线模式：模拟进化
      return await _simulateEvolution();
    }
  }

  /// 加载进化状态
  Future<void> loadEvolutionStatus() async {
    _isLoading = true;
    notifyListeners();

    try {
      await _loadEvolutionStatus();
      await _loadModelPerformance();
      await _loadEvolutionHistory();
      await _loadModelStatuses();
      await _loadAlerts();
    } catch (e) {
      _error = e.toString();
    }

    _isLoading = false;
    notifyListeners();
  }

  /// 重置进化权重
  Future<void> resetWeights() async {
    try {
      await apiService.api.resetEvolutionWeights(lotteryType: _lotteryType);
      await loadEvolutionStatus();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  /// 重置所有进化数据
  Future<void> resetEvolution() async {
    try {
      await apiService.api.resetEvolution(lotteryType: _lotteryType);
      await loadEvolutionStatus();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  // ============================================================
  // 模型管理
  // ============================================================

  Future<void> _loadModelStatuses() async {
    try {
      final result = await apiService.client.get('/evolution/models/status?lottery_type=$_lotteryType');
      final list = result['models'] as List<dynamic>?;
      if (list != null) {
        _modelStatuses = list
            .map((e) => ModelStatus.fromJson(e as Map<String, dynamic>))
            .toList();
      }
    } catch (_) {}
  }

  Future<void> retireModel(String modelName, {String reason = '手动淘汰'}) async {
    try {
      await apiService.client.post('/evolution/models/$modelName/retire?reason=$reason');
      await _loadModelStatuses();
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> reactivateModel(String modelName) async {
    try {
      await apiService.client.post('/evolution/models/$modelName/reactivate');
      await _loadModelStatuses();
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> retrainDegradedModels() async {
    _isEvolving = true;
    notifyListeners();
    try {
      await apiService.client.post('/evolution/models/retrain-degraded');
      await loadEvolutionStatus();
    } catch (e) {
      _error = e.toString();
    }
    _isEvolving = false;
    notifyListeners();
  }

  // ============================================================
  // 告警
  // ============================================================

  Future<void> _loadAlerts() async {
    try {
      final result = await apiService.client.get('/evolution/alerts?limit=20');
      final list = result['alerts'] as List<dynamic>?;
      if (list != null) {
        _alerts = list
            .map((e) => AlertInfo.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      _alertSummary = AlertSummary.fromJson(result);
    } catch (_) {}
  }

  Future<void> acknowledgeAlert(String alertId) async {
    try {
      await apiService.client.post('/evolution/alerts/$alertId/acknowledge');
      await _loadAlerts();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> resolveAlert(String alertId) async {
    try {
      await apiService.client.post('/evolution/alerts/$alertId/resolve');
      await _loadAlerts();
      notifyListeners();
    } catch (_) {}
  }

  // ============================================================
  // 私有方法
  // ============================================================

  Future<void> _loadEvolutionStatus() async {
    try {
      final result = await apiService.api.getEvolutionStatus(lotteryType: _lotteryType);
      _evolutionStatus = EvolutionStatus.fromJson(result);
      if (_evolutionStatus!.weights.isNotEmpty) {
        _currentWeights = Map<String, double>.from(_evolutionStatus!.weights);
      }
    } catch (_) {}
  }

  Future<void> _loadEvolutionHistory() async {
    try {
      final result = await apiService.api.getEvolutionHistory(lotteryType: _lotteryType);
      final list = result['history'] as List<dynamic>?;
      if (list != null) {
        _evolutionHistory = list
            .map((e) => EvolutionHistory.fromJson(e as Map<String, dynamic>))
            .toList();
      }
    } catch (_) {}
  }

  Future<void> _loadModelPerformance() async {
    try {
      final result =
          await apiService.api.getEvolutionModelPerformance(lotteryType: _lotteryType);
      _modelPerformance = (result['models'] as List<dynamic>?)
              ?.cast<Map<String, dynamic>>() ??
          [];
    } catch (_) {}
  }

  /// 离线模拟进化（后端不可用时使用）
  Future<EvolutionStatus> _simulateEvolution() async {
    await Future.delayed(const Duration(seconds: 1));

    final modelNames = [
      'XGBoost', 'LSTM', 'Transformer', 'PPO', 'Statistic', 'Behavior'
    ];
    final now = DateTime.now();

    _modelPerformance = modelNames.map((name) {
      final hitRate = 0.15 + (name.hashCode % 20) / 100.0;
      return {
        'name': name,
        'hit_rate': hitRate,
        'precision': 0.08 + (name.hashCode % 15) / 100.0,
        'recall': 0.12 + (name.hashCode % 18) / 100.0,
        'avg_score': 0.10 + (name.hashCode % 22) / 100.0,
        'trend': ['improving', 'stable', 'declining'][name.hashCode % 3],
        'matched_count': 20 + name.hashCode % 30,
        'last_updated': now.toIso8601String(),
      };
    }).toList();

    _currentWeights = {
      'XGBoost': 0.18, 'LSTM': 0.16, 'Transformer': 0.20,
      'PPO': 0.12, 'Statistic': 0.18, 'Behavior': 0.16,
    };

    _evolutionStatus = EvolutionStatus(
      status: 'completed',
      lotteryType: _lotteryType,
      lastEvolution: now,
      totalCycles: 12,
      matchedCount: 36,
      weights: _currentWeights,
      cycleDurationMs: 2340,
    );

    _evolutionHistory = List.generate(5, (i) => EvolutionHistory(
      cycle: 12 - i,
      timestamp: DateTime.now().subtract(Duration(days: i * 7)),
      matchedCount: 30 + i * 3,
      bestModel: modelNames[i % 6],
      bestScore: 0.15 + i * 0.01,
      durationMs: 1500 + i * 200,
    ));

    return _evolutionStatus!;
  }
}
