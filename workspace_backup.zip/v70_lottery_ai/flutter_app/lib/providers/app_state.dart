import 'package:flutter/material.dart';
import '../api/api_service.dart';
import '../models/system_data.dart';
import 'lottery_provider.dart';

/// 连接模式枚举
enum ConnectionMode {
  /// 后端优先 — 优先连接后端 API，失败时降级到本地
  backend,
  /// 纯本地 — 仅使用本地离线数据
  local,
}

class AppState extends ChangeNotifier {
  bool _isLoading = false;
  String _systemState = 'running';
  String? _error;
  String _lotteryType = 'ssq';

  /// 连接模式（默认后端优先）
  ConnectionMode _connectionMode = ConnectionMode.backend;
  /// 后端 API 地址
  String _backendUrl = 'http://10.0.2.2:8000/api/v1';
  /// 后端连接状态
  bool _isBackendConnected = false;
  /// 是否已尝试连接
  bool _connectionChecked = false;
  /// 系统状态（类型安全）
  SystemStatus? _systemStatus;

  /// 工作流步骤状态
  List<WorkflowStep> _workflowSteps = [];
  /// 工作流统计
  int _todayPredictions = 0;
  int _todayMatched = 0;
  String _orchestratorState = 'idle';

  AppState() {
    apiService.init(baseUrl: _backendUrl);
  }

  bool get isLoading => _isLoading;
  String get systemState => _systemState;
  String? get error => _error;
  bool get isBackendAvailable => _isBackendConnected;
  bool get shouldUseBackend =>
      _connectionMode == ConnectionMode.backend && _isBackendConnected;

  ConnectionMode get connectionMode => _connectionMode;
  String get backendUrl => _backendUrl;
  bool get isBackendConnected => _isBackendConnected;
  bool get connectionChecked => _connectionChecked;
  SystemStatus? get systemStatus => _systemStatus;
  List<WorkflowStep> get workflowSteps => _workflowSteps;
  int get todayPredictions => _todayPredictions;
  int get todayMatched => _todayMatched;
  String get orchestratorState => _orchestratorState;

  /// 是否处于离线状态（本地模式或后端未连接）
  bool get isOffline =>
      _connectionMode == ConnectionMode.local || !_isBackendConnected;

  /// 是否可以连接后端
  bool get canUseBackend =>
      _isBackendConnected && _connectionMode == ConnectionMode.backend;

  void updateLotteryType(LotteryType type) {
    _lotteryType = type.apiValue;
    notifyListeners();
  }

  /// 切换连接模式
  void setConnectionMode(ConnectionMode mode) {
    _connectionMode = mode;
    if (mode == ConnectionMode.backend) {
      _testBackendConnection();
    }
    notifyListeners();
  }

  /// 设置后端地址
  void setBackendUrl(String url) {
    if (url.isEmpty) return;
    _backendUrl = url.trim();
    apiService.updateBaseUrl(_backendUrl);
    _isBackendConnected = false;
    _connectionChecked = false;
    if (_connectionMode == ConnectionMode.backend) {
      _testBackendConnection();
    }
    notifyListeners();
  }

  /// 测试后端连接
  Future<void> _testBackendConnection() async {
    _isLoading = true;
    notifyListeners();

    try {
      final status = await apiService.api.getSystemStatus(lotteryType: _lotteryType);
      _systemStatus = SystemStatus.fromJson(status);
      _systemState = _systemStatus!.state;
      _isBackendConnected = true;
      _error = null;
    } catch (e) {
      _isBackendConnected = false;
      // 只取简洁的错误信息，避免返回体中的 HTML 乱码
      final errMsg = e.toString();
      if (errMsg.length > 150) {
        _error = '后端连接失败: ${errMsg.substring(0, 150)}...';
      } else {
        _error = '后端连接失败: $errMsg';
      }
    }

    _connectionChecked = true;
    _isLoading = false;
    notifyListeners();
  }

  /// 加载系统状态（启动时调用）
  Future<void> loadSystemStatus() async {
    await _testBackendConnection();
    if (!_isBackendConnected) {
      // 后端不可用，自动切换到本地模式
      _systemState = 'running (offline)';
      _connectionMode = ConnectionMode.local;
    }
    // 加载工作流状态
    await loadWorkflowStatus();
    notifyListeners();
  }

  /// 加载工作流状态
  Future<void> loadWorkflowStatus() async {
    if (!_isBackendConnected) {
      _buildOfflineWorkflowSteps();
      return;
    }
    try {
      final result = await apiService.api.getWorkflowStatus(lotteryType: _lotteryType);
      final steps = result['steps'] as List<dynamic>?;
      if (steps != null) {
        _workflowSteps = steps
            .map((s) => WorkflowStep.fromJson(s as Map<String, dynamic>))
            .toList();
      }
      _todayPredictions = result['today_predictions'] as int? ?? 0;
      _todayMatched = result['today_matched'] as int? ?? 0;
      _orchestratorState = result['orchestrator_state'] as String? ?? 'idle';
    } catch (e) {
      _buildOfflineWorkflowSteps();
    }
    notifyListeners();
  }

  /// 构建离线工作流步骤（后端不可用时）
  void _buildOfflineWorkflowSteps() {
    _workflowSteps = [
      WorkflowStep(name: "数据更新", status: "pending", time: "-"),
      WorkflowStep(name: "数据检查", status: "pending", time: "-"),
      WorkflowStep(name: "特征生成", status: "pending", time: "-"),
      WorkflowStep(name: "模型预测", status: "pending", time: "-"),
      WorkflowStep(name: "Fusion融合", status: "pending", time: "-"),
      WorkflowStep(name: "候选生成", status: "pending", time: "-"),
      WorkflowStep(name: "回测评分", status: "pending", time: "-"),
      WorkflowStep(name: "保存结果", status: "pending", time: "-", detail: "后端未连接"),
      WorkflowStep(name: "等待开奖", status: "pending", time: "-"),
      WorkflowStep(name: "反馈学习", status: "pending", time: "-"),
    ];
    _todayPredictions = 0;
    _todayMatched = 0;
    _orchestratorState = 'offline';
  }

  /// 刷新数据
  Future<void> refreshData() async {
    await _testBackendConnection();
  }

  /// 快速检查连通性（不阻塞 UI）
  Future<bool> checkConnectivity() async {
    try {
      final status =
          await apiService.api.getSystemStatus(lotteryType: _lotteryType);
      _systemStatus = SystemStatus.fromJson(status);
      _systemState = _systemStatus!.state;
      _isBackendConnected = true;
      _error = null;
      _connectionChecked = true;
      notifyListeners();
      return true;
    } catch (e) {
      _isBackendConnected = false;
      _connectionChecked = true;
      notifyListeners();
      return false;
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

}
