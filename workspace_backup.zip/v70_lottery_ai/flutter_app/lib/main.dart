import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_state.dart';
import 'providers/prediction_provider.dart';
import 'providers/model_provider.dart';
import 'providers/lottery_provider.dart';
import 'providers/evolution_provider.dart';
import 'pages/dashboard_page.dart';
import 'pages/prediction_page.dart';
import 'pages/models_page.dart';
import 'pages/system_page.dart';
import 'pages/data_page.dart';
import 'pages/evolution_page.dart';
import 'theme/app_theme.dart';
import 'api/api_service.dart';

void main() {
  // 初始化全局 API 服务（默认连接后端）
  apiService.init();
  runApp(const V70App());
}

class V70App extends StatelessWidget {
  const V70App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LotteryProvider()),
        ChangeNotifierProvider(create: (_) => AppState()),
        ChangeNotifierProvider(create: (_) => PredictionProvider()),
        ChangeNotifierProvider(create: (_) => ModelProvider()),
        ChangeNotifierProvider(create: (_) => EvolutionProvider()),
      ],
      child: MaterialApp(
        title: 'V70 彩票AI工作台',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        home: const MainScreen(),
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = const [
    DashboardPage(),
    PredictionPage(),
    ModelsPage(),
    EvolutionPage(),
    DataPage(),
    SystemPage(),
  ];

  void _onLotteryTypeChanged(
      LotteryType type, LotteryProvider lotteryProvider) {
    lotteryProvider.setType(type);
    context.read<AppState>().updateLotteryType(type);
    context.read<PredictionProvider>().updateLotteryType(type);
    context.read<ModelProvider>().updateLotteryType(type);
    context.read<EvolutionProvider>().updateLotteryType(type.apiValue);
  }

  /// 初始化数据加载（后端优先，失败降级本地）
  void _initDataLoad() {
    final appState = context.read<AppState>();
    final predictionProvider = context.read<PredictionProvider>();
    final modelProvider = context.read<ModelProvider>();
    final evolutionProvider = context.read<EvolutionProvider>();

    predictionProvider.bindModelProvider(modelProvider);

    // 先加载本地数据作为兜底
    predictionProvider.init();
    modelProvider.init();

    // 异步尝试从后端加载（如果连接成功会自动覆盖本地数据）
    if (appState.shouldUseBackend) {
      predictionProvider.generatePrediction();
      modelProvider.loadModels();
      modelProvider.loadWeights();
      evolutionProvider.loadEvolutionStatus();
    }
  }

  void _showConnectionSettings(BuildContext context, AppState appState) {
    final controller = TextEditingController(text: appState.backendUrl);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF161B22),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('后端服务地址',
            style: TextStyle(color: Color(0xFFE6EDF3))),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '输入后端 API 地址，手机需与服务器在同一网络',
              style: TextStyle(fontSize: 12, color: Color(0xFF8B949E)),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              style: const TextStyle(color: Color(0xFFE6EDF3)),
              decoration: InputDecoration(
                labelText: 'API 地址',
                hintText: 'http://192.168.1.100:8000/api/v1',
                hintStyle: const TextStyle(color: Color(0xFF484F58)),
                prefixIcon: const Icon(Icons.link, color: Color(0xFF4FC3F7)),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF30363D)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF30363D)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF4FC3F7)),
                ),
              ),
              keyboardType: TextInputType.url,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消',
                style: TextStyle(color: Color(0xFF8B949E))),
          ),
          ElevatedButton(
            onPressed: () {
              appState.setBackendUrl(controller.text.trim());
              if (!appState.isBackendConnected &&
                  appState.connectionMode == ConnectionMode.backend) {
                appState.setConnectionMode(ConnectionMode.backend);
              }
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content:
                      Text('后端地址已更新: ${controller.text.trim()}'),
                  duration: const Duration(seconds: 2),
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              );
            },
            child: const Text('连接'),
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final appState = context.read<AppState>();

      // 异步检测后端连接，连接成功后自动加载数据
      appState.loadSystemStatus().then((_) {
        _initDataLoad();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final lotteryProvider = context.watch<LotteryProvider>();
    final appState = context.watch<AppState>();
    final isLocal = appState.connectionMode == ConnectionMode.local;
    final isBackendOk = appState.isBackendConnected;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                gradient: AppTheme.primaryGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.auto_awesome,
                  size: 16, color: Colors.white),
            ),
            const SizedBox(width: 10),
            const Text('V70 彩票AI工作台'),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            icon: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFF21262D),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isBackendOk
                      ? AppTheme.accentGreen.withOpacity(0.4)
                      : const Color(0xFF30363D),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isLocal
                          ? AppTheme.accentGreen
                          : (appState.isBackendConnected
                              ? AppTheme.accentGreen
                              : AppTheme.accentRed),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Icon(
                    isLocal ? Icons.phone_android : Icons.cloud,
                    size: 16,
                    color: isLocal
                        ? AppTheme.accentGreen
                        : AppTheme.accentBlue,
                  ),
                  const SizedBox(width: 4),
                  Icon(Icons.arrow_drop_down,
                      size: 16, color: Colors.grey[600]),
                ],
              ),
            ),
            tooltip: '切换连接模式',
            offset: const Offset(0, 44),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            color: const Color(0xFF21262D),
            onSelected: (value) {
              if (value == 'local') {
                appState.setConnectionMode(ConnectionMode.local);
              } else if (value == 'backend') {
                appState.setConnectionMode(ConnectionMode.backend);
              } else if (value == 'edit_url') {
                _showConnectionSettings(context, appState);
              }
            },
            itemBuilder: (ctx) => [
              PopupMenuItem(
                value: 'backend',
                child: Row(
                  children: [
                    Icon(Icons.cloud,
                        size: 18,
                        color: isBackendOk
                            ? AppTheme.accentGreen
                            : const Color(0xFF8B949E)),
                    const SizedBox(width: 10),
                    const Text('后端连接'),
                    if (!isLocal) ...[
                      const Spacer(),
                      Icon(
                        appState.isBackendConnected
                            ? Icons.check
                            : Icons.close,
                        size: 16,
                        color: appState.isBackendConnected
                            ? AppTheme.accentGreen
                            : AppTheme.accentRed,
                      ),
                    ],
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'local',
                child: Row(
                  children: [
                    Icon(Icons.phone_android,
                        size: 18,
                        color: isLocal
                            ? AppTheme.accentGreen
                            : const Color(0xFF8B949E)),
                    const SizedBox(width: 10),
                    const Text('离线模式'),
                    if (isLocal) ...[
                      const Spacer(),
                      Icon(Icons.check,
                          size: 16, color: AppTheme.accentGreen),
                    ],
                  ],
                ),
              ),
              const PopupMenuDivider(height: 1),
              PopupMenuItem(
                value: 'edit_url',
                child: Row(
                  children: [
                    const Icon(Icons.edit,
                        size: 18, color: Color(0xFF8B949E)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '后端地址: ${appState.backendUrl.length > 25 ? '${appState.backendUrl.substring(0, 25)}...' : appState.backendUrl}',
                        style:
                            const TextStyle(fontSize: 11, color: Color(0xFF8B949E)),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(width: 8),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(52),
          child: Container(
            height: 52,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0xFF21262D), width: 0.5),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: LotteryType.values.map((type) {
                final isSelected = lotteryProvider.currentType == type;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    child: ChoiceChip(
                      label: Text(type.displayName),
                      selected: isSelected,
                      selectedColor: const Color(0xFF1F6FEB),
                      backgroundColor: const Color(0xFF21262D),
                      side: BorderSide(
                        color: isSelected
                            ? const Color(0xFF1F6FEB)
                            : Colors.transparent,
                      ),
                      labelStyle: TextStyle(
                        color: isSelected
                            ? Colors.white
                            : const Color(0xFF8B949E),
                        fontWeight: isSelected
                            ? FontWeight.w600
                            : FontWeight.normal,
                        fontSize: 13,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      visualDensity: VisualDensity.compact,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      onSelected: (selected) {
                        if (selected) {
                          _onLotteryTypeChanged(type, lotteryProvider);
                        }
                      },
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: Color(0xFF21262D), width: 0.5),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() => _currentIndex = index);
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: const Color(0xFF0D1117),
          selectedItemColor: const Color(0xFF4FC3F7),
          unselectedItemColor: const Color(0xFF8B949E),
          selectedLabelStyle: const TextStyle(
              fontSize: 11, fontWeight: FontWeight.w600),
          unselectedLabelStyle:
              const TextStyle(fontSize: 10),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.dashboard_outlined, size: 22),
              activeIcon: Icon(Icons.dashboard, size: 22),
              label: '仪表盘',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.auto_awesome_outlined, size: 22),
              activeIcon: Icon(Icons.auto_awesome, size: 22),
              label: '预测中心',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.model_training_outlined, size: 22),
              activeIcon: Icon(Icons.model_training, size: 22),
              label: '模型管理',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.psychology_outlined, size: 22),
              activeIcon: Icon(Icons.psychology, size: 22),
              label: '进化中心',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.storage_outlined, size: 22),
              activeIcon: Icon(Icons.storage, size: 22),
              label: '数据中心',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings_outlined, size: 22),
              activeIcon: Icon(Icons.settings, size: 22),
              label: '系统中心',
            ),
          ],
        ),
      ),
    );
  }
}
