import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;

class ApiClient {
  static const String defaultBaseUrl = 'http://10.0.2.2:8000/api/v1';
  static const Duration _timeout = Duration(seconds: 15);
  static const int _defaultMaxRetries = 3;
  static const List<Duration> _defaultBackoffDelays = [
    Duration(seconds: 1),
    Duration(seconds: 2),
    Duration(seconds: 4),
  ];

  final http.Client _client = http.Client();
  String _baseUrl;

  ApiClient({String? baseUrl}) : _baseUrl = baseUrl ?? defaultBaseUrl;

  String get baseUrl => _baseUrl;

  void updateBaseUrl(String newUrl) {
    _baseUrl = newUrl.endsWith('/') ? newUrl.substring(0, newUrl.length - 1) : newUrl;
  }

  /// 判断错误是否可重试
  /// - 网络错误（SocketException, TimeoutException 等）可重试
  /// - 5xx 服务器错误可重试
  /// - 4xx 客户端错误不重试
  bool _isRetryable(Object error) {
    if (error is ApiException) {
      return error.statusCode >= 500 && error.statusCode < 600;
    }
    // 网络层错误：SocketException, TimeoutException, HttpException 等
    return error is TimeoutException ||
        error is http.ClientException ||
        error.runtimeType.toString().contains('SocketException');
  }

  /// 带指数退避重试的通用请求方法
  Future<Map<String, dynamic>> _executeWithRetry(
    Future<http.Response> Function() requestFn, {
    int retryCount = _defaultMaxRetries,
  }) async {
    int attempts = 0;
    Object? lastError;

    while (attempts <= retryCount) {
      try {
        final response = await requestFn().timeout(_timeout);
        return _handleResponse(response);
      } catch (e) {
        lastError = e;
        attempts++;

        // 如果已超过最大重试次数，或错误不可重试，直接抛出
        if (attempts > retryCount || !_isRetryable(e)) {
          if (e is ApiException) {
            rethrow;
          }
          throw ApiException(-1, '网络请求失败: $e');
        }

        // 指数退避等待
        final delayIndex = min(attempts - 1, _defaultBackoffDelays.length - 1);
        final delay = _defaultBackoffDelays[delayIndex];
        await Future.delayed(delay);
      }
    }

    // 理论上不会走到这里，但以防万一
    throw ApiException(-1, '请求失败（已达最大重试次数）: $lastError');
  }

  Future<Map<String, dynamic>> get(String endpoint, {int retryCount = _defaultMaxRetries}) async {
    return _executeWithRetry(
      () => _client.get(
        Uri.parse('$_baseUrl$endpoint'),
        headers: {'Content-Type': 'application/json'},
      ),
      retryCount: retryCount,
    );
  }

  Future<Map<String, dynamic>> post(String endpoint,
      {Map<String, dynamic>? body, int retryCount = _defaultMaxRetries}) async {
    return _executeWithRetry(
      () => _client.post(
        Uri.parse('$_baseUrl$endpoint'),
        headers: {'Content-Type': 'application/json'},
        body: body != null ? jsonEncode(body) : null,
      ),
      retryCount: retryCount,
    );
  }

  Map<String, dynamic> _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      // 显式用 UTF-8 解码，防止 Android 端因缺少 charset 而用 latin-1 导致乱码
      final bodyUtf8 = utf8.decode(response.bodyBytes);
      return jsonDecode(bodyUtf8) as Map<String, dynamic>;
    } else {
      throw ApiException(response.statusCode, response.body);
    }
  }

  void dispose() {
    _client.close();
  }
}

class ApiException implements Exception {
  final int statusCode;
  final String message;

  ApiException(this.statusCode, this.message);

  @override
  String toString() => 'ApiException($statusCode): $message';
}
