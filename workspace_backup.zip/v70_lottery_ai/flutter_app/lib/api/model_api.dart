import 'api_client.dart';
import '../providers/lottery_provider.dart';

class ModelApi {
  final ApiClient _client;

  ModelApi(this._client);

  String _buildUrl(String base, String lotteryType) {
    if (base.contains('?')) {
      return '$base&lottery_type=$lotteryType';
    } else {
      return '$base?lottery_type=$lotteryType';
    }
  }

  /// 获取支持的彩票类型
  Future<Map<String, dynamic>> getSupportedLotteryTypes() async {
    return _client.get('/system/lottery-types');
  }

  /// 获取仪表盘概览
  Future<Map<String, dynamic>> getDashboardOverview({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/dashboard/overview', lotteryType));
  }

  /// 获取模型表现图表数据
  Future<Map<String, dynamic>> getModelPerformanceChart({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/dashboard/charts/model-performance', lotteryType));
  }

  /// 获取冷热号图表数据
  Future<Map<String, dynamic>> getHotNumbersChart({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/dashboard/charts/hot-numbers', lotteryType));
  }

  /// 生成预测
  Future<Map<String, dynamic>> generatePrediction({String lotteryType = 'ssq'}) async {
    return _client.post('/prediction/generate', body: {'lottery_type': lotteryType});
  }

  /// 获取最新预测
  Future<Map<String, dynamic>> getLatestPrediction({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/prediction/latest', lotteryType));
  }

  /// 获取预测历史
  Future<Map<String, dynamic>> getPredictionHistory({int limit = 20, String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/prediction/history?limit=$limit', lotteryType));
  }

  /// 运行回测
  Future<Map<String, dynamic>> runBacktest({int periods = 50, String lotteryType = 'ssq'}) async {
    return _client.post('/prediction/backtest', body: {'periods': periods, 'lottery_type': lotteryType});
  }

  /// 获取模型列表
  Future<Map<String, dynamic>> getModels({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/models/list', lotteryType));
  }

  /// 训练模型
  Future<Map<String, dynamic>> trainModel(String modelName, {String lotteryType = 'ssq'}) async {
    return _client.post('/models/$modelName/train', body: {'lottery_type': lotteryType});
  }

  /// 训练所有模型
  Future<Map<String, dynamic>> trainAllModels({String lotteryType = 'ssq'}) async {
    return _client.post('/models/train-all', body: {'lottery_type': lotteryType});
  }

  /// 更新模型权重
  Future<Map<String, dynamic>> updateWeights(Map<String, double> weights, {String lotteryType = 'ssq'}) async {
    return _client.post('/models/weights', body: {'weights': weights, 'lottery_type': lotteryType});
  }

  /// 获取当前权重
  Future<Map<String, dynamic>> getCurrentWeights({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/models/weights/current', lotteryType));
  }

  /// 获取系统状态
  Future<Map<String, dynamic>> getSystemStatus({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/system/status', lotteryType));
  }

  /// 获取系统配置
  Future<Map<String, dynamic>> getSystemConfig({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/system/config', lotteryType));
  }

  /// 获取工作流状态
  Future<Map<String, dynamic>> getWorkflowStatus({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/system/workflow-status', lotteryType));
  }

  /// 获取开奖数据
  Future<Map<String, dynamic>> getDraws({int limit = 50, String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/data/draws?limit=$limit', lotteryType));
  }

  /// 获取数据统计
  Future<Map<String, dynamic>> getDataStats({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/data/stats', lotteryType));
  }

  /// 导入模拟数据
  Future<Map<String, dynamic>> importMockData({int count = 500, String lotteryType = 'ssq'}) async {
    return _client.post('/data/import-mock', body: {'count': count, 'lottery_type': lotteryType});
  }

  // ============================================================
  // 自学习进化 API
  // ============================================================

  /// 触发进化周期
  Future<Map<String, dynamic>> triggerEvolution({String lotteryType = 'ssq'}) async {
    return _client.post('/evolution/trigger', body: {'lottery_type': lotteryType});
  }

  /// 获取进化状态
  Future<Map<String, dynamic>> getEvolutionStatus({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/evolution/status', lotteryType));
  }

  /// 获取进化历史
  Future<Map<String, dynamic>> getEvolutionHistory({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/evolution/history', lotteryType));
  }

  /// 获取各模型进化表现
  Future<Map<String, dynamic>> getEvolutionModelPerformance({String lotteryType = 'ssq'}) async {
    return _client.get(_buildUrl('/evolution/models/performance', lotteryType));
  }

  /// 重置进化权重为默认值
  Future<Map<String, dynamic>> resetEvolutionWeights({String lotteryType = 'ssq'}) async {
    return _client.post('/evolution/weights/reset', body: {'lottery_type': lotteryType});
  }

  /// 重置所有进化数据
  Future<Map<String, dynamic>> resetEvolution({String lotteryType = 'ssq'}) async {
    return _client.post('/evolution/reset', body: {'lottery_type': lotteryType});
  }
}
