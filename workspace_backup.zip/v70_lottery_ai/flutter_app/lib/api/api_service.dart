import 'api_client.dart';
import 'model_api.dart';

/// 全局 API 服务单例
/// 统一管理 ApiClient 和 ModelApi，确保所有 Provider 共享同一个 HTTP 客户端
class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  late final ApiClient client;
  late final ModelApi api;

  bool _initialized = false;

  void init({String? baseUrl}) {
    if (_initialized) return;
    client = ApiClient(baseUrl: baseUrl);
    api = ModelApi(client);
    _initialized = true;
  }

  void updateBaseUrl(String url) {
    client.updateBaseUrl(url);
  }

  String get baseUrl => client.baseUrl;
}

/// 便捷获取
final apiService = ApiService();
