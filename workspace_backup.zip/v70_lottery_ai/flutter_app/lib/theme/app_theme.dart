import 'package:flutter/material.dart';

class AppTheme {
  // 统一的高亮颜色（暗色主题下更醒目）
  static const Color accentAmber = Color(0xFFFFB300); // 琥珀金
  static const Color accentGreen = Color(0xFF69F0AE); // 亮绿
  static const Color accentBlue = Color(0xFF4FC3F7); // 天蓝
  static const Color accentRed = Color(0xFFFF6E6E); // 亮红
  static const Color accentOrange = Color(0xFFFFB74D); // 亮橙
  static const Color accentPurple = Color(0xFFB39DDB); // 亮紫
  static const Color accentCyan = Color(0xFF26C6DA); // 青色

  // 渐变色
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF4FC3F7), Color(0xFF2196F3)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient amberGradient = LinearGradient(
    colors: [Color(0xFFFFD54F), Color(0xFFFFB300)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient purpleGradient = LinearGradient(
    colors: [Color(0xFFCE93D8), Color(0xFFAB47BC)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient darkCardGradient = LinearGradient(
    colors: [Color(0xFF1A1F2E), Color(0xFF161B22)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // 间距
  static const double spacingXs = 4;
  static const double spacingSm = 8;
  static const double spacingMd = 12;
  static const double spacingLg = 16;
  static const double spacingXl = 20;
  static const double spacingXxl = 24;

  // 圆角
  static const double radiusSm = 8;
  static const double radiusMd = 12;
  static const double radiusLg = 16;
  static const double radiusXl = 20;

  static final ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    primarySwatch: Colors.blue,
    scaffoldBackgroundColor: const Color(0xFFF0F4F8),
    appBarTheme: const AppBarTheme(
      centerTitle: true,
      elevation: 0,
    ),
    cardTheme: CardTheme(
      elevation: 1,
      shadowColor: Colors.black12,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),
  );

  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primarySwatch: Colors.blue,
    scaffoldBackgroundColor: const Color(0xFF0A0E17),
    fontFamily: 'NotoSansSC',
    appBarTheme: const AppBarTheme(
      centerTitle: true,
      elevation: 0,
      backgroundColor: Color(0xFF0D1117),
    ),
    cardTheme: CardTheme(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Color(0xFF0D1117),
      selectedItemColor: Color(0xFF4FC3F7),
      unselectedItemColor: Color(0xFF8B949E),
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
    colorScheme: const ColorScheme.dark(
      primary: Color(0xFF4FC3F7),
      secondary: Color(0xFF69F0AE),
      surface: Color(0xFF161B22),
    ),
    // 全局文本颜色增强可读性
    textTheme: const TextTheme(
      bodySmall: TextStyle(color: Color(0xFFB0B8C4)),
      bodyMedium: TextStyle(color: Color(0xFFD0D7E2)),
      titleMedium: TextStyle(color: Color(0xFFE6EDF3)),
      titleLarge: TextStyle(color: Color(0xFFE6EDF3)),
    ),
  );
}
