import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 可复用的加载指示器组件。
///
/// 支持多种形式：居中旋转指示器、骨架屏列表、全屏加载覆盖。
/// 在整个应用中提供一致的加载体验。
class LoadingIndicator extends StatelessWidget {
  /// 加载提示文字
  final String? message;

  /// 加载器颜色
  final Color? color;

  /// 是否显示为骨架屏
  final bool isSkeleton;

  /// 骨架屏行数（仅在 isSkeleton 为 true 时有效）
  final int skeletonRows;

  const LoadingIndicator({
    Key? key,
    this.message,
    this.color,
    this.isSkeleton = false,
    this.skeletonRows = 3,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (isSkeleton) {
      return _buildSkeleton(context);
    }
    return _buildSpinner(context);
  }

  Widget _buildSpinner(BuildContext context) {
    final effectiveColor = color ?? AppTheme.accentBlue;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 36,
              height: 36,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                color: effectiveColor,
              ),
            ),
            if (message != null) ...[
              const SizedBox(height: 16),
              Text(
                message!,
                style: const TextStyle(
                  color: Color(0xFF8B949E),
                  fontSize: 13,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSkeleton(BuildContext context) {
    return Column(
      children: List.generate(skeletonRows, (index) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
          child: Container(
            height: 16,
            decoration: BoxDecoration(
              color: const Color(0xFF21262D),
              borderRadius: BorderRadius.circular(4),
            ),
            // 模拟不同宽度
            child: FractionallySizedBox(
              widthFactor: (index == skeletonRows - 1) ? 0.6 : (0.85 + (index * 0.05)),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFF21262D),
                      const Color(0xFF30363D),
                      const Color(0xFF21262D),
                    ],
                    stops: const [0.3, 0.5, 0.7],
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

/// 卡片骨架屏组件
///
/// 显示一个模拟卡片布局的骨架屏
class CardSkeleton extends StatelessWidget {
  const CardSkeleton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF161B22),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF21262D), width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题行骨架
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: const Color(0xFF21262D),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: 120,
                height: 16,
                decoration: BoxDecoration(
                  color: const Color(0xFF21262D),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // 内容骨架
          const LoadingIndicator(isSkeleton: true, skeletonRows: 4),
        ],
      ),
    );
  }
}
