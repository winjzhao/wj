import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 可复用的雷达图组件。
///
/// 用于风险评估的可视化展示，从预测页面提取。
/// 显示多个维度的评分，用多边形连接各数据点。
class RiskRadarChart extends StatelessWidget {
  /// 数据维度名称列表
  final List<String> dimensions;

  /// 各维度的数值（0.0-1.0）
  final List<double> values;

  /// 图表尺寸
  final double size;

  /// 雷达图颜色
  final Color color;

  /// 填充透明度
  final double fillOpacity;

  /// 轴线颜色
  final Color gridColor;

  /// 标签文字颜色
  final Color labelColor;

  /// 标题（可选）
  final String? title;

  const RiskRadarChart({
    Key? key,
    required this.dimensions,
    required this.values,
    this.size = 200,
    this.color = const Color(0xFF4FC3F7),
    this.fillOpacity = 0.15,
    this.gridColor = const Color(0xFF21262D),
    this.labelColor = const Color(0xFF8B949E),
    this.title,
  })  : assert(dimensions.length == values.length,
            'dimensions and values must have the same length'),
        assert(dimensions.length >= 3, 'At least 3 dimensions are required'),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (title != null) ...[
          Text(
            title!,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 16),
        ],
        CustomPaint(
          size: Size(size, size),
          painter: _RadarChartPainter(
            dimensions: dimensions,
            values: values,
            color: color,
            fillOpacity: fillOpacity,
            gridColor: gridColor,
            labelColor: labelColor,
          ),
        ),
      ],
    );
  }
}

class _RadarChartPainter extends CustomPainter {
  final List<String> dimensions;
  final List<double> values;
  final Color color;
  final double fillOpacity;
  final Color gridColor;
  final Color labelColor;

  _RadarChartPainter({
    required this.dimensions,
    required this.values,
    required this.color,
    required this.fillOpacity,
    required this.gridColor,
    required this.labelColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 40;
    final n = dimensions.length;

    // 绘制背景网格（3层同心多边形）
    final gridPaint = Paint()
      ..color = gridColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5;

    final axisPaint = Paint()
      ..color = gridColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5;

    for (int level = 1; level <= 4; level++) {
      final levelRadius = radius * level / 4;
      final path = Path();
      for (int i = 0; i < n; i++) {
        final angle = -math.pi / 2 + (2 * math.pi * i) / n;
        final x = center.dx + levelRadius * math.cos(angle);
        final y = center.dy + levelRadius * math.sin(angle);
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      path.close();
      canvas.drawPath(path, gridPaint);
    }

    // 绘制轴线
    for (int i = 0; i < n; i++) {
      final angle = -math.pi / 2 + (2 * math.pi * i) / n;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);
      canvas.drawLine(center, Offset(x, y), axisPaint);
    }

    // 绘制数据多边形（填充）
    final dataPath = Path();
    for (int i = 0; i < n; i++) {
      final angle = -math.pi / 2 + (2 * math.pi * i) / n;
      final value = values[i].clamp(0.0, 1.0);
      final x = center.dx + radius * value * math.cos(angle);
      final y = center.dy + radius * value * math.sin(angle);
      if (i == 0) {
        dataPath.moveTo(x, y);
      } else {
        dataPath.lineTo(x, y);
      }
    }
    dataPath.close();

    final fillPaint = Paint()
      ..color = color.withOpacity(fillOpacity)
      ..style = PaintingStyle.fill;
    canvas.drawPath(dataPath, fillPaint);

    // 绘制数据多边形（描边）
    final strokePaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawPath(dataPath, strokePaint);

    // 绘制数据点
    final dotPaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    for (int i = 0; i < n; i++) {
      final angle = -math.pi / 2 + (2 * math.pi * i) / n;
      final value = values[i].clamp(0.0, 1.0);
      final x = center.dx + radius * value * math.cos(angle);
      final y = center.dy + radius * value * math.sin(angle);
      canvas.drawCircle(Offset(x, y), 4, dotPaint);
      canvas.drawCircle(
        Offset(x, y),
        4,
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5,
      );
    }

    // 绘制标签
    for (int i = 0; i < n; i++) {
      final angle = -math.pi / 2 + (2 * math.pi * i) / n;
      final labelRadius = radius + 22;
      final x = center.dx + labelRadius * math.cos(angle);
      final y = center.dy + labelRadius * math.sin(angle);

      final textPainter = TextPainter(
        text: TextSpan(
          text: dimensions[i],
          style: TextStyle(
            color: labelColor,
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
      );
      textPainter.layout(maxWidth: 60);

      // 调整位置使文字居中
      final textOffset = Offset(
        x - textPainter.width / 2,
        y - textPainter.height / 2,
      );
      textPainter.paint(canvas, textOffset);
    }
  }

  @override
  bool shouldRepaint(covariant _RadarChartPainter oldDelegate) {
    return color != oldDelegate.color ||
        values != oldDelegate.values ||
        dimensions != oldDelegate.dimensions;
  }
}
