import 'package:flutter/material.dart';

/// 彩票球状态
enum BallState { normal, hot, cold }

/// 可复用的彩票球组件。
///
/// 显示一个带有径向渐变和阴影的圆形号码球。
/// 支持不同尺寸和热/冷/正常状态颜色。
/// 在预测页面和仪表盘中用于号码球可视化。
class LotteryBall extends StatelessWidget {
  /// 显示的数字
  final String number;

  /// 球的颜色
  final Color color;

  /// 球的大小（直径）
  final double size;

  /// 球的状态（热/冷/正常）
  final BallState state;

  /// 是否被选中
  final bool isSelected;

  /// 点击回调
  final VoidCallback? onTap;

  const LotteryBall({
    Key? key,
    required this.number,
    required this.color,
    this.size = 36,
    this.state = BallState.normal,
    this.isSelected = false,
    this.onTap,
  }) : super(key: key);

  /// 根据状态获取球的颜色
  static Color getStateColor(BallState state, Color baseColor) {
    switch (state) {
      case BallState.hot:
        return const Color(0xFFFF6B6B);
      case BallState.cold:
        return const Color(0xFF42A5F5);
      case BallState.normal:
        return baseColor;
    }
  }

  /// 根据状态获取标签
  static String getStateLabel(BallState state) {
    switch (state) {
      case BallState.hot:
        return '热';
      case BallState.cold:
        return '冷';
      case BallState.normal:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final effectiveColor = state != BallState.normal
        ? getStateColor(state, color)
        : color;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [effectiveColor.withOpacity(0.8), effectiveColor],
            center: const Alignment(-0.3, -0.3),
          ),
          boxShadow: [
            BoxShadow(
              color: effectiveColor.withOpacity(0.35),
              blurRadius: size * 0.22,
              offset: Offset(0, size * 0.08),
            ),
            if (isSelected)
              BoxShadow(
                color: effectiveColor.withOpacity(0.6),
                blurRadius: size * 0.3,
                spreadRadius: 2,
              ),
          ],
          border: isSelected
              ? Border.all(color: Colors.white, width: 2)
              : null,
        ),
        alignment: Alignment.center,
        child: Text(
          number,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: size * 0.4,
          ),
        ),
      ),
    );
  }
}
