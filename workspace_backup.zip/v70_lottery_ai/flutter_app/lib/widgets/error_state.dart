import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 可复用的错误状态组件。
///
/// 当数据加载失败时显示，包含错误信息、图标和重试按钮。
class ErrorState extends StatelessWidget {
  /// 错误提示信息
  final String message;

  /// 错误详情（可选）
  final String? detail;

  /// 图标（可选）
  final IconData? icon;

  /// 重试回调
  final VoidCallback? onRetry;

  /// 重试按钮文字
  final String retryLabel;

  /// 内边距
  final EdgeInsetsGeometry padding;

  const ErrorState({
    Key? key,
    required this.message,
    this.detail,
    this.icon,
    this.onRetry,
    this.retryLabel = '重试',
    this.padding = const EdgeInsets.all(32),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: const Color(0xFF161B22),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.accentRed.withOpacity(0.3),
        ),
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.accentRed.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon ?? Icons.error_outline,
                size: 32,
                color: AppTheme.accentRed,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFFE6EDF3),
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
            if (detail != null) ...[
              const SizedBox(height: 8),
              Text(
                detail!,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF8B949E),
                  fontSize: 12,
                ),
              ),
            ],
            if (onRetry != null) ...[
              const SizedBox(height: 20),
              OutlinedButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh, size: 16),
                label: Text(retryLabel),
                style: OutlinedButton.styleFrom(
                  primary: AppTheme.accentBlue,
                  side: BorderSide(
                    color: AppTheme.accentBlue.withOpacity(0.5),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
