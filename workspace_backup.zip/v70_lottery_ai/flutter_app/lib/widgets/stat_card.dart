import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 趋势方向枚举
enum TrendDirection { up, down, neutral }

/// 可复用的统计卡片组件。
///
/// 用于展示关键统计数据，包含图标、标题、数值、副标题和可选的趋势指示器。
/// 在仪表盘、模型管理和系统页面中广泛使用。
class StatCard extends StatelessWidget {
  /// 卡片图标
  final IconData icon;

  /// 卡片标题/标签
  final String title;

  /// 主要数值
  final String value;

  /// 副标题（可选）
  final String? subtitle;

  /// 渐变背景
  final LinearGradient? gradient;

  /// 图标颜色（当不提供渐变时使用）
  final Color? iconColor;

  /// 趋势方向
  final TrendDirection? trend;

  /// 趋势数值（如 "+5%"）
  final String? trendValue;

  /// 点击回调
  final VoidCallback? onTap;

  const StatCard({
    Key? key,
    required this.icon,
    required this.title,
    required this.value,
    this.subtitle,
    this.gradient,
    this.iconColor,
    this.trend,
    this.trendValue,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final effectiveGradient = gradient ?? AppTheme.primaryGradient;
    final effectiveIconColor = iconColor ?? AppTheme.accentBlue;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF161B22),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF21262D)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: effectiveGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            const SizedBox(height: 12),
            Text(
              value,
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: const Color(0xFFE6EDF3),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: theme.textTheme.bodySmall?.copyWith(
                color: const Color(0xFF8B949E),
              ),
            ),
            if (subtitle != null) ...[
              const SizedBox(height: 2),
              Text(
                subtitle!,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: const Color(0xFF8B949E),
                  fontSize: 10,
                ),
              ),
            ],
            if (trend != null && trendValue != null) ...[
              const SizedBox(height: 8),
              _buildTrend(theme),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTrend(ThemeData theme) {
    final Color trendColor;
    final IconData trendIcon;

    switch (trend!) {
      case TrendDirection.up:
        trendColor = AppTheme.accentGreen;
        trendIcon = Icons.trending_up;
        break;
      case TrendDirection.down:
        trendColor = AppTheme.accentRed;
        trendIcon = Icons.trending_down;
        break;
      case TrendDirection.neutral:
        trendColor = const Color(0xFF8B949E);
        trendIcon = Icons.trending_flat;
        break;
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(trendIcon, size: 14, color: trendColor),
        const SizedBox(width: 4),
        Text(
          trendValue!,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: trendColor,
          ),
        ),
      ],
    );
  }
}
