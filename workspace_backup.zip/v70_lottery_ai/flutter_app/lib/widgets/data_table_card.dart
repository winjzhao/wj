import 'package:flutter/material.dart';
import 'section_header.dart';

/// 可复用的数据表格卡片组件。
///
/// 包含标题和数据表格的卡片，从仪表盘的开奖历史表格提取。
/// 支持自定义列定义、数据行和分页加载。
class DataTableCard extends StatelessWidget {
  /// 表格标题
  final String title;

  /// 标题图标
  final IconData? icon;

  /// 图标背景色
  final Color? iconColor;

  /// 标题徽章
  final String? badge;

  /// 徽章颜色
  final Color? badgeColor;

  /// 列定义
  final List<DataTableColumn> columns;

  /// 数据行
  final List<DataTableRow> rows;

  /// 是否还有更多数据
  final bool hasMore;

  /// 剩余数据条数
  final int remainingCount;

  /// 是否正在加载更多
  final bool isLoadingMore;

  /// 加载更多回调
  final VoidCallback? onLoadMore;

  /// 空数据提示
  final String emptyMessage;

  const DataTableCard({
    Key? key,
    required this.title,
    this.icon,
    this.iconColor,
    this.badge,
    this.badgeColor,
    required this.columns,
    required this.rows,
    this.hasMore = false,
    this.remainingCount = 0,
    this.isLoadingMore = false,
    this.onLoadMore,
    this.emptyMessage = '暂无数据',
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      color: const Color(0xFF161B22),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF21262D), width: 0.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            SectionHeader(
              title: title,
              icon: icon,
              iconColor: iconColor,
              badge: badge,
              badgeColor: badgeColor,
            ),
            const SizedBox(height: 12),
            if (rows.isEmpty)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Center(
                  child: Text(
                    emptyMessage,
                    style: const TextStyle(color: Color(0xFF8B949E)),
                  ),
                ),
              )
            else
              ...rows.map((row) => _buildRow(context, theme, row)),
            if (hasMore)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Center(
                  child: isLoadingMore
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Color(0xFF4FC3F7),
                          ),
                        )
                      : TextButton.icon(
                          onPressed: onLoadMore,
                          icon: const Icon(Icons.expand_more,
                              size: 18, color: Color(0xFF4FC3F7)),
                          label: Text(
                            '加载更多 ($remainingCount 条)',
                            style: const TextStyle(
                              fontSize: 13,
                              color: Color(0xFF4FC3F7),
                            ),
                          ),
                        ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(BuildContext context, ThemeData theme, DataTableRow row) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F2E),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: row.cells.asMap().entries.map((entry) {
          final idx = entry.key;
          final cell = entry.value;
          final col = idx < columns.length ? columns[idx] : null;
          final flex = col?.flex ?? 1;

          if (col != null && col.isFixed) {
            return SizedBox(
              width: col.fixedWidth,
              child: cell,
            );
          }

          return Expanded(
            flex: flex,
            child: cell,
          );
        }).toList(),
      ),
    );
  }
}

/// 数据表格列定义
class DataTableColumn {
  /// 列标题
  final String title;

  /// 弹性比例
  final int flex;

  /// 固定宽度（如果isFixed为true）
  final double? fixedWidth;

  /// 是否固定宽度
  final bool isFixed;

  const DataTableColumn({
    required this.title,
    this.flex = 1,
    this.fixedWidth,
    this.isFixed = false,
  });
}

/// 数据表格行
class DataTableRow {
  /// 该行的单元格组件列表
  final List<Widget> cells;

  const DataTableRow({
    required this.cells,
  });
}
