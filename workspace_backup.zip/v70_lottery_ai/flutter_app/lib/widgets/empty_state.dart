import 'package:flutter/material.dart';

/// 可复用的空状态组件。
///
/// 当列表或内容区域为空时显示，包含图标、提示信息和可选的操作按钮。
class EmptyState extends StatelessWidget {
  /// 提示信息
  final String message;

  /// 图标（可选）
  final IconData? icon;

  /// 图标颜色
  final Color? iconColor;

  /// 操作按钮文字
  final String? actionLabel;

  /// 操作按钮图标
  final IconData? actionIcon;

  /// 操作按钮回调
  final VoidCallback? onAction;

  /// 内边距
  final EdgeInsetsGeometry padding;

  const EmptyState({
    Key? key,
    required this.message,
    this.icon,
    this.iconColor,
    this.actionLabel,
    this.actionIcon,
    this.onAction,
    this.padding = const EdgeInsets.all(32),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: const Color(0xFF161B22),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF21262D)),
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null)
              Icon(
                icon,
                size: 48,
                color: iconColor ?? const Color(0xFF484F58),
              ),
            if (icon != null) const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF8B949E),
                fontSize: 14,
              ),
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 20),
              OutlinedButton.icon(
                onPressed: onAction,
                icon: Icon(actionIcon ?? Icons.add, size: 16),
                label: Text(actionLabel!),
                style: OutlinedButton.styleFrom(
                  primary: Colors.white70,
                  side: const BorderSide(color: Color(0xFF30363D)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 12,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
