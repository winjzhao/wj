import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

/// 模型贡献度饼图/环形图组件。
///
/// 从仪表盘和预测页面提取，展示各AI模型在融合决策中的贡献占比。
/// 包含饼图和右侧图例。
class ModelContributionChart extends StatelessWidget {
  /// 模型贡献度映射表（模型名 -> 权重占比 0.0-1.0）
  final Map<String, double> contributions;

  /// 图表高度
  final double height;

  /// 饼图中心空白半径
  final double centerSpaceRadius;

  /// 饼图外半径
  final double radius;

  /// 是否显示图例
  final bool showLegend;

  /// 自定义模型颜色映射（可选）
  final Map<String, Color>? colorMap;

  /// 空数据时的提示文字
  final String emptyMessage;

  const ModelContributionChart({
    Key? key,
    required this.contributions,
    this.height = 200,
    this.centerSpaceRadius = 28,
    this.radius = 68,
    this.showLegend = true,
    this.colorMap,
    this.emptyMessage = '暂无模型贡献数据',
  }) : super(key: key);

  /// 默认的模型颜色映射
  static const Map<String, Color> defaultColors = {
    'XGBoost': Color(0xFFFF6B6B),
    'LSTM': Color(0xFF5C6BC0),
    'Transformer': Color(0xFF66BB6A),
    'PPO': Color(0xFF42A5F5),
    'Statistic': Color(0xFFFFA726),
    'Behavior': Color(0xFFAB47BC),
  };

  Color _getColor(String modelName) {
    if (colorMap != null && colorMap!.containsKey(modelName)) {
      return colorMap![modelName]!;
    }
    return defaultColors[modelName] ?? Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (contributions.isEmpty) {
      return SizedBox(
        height: height,
        child: Center(
          child: Text(
            emptyMessage,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: const Color(0xFF8B949E),
            ),
          ),
        ),
      );
    }

    return SizedBox(
      height: height,
      child: Row(
        children: [
          Expanded(
            child: PieChart(
              PieChartData(
                sections: contributions.entries.map((entry) {
                  return PieChartSectionData(
                    value: (entry.value).toDouble() * 100,
                    title:
                        '${entry.key}\n${(entry.value * 100).toStringAsFixed(0)}%',
                    color: _getColor(entry.key),
                    radius: radius,
                    titleStyle: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                    titlePositionPercentageOffset: 0.55,
                  );
                }).toList(),
                sectionsSpace: 2,
                centerSpaceRadius: centerSpaceRadius,
              ),
            ),
          ),
          if (showLegend) ...[
            const SizedBox(width: 12),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: contributions.entries.map((entry) {
                final color = _getColor(entry.key);
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '${entry.key} ${(entry.value * 100).toStringAsFixed(0)}%',
                        style: theme.textTheme.bodySmall?.copyWith(
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
        ],
      ),
    );
  }
}
