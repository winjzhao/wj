import 'package:flutter/material.dart';
import 'lottery_ball.dart';

/// 可复用的号码网格组件。
///
/// 以网格形式展示可选号码球，支持选中/取消选中状态。
/// 从预测页面候选方案展示中提取，适用于号码选择器场景。
class NumberGrid extends StatelessWidget {
  /// 主球号码列表
  final List<int> mainBalls;

  /// 主球颜色
  final Color mainColor;

  /// 附加球号码列表
  final List<int>? bonusBalls;

  /// 附加球颜色
  final Color? bonusColor;

  /// 主球最大数量限制
  final int? mainMaxCount;

  /// 附加球最大数量限制
  final int? bonusMaxCount;

  /// 球的大小
  final double ballSize;

  /// 球的间距
  final double spacing;

  /// 每行球的数量
  final int? columns;

  /// 被选中的主球集合
  final Set<int>? selectedMainBalls;

  /// 被选中的附加球集合
  final Set<int>? selectedBonusBalls;

  /// 热号集合
  final Set<int>? hotBalls;

  /// 冷号集合
  final Set<int>? coldBalls;

  /// 点击球回调
  final Function(int number, bool isMainBall)? onBallTap;

  /// 主球标签
  final String mainLabel;

  /// 附加球标签
  final String bonusLabel;

  const NumberGrid({
    Key? key,
    required this.mainBalls,
    required this.mainColor,
    this.bonusBalls,
    this.bonusColor,
    this.mainMaxCount,
    this.bonusMaxCount,
    this.ballSize = 36,
    this.spacing = 6,
    this.columns,
    this.selectedMainBalls,
    this.selectedBonusBalls,
    this.hotBalls,
    this.coldBalls,
    this.onBallTap,
    this.mainLabel = '主号码',
    this.bonusLabel = '附加号',
  }) : super(key: key);

  BallState _getBallState(int number, bool isMain) {
    if (hotBalls != null && hotBalls!.contains(number)) {
      return BallState.hot;
    }
    if (coldBalls != null && coldBalls!.contains(number)) {
      return BallState.cold;
    }
    return BallState.normal;
  }

  bool _isSelected(int number, bool isMain) {
    if (isMain && selectedMainBalls != null) {
      return selectedMainBalls!.contains(number);
    }
    if (!isMain && selectedBonusBalls != null) {
      return selectedBonusBalls!.contains(number);
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (mainBalls.isNotEmpty) ...[
          _buildBallSection(
            context,
            theme,
            label: mainLabel,
            labelColor: mainColor,
            balls: mainBalls,
            color: mainColor,
            maxCount: mainMaxCount,
            isMain: true,
          ),
        ],
        if (bonusBalls != null && bonusBalls!.isNotEmpty) ...[
          const SizedBox(height: 12),
          _buildBallSection(
            context,
            theme,
            label: bonusLabel,
            labelColor: bonusColor ?? mainColor,
            balls: bonusBalls!,
            color: bonusColor ?? mainColor,
            maxCount: bonusMaxCount,
            isMain: false,
          ),
        ],
      ],
    );
  }

  Widget _buildBallSection(
    BuildContext context,
    ThemeData theme, {
    required String label,
    required Color labelColor,
    required List<int> balls,
    required Color color,
    int? maxCount,
    required bool isMain,
  }) {
    final selectedCount = isMain
        ? (selectedMainBalls?.length ?? 0)
        : (selectedBonusBalls?.length ?? 0);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: labelColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            if (maxCount != null) ...[
              const SizedBox(width: 6),
              Text(
                '($selectedCount/$maxCount)',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: const Color(0xFF8B949E),
                  fontSize: 11,
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: balls.map((number) {
            return LotteryBall(
              number: number.toString().padLeft(2, '0'),
              color: color,
              size: ballSize,
              state: _getBallState(number, isMain),
              isSelected: _isSelected(number, isMain),
              onTap: onBallTap != null
                  ? () => onBallTap!(number, isMain)
                  : null,
            );
          }).toList(),
        ),
      ],
    );
  }
}
