import 'package:flutter/material.dart';

/// 可复用的动画数字计数器组件。
///
/// 当数值变化时，以动画方式从旧值滚动到新值。
/// 用于统计卡片中的数值展示，提供视觉上的动态效果。
class AnimatedCounter extends StatefulWidget {
  /// 目标数值
  final double value;

  /// 动画持续时间
  final Duration duration;

  /// 数值样式
  final TextStyle? style;

  /// 小数位数
  final int decimalPlaces;

  /// 是否显示千分位分隔符
  final bool useThousandSeparator;

  /// 前缀文字
  final String? prefix;

  /// 后缀文字
  final String? suffix;

  /// 动画曲线
  final Curve curve;

  const AnimatedCounter({
    Key? key,
    required this.value,
    this.duration = const Duration(milliseconds: 800),
    this.style,
    this.decimalPlaces = 1,
    this.useThousandSeparator = false,
    this.prefix,
    this.suffix,
    this.curve = Curves.easeOutCubic,
  }) : super(key: key);

  @override
  State<AnimatedCounter> createState() => _AnimatedCounterState();
}

class _AnimatedCounterState extends State<AnimatedCounter>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  double _previousValue = 0;

  @override
  void initState() {
    super.initState();
    _previousValue = widget.value;
    _controller = AnimationController(
      duration: widget.duration,
      vsync: this,
    );
    _animation = Tween<double>(
      begin: 0,
      end: widget.value,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: widget.curve,
    ));
    _controller.forward();
  }

  @override
  void didUpdateWidget(AnimatedCounter oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value) {
      _previousValue = oldWidget.value;
      _animation = Tween<double>(
        begin: _previousValue,
        end: widget.value,
      ).animate(CurvedAnimation(
        parent: _controller,
        curve: widget.curve,
      ));
      _controller.reset();
      _controller.forward();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _formatValue(double value) {
    String formatted;
    if (widget.decimalPlaces == 0) {
      formatted = value.round().toString();
    } else {
      formatted = value.toStringAsFixed(widget.decimalPlaces);
    }

    if (widget.useThousandSeparator) {
      final parts = formatted.split('.');
      final intPart = parts[0];
      final decimalPart = parts.length > 1 ? '.${parts[1]}' : '';
      final buffer = StringBuffer();
      for (int i = 0; i < intPart.length; i++) {
        if (i > 0 && (intPart.length - i) % 3 == 0) {
          buffer.write(',');
        }
        buffer.write(intPart[i]);
      }
      formatted = '$buffer$decimalPart';
    }

    if (widget.prefix != null) {
      formatted = '${widget.prefix}$formatted';
    }
    if (widget.suffix != null) {
      formatted = '$formatted${widget.suffix}';
    }

    return formatted;
  }

  @override
  Widget build(BuildContext context) {
    final defaultStyle = Theme.of(context).textTheme.headlineSmall?.copyWith(
          fontWeight: FontWeight.bold,
          color: const Color(0xFFE6EDF3),
        );

    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Text(
          _formatValue(_animation.value),
          style: widget.style ?? defaultStyle,
        );
      },
    );
  }
}
