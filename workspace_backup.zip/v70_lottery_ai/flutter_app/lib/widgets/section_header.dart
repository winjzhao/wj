import 'package:flutter/material.dart';

/// 可复用的分区标题组件。
///
/// 包含标题、可选副标题和可选的操作按钮。
/// 在仪表盘、预测页面、系统页面等多处广泛使用。
class SectionHeader extends StatelessWidget {
  /// 标题文字
  final String title;

  /// 副标题文字（可选）
  final String? subtitle;

  /// 标题前的图标（可选）
  final IconData? icon;

  /// 图标背景色
  final Color? iconBackgroundColor;

  /// 图标颜色
  final Color? iconColor;

  /// 操作按钮文字（可选）
  final String? actionLabel;

  /// 操作按钮图标（可选）
  final IconData? actionIcon;

  /// 操作按钮点击回调
  final VoidCallback? onAction;

  /// 标题右侧的状态徽章文字（可选）
  final String? badge;

  /// 状态徽章颜色
  final Color? badgeColor;

  /// 标题右侧的额外组件（可选）
  final Widget? trailing;

  const SectionHeader({
    Key? key,
    required this.title,
    this.subtitle,
    this.icon,
    this.iconBackgroundColor,
    this.iconColor,
    this.actionLabel,
    this.actionIcon,
    this.onAction,
    this.badge,
    this.badgeColor,
    this.trailing,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        if (icon != null) ...[
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: (iconBackgroundColor ?? iconColor ?? Colors.blue)
                  .withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 18, color: iconColor ?? Colors.blue),
          ),
          const SizedBox(width: 10),
        ],
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (subtitle != null) ...[
                const SizedBox(height: 2),
                Text(
                  subtitle!,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: const Color(0xFF8B949E),
                  ),
                ),
              ],
            ],
          ),
        ),
        if (badge != null) ...[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: (badgeColor ?? Colors.grey).withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              badge!,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: badgeColor,
              ),
            ),
          ),
          const SizedBox(width: 8),
        ],
        if (trailing != null) ...[
          trailing!,
          const SizedBox(width: 4),
        ],
        if (onAction != null && actionLabel != null)
          TextButton(
            onPressed: onAction,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (actionIcon != null) ...[
                  Icon(actionIcon, size: 16),
                  const SizedBox(width: 4),
                ],
                Text(actionLabel!, style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
      ],
    );
  }
}
