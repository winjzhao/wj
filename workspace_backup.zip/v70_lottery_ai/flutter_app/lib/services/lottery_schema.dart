/// 彩票类型完整配置
///
/// 纯 Dart 实现，零 ML 依赖。定义各彩票类型的号码结构，
/// 提供统一的维度查询和号码校验接口。
class LotterySchema {
  final String name;
  final String displayName;
  final int mainCount; // 主球选号个数
  final int mainRange; // 主球范围 [1, mainRange]
  final List<int> bonusCounts; // 附加球区各区的选号个数
  final List<int> bonusRanges; // 附加球区各区的范围

  const LotterySchema({
    required this.name,
    required this.displayName,
    required this.mainCount,
    required this.mainRange,
    required this.bonusCounts,
    required this.bonusRanges,
  });

  /// 主球维度（概率向量长度）
  int get mainDim => mainRange;

  /// 附加球维度列表
  List<int> get bonusDims => bonusRanges;

  /// 总维度（主球区 + 所有附加球区）
  int get totalDim =>
      mainRange + bonusRanges.fold<int>(0, (a, b) => a + b);

  /// 附加球区总选号个数
  int get totalBonusCount =>
      bonusCounts.fold<int>(0, (a, b) => a + b);

  /// 总选号个数（主球 + 附加球）
  int get totalCount => mainCount + totalBonusCount;

  /// 校验主球号码是否合法
  ///
  /// 检查数量、范围、无重复。
  bool validateMainBalls(List<int> balls) {
    if (balls.length != mainCount) return false;
    for (final b in balls) {
      if (b < 1 || b > mainRange) return false;
    }
    return balls.toSet().length == balls.length;
  }

  /// 校验附加球号码是否合法
  ///
  /// 检查各区数量、范围、无重复。
  bool validateBonusBalls(List<List<int>> bonusBalls) {
    if (bonusBalls.length != bonusCounts.length) return false;
    for (int i = 0; i < bonusBalls.length; i++) {
      final balls = bonusBalls[i];
      if (balls.length != bonusCounts[i]) return false;
      for (final b in balls) {
        if (b < 1 || b > bonusRanges[i]) return false;
      }
      if (balls.toSet().length != balls.length) return false;
    }
    return true;
  }

  /// 校验所有号码（主球 + 附加球）
  bool validateBalls(List<int> mainBalls, List<List<int>> bonusBalls) {
    return validateMainBalls(mainBalls) && validateBonusBalls(bonusBalls);
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is LotterySchema &&
          name == other.name &&
          displayName == other.displayName &&
          mainCount == other.mainCount &&
          mainRange == other.mainRange;

  @override
  int get hashCode => name.hashCode;
}

/// 预定义的彩票 Schema
///
/// 包含双色球 (SSQ)、大乐透 (DLT)、快乐8 (K8) 三种主流彩票的完整配置。
class LotterySchemas {
  LotterySchemas._();

  /// 双色球：红球 6/33 + 蓝球 1/16
  static const ssq = LotterySchema(
    name: 'ssq',
    displayName: '双色球',
    mainCount: 6,
    mainRange: 33,
    bonusCounts: [1],
    bonusRanges: [16],
  );

  /// 大乐透：前区 5/35 + 后区 2/12
  static const dlt = LotterySchema(
    name: 'dlt',
    displayName: '大乐透',
    mainCount: 5,
    mainRange: 35,
    bonusCounts: [2],
    bonusRanges: [12],
  );

  /// 快乐8：选号 20/80，无附加球区
  static const k8 = LotterySchema(
    name: 'k8',
    displayName: '快乐8',
    mainCount: 20,
    mainRange: 80,
    bonusCounts: [],
    bonusRanges: [],
  );

  /// 根据名称获取对应的 Schema
  ///
  /// 默认返回 [ssq]（双色球）。
  static LotterySchema getByName(String name) {
    switch (name.toLowerCase()) {
      case 'dlt':
        return dlt;
      case 'k8':
        return k8;
      default:
        return ssq;
    }
  }

  /// 所有支持的彩票类型列表
  static List<String> get allTypes => ['ssq', 'dlt', 'k8'];
}
