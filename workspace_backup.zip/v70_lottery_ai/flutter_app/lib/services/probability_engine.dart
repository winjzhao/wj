/// 概率融合引擎 - 纯 Dart 实现
///
/// 将 Python 后端 probability.py 的 4 种融合算法
/// 以纯数学公式移植到 Dart，零 ML 依赖。
import 'dart:math';

class ProbabilityEngine {
  ProbabilityEngine._();

  /// 安全归一化：将概率向量归一化到和为 1
  ///
  /// 对应 Python: _safe_normalize()
  static List<double> safeNormalize(List<double> probs) {
    final sum = probs.fold<double>(0, (a, b) => a + b);
    if (sum == 0) {
      return List.filled(probs.length, 1.0 / probs.length);
    }
    return probs.map((p) => p / sum).toList();
  }

  /// 加权平均融合
  ///
  /// 对应 Python: weighted_average()
  /// result[j] = sum(prob_i[j] * weight_i) / sum(weights)
  static List<double> weightedAverage({
    required List<List<double>> probsList,
    required List<double> weights,
  }) {
    final n = probsList[0].length;
    final result = List<double>.filled(n, 0.0);
    final sumW = weights.fold<double>(0, (a, b) => a + b);

    for (int i = 0; i < probsList.length; i++) {
      final w = sumW > 0 ? weights[i] / sumW : 1.0 / probsList.length;
      for (int j = 0; j < n; j++) {
        result[j] += probsList[i][j] * w;
      }
    }
    return result;
  }

  /// 贝叶斯融合
  ///
  /// 对应 Python: bayesian_fusion()
  /// result[j] = ∏ prob_i[j] * prior[j], then normalize
  static List<double> bayesianFusion({
    required List<List<double>> probsList,
    List<double>? prior,
  }) {
    final n = probsList[0].length;
    final result = List<double>.filled(n, 1.0);
    final p = prior ?? List.filled(n, 1.0 / n);

    for (int i = 0; i < probsList.length; i++) {
      for (int j = 0; j < n; j++) {
        result[j] *= (probsList[i][j] + 1e-10) * p[j]; // 防止零乘
      }
    }
    return safeNormalize(result);
  }

  /// 对数意见池融合
  ///
  /// 对应 Python: log_opinion_pool()
  /// result[j] = exp(sum(w_i * log(prob_i[j])))
  static List<double> logOpinionPool({
    required List<List<double>> probsList,
    required List<double> weights,
  }) {
    final n = probsList[0].length;
    final result = List<double>.filled(n, 0.0);
    final sumW = weights.fold<double>(0, (a, b) => a + b);

    for (int i = 0; i < probsList.length; i++) {
      final w = sumW > 0 ? weights[i] / sumW : 1.0 / probsList.length;
      for (int j = 0; j < n; j++) {
        result[j] += w * log(max(probsList[i][j], 1e-10));
      }
    }

    for (int j = 0; j < n; j++) {
      result[j] = exp(result[j]);
    }
    return safeNormalize(result);
  }

  /// 混合专家融合
  ///
  /// 对应 Python: mixture_of_experts()
  static List<double> mixtureOfExperts({
    required List<List<double>> probsList,
    required List<double> gateWeights,
  }) {
    return weightedAverage(probsList: probsList, weights: gateWeights);
  }

  /// 熵计算 - 衡量预测的确定性
  static double calculateEntropy(List<double> probs) {
    double entropy = 0;
    for (final p in probs) {
      if (p > 1e-10) {
        entropy -= p * log(p);
      }
    }
    return entropy;
  }

  /// 预测分数计算
  ///
  /// 对应 Python: _calculate_final_score()
  /// mean / (1 + std * 0.1)
  static double calculateFinalScore(List<double> scores) {
    if (scores.isEmpty) return 0;
    final mean = scores.reduce((a, b) => a + b) / scores.length;
    if (scores.length < 2) return mean;
    final variance = scores
            .map((s) => (s - mean) * (s - mean))
            .reduce((a, b) => a + b) /
        scores.length;
    final std = sqrt(variance);
    return mean / (1 + std * 0.1);
  }
}
