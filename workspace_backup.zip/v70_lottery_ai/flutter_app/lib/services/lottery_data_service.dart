import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models/lottery_draw.dart';

/// 从 assets/lottery_data.json 加载真实彩票数据
class LotteryDataService {
  static LotteryDataService? _instance;
  Map<String, dynamic>? _cache;
  bool _loaded = false;

  factory LotteryDataService() {
    _instance ??= LotteryDataService._();
    return _instance!;
  }

  LotteryDataService._();

  bool get isLoaded => _loaded;

  /// 加载 JSON 数据文件
  Future<void> load() async {
    if (_loaded) return;
    try {
      final jsonStr = await rootBundle.loadString('assets/lottery_data.json');
      _cache = jsonDecode(jsonStr) as Map<String, dynamic>;
      _loaded = true;
    } catch (e) {
      _cache = {};
      _loaded = true;
    }
  }

  /// 获取某类型彩票的开奖数据列表（保持 Map 类型，向后兼容）
  List<Map<String, dynamic>> getDraws(String lotteryType) {
    if (_cache == null) return [];
    final list = _cache![lotteryType];
    if (list is List) return list.cast<Map<String, dynamic>>();
    return [];
  }

  /// 获取某类型彩票的开奖数据列表（类型安全）
  List<LotteryDraw> getDrawsTyped(String lotteryType) {
    return getDraws(lotteryType)
        .map((json) => LotteryDraw.fromJson(json))
        .toList();
  }

  /// 获取数据总量
  int getDrawCount(String lotteryType) => getDraws(lotteryType).length;

  /// 获取总条数
  int get totalDraws =>
      getDrawCount('ssq') + getDrawCount('dlt') + getDrawCount('k8');

  /// 获取数据源信息
  Map<String, String> get dataSources {
    if (_cache == null) return {};
    final src = _cache!['data_sources'];
    if (src is Map) return src.cast<String, String>();
    return {};
  }

  /// 获取生成时间
  String get generatedAt => _cache?['generated_at']?.toString() ?? '';
}
