/// 风险控制器 - 纯 Dart 实现
///
/// 将 Python 后端 risk_control.py 的风险评估逻辑
/// 以纯 Dart 重写。评估候选方案的集中度、模式、波动风险。
import 'dart:math';
import 'lottery_schema.dart';

/// 风险评估结果
class RiskAssessment {
  final double overallRisk; // 0-1，越高越危险
  final String riskLevel; // low, medium, high
  final List<String> warnings;
  final double concentrationRisk;
  final double patternRisk;
  final double volatilityRisk;

  const RiskAssessment({
    required this.overallRisk,
    required this.riskLevel,
    required this.warnings,
    this.concentrationRisk = 0,
    this.patternRisk = 0,
    this.volatilityRisk = 0,
  });

  Map<String, dynamic> toMap() => {
        'overall_risk': overallRisk,
        'risk_level': riskLevel,
        'warnings': warnings,
        'concentration_risk': concentrationRisk,
        'pattern_risk': patternRisk,
        'volatility_risk': volatilityRisk,
      };
}

class RiskController {
  RiskController._();

  /// 评估候选方案的整体风险
  static RiskAssessment assessRisk({
    required List<List<int>> candidateMainBalls,
    required LotterySchema schema,
  }) {
    final warnings = <String>[];

    // 1. 集中度风险
    final allBalls = candidateMainBalls.expand((b) => b).toList();
    final freq = <int, int>{};
    for (final ball in allBalls) {
      freq[ball] = (freq[ball] ?? 0) + 1;
    }

    double concentrationRisk = 0;
    if (candidateMainBalls.isNotEmpty && allBalls.isNotEmpty) {
      final maxFreq =
          freq.values.fold<int>(0, (a, b) => a > b ? a : b);
      final avgFreq = allBalls.length / schema.mainDim;
      concentrationRisk =
          ((maxFreq / max(avgFreq, 1)) - 1).clamp(0.0, 1.0);
      if (concentrationRisk > 0.5) {
        warnings.add('候选方案号码集中度较高，建议分散选号');
      }
    }

    // 2. 模式风险
    double patternRisk = 0;
    for (final balls in candidateMainBalls) {
      final sorted = List<int>.from(balls)..sort();
      int maxConsecutive = 1;
      int currentConsecutive = 1;
      for (int i = 1; i < sorted.length; i++) {
        if (sorted[i] - sorted[i - 1] == 1) {
          currentConsecutive++;
          maxConsecutive = max(maxConsecutive, currentConsecutive);
        } else {
          currentConsecutive = 1;
        }
      }
      if (maxConsecutive >= 3) {
        patternRisk += 0.2;
      }

      final oddCount = balls.where((b) => b % 2 == 1).length;
      if (oddCount == 0 || oddCount == balls.length) {
        patternRisk += 0.3;
        if (!warnings.contains('存在全奇或全偶方案，建议调整')) {
          warnings.add('存在全奇或全偶方案，建议调整');
        }
      }
    }
    patternRisk =
        min(patternRisk / max(candidateMainBalls.length, 1), 1.0);

    // 3. 波动风险 - 基于候选间重叠度
    double volatilityRisk = 0;
    if (candidateMainBalls.length >= 2) {
      final sets = candidateMainBalls.map((b) => b.toSet()).toList();
      double totalOverlap = 0;
      int pairs = 0;
      for (int i = 0; i < sets.length; i++) {
        for (int j = i + 1; j < sets.length; j++) {
          totalOverlap +=
              sets[i].intersection(sets[j]).length / schema.mainCount;
          pairs++;
        }
      }
      final avgOverlap = pairs > 0 ? totalOverlap / pairs : 0;
      volatilityRisk = 1.0 - avgOverlap;
    }

    // 综合
    final overallRisk =
        (concentrationRisk * 0.35 + patternRisk * 0.35 + volatilityRisk * 0.3)
            .clamp(0.0, 1.0);

    String riskLevel;
    if (overallRisk < 0.3) {
      riskLevel = 'low';
    } else if (overallRisk < 0.6) {
      riskLevel = 'medium';
    } else {
      riskLevel = 'high';
      if (warnings.isEmpty) {
        warnings.add('整体风险偏高，请谨慎参考');
      }
    }

    return RiskAssessment(
      overallRisk: overallRisk,
      riskLevel: riskLevel,
      warnings: warnings,
      concentrationRisk: concentrationRisk,
      patternRisk: patternRisk,
      volatilityRisk: volatilityRisk,
    );
  }

  /// 单方案风险评估
  static Map<String, dynamic> assessSingleCandidate({
    required List<int> mainBalls,
    required LotterySchema schema,
  }) {
    final sum = mainBalls.fold<int>(0, (a, b) => a + b);
    final sorted = List<int>.from(mainBalls)..sort();
    final span = sorted.last - sorted.first;
    final oddCount = mainBalls.where((b) => b % 2 == 1).length;

    final warnings = <String>[];

    switch (schema.name) {
      case 'ssq':
        if (sum < 60 || sum > 150) warnings.add('和值偏离正常范围');
        if (span < 12 || span > 32) warnings.add('跨度偏离正常范围');
        if (oddCount <= 1 || oddCount >= 5) warnings.add('奇偶比失衡');
        break;
      case 'dlt':
        if (sum < 30 || sum > 120) warnings.add('和值偏离正常范围');
        if (oddCount <= 0 || oddCount >= 5) warnings.add('奇偶比失衡');
        break;
    }

    return {
      'sum': sum,
      'span': span,
      'odd_ratio': oddCount / mainBalls.length,
      'warnings': warnings,
      'is_risky': warnings.isNotEmpty,
    };
  }
}
