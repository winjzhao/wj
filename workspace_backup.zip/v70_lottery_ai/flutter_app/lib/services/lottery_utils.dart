/// 彩票工具函数
///
/// 纯 Dart 实现，零 ML 依赖。
/// 提供命中计算、奖级判定、期号格式化等功能。
import 'lottery_schema.dart';

/// 命中计算结果
///
/// 表示预测号码与开奖号码在各区的命中情况。
class MatchResult {
  /// 主球区命中数
  final int mainMatches;

  /// 各附加球区的命中数
  final List<int> bonusMatches;

  /// 总命中数（主球 + 所有附加球）
  final int totalMatches;

  const MatchResult({
    required this.mainMatches,
    required this.bonusMatches,
    required this.totalMatches,
  });

  /// 是否命中（至少命中一球）
  bool get isWin => mainMatches > 0 || totalMatches > 0;

  @override
  String toString() =>
      'MatchResult(main=$mainMatches, bonus=$bonusMatches, total=$totalMatches)';
}

/// 奖级信息
class PrizeLevel {
  final String name;
  final int level;
  final int requiredMainMatches;
  final List<int> requiredBonusMatches;

  const PrizeLevel({
    required this.name,
    required this.level,
    required this.requiredMainMatches,
    required this.requiredBonusMatches,
  });

  @override
  String toString() => '$name（${level}等奖）';
}

// ============================================================
// 命中计算
// ============================================================

/// 通用命中计算
///
/// 计算预测号码与开奖号码在各区的交集命中数。
/// [predictionMain] 和 [actualMain] 是主球号码列表。
/// [predictionBonus] 和 [actualBonus] 是附加球各区号码列表的列表。
MatchResult calculateMatchCount({
  required List<int> predictionMain,
  required List<List<int>> predictionBonus,
  required List<int> actualMain,
  required List<List<int>> actualBonus,
}) {
  final mainSet = predictionMain.toSet();
  final actualMainSet = actualMain.toSet();
  final mainMatches = mainSet.intersection(actualMainSet).length;

  final bonusMatches = <int>[];
  int totalBonusMatches = 0;
  for (int i = 0; i < predictionBonus.length; i++) {
    if (i < actualBonus.length) {
      final pSet = predictionBonus[i].toSet();
      final aSet = actualBonus[i].toSet();
      final m = pSet.intersection(aSet).length;
      bonusMatches.add(m);
      totalBonusMatches += m;
    } else {
      bonusMatches.add(0);
    }
  }

  return MatchResult(
    mainMatches: mainMatches,
    bonusMatches: bonusMatches,
    totalMatches: mainMatches + totalBonusMatches,
  );
}

/// SSQ 向后兼容命中计算
///
/// 将 7 个球的扁平列表（前 6 红 + 最后 1 蓝）与开奖号对比。
MatchResult calculateMatchCountSSQ(
  List<int> prediction,
  List<int> actual,
) {
  final predMain = prediction.take(6).toList();
  final actualMain = actual.take(6).toList();
  final predBonus = prediction.length > 6 ? [prediction[6]] : <int>[];
  final actualBonus = actual.length > 6 ? [actual[6]] : <int>[];

  return calculateMatchCount(
    predictionMain: predMain,
    predictionBonus: predBonus.isNotEmpty ? [predBonus] : [],
    actualMain: actualMain,
    actualBonus: actualBonus.isNotEmpty ? [actualBonus] : [],
  );
}

// ============================================================
// 奖级判定
// ============================================================

/// SSQ 双色球奖级判定
///
/// 根据红球命中数和蓝球命中数返回对应奖级。
/// 红球 6/33，蓝球 1/16。
PrizeLevel? calculateSSQPrizeLevel(int redMatches, int blueMatches) {
  if (redMatches == 6 && blueMatches == 1) {
    return const PrizeLevel(
        name: '一等奖', level: 1, requiredMainMatches: 6, requiredBonusMatches: [1]);
  } else if (redMatches == 6 && blueMatches == 0) {
    return const PrizeLevel(
        name: '二等奖', level: 2, requiredMainMatches: 6, requiredBonusMatches: [0]);
  } else if (redMatches == 5 && blueMatches == 1) {
    return const PrizeLevel(
        name: '三等奖', level: 3, requiredMainMatches: 5, requiredBonusMatches: [1]);
  } else if ((redMatches == 5 && blueMatches == 0) ||
      (redMatches == 4 && blueMatches == 1)) {
    return const PrizeLevel(
        name: '四等奖', level: 4, requiredMainMatches: 5, requiredBonusMatches: [0]);
  } else if ((redMatches == 4 && blueMatches == 0) ||
      (redMatches == 3 && blueMatches == 1)) {
    return const PrizeLevel(
        name: '五等奖', level: 5, requiredMainMatches: 4, requiredBonusMatches: [0]);
  } else if (blueMatches == 1) {
    return const PrizeLevel(
        name: '六等奖', level: 6, requiredMainMatches: 0, requiredBonusMatches: [1]);
  }
  return null;
}

/// DLT 大乐透奖级判定
///
/// 根据前区命中数和后区命中数返回对应奖级。
/// 前区 5/35，后区 2/12。
PrizeLevel? calculateDLTPrizeLevel(int mainMatches, int bonusMatches) {
  if (mainMatches == 5 && bonusMatches == 2) {
    return const PrizeLevel(
        name: '一等奖', level: 1, requiredMainMatches: 5, requiredBonusMatches: [2]);
  } else if (mainMatches == 5 && bonusMatches == 1) {
    return const PrizeLevel(
        name: '二等奖', level: 2, requiredMainMatches: 5, requiredBonusMatches: [1]);
  } else if (mainMatches == 5 && bonusMatches == 0) {
    return const PrizeLevel(
        name: '三等奖', level: 3, requiredMainMatches: 5, requiredBonusMatches: [0]);
  } else if (mainMatches == 4 && bonusMatches == 2) {
    return const PrizeLevel(
        name: '四等奖', level: 4, requiredMainMatches: 4, requiredBonusMatches: [2]);
  } else if (mainMatches == 4 && bonusMatches == 1) {
    return const PrizeLevel(
        name: '五等奖', level: 5, requiredMainMatches: 4, requiredBonusMatches: [1]);
  } else if (mainMatches == 3 && bonusMatches == 2) {
    return const PrizeLevel(
        name: '六等奖', level: 6, requiredMainMatches: 3, requiredBonusMatches: [2]);
  } else if (mainMatches == 4 && bonusMatches == 0) {
    return const PrizeLevel(
        name: '七等奖', level: 7, requiredMainMatches: 4, requiredBonusMatches: [0]);
  } else if ((mainMatches == 3 && bonusMatches == 1) ||
      (mainMatches == 2 && bonusMatches == 2)) {
    return const PrizeLevel(
        name: '八等奖', level: 8, requiredMainMatches: 3, requiredBonusMatches: [1]);
  } else if ((mainMatches == 3 && bonusMatches == 0) ||
      (mainMatches == 1 && bonusMatches == 2) ||
      (mainMatches == 2 && bonusMatches == 1) ||
      (mainMatches == 0 && bonusMatches == 2)) {
    return const PrizeLevel(
        name: '九等奖', level: 9, requiredMainMatches: 0, requiredBonusMatches: [2]);
  }
  return null;
}

/// K8 快乐8奖级判定
///
/// 根据命中数返回对应奖级。
/// 选 20/80。
PrizeLevel? calculateK8PrizeLevel(int matchCount) {
  if (matchCount >= 20) {
    return const PrizeLevel(
        name: '一等奖', level: 1, requiredMainMatches: 20, requiredBonusMatches: []);
  } else if (matchCount >= 18) {
    return const PrizeLevel(
        name: '二等奖', level: 2, requiredMainMatches: 18, requiredBonusMatches: []);
  } else if (matchCount >= 16) {
    return const PrizeLevel(
        name: '三等奖', level: 3, requiredMainMatches: 16, requiredBonusMatches: []);
  } else if (matchCount >= 14) {
    return const PrizeLevel(
        name: '四等奖', level: 4, requiredMainMatches: 14, requiredBonusMatches: []);
  } else if (matchCount >= 12) {
    return const PrizeLevel(
        name: '五等奖', level: 5, requiredMainMatches: 12, requiredBonusMatches: []);
  } else if (matchCount >= 10) {
    return const PrizeLevel(
        name: '六等奖', level: 6, requiredMainMatches: 10, requiredBonusMatches: []);
  } else if (matchCount >= 5) {
    return const PrizeLevel(
        name: '七等奖', level: 7, requiredMainMatches: 5, requiredBonusMatches: []);
  }
  return null;
}

/// 根据彩票类型和命中结果判定奖级
///
/// 自动路由到对应的奖级判定函数。
PrizeLevel? calculatePrizeLevel(
  String lotteryType,
  MatchResult match,
) {
  switch (lotteryType.toLowerCase()) {
    case 'dlt':
      return calculateDLTPrizeLevel(
        match.mainMatches,
        match.bonusMatches.isNotEmpty ? match.bonusMatches[0] : 0,
      );
    case 'k8':
      return calculateK8PrizeLevel(match.totalMatches);
    default:
      return calculateSSQPrizeLevel(
        match.mainMatches,
        match.bonusMatches.isNotEmpty ? match.bonusMatches[0] : 0,
      );
  }
}

/// 通用奖级判定（基于总命中数和蓝球命中）
///
/// 与 Python 后端 utils.py 保持一致的简化接口。
String calculatePrizeLevelSimple(
    int matchCount, bool matchBlue, String lotteryType) {
  if (lotteryType == 'ssq') {
    if (matchCount == 7) {
      return '一等奖';
    } else if (matchCount == 6 && !matchBlue) {
      return '二等奖';
    } else if (matchCount == 6) {
      return '三等奖';
    } else if (matchCount == 5) {
      return '四等奖';
    } else if (matchCount == 4) {
      return '五等奖';
    } else if (matchBlue) {
      return '六等奖';
    } else {
      return '未中奖';
    }
  } else if (lotteryType == 'dlt') {
    if (matchCount >= 7) {
      return '一等奖';
    } else if (matchCount == 6) {
      return '二等奖';
    } else if (matchCount == 5) {
      return '三等奖';
    } else if (matchCount == 4) {
      return '四等奖';
    } else if (matchCount == 3) {
      return '五等奖';
    } else if (matchCount == 2) {
      return '六等奖';
    } else if (matchCount == 1) {
      return '七等奖';
    } else {
      return '未中奖';
    }
  } else if (lotteryType == 'k8') {
    if (matchCount >= 18) {
      return '一等奖';
    } else if (matchCount >= 16) {
      return '二等奖';
    } else if (matchCount >= 14) {
      return '三等奖';
    } else if (matchCount >= 12) {
      return '四等奖';
    } else if (matchCount >= 10) {
      return '五等奖';
    } else if (matchCount >= 8) {
      return '六等奖';
    } else if (matchCount >= 5) {
      return '七等奖';
    } else {
      return '未中奖';
    }
  } else {
    return '未中奖';
  }
}

// ============================================================
// 期号工具
// ============================================================

/// 格式化期号
///
/// 与 Python 后端保持一致：`第{period}期`
String formatPeriod(String rawPeriod) {
  return '第$rawPeriod期';
}

/// 获取当前大致期号（基于日期估算）
///
/// 根据彩票类型的开奖频率估算当前期号。
/// - SSQ: 每周 3 次（二四日）
/// - DLT: 每周 3 次（一三六）
/// - K8: 每天 1 次
String estimateCurrentPeriod(String lotteryType) {
  final now = DateTime.now();

  // 各彩票起始日期
  final DateTime startDate;
  int periodsPerWeek;
  switch (lotteryType.toLowerCase()) {
    case 'dlt':
      startDate = DateTime(2007, 5, 28);
      periodsPerWeek = 3;
      break;
    case 'k8':
      startDate = DateTime(2021, 1, 8);
      periodsPerWeek = 7;
      break;
    default:
      startDate = DateTime(2003, 2, 23);
      periodsPerWeek = 3;
  }

  final daysSinceStart = now.difference(startDate).inDays;
  final estimatedPeriods = (daysSinceStart * periodsPerWeek / 7).round();

  return '${now.year}$estimatedPeriods';
}
