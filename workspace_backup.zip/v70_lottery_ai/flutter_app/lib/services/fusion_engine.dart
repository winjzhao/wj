/// 融合决策引擎 - 纯 Dart 实现
///
/// 将 Python 后端 fusion.py 的融合决策逻辑
/// 以纯 Dart 重写。支持：
/// 1. 多模型概率加权融合
/// 2. 按概率不放回采样生成候选方案
/// 3. 结构过滤、评分、低撞去重
import 'dart:math';
import 'probability_engine.dart';
import 'lottery_schema.dart';

/// 模型输出
class ModelOutput {
  final String modelName;
  final List<double> mainProbs;
  final List<List<double>> bonusProbs;
  final double confidence;
  final double credibility;
  final double baseWeight;

  const ModelOutput({
    required this.modelName,
    required this.mainProbs,
    required this.bonusProbs,
    this.confidence = 0.5,
    this.credibility = 0.5,
    this.baseWeight = 1.0,
  });
}

/// 候选方案
class FusionCandidate {
  final List<int> mainBalls;
  final List<List<int>> bonusBalls;
  final double score;
  final double probability;

  const FusionCandidate({
    required this.mainBalls,
    required this.bonusBalls,
    required this.score,
    required this.probability,
  });
}

/// 融合结果
class FusionResult {
  final List<double> fusedMainProbs;
  final List<List<double>> fusedBonusProbs;
  final List<FusionCandidate> candidates;
  final double finalScore;
  final Map<String, double> modelContributions;
  final double riskScore;
  final double entropy;

  const FusionResult({
    required this.fusedMainProbs,
    required this.fusedBonusProbs,
    required this.candidates,
    required this.finalScore,
    required this.modelContributions,
    required this.riskScore,
    required this.entropy,
  });
}

/// 融合决策引擎
class FusionEngine {
  final LotterySchema schema;
  final int numCandidates;
  final Random _random;

  FusionEngine({
    required this.schema,
    this.numCandidates = 10,
    Random? random,
  }) : _random = random ?? Random();

  /// 计算实际权重：baseWeight * credibility * confidence，归一化
  Map<String, double> _calculateWeights(List<ModelOutput> outputs) {
    final rawWeights = <String, double>{};
    for (final o in outputs) {
      rawWeights[o.modelName] = o.baseWeight * o.credibility * o.confidence;
    }
    final total = rawWeights.values.fold<double>(0, (a, b) => a + b);
    if (total == 0) {
      final equal = 1.0 / outputs.length;
      for (final o in outputs) {
        rawWeights[o.modelName] = equal;
      }
      return rawWeights;
    }
    for (final key in rawWeights.keys) {
      rawWeights[key] = rawWeights[key]! / total;
    }
    return rawWeights;
  }

  /// 主融合函数
  FusionResult fuse(List<ModelOutput> outputs) {
    if (outputs.isEmpty) {
      throw ArgumentError('至少需要一个模型输出');
    }

    final weights = _calculateWeights(outputs);
    final weightList = outputs.map((o) => weights[o.modelName]!).toList();

    // 1. 融合主球概率
    final mainProbsList = outputs.map((o) => o.mainProbs).toList();
    final fusedMainProbs = ProbabilityEngine.weightedAverage(
      probsList: mainProbsList,
      weights: weightList,
    );

    // 2. 融合附加球概率
    final fusedBonusProbs = <List<double>>[];
    if (outputs.first.bonusProbs.isNotEmpty) {
      for (int b = 0; b < outputs.first.bonusProbs.length; b++) {
        final bonusProbsList = outputs.map((o) => o.bonusProbs[b]).toList();
        fusedBonusProbs.add(ProbabilityEngine.weightedAverage(
          probsList: bonusProbsList,
          weights: weightList,
        ));
      }
    }

    // 3. 生成候选方案
    final candidates =
        _generateCandidates(fusedMainProbs, fusedBonusProbs);

    // 4. 计算最终评分
    final scores = candidates.map((c) => c.score).toList();
    final finalScore = ProbabilityEngine.calculateFinalScore(scores);

    // 5. 风险评分
    final riskScore = _calculateRiskScore(candidates, fusedMainProbs);

    // 6. 熵
    final entropy = ProbabilityEngine.calculateEntropy(fusedMainProbs);

    return FusionResult(
      fusedMainProbs: fusedMainProbs,
      fusedBonusProbs: fusedBonusProbs,
      candidates: candidates,
      finalScore: finalScore,
      modelContributions: Map<String, double>.from(weights),
      riskScore: riskScore,
      entropy: entropy,
    );
  }

  /// 生成候选方案 - 按概率加权不放回采样
  List<FusionCandidate> _generateCandidates(
    List<double> mainProbs,
    List<List<double>> bonusProbs,
  ) {
    final candidates = <FusionCandidate>[];
    final usedSets = <String>{};

    int attempts = 0;
    while (candidates.length < numCandidates &&
        attempts < numCandidates * 20) {
      attempts++;

      // 加权不放回采样主球
      final mainBalls =
          _weightedSampleWithoutReplacement(mainProbs, schema.mainCount);
      mainBalls.sort();

      // 采样附加球
      final bonusBalls = <List<int>>[];
      for (int b = 0; b < schema.bonusCounts.length; b++) {
        final bBalls = _weightedSampleWithoutReplacement(
          bonusProbs.isNotEmpty && b < bonusProbs.length
              ? bonusProbs[b]
              : List.filled(
                  schema.bonusRanges[b], 1.0 / schema.bonusRanges[b]),
          schema.bonusCounts[b],
        );
        bBalls.sort();
        bonusBalls.add(bBalls);
      }

      // 结构过滤
      if (!_structureFilter(mainBalls)) continue;

      // 低撞过滤（去重）
      final key =
          '${mainBalls.join(',')}|${bonusBalls.map((b) => b.join(',')).join('|')}';
      if (usedSets.contains(key)) continue;
      usedSets.add(key);

      // 评分
      final score = _scoreCandidate(mainBalls, bonusBalls, mainProbs);
      final probability =
          _calculateCandidateProbability(mainBalls, mainProbs);

      candidates.add(FusionCandidate(
        mainBalls: mainBalls,
        bonusBalls: bonusBalls,
        score: score,
        probability: probability,
      ));
    }

    // 按分数降序排序
    candidates.sort((a, b) => b.score.compareTo(a.score));
    return candidates;
  }

  /// 加权不放回采样
  List<int> _weightedSampleWithoutReplacement(
      List<double> probs, int count) {
    final indices =
        List.generate(probs.length, (i) => i);
    final sampled = <int>[];
    final remainingProbs = List<double>.from(probs);

    for (int k = 0; k < count && indices.isNotEmpty; k++) {
      final sum = remainingProbs.fold<double>(0, (a, b) => a + b);
      if (sum <= 0) break;

      double r = _random.nextDouble() * sum;
      int selectedIdx = 0;
      double cumulative = 0;
      for (int i = 0; i < remainingProbs.length; i++) {
        cumulative += remainingProbs[i];
        if (r <= cumulative) {
          selectedIdx = i;
          break;
        }
      }

      sampled.add(indices[selectedIdx] + 1); // 转为 1-indexed
      indices.removeAt(selectedIdx);
      remainingProbs.removeAt(selectedIdx);
    }

    return sampled;
  }

  /// 结构过滤器 - 对应 Python _structure_filter()
  bool _structureFilter(List<int> mainBalls) {
    final sum = mainBalls.fold<int>(0, (a, b) => a + b);
    final sorted = List<int>.from(mainBalls)..sort();
    final span = sorted.last - sorted.first;
    final oddCount = mainBalls.where((b) => b % 2 == 1).length;

    switch (schema.name) {
      case 'ssq':
        // 红球和值: 40-180
        if (sum < 40 || sum > 180) return false;
        // 跨度: 10-32
        if (span < 10 || span > 32) return false;
        // 不能全奇全偶
        if (oddCount == 0 || oddCount == 6) return false;
        // 三区分布不能全集中在一个区
        int zone1 = 0, zone2 = 0, zone3 = 0;
        for (final r in mainBalls) {
          if (r <= 11) zone1++;
          else if (r <= 22) zone2++;
          else zone3++;
        }
        if (zone1 == 6 || zone2 == 6 || zone3 == 6) return false;
        break;
      case 'dlt':
        if (sum < 30 || sum > 155) return false;
        if (span < 8 || span > 34) return false;
        if (oddCount == 0 || oddCount == 5) return false;
        break;
      case 'k8':
        if (mainBalls.length != 20) return false;
        if (sum < 400 || sum > 1200) return false;
        if (oddCount <= 2 || oddCount >= 18) return false;
        break;
    }

    return true;
  }

  /// 候选评分 - 对应 Python _score_candidate()
  double _scoreCandidate(
    List<int> mainBalls,
    List<List<int>> bonusBalls,
    List<double> mainProbs,
  ) {
    // 概率评分
    double probScore = 0;
    for (final ball in mainBalls) {
      if (ball >= 1 && ball <= mainProbs.length) {
        probScore += mainProbs[ball - 1];
      }
    }
    probScore /= mainBalls.length;

    // 结构评分
    final sum = mainBalls.fold<int>(0, (a, b) => a + b);
    final sorted = List<int>.from(mainBalls)..sort();
    final span = sorted.last - sorted.first;

    double structureScore = 1.0;
    switch (schema.name) {
      case 'ssq':
        if (sum >= 80 && sum <= 130) structureScore += 0.2;
        if (span >= 18 && span <= 28) structureScore += 0.1;
        break;
      case 'dlt':
        if (sum >= 50 && sum <= 120) structureScore += 0.2;
        if (span >= 15 && span <= 30) structureScore += 0.1;
        break;
      case 'k8':
        if (sum >= 600 && sum <= 1000) structureScore += 0.2;
        break;
    }

    // 稳定性评分（概率标准差越小越稳定）
    final ballProbs =
        mainBalls.where((b) => b >= 1 && b <= mainProbs.length).map((b) => mainProbs[b - 1]).toList();
    double stabilityScore = 0;
    if (ballProbs.length >= 2) {
      final mean =
          ballProbs.reduce((a, b) => a + b) / ballProbs.length;
      final variance = ballProbs
              .map((p) => (p - mean) * (p - mean))
              .reduce((a, b) => a + b) /
          ballProbs.length;
      stabilityScore = 1.0 / (1.0 + sqrt(variance));
    }

    final result =
        probScore * 0.5 + structureScore * 0.3 + stabilityScore * 0.2;
    return (result * 100).clamp(0, 100).toDouble();
  }

  /// 计算候选方案概率
  double _calculateCandidateProbability(
      List<int> mainBalls, List<double> mainProbs) {
    double prob = 1.0;
    for (final ball in mainBalls) {
      if (ball >= 1 && ball <= mainProbs.length) {
        prob *= max(mainProbs[ball - 1], 1e-10);
      }
    }
    return prob;
  }

  /// 风险评分：候选间相似度越高风险越低（共识强）
  double _calculateRiskScore(
      List<FusionCandidate> candidates, List<double> fusedProbs) {
    if (candidates.length < 2) return 0.5;

    double avgSimilarity = 0;
    int pairCount = 0;
    for (int i = 0; i < candidates.length; i++) {
      for (int j = i + 1; j < candidates.length; j++) {
        final setI = candidates[i].mainBalls.toSet();
        final setJ = candidates[j].mainBalls.toSet();
        final intersection = setI.intersection(setJ).length;
        avgSimilarity += intersection / schema.mainCount;
        pairCount++;
      }
    }
    if (pairCount > 0) avgSimilarity /= pairCount;

    return 1.0 - avgSimilarity;
  }
}
