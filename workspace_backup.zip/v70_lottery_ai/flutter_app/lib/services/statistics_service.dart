/// 统计分析服务
///
/// 纯 Dart 实现，零 ML 依赖。
/// 提供冷热号分析、遗漏值计算、号码趋势、奇偶比、和值、跨度、分区分布等统计功能。
import 'dart:math';
import '../models/lottery_draw.dart';
import 'lottery_schema.dart';

/// 号码频率统计
class NumberFrequency {
  /// 号码值
  final int number;

  /// 出现次数
  final int count;

  /// 出现频率 (0-1)
  final double frequency;

  /// 是否为热号（出现次数高于平均 * hotThreshold）
  final bool isHot;

  /// 是否为冷号（出现次数低于平均 * coldThreshold）
  final bool isCold;

  const NumberFrequency({
    required this.number,
    required this.count,
    required this.frequency,
    required this.isHot,
    required this.isCold,
  });

  @override
  String toString() =>
      'NumberFrequency(#$number, count=$count, freq=${frequency.toStringAsFixed(3)}, hot=$isHot, cold=$isCold)';
}

/// 统计分析服务
///
/// 所有方法均为静态方法，无需实例化。
class StatisticsService {
  StatisticsService._();

  /// 默认热号阈值：高于均值 1.2 倍即为热号
  static const double defaultHotThreshold = 1.2;

  /// 默认冷号阈值：低于均值 0.8 倍即为冷号
  static const double defaultColdThreshold = 0.8;

  // ============================================================
  // 冷热号分析
  // ============================================================

  /// 计算冷热号分布
  ///
  /// 基于历史开奖数据统计每个号码的出现次数，
  /// 并与平均值比较判断冷热。
  ///
  /// [draws] 历史开奖数据列表（按时间降序排列，最新的在前）
  /// [schema] 彩票类型配置
  /// [hotThreshold] 热号阈值，出现次数 > 均值 * hotThreshold 为热号
  /// [coldThreshold] 冷号阈值，出现次数 < 均值 * coldThreshold 为冷号
  static List<NumberFrequency> calculateHotColdNumbers({
    required List<LotteryDraw> draws,
    required LotterySchema schema,
    double hotThreshold = defaultHotThreshold,
    double coldThreshold = defaultColdThreshold,
  }) {
    final totalDraws = draws.length;
    if (totalDraws == 0) return [];

    // 统计每个号码出现次数（1-indexed）
    final counts = List<int>.filled(schema.mainDim + 1, 0);
    for (final draw in draws) {
      for (final ball in draw.mainBalls) {
        if (ball >= 1 && ball <= schema.mainDim) {
          counts[ball]++;
        }
      }
    }

    // 理论平均出现次数
    final avgCount = schema.mainCount * totalDraws / schema.mainDim;

    final results = <NumberFrequency>[];
    for (int i = 1; i <= schema.mainDim; i++) {
      final freq = totalDraws > 0 ? counts[i] / totalDraws : 0.0;
      results.add(NumberFrequency(
        number: i,
        count: counts[i],
        frequency: freq,
        isHot: counts[i] > avgCount * hotThreshold,
        isCold: counts[i] < avgCount * coldThreshold,
      ));
    }

    return results;
  }

  /// 获取热号列表
  ///
  /// 返回所有热号，按出现次数降序排列。
  static List<int> getHotNumbers(
    List<NumberFrequency> frequencies, {
    int topN = 10,
  }) {
    final hot = frequencies
        .where((f) => f.isHot)
        .toList()
      ..sort((a, b) => b.count.compareTo(a.count));
    return hot.take(topN).map((f) => f.number).toList();
  }

  /// 获取冷号列表
  ///
  /// 返回所有冷号，按出现次数升序排列（最冷的在前）。
  static List<int> getColdNumbers(
    List<NumberFrequency> frequencies, {
    int topN = 10,
  }) {
    final cold = frequencies
        .where((f) => f.isCold)
        .toList()
      ..sort((a, b) => a.count.compareTo(b.count));
    return cold.take(topN).map((f) => f.number).toList();
  }

  // ============================================================
  // 遗漏值计算
  // ============================================================

  /// 计算遗漏值（最近未出现的期数）
  ///
  /// 返回每个号码自最近一次出现以来经过的期数。
  /// [draws] 按时间降序排列（最新在前）。
  static Map<int, int> calculateMissingPeriods({
    required List<LotteryDraw> draws,
    required LotterySchema schema,
  }) {
    final missing = <int, int>{};
    for (int i = 1; i <= schema.mainDim; i++) {
      missing[i] = 0;
    }

    for (final draw in draws) {
      bool allFound = true;
      for (int i = 1; i <= schema.mainDim; i++) {
        if (missing[i] == 0) {
          if (!draw.mainBalls.contains(i)) {
            missing[i] = (missing[i] ?? 0) + 1;
          }
        }
        if (missing[i] == 0 && !draw.mainBalls.contains(i)) {
          missing[i] = 1;
        }
      }
    }

    return missing;
  }

  /// 计算遗漏值（简化版，从最新一期倒推）
  ///
  /// 更准确的实现：从最新一期往前扫描，记录每个号码首次出现的位置。
  static Map<int, int> calculateMissingPeriodsSimple({
    required List<LotteryDraw> draws,
    required LotterySchema schema,
  }) {
    final missing = <int, int>{};
    for (int i = 1; i <= schema.mainDim; i++) {
      missing[i] = 0;
    }

    for (int di = 0; di < draws.length; di++) {
      final draw = draws[di];
      for (int i = 1; i <= schema.mainDim; i++) {
        if (missing[i] == 0) {
          if (draw.mainBalls.contains(i)) {
            missing[i] = di; // 最近出现距今 di 期
          } else if (di == draws.length - 1) {
            missing[i] = draws.length; // 从未出现
          }
        }
      }
    }

    return missing;
  }

  // ============================================================
  // 号码趋势
  // ============================================================

  /// 计算号码趋势（最近 N 期出现情况）
  ///
  /// 返回一个长度为 min(windowSize, draws.length) 的列表，
  /// 1.0 表示该期出现，0.0 表示未出现。
  /// 结果按时间升序排列（最旧在前，最新在后）。
  static List<double> calculateNumberTrend({
    required List<LotteryDraw> draws,
    required int number,
    int windowSize = 10,
  }) {
    final recentDraws = draws.take(windowSize).toList().reversed.toList();
    return recentDraws
        .map((d) => d.mainBalls.contains(number) ? 1.0 : 0.0)
        .toList();
  }

  /// 计算所有号码的趋势强度
  ///
  /// 趋势强度 = 最近 windowSize 期内出现的次数。
  /// 返回 Map<号码, 出现次数>。
  static Map<int, int> calculateTrendStrength({
    required List<LotteryDraw> draws,
    required LotterySchema schema,
    int windowSize = 10,
  }) {
    final strength = <int, int>{};
    for (int i = 1; i <= schema.mainDim; i++) {
      strength[i] = 0;
    }

    final recentDraws = draws.take(windowSize).toList();
    for (final draw in recentDraws) {
      for (final ball in draw.mainBalls) {
        if (ball >= 1 && ball <= schema.mainDim) {
          strength[ball] = (strength[ball] ?? 0) + 1;
        }
      }
    }

    return strength;
  }

  // ============================================================
  // 基本统计指标
  // ============================================================

  /// 计算奇偶比
  ///
  /// 返回奇数占比 (0-1)。
  static double calculateOddEvenRatio(List<int> balls) {
    if (balls.isEmpty) return 0;
    final oddCount = balls.where((b) => b % 2 == 1).length;
    return oddCount / balls.length;
  }

  /// 计算奇数和偶数个数
  ///
  /// 返回 [奇数个数, 偶数个数]。
  static List<int> calculateOddEvenCount(List<int> balls) {
    final oddCount = balls.where((b) => b % 2 == 1).length;
    return [oddCount, balls.length - oddCount];
  }

  /// 计算和值
  static int calculateSum(List<int> balls) {
    return balls.fold<int>(0, (a, b) => a + b);
  }

  /// 计算平均和值（多期）
  static double calculateAverageSum(List<LotteryDraw> draws) {
    if (draws.isEmpty) return 0;
    final total = draws.fold<int>(
        0, (sum, d) => sum + d.mainBalls.fold<int>(0, (a, b) => a + b));
    return total / draws.length;
  }

  /// 计算跨度（最大值 - 最小值）
  static int calculateSpan(List<int> balls) {
    if (balls.isEmpty) return 0;
    final sorted = List<int>.from(balls)..sort();
    return sorted.last - sorted.first;
  }

  /// 计算平均值
  static double calculateMean(List<int> balls) {
    if (balls.isEmpty) return 0;
    return balls.fold<int>(0, (a, b) => a + b) / balls.length;
  }

  /// 计算标准差
  static double calculateStdDev(List<int> balls) {
    if (balls.isEmpty) return 0;
    final mean = calculateMean(balls);
    final variance =
        balls.fold<double>(0, (sum, b) => sum + (b - mean) * (b - mean)) /
            balls.length;
    return sqrt(variance);
  }

  // ============================================================
  // 分区分布
  // ============================================================

  /// 计算分区分布
  ///
  /// 将主球区 [1, range] 等分为 [zones] 个区，
  /// 统计每个区内的号码个数。
  static List<int> calculateZoneDistribution(
      List<int> balls, int range, int zones) {
    final zoneSize = range ~/ zones;
    final dist = List<int>.filled(zones, 0);
    for (final ball in balls) {
      final zone = ((ball - 1) / zoneSize).floor();
      if (zone >= 0 && zone < zones) {
        dist[zone]++;
      }
    }
    return dist;
  }

  /// 计算多期的平均分区分布
  static List<double> calculateAverageZoneDistribution(
    List<LotteryDraw> draws,
    int range,
    int zones,
  ) {
    if (draws.isEmpty) return List<double>.filled(zones, 0);

    final totalDist = List<int>.filled(zones, 0);
    for (final draw in draws) {
      final dist = calculateZoneDistribution(draw.mainBalls, range, zones);
      for (int i = 0; i < zones; i++) {
        totalDist[i] += dist[i];
      }
    }

    return totalDist.map((c) => c / draws.length).toList();
  }

  // ============================================================
  // 连号分析
  // ============================================================

  /// 检测连号（连续号码对）
  ///
  /// 返回连号对的数量。例如 [1, 2, 3, 10, 20] 中
  /// (1,2) 和 (2,3) 是连号，返回 2。
  static int countConsecutivePairs(List<int> balls) {
    if (balls.length < 2) return 0;
    final sorted = List<int>.from(balls)..sort();
    int count = 0;
    for (int i = 0; i < sorted.length - 1; i++) {
      if (sorted[i + 1] - sorted[i] == 1) {
        count++;
      }
    }
    return count;
  }

  /// 计算多期平均连号数
  static double calculateAverageConsecutivePairs(List<LotteryDraw> draws) {
    if (draws.isEmpty) return 0;
    final total = draws.fold<int>(
        0, (sum, d) => sum + countConsecutivePairs(d.mainBalls));
    return total / draws.length;
  }

  // ============================================================
  // AC 值（算术复杂度）
  // ============================================================

  /// 计算 AC 值（Arithmetic Complexity）
  ///
  /// AC 值是衡量号码离散程度的重要指标。
  /// 计算所有两两差值（正数）的去重个数，然后减去 (n-1)。
  static int calculateACValue(List<int> balls) {
    if (balls.length < 2) return 0;
    final sorted = List<int>.from(balls)..sort();
    final diffs = <int>{};
    for (int i = 0; i < sorted.length; i++) {
      for (int j = i + 1; j < sorted.length; j++) {
        diffs.add(sorted[j] - sorted[i]);
      }
    }
    return diffs.length - (balls.length - 1);
  }
}
