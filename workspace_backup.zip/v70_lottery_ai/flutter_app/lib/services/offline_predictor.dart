/// 离线预测器 - 无需后端即可生成 AI 预测方案
///
/// 使用 6 种统计启发式策略模拟后端 ML 模型的输出，
/// 再通过融合引擎生成最终方案。所有计算均在设备本地完成。
import 'dart:math';
import '../models/lottery_draw.dart';
import '../models/prediction_result.dart';
import 'lottery_schema.dart';
import 'statistics_service.dart';
import 'probability_engine.dart';
import 'fusion_engine.dart';
import 'risk_control.dart';
import 'lottery_data_service.dart';

class OfflinePredictor {
  final LotteryDataService _dataService;

  OfflinePredictor({LotteryDataService? dataService})
      : _dataService = dataService ?? LotteryDataService();

  /// 生成离线预测（主入口）
  PredictionResult predict({
    required String lotteryType,
    int numCandidates = 10,
    int historyPeriods = 100,
  }) {
    final schema = LotterySchemas.getByName(lotteryType);
    final draws =
        _dataService.getDrawsTyped(lotteryType).take(historyPeriods).toList();

    if (draws.isEmpty) {
      return _generateRandomPrediction(schema, lotteryType, numCandidates);
    }

    // 生成 6 个统计模型的输出（模拟后端 ML 模型）
    final modelOutputs = _generateStatisticalModelOutputs(draws, schema);

    // 融合
    final engine =
        FusionEngine(schema: schema, numCandidates: numCandidates);
    final fusionResult = engine.fuse(modelOutputs);

    // 风险评估
    final riskAssessment = RiskController.assessRisk(
      candidateMainBalls:
          fusionResult.candidates.map((c) => c.mainBalls).toList(),
      schema: schema,
    );

    // 构建结果
    final candidates = fusionResult.candidates
        .map((c) => Candidate(
              mainBalls: c.mainBalls,
              bonusBalls:
                  c.bonusBalls.isNotEmpty ? c.bonusBalls[0] : [],
              score: c.score,
              probability: c.probability,
            ))
        .toList();

    return PredictionResult(
      status: 'completed_offline',
      lotteryType: lotteryType,
      candidates: candidates,
      finalScore: fusionResult.finalScore,
      modelContributions: fusionResult.modelContributions,
      riskAssessment: riskAssessment.toMap(),
      fusionCount: 1,
    );
  }

  /// 生成 6 个统计模型输出
  List<ModelOutput> _generateStatisticalModelOutputs(
    List<LotteryDraw> draws,
    LotterySchema schema,
  ) {
    return [
      _frequencyModel(draws, schema, 'XGBoost'),
      _hotColdModel(draws, schema, 'LSTM'),
      _trendModel(draws, schema, 'Transformer'),
      _randomWalkModel(draws, schema, 'PPO'),
      _weightedHistoryModel(draws, schema, 'Statistic'),
      _patternModel(draws, schema, 'Behavior'),
    ];
  }

  /// 频率模型 - 基于历史出现频率
  ModelOutput _frequencyModel(
      List<LotteryDraw> draws, LotterySchema schema, String name) {
    final freq = StatisticsService.calculateHotColdNumbers(
        draws: draws, schema: schema);
    final probs = List<double>.filled(schema.mainDim, 0.0);
    for (final f in freq) {
      probs[f.number - 1] = f.count.toDouble();
    }
    return ModelOutput(
      modelName: name,
      mainProbs: ProbabilityEngine.safeNormalize(probs),
      bonusProbs: _generateBonusProbs(draws, schema),
      confidence: 0.6,
      credibility: 0.7,
      baseWeight: 1.0,
    );
  }

  /// 冷热号模型 - 热号加权，冷号降权
  ModelOutput _hotColdModel(
      List<LotteryDraw> draws, LotterySchema schema, String name) {
    final freq = StatisticsService.calculateHotColdNumbers(
        draws: draws, schema: schema);
    final probs = List<double>.filled(schema.mainDim, 0.0);
    for (final f in freq) {
      if (f.isHot) {
        probs[f.number - 1] = f.count * 2.0;
      } else if (f.isCold) {
        probs[f.number - 1] = f.count * 0.3;
      } else {
        probs[f.number - 1] = f.count.toDouble();
      }
    }
    return ModelOutput(
      modelName: name,
      mainProbs: ProbabilityEngine.safeNormalize(probs),
      bonusProbs: _generateBonusProbs(draws, schema),
      confidence: 0.55,
      credibility: 0.6,
      baseWeight: 0.9,
    );
  }

  /// 趋势模型 - 基于最近 20 期趋势
  ModelOutput _trendModel(
      List<LotteryDraw> draws, LotterySchema schema, String name) {
    final recent = draws.take(20).toList();
    final freq = StatisticsService.calculateHotColdNumbers(
        draws: recent, schema: schema);
    final probs = List<double>.filled(schema.mainDim, 0.0);
    for (final f in freq) {
      probs[f.number - 1] = f.count.toDouble() + 0.5;
    }
    return ModelOutput(
      modelName: name,
      mainProbs: ProbabilityEngine.safeNormalize(probs),
      bonusProbs: _generateBonusProbs(draws, schema),
      confidence: 0.5,
      credibility: 0.5,
      baseWeight: 0.85,
    );
  }

  /// 随机游走模型 - 在历史分布上加随机扰动
  ModelOutput _randomWalkModel(
      List<LotteryDraw> draws, LotterySchema schema, String name) {
    final random = Random(42);
    final freq = StatisticsService.calculateHotColdNumbers(
        draws: draws, schema: schema);
    final probs = List<double>.filled(schema.mainDim, 0.0);
    for (final f in freq) {
      probs[f.number - 1] =
          f.count.toDouble() + random.nextDouble() * 5;
    }
    return ModelOutput(
      modelName: name,
      mainProbs: ProbabilityEngine.safeNormalize(probs),
      bonusProbs: _generateBonusProbs(draws, schema),
      confidence: 0.45,
      credibility: 0.4,
      baseWeight: 0.7,
    );
  }

  /// 加权历史模型 - 越近期权重越大
  ModelOutput _weightedHistoryModel(
      List<LotteryDraw> draws, LotterySchema schema, String name) {
    final probs = List<double>.filled(schema.mainDim, 0.0);
    for (int i = 0; i < draws.length; i++) {
      final weight = 1.0 / (i + 1);
      for (final ball in draws[i].mainBalls) {
        if (ball >= 1 && ball <= schema.mainDim) {
          probs[ball - 1] += weight;
        }
      }
    }
    return ModelOutput(
      modelName: name,
      mainProbs: ProbabilityEngine.safeNormalize(probs),
      bonusProbs: _generateBonusProbs(draws, schema),
      confidence: 0.5,
      credibility: 0.55,
      baseWeight: 0.8,
    );
  }

  /// 模式模型 - 寻找号码模式（连号、间隔等）
  ModelOutput _patternModel(
      List<LotteryDraw> draws, LotterySchema schema, String name) {
    final probs = List<double>.filled(schema.mainDim, 0.0);
    final random = Random(123);

    for (final draw in draws.take(50)) {
      final sorted = List<int>.from(draw.mainBalls)..sort();
      for (int i = 1; i < sorted.length; i++) {
        if (sorted[i] - sorted[i - 1] == 1) {
          for (int offset = -1; offset <= 2; offset++) {
            final idx = sorted[i - 1] + offset;
            if (idx >= 1 && idx <= schema.mainDim) {
              probs[idx - 1] += 1.0;
            }
          }
        }
      }
    }

    for (int i = 0; i < probs.length; i++) {
      probs[i] += random.nextDouble() * 2;
    }

    return ModelOutput(
      modelName: name,
      mainProbs: ProbabilityEngine.safeNormalize(probs),
      bonusProbs: _generateBonusProbs(draws, schema),
      confidence: 0.4,
      credibility: 0.35,
      baseWeight: 0.65,
    );
  }

  /// 生成附加球概率
  List<List<double>> _generateBonusProbs(
      List<LotteryDraw> draws, LotterySchema schema) {
    final result = <List<double>>[];
    for (int b = 0; b < schema.bonusCounts.length; b++) {
      final probs =
          List<double>.filled(schema.bonusRanges[b], 0.0);
      for (final draw in draws) {
        for (final ball in draw.bonusBalls) {
          // bonusBalls is flat; use schema to determine which bonus zone this ball belongs to
          final zoneStart = b == 0 ? 1 : schema.bonusRanges[b - 1] + 1;
          final zoneEnd = schema.bonusRanges[b];
          if (ball >= zoneStart && ball <= zoneEnd) {
            final idx = ball - zoneStart;
            if (idx >= 0 && idx < probs.length) {
              probs[idx]++;
            }
          }
        }
      }
      result.add(ProbabilityEngine.safeNormalize(probs));
    }
    return result;
  }

  /// 纯随机预测（无历史数据时的兜底）
  PredictionResult _generateRandomPrediction(
    LotterySchema schema,
    String lotteryType,
    int numCandidates,
  ) {
    final random = Random();
    final candidates = <Candidate>[];

    for (int i = 0; i < numCandidates; i++) {
      final pool =
          List.generate(schema.mainRange, (i) => i + 1)..shuffle(random);
      final selected = pool.take(schema.mainCount).toList()..sort();

      final bonusBalls = <List<int>>[];
      for (int b = 0; b < schema.bonusCounts.length; b++) {
        final bp = List.generate(schema.bonusRanges[b], (i) => i + 1)
          ..shuffle(random);
        bonusBalls.add(bp.take(schema.bonusCounts[b]).toList()..sort());
      }

      candidates.add(Candidate(
        mainBalls: selected,
        bonusBalls: bonusBalls.isNotEmpty ? bonusBalls[0] : [],
        score: random.nextDouble() * 30,
        probability: random.nextDouble() * 0.1,
      ));
    }

    return PredictionResult(
      status: 'completed_offline_random',
      lotteryType: lotteryType,
      candidates: candidates,
      finalScore: 0.1,
      modelContributions: {'random': 1.0},
      riskAssessment: {
        'overall_risk': 0.9,
        'risk_level': 'high',
        'warnings': ['无历史数据，纯随机生成，仅供参考'],
      },
      fusionCount: 0,
    );
  }

  /// 快速分析 - 不做完整预测，只做统计分析
  Map<String, dynamic> quickAnalysis(String lotteryType) {
    final schema = LotterySchemas.getByName(lotteryType);
    final draws =
        _dataService.getDrawsTyped(lotteryType).take(100).toList();

    if (draws.isEmpty) {
      return {'status': 'no_data', 'message': '无历史数据'};
    }

    final hotCold = StatisticsService.calculateHotColdNumbers(
        draws: draws, schema: schema);
    final missing = StatisticsService.calculateMissingPeriodsSimple(
        draws: draws, schema: schema);

    return {
      'status': 'ok',
      'total_draws': draws.length,
      'hot_numbers':
          hotCold.where((f) => f.isHot).map((f) => f.number).toList(),
      'cold_numbers':
          hotCold.where((f) => f.isCold).map((f) => f.number).toList(),
      'top_missing': missing.entries
          .where((e) => e.value > 5)
          .map((e) => {'number': e.key, 'missing_periods': e.value})
          .toList()
        ..sort((a, b) =>
            (b['missing_periods'] as int).compareTo(a['missing_periods'] as int)),
      'latest_draw': draws.first.toMap(),
    };
  }
}
