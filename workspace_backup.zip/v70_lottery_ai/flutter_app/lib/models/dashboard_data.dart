class DashboardOverview {
  final String lotteryType;
  final double fusionScore;
  final int activeModels;
  final int totalDraws;
  final Map<String, double>? modelContributions;
  final int? totalPredictions;
  final double? avgPredictionScore;

  DashboardOverview({
    this.lotteryType = 'ssq',
    this.fusionScore = 0,
    this.activeModels = 0,
    this.totalDraws = 0,
    this.modelContributions,
    this.totalPredictions,
    this.avgPredictionScore,
  });

  factory DashboardOverview.fromJson(Map<String, dynamic> json) {
    return DashboardOverview(
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      fusionScore: (json['fusion_score'] as num?)?.toDouble() ?? 0,
      activeModels: json['active_models'] as int? ?? 0,
      totalDraws: json['total_draws'] as int? ?? 0,
      modelContributions:
          (json['model_contributions'] as Map<String, dynamic>?)
              ?.map((k, v) => MapEntry(k, (v as num).toDouble())),
      totalPredictions: json['total_predictions'] as int?,
      avgPredictionScore:
          (json['avg_prediction_score'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'lottery_type': lotteryType,
      'fusion_score': fusionScore,
      'active_models': activeModels,
      'total_draws': totalDraws,
      if (modelContributions != null) 'model_contributions': modelContributions,
      if (totalPredictions != null) 'total_predictions': totalPredictions,
      if (avgPredictionScore != null)
        'avg_prediction_score': avgPredictionScore,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class DashboardStats {
  final int totalDraws;
  final int activeModels;
  final double fusionScore;
  final int totalPredictions;
  final double avgPredictionScore;

  DashboardStats({
    this.totalDraws = 0,
    this.activeModels = 0,
    this.fusionScore = 0,
    this.totalPredictions = 0,
    this.avgPredictionScore = 0,
  });

  factory DashboardStats.fromJson(Map<String, dynamic> json) {
    return DashboardStats(
      totalDraws: json['total_draws'] as int? ?? 0,
      activeModels: json['active_models'] as int? ?? 0,
      fusionScore: (json['fusion_score'] as num?)?.toDouble() ?? 0,
      totalPredictions: json['total_predictions'] as int? ?? 0,
      avgPredictionScore:
          (json['avg_prediction_score'] as num?)?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'total_draws': totalDraws,
      'active_models': activeModels,
      'fusion_score': fusionScore,
      'total_predictions': totalPredictions,
      'avg_prediction_score': avgPredictionScore,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class ModelPerformanceChart {
  final List<String> labels;
  final Map<String, List<double>> data;

  ModelPerformanceChart({
    this.labels = const [],
    this.data = const {},
  });

  factory ModelPerformanceChart.fromJson(Map<String, dynamic> json) {
    return ModelPerformanceChart(
      labels: (json['labels'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          [],
      data: (json['data'] as Map<String, dynamic>?)?.map(
                (k, v) => MapEntry(
                  k,
                  (v as List<dynamic>).map((e) => (e as num).toDouble()).toList(),
                ),
              ) ??
          {},
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'labels': labels,
      'data': data,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class HotNumbersChart {
  final List<int> numbers;
  final List<int> frequencies;
  final String lotteryType;

  HotNumbersChart({
    this.numbers = const [],
    this.frequencies = const [],
    this.lotteryType = 'ssq',
  });

  factory HotNumbersChart.fromJson(Map<String, dynamic> json) {
    return HotNumbersChart(
      numbers: (json['numbers'] as List<dynamic>?)?.cast<int>() ?? [],
      frequencies:
          (json['frequencies'] as List<dynamic>?)?.cast<int>() ?? [],
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'numbers': numbers,
      'frequencies': frequencies,
      'lottery_type': lotteryType,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}
