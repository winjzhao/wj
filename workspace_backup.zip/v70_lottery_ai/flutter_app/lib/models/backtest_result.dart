class ModelPerformance {
  final double avgScore;
  final String trend;

  ModelPerformance({
    this.avgScore = 0,
    this.trend = 'stable',
  });

  factory ModelPerformance.fromJson(Map<String, dynamic> json) {
    return ModelPerformance(
      avgScore: (json['avg_score'] as num?)?.toDouble() ?? 0,
      trend: json['trend'] as String? ?? 'stable',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'avg_score': avgScore,
      'trend': trend,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class BacktestResult {
  final String lotteryType;
  final int totalPeriods;
  final double avgScore;
  final List<double> accuracyTrend;
  final Map<String, ModelPerformance> modelPerformance;

  BacktestResult({
    this.lotteryType = 'ssq',
    this.totalPeriods = 0,
    this.avgScore = 0,
    this.accuracyTrend = const [],
    this.modelPerformance = const {},
  });

  factory BacktestResult.fromJson(Map<String, dynamic> json) {
    final modelPerf = (json['model_performance'] as Map<String, dynamic>?)
            ?.map((k, v) =>
                MapEntry(k, ModelPerformance.fromJson(v as Map<String, dynamic>))) ??
        {};

    return BacktestResult(
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      totalPeriods: json['total_periods'] as int? ?? 0,
      avgScore: (json['avg_score'] as num?)?.toDouble() ?? 0,
      accuracyTrend: (json['accuracy_trend'] as List<dynamic>?)
              ?.map((e) => (e as num).toDouble())
              .toList() ??
          [],
      modelPerformance: modelPerf,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'lottery_type': lotteryType,
      'total_periods': totalPeriods,
      'avg_score': avgScore,
      'accuracy_trend': accuracyTrend,
      'model_performance':
          modelPerformance.map((k, v) => MapEntry(k, v.toJson())),
    };
  }

  Map<String, dynamic> toMap() => toJson();
}
