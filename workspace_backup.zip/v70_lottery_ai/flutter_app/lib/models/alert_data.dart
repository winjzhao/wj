class AlertInfo {
  final String id;
  final String type;
  final String severity;
  final String message;
  final String? source;
  final String? status;
  final DateTime? createdAt;
  final DateTime? acknowledgedAt;
  final DateTime? resolvedAt;

  AlertInfo({
    required this.id,
    this.type = 'info',
    this.severity = 'info',
    this.message = '',
    this.source,
    this.status = 'active',
    this.createdAt,
    this.acknowledgedAt,
    this.resolvedAt,
  });

  factory AlertInfo.fromJson(Map<String, dynamic> json) {
    return AlertInfo(
      id: json['id']?.toString() ?? '',
      type: json['type'] as String? ?? 'info',
      severity: json['severity'] as String? ?? 'info',
      message: json['message'] as String? ?? '',
      source: json['source'] as String?,
      status: json['status'] as String? ?? 'active',
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'] as String)
          : null,
      acknowledgedAt: json['acknowledged_at'] != null
          ? DateTime.tryParse(json['acknowledged_at'] as String)
          : null,
      resolvedAt: json['resolved_at'] != null
          ? DateTime.tryParse(json['resolved_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'severity': severity,
      'message': message,
      if (source != null) 'source': source,
      'status': status,
      if (createdAt != null) 'created_at': createdAt!.toIso8601String(),
      if (acknowledgedAt != null)
        'acknowledged_at': acknowledgedAt!.toIso8601String(),
      if (resolvedAt != null) 'resolved_at': resolvedAt!.toIso8601String(),
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class AlertSummary {
  final int totalAlerts;
  final int activeAlerts;
  final int acknowledgedAlerts;
  final int resolvedAlerts;
  final Map<String, int>? severityCounts;
  final List<AlertInfo>? alerts;

  AlertSummary({
    this.totalAlerts = 0,
    this.activeAlerts = 0,
    this.acknowledgedAlerts = 0,
    this.resolvedAlerts = 0,
    this.severityCounts,
    this.alerts,
  });

  factory AlertSummary.fromJson(Map<String, dynamic> json) {
    return AlertSummary(
      totalAlerts: json['total'] as int? ??
          json['total_alerts'] as int? ??
          0,
      activeAlerts: json['active'] as int? ??
          json['active_alerts'] as int? ??
          0,
      acknowledgedAlerts: json['acknowledged'] as int? ??
          json['acknowledged_alerts'] as int? ??
          0,
      resolvedAlerts: json['resolved'] as int? ??
          json['resolved_alerts'] as int? ??
          0,
      severityCounts:
          (json['severity_counts'] as Map<String, dynamic>?)
              ?.map((k, v) => MapEntry(k, v as int)),
      alerts: (json['alerts'] as List<dynamic>?)
          ?.map((a) => AlertInfo.fromJson(a as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'total_alerts': totalAlerts,
      'active_alerts': activeAlerts,
      'acknowledged_alerts': acknowledgedAlerts,
      'resolved_alerts': resolvedAlerts,
      if (severityCounts != null) 'severity_counts': severityCounts,
      if (alerts != null) 'alerts': alerts!.map((a) => a.toJson()).toList(),
    };
  }

  Map<String, dynamic> toMap() => toJson();
}
