class LotteryDraw {
  final String period;
  final String lotteryType;
  final List<int> mainBalls;
  final List<int> bonusBalls;
  final DateTime? drawDate;

  LotteryDraw({
    required this.period,
    this.lotteryType = 'ssq',
    required this.mainBalls,
    required this.bonusBalls,
    this.drawDate,
  });

  factory LotteryDraw.fromJson(Map<String, dynamic> json) {
    return LotteryDraw(
      period: json['period']?.toString() ?? '',
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      mainBalls: (json['main_balls'] as List<dynamic>?)?.cast<int>() ?? [],
      bonusBalls: _parseBonusBalls(json['bonus_balls']),
      drawDate: json['draw_date'] != null
          ? DateTime.tryParse(json['draw_date'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'period': period,
      'lottery_type': lotteryType,
      'main_balls': mainBalls,
      'bonus_balls': bonusBalls,
      if (drawDate != null) 'draw_date': drawDate!.toIso8601String(),
    };
  }

  Map<String, dynamic> toMap() => toJson();

  static List<int> _parseBonusBalls(dynamic value) {
    if (value == null) return [];
    if (value is List) {
      if (value.isEmpty) return [];
      if (value.first is List) {
        final flat = <int>[];
        for (final b in value) {
          if (b is List) flat.addAll(b.cast<int>());
        }
        return flat;
      }
      return value.cast<int>();
    }
    return [];
  }
}
