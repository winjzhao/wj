class Candidate {
  final List<int> mainBalls;
  final List<int> bonusBalls;
  final double score;
  final double probability;
  final String? strategy;

  Candidate({
    required this.mainBalls,
    required this.bonusBalls,
    required this.score,
    required this.probability,
    this.strategy,
  });

  factory Candidate.fromJson(Map<String, dynamic> json) {
    return Candidate(
      mainBalls: (json['main_balls'] as List<dynamic>?)?.cast<int>() ?? [],
      bonusBalls: _parseBonusBalls(json['bonus_balls']),
      score: (json['score'] as num?)?.toDouble() ?? 0,
      probability: (json['probability'] as num?)?.toDouble() ?? 0,
      strategy: json['strategy'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'main_balls': mainBalls,
      'bonus_balls': bonusBalls,
      'score': score,
      'probability': probability,
      if (strategy != null) 'strategy': strategy,
    };
  }

  /// Keep backward compatibility: allow accessing as Map
  Map<String, dynamic> toMap() => toJson();

  static List<int> _parseBonusBalls(dynamic value) {
    if (value == null) return [];
    if (value is List) {
      if (value.isEmpty) return [];
      // If first element is also a list, flatten
      if (value.first is List) {
        final flat = <int>[];
        for (final b in value) {
          if (b is List) flat.addAll(b.cast<int>());
        }
        return flat;
      }
      return value.cast<int>();
    }
    return [];
  }
}

class PredictionResult {
  final String status;
  final String lotteryType;
  final List<Candidate> candidates;
  final double finalScore;
  final Map<String, double> modelContributions;
  final Map<String, dynamic> riskAssessment;
  final int fusionCount;
  final String? generatedAt;
  final String? basedOn;

  PredictionResult({
    this.status = 'completed',
    this.lotteryType = 'ssq',
    required this.candidates,
    required this.finalScore,
    required this.modelContributions,
    this.riskAssessment = const {},
    this.fusionCount = 6,
    this.generatedAt,
    this.basedOn,
  });

  factory PredictionResult.fromJson(Map<String, dynamic> json) {
    final candidatesList = (json['candidates'] as List<dynamic>?)
            ?.map((c) => Candidate.fromJson(c as Map<String, dynamic>))
            .toList() ??
        [];

    return PredictionResult(
      status: json['status'] as String? ?? 'completed',
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      candidates: candidatesList,
      finalScore: (json['final_score'] as num?)?.toDouble() ?? 0,
      modelContributions: (json['model_contributions'] as Map<String, dynamic>?)
              ?.map((k, v) => MapEntry(k, (v as num).toDouble())) ??
          {},
      riskAssessment: json['risk_assessment'] as Map<String, dynamic>? ?? {},
      fusionCount: json['fusion_count'] as int? ?? 6,
      generatedAt: json['generated_at'] as String?,
      basedOn: json['based_on'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'status': status,
      'lottery_type': lotteryType,
      'candidates': candidates.map((c) => c.toJson()).toList(),
      'final_score': finalScore,
      'model_contributions': modelContributions,
      'risk_assessment': riskAssessment,
      'fusion_count': fusionCount,
      if (generatedAt != null) 'generated_at': generatedAt,
      if (basedOn != null) 'based_on': basedOn,
    };
  }

  Map<String, dynamic> toMap() => toJson();

  PredictionResult copyWith({
    String? status,
    String? lotteryType,
    List<Candidate>? candidates,
    double? finalScore,
    Map<String, double>? modelContributions,
    Map<String, dynamic>? riskAssessment,
    int? fusionCount,
    String? generatedAt,
    String? basedOn,
  }) {
    return PredictionResult(
      status: status ?? this.status,
      lotteryType: lotteryType ?? this.lotteryType,
      candidates: candidates ?? this.candidates,
      finalScore: finalScore ?? this.finalScore,
      modelContributions: modelContributions ?? this.modelContributions,
      riskAssessment: riskAssessment ?? this.riskAssessment,
      fusionCount: fusionCount ?? this.fusionCount,
      generatedAt: generatedAt ?? this.generatedAt,
      basedOn: basedOn ?? this.basedOn,
    );
  }
}
