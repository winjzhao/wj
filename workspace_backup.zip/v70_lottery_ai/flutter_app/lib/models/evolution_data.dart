class EvolutionStatus {
  final String status;
  final String lotteryType;
  final DateTime? lastEvolution;
  final int totalCycles;
  final int matchedCount;
  final Map<String, double> weights;
  final int? cycleDurationMs;

  EvolutionStatus({
    this.status = 'idle',
    this.lotteryType = 'ssq',
    this.lastEvolution,
    this.totalCycles = 0,
    this.matchedCount = 0,
    this.weights = const {},
    this.cycleDurationMs,
  });

  factory EvolutionStatus.fromJson(Map<String, dynamic> json) {
    return EvolutionStatus(
      status: json['status'] as String? ?? 'idle',
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      lastEvolution: json['last_evolution'] != null
          ? DateTime.tryParse(json['last_evolution'] as String)
          : null,
      totalCycles: json['total_cycles'] as int? ?? 0,
      matchedCount: json['matched_count'] as int? ?? 0,
      weights: (json['weights'] as Map<String, dynamic>?)
              ?.map((k, v) => MapEntry(k, (v as num).toDouble())) ??
          {},
      cycleDurationMs: json['cycle_duration_ms'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'status': status,
      'lottery_type': lotteryType,
      if (lastEvolution != null)
        'last_evolution': lastEvolution!.toIso8601String(),
      'total_cycles': totalCycles,
      'matched_count': matchedCount,
      'weights': weights,
      if (cycleDurationMs != null) 'cycle_duration_ms': cycleDurationMs,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class EvolutionHistory {
  final int cycle;
  final DateTime? timestamp;
  final int matchedCount;
  final String bestModel;
  final double bestScore;
  final int? durationMs;

  EvolutionHistory({
    this.cycle = 0,
    this.timestamp,
    this.matchedCount = 0,
    this.bestModel = '',
    this.bestScore = 0,
    this.durationMs,
  });

  factory EvolutionHistory.fromJson(Map<String, dynamic> json) {
    return EvolutionHistory(
      cycle: json['cycle'] as int? ?? 0,
      timestamp: json['timestamp'] != null
          ? DateTime.tryParse(json['timestamp'] as String)
          : null,
      matchedCount: json['matched_count'] as int? ?? 0,
      bestModel: json['best_model'] as String? ?? '',
      bestScore: (json['best_score'] as num?)?.toDouble() ?? 0,
      durationMs: json['duration_ms'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'cycle': cycle,
      if (timestamp != null) 'timestamp': timestamp!.toIso8601String(),
      'matched_count': matchedCount,
      'best_model': bestModel,
      'best_score': bestScore,
      if (durationMs != null) 'duration_ms': durationMs,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class WeightSnapshot {
  final DateTime timestamp;
  final Map<String, double> weights;

  WeightSnapshot({
    required this.timestamp,
    this.weights = const {},
  });

  factory WeightSnapshot.fromJson(Map<String, dynamic> json) {
    return WeightSnapshot(
      timestamp: json['timestamp'] != null
          ? DateTime.parse(json['timestamp'] as String)
          : DateTime.now(),
      weights: (json['weights'] as Map<String, dynamic>?)
              ?.map((k, v) => MapEntry(k, (v as num).toDouble())) ??
          {},
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'timestamp': timestamp.toIso8601String(),
      'weights': weights,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class CodeChange {
  final String file;
  final String changeType;
  final String? description;
  final DateTime? timestamp;

  CodeChange({
    required this.file,
    required this.changeType,
    this.description,
    this.timestamp,
  });

  factory CodeChange.fromJson(Map<String, dynamic> json) {
    return CodeChange(
      file: json['file'] as String? ?? '',
      changeType: json['change_type'] as String? ?? 'modified',
      description: json['description'] as String?,
      timestamp: json['timestamp'] != null
          ? DateTime.tryParse(json['timestamp'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'file': file,
      'change_type': changeType,
      if (description != null) 'description': description,
      if (timestamp != null) 'timestamp': timestamp!.toIso8601String(),
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class ModelStatus {
  final String name;
  final String status; // active, degraded, retired
  final double? f1Score;
  final double? accuracy;
  final double? precision;
  final double? recall;
  final DateTime? lastTrained;
  final DateTime? lastEvaluated;
  final String? message;

  ModelStatus({
    required this.name,
    this.status = 'active',
    this.f1Score,
    this.accuracy,
    this.precision,
    this.recall,
    this.lastTrained,
    this.lastEvaluated,
    this.message,
  });

  factory ModelStatus.fromJson(Map<String, dynamic> json) {
    return ModelStatus(
      name: json['name'] as String? ?? '',
      status: json['status'] as String? ?? 'active',
      f1Score: (json['f1_score'] as num?)?.toDouble(),
      accuracy: (json['accuracy'] as num?)?.toDouble(),
      precision: (json['precision'] as num?)?.toDouble(),
      recall: (json['recall'] as num?)?.toDouble(),
      lastTrained: json['last_trained'] != null
          ? DateTime.tryParse(json['last_trained'] as String)
          : null,
      lastEvaluated: json['last_evaluated'] != null
          ? DateTime.tryParse(json['last_evaluated'] as String)
          : null,
      message: json['message'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'status': status,
      if (f1Score != null) 'f1_score': f1Score,
      if (accuracy != null) 'accuracy': accuracy,
      if (precision != null) 'precision': precision,
      if (recall != null) 'recall': recall,
      if (lastTrained != null) 'last_trained': lastTrained!.toIso8601String(),
      if (lastEvaluated != null) 'last_evaluated': lastEvaluated!.toIso8601String(),
      if (message != null) 'message': message,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}
