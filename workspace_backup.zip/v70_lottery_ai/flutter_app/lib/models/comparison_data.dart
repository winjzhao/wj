/// 预测 vs 开奖 对比数据模型
class PredictionComparison {
  final int id;
  final String period;
  final String lotteryType;
  final String modelName;
  final List<int> predictedMain;
  final List<int> predictedBonus;
  final List<int> actualMain;
  final List<int> actualBonus;
  final int? matchMainCount;
  final int? matchBonusCount;
  final int? matchTotal;
  final double? matchHitRate;
  final double? score;
  final String? matchedAt;
  final String? createdAt;

  PredictionComparison({
    required this.id,
    required this.period,
    required this.lotteryType,
    required this.modelName,
    required this.predictedMain,
    required this.predictedBonus,
    required this.actualMain,
    required this.actualBonus,
    this.matchMainCount,
    this.matchBonusCount,
    this.matchTotal,
    this.matchHitRate,
    this.score,
    this.matchedAt,
    this.createdAt,
  });

  factory PredictionComparison.fromJson(Map<String, dynamic> json) {
    return PredictionComparison(
      id: json['id'] as int? ?? 0,
      period: json['period'] as String? ?? '',
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      modelName: json['model_name'] as String? ?? '',
      predictedMain: (json['predicted_main'] as List<dynamic>?)?.cast<int>() ?? [],
      predictedBonus: _parseBonusBalls(json['predicted_bonus']),
      actualMain: (json['actual_main'] as List<dynamic>?)?.cast<int>() ?? [],
      actualBonus: _parseBonusBalls(json['actual_bonus']),
      matchMainCount: json['match_main_count'] as int?,
      matchBonusCount: json['match_bonus_count'] as int?,
      matchTotal: json['match_total'] as int?,
      matchHitRate: (json['match_hit_rate'] as num?)?.toDouble(),
      score: (json['score'] as num?)?.toDouble(),
      matchedAt: json['matched_at'] as String?,
      createdAt: json['created_at'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'period': period,
      'lottery_type': lotteryType,
      'model_name': modelName,
      'predicted_main': predictedMain,
      'predicted_bonus': predictedBonus,
      'actual_main': actualMain,
      'actual_bonus': actualBonus,
      'match_main_count': matchMainCount,
      'match_bonus_count': matchBonusCount,
      'match_total': matchTotal,
      'match_hit_rate': matchHitRate,
      'score': score,
      'matched_at': matchedAt,
      'created_at': createdAt,
    };
  }

  /// 判断某个主球号是否命中
  bool isMainBallHit(int ball) {
    return actualMain.contains(ball) && predictedMain.contains(ball);
  }

  /// 判断某个主球号是否预测了但未命中
  bool isMainBallMiss(int ball) {
    return predictedMain.contains(ball) && !actualMain.contains(ball);
  }

  /// 判断某个附加球号是否命中
  bool isBonusBallHit(int ball) {
    return actualBonus.contains(ball) && predictedBonus.contains(ball);
  }

  /// 判断某个附加球号是否预测了但未命中
  bool isBonusBallMiss(int ball) {
    return predictedBonus.contains(ball) && !actualBonus.contains(ball);
  }

  static List<int> _parseBonusBalls(dynamic value) {
    if (value == null) return [];
    if (value is List) {
      if (value.isEmpty) return [];
      if (value.first is List) {
        final flat = <int>[];
        for (final b in value) {
          if (b is List) flat.addAll(b.cast<int>());
        }
        return flat;
      }
      return value.cast<int>();
    }
    return [];
  }
}

/// 对比列表汇总
class ComparisonSummary {
  final String lotteryType;
  final int total;
  final double avgHit;
  final double avgHitRate;
  final List<PredictionComparison> comparisons;

  ComparisonSummary({
    required this.lotteryType,
    required this.total,
    required this.avgHit,
    required this.avgHitRate,
    required this.comparisons,
  });

  factory ComparisonSummary.fromJson(Map<String, dynamic> json) {
    final list = (json['comparisons'] as List<dynamic>?)
            ?.map((e) => PredictionComparison.fromJson(e as Map<String, dynamic>))
            .toList() ??
        [];
    return ComparisonSummary(
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      total: json['total'] as int? ?? 0,
      avgHit: (json['avg_hit'] as num?)?.toDouble() ?? 0,
      avgHitRate: (json['avg_hit_rate'] as num?)?.toDouble() ?? 0,
      comparisons: list,
    );
  }
}

/// 单期对比详情
class PeriodComparison {
  final String period;
  final String lotteryType;
  final bool hasDraw;
  final List<int>? actualMain;
  final List<int>? actualBonus;
  final List<PredictionComparison> predictions;

  PeriodComparison({
    required this.period,
    required this.lotteryType,
    required this.hasDraw,
    this.actualMain,
    this.actualBonus,
    required this.predictions,
  });

  factory PeriodComparison.fromJson(Map<String, dynamic> json) {
    return PeriodComparison(
      period: json['period'] as String? ?? '',
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      hasDraw: json['has_draw'] as bool? ?? false,
      actualMain: (json['actual_main'] as List<dynamic>?)?.cast<int>(),
      actualBonus: _parseBonusBalls(json['actual_bonus']),
      predictions: (json['predictions'] as List<dynamic>?)
              ?.map((e) => PredictionComparison.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  static List<int> _parseBonusBalls(dynamic value) {
    if (value == null) return [];
    if (value is List) {
      if (value.isEmpty) return [];
      if (value.first is List) {
        final flat = <int>[];
        for (final b in value) {
          if (b is List) flat.addAll(b.cast<int>());
        }
        return flat;
      }
      return value.cast<int>();
    }
    return [];
  }
}
