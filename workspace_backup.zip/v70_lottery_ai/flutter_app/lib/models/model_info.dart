class ModelInfo {
  final String name;
  final String type;
  final String status;
  final double accuracy;
  final double weight;
  final double credibility;
  final DateTime? lastTrained;
  final String? version;
  final bool isTrained;
  final double performanceAvg;
  final int dataPeriods;
  final double? precision;
  final double? recall;
  final String? basedOn;

  ModelInfo({
    required this.name,
    this.type = 'ML',
    this.status = 'active',
    this.accuracy = 0,
    this.weight = 0,
    this.credibility = 0,
    this.lastTrained,
    this.version,
    this.isTrained = true,
    this.performanceAvg = 0,
    this.dataPeriods = 0,
    this.precision,
    this.recall,
    this.basedOn,
  });

  factory ModelInfo.fromJson(Map<String, dynamic> json) {
    return ModelInfo(
      name: json['name'] as String? ?? '',
      type: json['type'] as String? ?? 'ML',
      status: json['status'] as String? ?? 'active',
      accuracy: (json['accuracy'] as num?)?.toDouble() ?? 0,
      weight: (json['weight'] as num?)?.toDouble() ?? 0,
      credibility: (json['credibility_score'] as num?)?.toDouble() ??
          (json['credibility'] as num?)?.toDouble() ??
          0,
      lastTrained: json['last_trained'] != null
          ? DateTime.tryParse(json['last_trained'] as String)
          : null,
      version: json['version'] as String?,
      isTrained: json['is_trained'] as bool? ?? true,
      performanceAvg: (json['performance_avg'] as num?)?.toDouble() ?? 0,
      dataPeriods: json['data_periods'] as int? ?? 0,
      precision: (json['precision'] as num?)?.toDouble(),
      recall: (json['recall'] as num?)?.toDouble(),
      basedOn: json['based_on'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'type': type,
      'status': status,
      'accuracy': accuracy,
      'weight': weight,
      'credibility_score': credibility,
      'credibility': credibility,
      if (lastTrained != null) 'last_trained': lastTrained!.toIso8601String(),
      if (version != null) 'version': version,
      'is_trained': isTrained,
      'performance_avg': performanceAvg,
      'data_periods': dataPeriods,
      if (precision != null) 'precision': precision,
      if (recall != null) 'recall': recall,
      if (basedOn != null) 'based_on': basedOn,
    };
  }

  Map<String, dynamic> toMap() => toJson();

  ModelInfo copyWith({
    String? name,
    String? type,
    String? status,
    double? accuracy,
    double? weight,
    double? credibility,
    DateTime? lastTrained,
    String? version,
    bool? isTrained,
    double? performanceAvg,
    int? dataPeriods,
    double? precision,
    double? recall,
    String? basedOn,
  }) {
    return ModelInfo(
      name: name ?? this.name,
      type: type ?? this.type,
      status: status ?? this.status,
      accuracy: accuracy ?? this.accuracy,
      weight: weight ?? this.weight,
      credibility: credibility ?? this.credibility,
      lastTrained: lastTrained ?? this.lastTrained,
      version: version ?? this.version,
      isTrained: isTrained ?? this.isTrained,
      performanceAvg: performanceAvg ?? this.performanceAvg,
      dataPeriods: dataPeriods ?? this.dataPeriods,
      precision: precision ?? this.precision,
      recall: recall ?? this.recall,
      basedOn: basedOn ?? this.basedOn,
    );
  }
}

class ModelComparison {
  final String modelName;
  final double accuracy;
  final double credibility;
  final double weight;
  final String trend;

  ModelComparison({
    required this.modelName,
    this.accuracy = 0,
    this.credibility = 0,
    this.weight = 0,
    this.trend = 'stable',
  });

  factory ModelComparison.fromJson(Map<String, dynamic> json) {
    return ModelComparison(
      modelName: json['model_name'] as String? ?? '',
      accuracy: (json['accuracy'] as num?)?.toDouble() ?? 0,
      credibility: (json['credibility'] as num?)?.toDouble() ?? 0,
      weight: (json['weight'] as num?)?.toDouble() ?? 0,
      trend: json['trend'] as String? ?? 'stable',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'model_name': modelName,
      'accuracy': accuracy,
      'credibility': credibility,
      'weight': weight,
      'trend': trend,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class ModelStatus {
  final String name;
  final String status;
  final String? version;
  final DateTime? lastUpdated;
  final bool isActive;

  ModelStatus({
    required this.name,
    this.status = 'active',
    this.version,
    this.lastUpdated,
    this.isActive = true,
  });

  factory ModelStatus.fromJson(Map<String, dynamic> json) {
    return ModelStatus(
      name: json['name'] as String? ?? '',
      status: json['status'] as String? ?? 'active',
      version: json['version'] as String?,
      lastUpdated: json['last_updated'] != null
          ? DateTime.tryParse(json['last_updated'] as String)
          : null,
      isActive: json['is_active'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'status': status,
      if (version != null) 'version': version,
      if (lastUpdated != null) 'last_updated': lastUpdated!.toIso8601String(),
      'is_active': isActive,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}
