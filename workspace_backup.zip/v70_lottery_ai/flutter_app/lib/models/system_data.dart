class SystemStatus {
  final String state;
  final String? version;
  final String? mode;
  final bool isBackendConnected;
  final DateTime? lastChecked;
  final String? error;

  SystemStatus({
    this.state = 'running',
    this.version,
    this.mode,
    this.isBackendConnected = false,
    this.lastChecked,
    this.error,
  });

  factory SystemStatus.fromJson(Map<String, dynamic> json) {
    return SystemStatus(
      state: (json['system_state'] ?? json['state'] ?? json['status'] ?? 'running') as String,
      version: json['version'] as String?,
      mode: json['mode'] as String?,
      isBackendConnected: json['is_backend_connected'] as bool? ?? false,
      lastChecked: json['last_checked'] != null
          ? DateTime.tryParse(json['last_checked'] as String)
          : null,
      error: json['error'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'state': state,
      if (version != null) 'version': version,
      if (mode != null) 'mode': mode,
      'is_backend_connected': isBackendConnected,
      if (lastChecked != null) 'last_checked': lastChecked!.toIso8601String(),
      if (error != null) 'error': error,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class SystemMetrics {
  final double cpuUsage;
  final double memoryUsage;
  final double diskUsage;
  final String? memoryUsed;
  final String? memoryTotal;
  final String? diskUsed;
  final String? diskTotal;

  SystemMetrics({
    this.cpuUsage = 0,
    this.memoryUsage = 0,
    this.diskUsage = 0,
    this.memoryUsed,
    this.memoryTotal,
    this.diskUsed,
    this.diskTotal,
  });

  factory SystemMetrics.fromJson(Map<String, dynamic> json) {
    return SystemMetrics(
      cpuUsage: (json['cpu_usage'] as num?)?.toDouble() ?? 0,
      memoryUsage: (json['memory_usage'] as num?)?.toDouble() ?? 0,
      diskUsage: (json['disk_usage'] as num?)?.toDouble() ?? 0,
      memoryUsed: json['memory_used'] as String?,
      memoryTotal: json['memory_total'] as String?,
      diskUsed: json['disk_used'] as String?,
      diskTotal: json['disk_total'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'cpu_usage': cpuUsage,
      'memory_usage': memoryUsage,
      'disk_usage': diskUsage,
      if (memoryUsed != null) 'memory_used': memoryUsed,
      if (memoryTotal != null) 'memory_total': memoryTotal,
      if (diskUsed != null) 'disk_used': diskUsed,
      if (diskTotal != null) 'disk_total': diskTotal,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}

class WorkflowStep {
  final String name;
  final String status;
  final String time;
  final String? detail;

  WorkflowStep({
    required this.name,
    required this.status,
    required this.time,
    this.detail,
  });

  factory WorkflowStep.fromJson(Map<String, dynamic> json) {
    return WorkflowStep(
      name: json['name'] as String? ?? '',
      status: json['status'] as String? ?? 'pending',
      time: json['time'] as String? ?? '-',
      detail: json['detail'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'status': status,
      'time': time,
      if (detail != null) 'detail': detail,
    };
  }
}

class ChangelogEntry {
  final String version;
  final String date;
  final String title;
  final List<String> changes;
  final String type;

  ChangelogEntry({
    required this.version,
    required this.date,
    required this.title,
    required this.changes,
    this.type = 'feature',
  });

  factory ChangelogEntry.fromJson(Map<String, dynamic> json) {
    return ChangelogEntry(
      version: json['version'] as String? ?? '',
      date: json['date'] as String? ?? '',
      title: json['title'] as String? ?? '',
      changes: (json['changes'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          [],
      type: json['type'] as String? ?? 'feature',
    );
  }

  Map<String, dynamic> toJson() => {
        'version': version,
        'date': date,
        'title': title,
        'changes': changes,
        'type': type,
      };
}

class VersionInfo {
  final String currentVersion;
  final String latestVersion;
  final bool hasUpdate;
  final bool updateAvailable;
  final String? updateUrl;
  final String? releaseDate;
  final List<ChangelogEntry> changelog;
  final String? checkTime;

  VersionInfo({
    required this.currentVersion,
    required this.latestVersion,
    required this.hasUpdate,
    required this.updateAvailable,
    this.updateUrl,
    this.releaseDate,
    required this.changelog,
    this.checkTime,
  });

  factory VersionInfo.fromJson(Map<String, dynamic> json) {
    return VersionInfo(
      currentVersion: json['current_version'] as String? ?? '1.0.0',
      latestVersion: json['latest_version'] as String? ?? '1.0.0',
      hasUpdate: json['has_update'] as bool? ?? false,
      updateAvailable: json['update_available'] as bool? ?? false,
      updateUrl: json['update_url'] as String?,
      releaseDate: json['release_date'] as String?,
      changelog: (json['changelog'] as List<dynamic>?)
              ?.map((e) => ChangelogEntry.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      checkTime: json['check_time'] as String?,
    );
  }

  factory VersionInfo.offline() {
    return VersionInfo(
      currentVersion: 'V72',
      latestVersion: 'V72',
      hasUpdate: false,
      updateAvailable: false,
      changelog: [
        ChangelogEntry(
          version: 'V72',
          date: '2026-07-10',
          title: '离线模式',
          changes: ['当前处于离线模式，无法获取更新信息'],
          type: 'info',
        ),
      ],
    );
  }

  Map<String, dynamic> toJson() => {
        'current_version': currentVersion,
        'latest_version': latestVersion,
        'has_update': hasUpdate,
        'update_available': updateAvailable,
        if (updateUrl != null) 'update_url': updateUrl,
        if (releaseDate != null) 'release_date': releaseDate,
        'changelog': changelog.map((e) => e.toJson()).toList(),
        if (checkTime != null) 'check_time': checkTime,
      };
}

class SystemConfig {
  final String appVersion;
  final String coreEngine;
  final String status;
  final String lotteryType;
  final String candidateStrategy;
  final String dailyUpdateTime;
  final String dataWindow;

  SystemConfig({
    this.appVersion = '',
    this.coreEngine = '',
    this.status = 'stable',
    this.lotteryType = 'ssq',
    this.candidateStrategy = '',
    this.dailyUpdateTime = '',
    this.dataWindow = '',
  });

  factory SystemConfig.fromJson(Map<String, dynamic> json) {
    return SystemConfig(
      appVersion: json['app_version'] as String? ?? '',
      coreEngine: json['core_engine'] as String? ?? '',
      status: json['status'] as String? ?? 'stable',
      lotteryType: json['lottery_type'] as String? ?? 'ssq',
      candidateStrategy: json['candidate_strategy'] as String? ?? '',
      dailyUpdateTime: json['daily_update_time'] as String? ?? '',
      dataWindow: json['data_window'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'app_version': appVersion,
      'core_engine': coreEngine,
      'status': status,
      'lottery_type': lotteryType,
      'candidate_strategy': candidateStrategy,
      'daily_update_time': dailyUpdateTime,
      'data_window': dataWindow,
    };
  }

  Map<String, dynamic> toMap() => toJson();
}
